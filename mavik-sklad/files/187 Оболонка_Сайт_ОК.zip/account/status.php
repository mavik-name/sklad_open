<?php
declare(strict_types=1);$config=require dirname(__DIR__).'/boss/config.php';$root=realpath((string)$config['site_root']);if(!$root){http_response_code(500);exit;}
require $root.'/_site-admin/auth.php';mavik_owner_session_start();header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store, private');header('X-Robots-Tag: noindex, nofollow, noarchive');
$o=mavik_owner_load($root);echo json_encode(['authenticated'=>mavik_owner_authed(),'owner_registered'=>mavik_owner_exists($root),'name'=>mavik_owner_authed()?(string)($_SESSION['mavik_owner_name']??($o['name']??'')):''],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);

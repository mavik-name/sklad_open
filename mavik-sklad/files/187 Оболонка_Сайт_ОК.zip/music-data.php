<?php
declare(strict_types=1);
require_once __DIR__.'/_site-admin/state.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, max-age=0');
header('X-Robots-Tag: noindex, nofollow');
$root=__DIR__;
function music_seed(string $root): array {
  $f=$root.'/assets/app/music-tracks.json';$raw=is_file($f)?file_get_contents($f):false;$j=$raw?json_decode($raw,true):null;
  $out=[];if(!is_array($j))return $out;
  foreach($j as $i=>$t){if(!is_array($t))continue;$src=(string)($t['src']??'');if($src==='')continue;
    $id='legacy-'.substr(sha1($src),0,14);
    $out[]=['id'=>$id,'title'=>(string)($t['title']??'Трек'),'artist'=>(string)($t['artist']??'MaVik_AI'),'album'=>(string)($t['album']??'Окремі треки'),'track'=>(int)($t['track']??($i+1)),'duration'=>(float)($t['duration']??0),'src'=>$src,'cover'=>(string)($t['cover']??'/assets/images/mavik-music.jpg'),'managed'=>false];
  }return $out;
}
function music_library(string $root): array {
  $f=mavik_state_seed($root,'music-library.json');$raw=is_file($f)?file_get_contents($f):false;$j=$raw?json_decode($raw,true):null;
  if(is_array($j)&&isset($j['tracks'])&&is_array($j['tracks'])){
    $j['collections']=isset($j['collections'])&&is_array($j['collections'])?$j['collections']:[];
    $j['book_collections']=isset($j['book_collections'])&&is_array($j['book_collections'])?$j['book_collections']:[];
    $j['external_recommendations']=isset($j['external_recommendations'])&&is_array($j['external_recommendations'])?$j['external_recommendations']:[];
    return $j;
  }
  return ['version'=>1,'updated_at'=>null,'tracks'=>music_seed($root),'collections'=>[],'book_collections'=>[],'external_recommendations'=>[]];
}
$lib=music_library($root);$tracks=array_values(array_filter($lib['tracks']??[],'is_array'));
$byId=[];foreach($tracks as $t){$id=(string)($t['id']??'');if($id!=='')$byId[$id]=$t;}
$collections=[];foreach(($lib['collections']??[]) as $c){if(!is_array($c))continue;$ids=[];foreach((array)($c['tracks']??[]) as $id)if(isset($byId[(string)$id]))$ids[]=(string)$id;$collections[]=['id'=>(string)($c['id']??''),'name'=>(string)($c['name']??'Збірка'),'description'=>(string)($c['description']??''),'cover'=>(string)($c['cover']??'/assets/images/mavik-music.jpg'),'count'=>count($ids),'tracks'=>$ids];}
$selected='all';$book=preg_replace('/[^a-z0-9-]/','',(string)($_GET['book']??''))??'';$requested=preg_replace('/[^a-z0-9-]/','',(string)($_GET['collection']??''))??'';
if($book!=='' && isset($lib['book_collections'][$book]))$selected=(string)$lib['book_collections'][$book];
elseif($requested!=='')$selected=$requested;
$selectedCollection=null;$selectedTracks=$tracks;
if($selected!=='all'){
  foreach($collections as $c)if($c['id']===$selected){$selectedCollection=$c;$selectedTracks=[];foreach($c['tracks'] as $id)if(isset($byId[$id]))$selectedTracks[]=$byId[$id];break;}
  if($selectedCollection===null){$selected='all';$selectedTracks=$tracks;}
}
foreach($selectedTracks as &$t){unset($t['managed']);}unset($t);
$recs=[];if($book!==''&&isset($lib['external_recommendations'][$book])&&is_array($lib['external_recommendations'][$book])){foreach($lib['external_recommendations'][$book] as $r)if(is_array($r))$recs[]=['id'=>(string)($r['id']??''),'title'=>(string)($r['title']??''),'source'=>(string)($r['source']??''),'note'=>(string)($r['note']??''),'url'=>(string)($r['url']??''),'provider'=>(string)($r['provider']??'link')];}
$out=['version'=>1,'updated_at'=>$lib['updated_at']??null,'selected'=>$selected,'collection'=>$selectedCollection,'collections'=>array_map(function($c){unset($c['tracks']);return $c;},$collections),'tracks'=>array_values($selectedTracks),'recommendations'=>$recs,'total_tracks'=>count($tracks)];
echo json_encode($out,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);

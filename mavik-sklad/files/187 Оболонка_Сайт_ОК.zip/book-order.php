<?php
declare(strict_types=1);
require_once __DIR__.'/_site-admin/state.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Robots-Tag: noindex, nofollow, noarchive');
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
    http_response_code(405);
    echo json_encode(['order'=>[]]);
    exit;
}
$file=mavik_state_seed(__DIR__,'book-order.json');
$raw=is_file($file)?file_get_contents($file):false;
$data=$raw!==false?json_decode($raw,true):null;
$order=is_array($data)&&isset($data['order'])&&is_array($data['order'])?$data['order']:[];
$order=array_values(array_filter(array_map(static function($slug){
    $slug=(string)$slug;
    return preg_match('/^[a-z0-9-]+$/',$slug)?$slug:'';
},$order)));
echo json_encode(['order'=>$order],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);

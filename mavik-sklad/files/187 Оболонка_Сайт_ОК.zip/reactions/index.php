<?php
declare(strict_types=1);

date_default_timezone_set('Europe/Kyiv');
header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store, max-age=0');
header('X-Robots-Tag: noindex, nofollow', true);
header('X-Content-Type-Options: nosniff');

$config = require __DIR__ . '/config.php';
$root = realpath(dirname(__DIR__));
if (!$root) {
    http_response_code(500);
    echo json_encode(['ok'=>false,'error'=>'site_root']);
    exit;
}

function out(array $data, int $status = 200): never {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function clean_slug(mixed $v): string {
    $s = strtolower(trim((string)$v));
    return preg_match('/^[a-z0-9-]{1,100}$/', $s) ? $s : '';
}

function clean_type(mixed $v): string {
    $s = strtolower(trim((string)$v));
    return in_array($s, ['book','blog'], true) ? $s : '';
}

function valid_item(string $root, string $type, string $slug): bool {
    $file = $root . ($type === 'book' ? '/books/' : '/blog/') . $slug . '/index.html';
    if (!is_file($file)) return false;
    $html = @file_get_contents($file, false, null, 0, 200000);
    if (!is_string($html)) return false;
    if ($type === 'book') return str_contains($html, 'class="book"') || str_contains($html, "class='book'");
    return str_contains($html, 'class="article-body"') || str_contains($html, "class='article-body'");
}

function public_state(int $count): array {
    if ($count < 5) return ['tier'=>'quiet','proof'=>''];
    if ($count < 20) return ['tier'=>'warm','proof'=>'Подобається читачам'];
    if ($count < 50) return ['tier'=>'20','proof'=>'20+ читачів'];
    if ($count < 100) return ['tier'=>'50','proof'=>'50+ читачів'];

    $n10 = $count % 10;
    $n100 = $count % 100;
    $word = ($n10 === 1 && $n100 !== 11) ? 'читач' : (($n10 >= 2 && $n10 <= 4 && !($n100 >= 12 && $n100 <= 14)) ? 'читачі' : 'читачів');
    return ['tier'=>'exact','proof'=>$count . ' ' . $word];
}

function normalize_store(mixed $j): array {
    if (!is_array($j)) $j = [];
    if (!isset($j['items']) || !is_array($j['items'])) $j['items'] = [];
    if (!isset($j['log']) || !is_array($j['log'])) $j['log'] = [];
    $j['version'] = 1;
    return $j;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') out(['ok'=>false,'error'=>'method'], 405);

$fetchSite = strtolower((string)($_SERVER['HTTP_SEC_FETCH_SITE'] ?? ''));
if ($fetchSite === 'cross-site') out(['ok'=>false,'error'=>'origin'], 403);
$origin = (string)($_SERVER['HTTP_ORIGIN'] ?? '');
if ($origin !== '') {
    $host = strtolower((string)(parse_url($origin, PHP_URL_HOST) ?? ''));
    if (!in_array($host, ['mavik.name','www.mavik.name','localhost','127.0.0.1'], true)) out(['ok'=>false,'error'=>'origin'], 403);
}

$len = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
if ($len < 1 || $len > 4096) out(['ok'=>false,'error'=>'body'], 400);
$raw = file_get_contents('php://input');
$payload = is_string($raw) ? json_decode($raw, true) : null;
if (!is_array($payload)) out(['ok'=>false,'error'=>'json'], 400);

$op = (string)($payload['op'] ?? 'status');
if (!in_array($op, ['status','toggle'], true)) out(['ok'=>false,'error'=>'op'], 400);
$type = clean_type($payload['type'] ?? '');
$slug = clean_slug($payload['slug'] ?? '');
$rid = strtolower(trim((string)($payload['rid'] ?? '')));
if ($type === '' || $slug === '' || !preg_match('/^[a-f0-9]{32,64}$/', $rid)) out(['ok'=>false,'error'=>'input'], 400);
if (!valid_item($root, $type, $slug)) out(['ok'=>false,'error'=>'item'], 404);

$key = $type . ':' . $slug;
$voter = hash_hmac('sha256', $rid, (string)$config['hmac_secret']);
$dataFile = (string)$config['data_file'];
$dir = dirname($dataFile);
if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) out(['ok'=>false,'error'=>'storage'], 503);

$fh = @fopen($dataFile, 'c+');
if (!$fh || !flock($fh, LOCK_EX)) {
    if (is_resource($fh)) fclose($fh);
    out(['ok'=>false,'error'=>'storage'], 503);
}
$existing = stream_get_contents($fh);
$data = normalize_store($existing ? json_decode($existing, true) : null);
$item = $data['items'][$key] ?? ['type'=>$type,'slug'=>$slug,'voters'=>[],'likes_all_time'=>0,'unlikes_all_time'=>0,'last_action'=>null];
if (!isset($item['voters']) || !is_array($item['voters'])) $item['voters'] = [];
$liked = isset($item['voters'][$voter]);

if ($op === 'toggle') {
    $now = date(DATE_ATOM);
    if ($liked) {
        unset($item['voters'][$voter]);
        $item['unlikes_all_time'] = (int)($item['unlikes_all_time'] ?? 0) + 1;
        $action = 'unlike';
        $liked = false;
    } else {
        $item['voters'][$voter] = ['liked_at'=>$now];
        $item['likes_all_time'] = (int)($item['likes_all_time'] ?? 0) + 1;
        $action = 'like';
        $liked = true;
    }
    $item['last_action'] = $now;
    $item['count'] = count($item['voters']);
    $data['items'][$key] = $item;
    $data['updated_at'] = $now;
    $data['log'][] = ['at'=>$now,'type'=>$type,'slug'=>$slug,'action'=>$action,'voter'=>substr($voter,0,12)];
    $limit = max(50, (int)($config['log_limit'] ?? 500));
    if (count($data['log']) > $limit) $data['log'] = array_slice($data['log'], -$limit);

    rewind($fh);
    ftruncate($fh, 0);
    fwrite($fh, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    fflush($fh);
}

$count = count($item['voters']);
$public = public_state($count);
flock($fh, LOCK_UN);
fclose($fh);

out(['ok'=>true,'liked'=>$liked,'tier'=>$public['tier'],'proof'=>$public['proof']]);

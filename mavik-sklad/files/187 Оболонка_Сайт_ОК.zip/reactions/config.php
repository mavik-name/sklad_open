<?php
return [
  'data_file' => __DIR__ . '/data/reactions.json',
  // Server-side HMAC secret. It never leaves PHP; the public endpoint stores only hashes of anonymous browser IDs.
  'hmac_secret' => '8a7a3525f7ea8f1111f915b8b0f0f8c489cf2af14494c0a67c2a7a1217319c15',
  'log_limit' => 500,
];

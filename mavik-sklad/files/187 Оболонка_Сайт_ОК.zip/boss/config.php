<?php
return [
  'password_hash' => '$2y$12$4X1G2cOlsrBVKws/IKxryez.tj4LEFgimSO0KtXnk.SH5nLheDtau',
  'site_root' => dirname(__DIR__),
  'manifest' => dirname(__DIR__) . '/_site-state/boss-content.json',
  'manifest_seed' => dirname(__DIR__) . '/_site-admin/state-defaults/boss-content.json',
  'templates' => dirname(__DIR__) . '/_site-admin/boss-templates',
  'email' => 'viktor@mavik.name',
];

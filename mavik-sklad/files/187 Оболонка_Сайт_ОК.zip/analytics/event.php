<?php
declare(strict_types=1);

date_default_timezone_set('Europe/Kyiv');
require_once dirname(__DIR__) . '/_site-admin/utf8.php';
ignore_user_abort(true);

const COLLECTOR_KEY = '47cb7a2a1e39ea4b2fb4e80c25923196';
const MAX_BODY_BYTES = 8192;

header('Cache-Control: no-store, max-age=0');
header('X-Robots-Tag: noindex, nofollow', true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit;
}

$len = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
if ($len > MAX_BODY_BYTES) {
    http_response_code(413);
    exit;
}

$fetchSite = strtolower((string)($_SERVER['HTTP_SEC_FETCH_SITE'] ?? ''));
if ($fetchSite === 'cross-site') {
    http_response_code(403);
    exit;
}

$origin = (string)($_SERVER['HTTP_ORIGIN'] ?? '');
if ($origin !== '') {
    $host = strtolower((string)(parse_url($origin, PHP_URL_HOST) ?? ''));
    $allowed = ['mavik.name', 'www.mavik.name', '127.0.0.1', 'localhost'];
    if (!in_array($host, $allowed, true)) {
        http_response_code(403);
        exit;
    }
}

$raw = file_get_contents('php://input');
if (!is_string($raw) || $raw === '' || strlen($raw) > MAX_BODY_BYTES) {
    http_response_code(400);
    exit;
}

$payload = json_decode($raw, true);
if (!is_array($payload) || !hash_equals(COLLECTOR_KEY, (string)($payload['key'] ?? ''))) {
    http_response_code(403);
    exit;
}

function clean_text(mixed $v, int $max = 160): string {
    $s = trim((string)$v);
    $s = preg_replace('/[\x00-\x1F\x7F]/u', '', $s) ?? '';
    return mavik_utf8_substr($s, 0, $max);
}
function inc(array &$a, string $k, int $by = 1): void {
    if ($k === '') return;
    $a[$k] = (int)($a[$k] ?? 0) + $by;
}

function inc_nested(array &$a, string $k1, string $k2, int $by = 1): void {
    if ($k1 === '' || $k2 === '') return;
    if (!isset($a[$k1]) || !is_array($a[$k1])) $a[$k1] = [];
    $a[$k1][$k2] = (int)($a[$k1][$k2] ?? 0) + $by;
}

$event = clean_text($payload['event'] ?? '', 64);
if (!preg_match('/^[a-z0-9_\-]{1,64}$/', $event)) {
    http_response_code(400);
    exit;
}

$path = clean_text($payload['path'] ?? '/', 240);
if ($path === '' || $path[0] !== '/') $path = '/';

$meta = is_array($payload['meta'] ?? null) ? $payload['meta'] : [];
$value = $payload['value'] ?? null;
$valueNum = is_numeric($value) ? (float)$value : null;

$section = clean_text($meta['section'] ?? '', 40);
$book = clean_text($meta['book'] ?? '', 100);
$article = clean_text($meta['article'] ?? '', 120);
$track = clean_text($meta['track'] ?? '', 160);
$album = clean_text($meta['album'] ?? '', 120);
$domain = clean_text($meta['domain'] ?? '', 120);
$device = clean_text($meta['device'] ?? '', 20);
$mode = clean_text($meta['mode'] ?? '', 20);
$referrer = clean_text($meta['referrer'] ?? '', 120);
$utmSource = clean_text($meta['utm_source'] ?? '', 80);
$utmMedium = clean_text($meta['utm_medium'] ?? '', 80);
$utmCampaign = clean_text($meta['utm_campaign'] ?? '', 100);
$label = clean_text($meta['label'] ?? '', 160);
$scroll = isset($meta['scroll']) && is_numeric($meta['scroll']) ? max(0, min(100, (int)$meta['scroll'])) : null;

$day = date('Y-m-d');
$now = date('c');
$file = __DIR__ . '/data/' . $day . '.json';

$fh = @fopen($file, 'c+');
if (!$fh) {
    http_response_code(503);
    exit;
}
if (!flock($fh, LOCK_EX)) {
    fclose($fh);
    http_response_code(503);
    exit;
}

$existing = stream_get_contents($fh);
$data = $existing ? json_decode($existing, true) : null;
if (!is_array($data)) {
    $data = [
        'date' => $day,
        'last_event' => $now,
        'events' => [],
        'pages' => [],
        'sections' => [],
        'devices' => [],
        'modes' => [],
        'referrers' => [],
        'campaigns' => [],
        'books' => [],
        'articles' => [],
        'tracks' => [],
        'external' => [],
        'labels' => [],
        'progress' => [],
        'scroll' => [],
        'value_sums' => [],
        'value_counts' => [],
    ];
}

$data['last_event'] = $now;
inc($data['events'], $event);

if (!isset($data['pages'][$path]) || !is_array($data['pages'][$path])) $data['pages'][$path] = [];
inc($data['pages'][$path], $event);

if ($event === 'page_view') {
    if ($section !== '') inc($data['sections'], $section);
    if ($device !== '') inc($data['devices'], $device);
    if ($mode !== '') inc($data['modes'], $mode);
    inc($data['referrers'], $referrer !== '' ? $referrer : 'direct');
    if ($utmSource !== '') {
        $campaignKey = $utmSource;
        if ($utmMedium !== '') $campaignKey .= ' / ' . $utmMedium;
        if ($utmCampaign !== '') $campaignKey .= ' / ' . $utmCampaign;
        inc($data['campaigns'], $campaignKey);
    }
}


if ($book !== '') {
    if (!isset($data['books'][$book]) || !is_array($data['books'][$book])) $data['books'][$book] = [];
    inc($data['books'][$book], $event);
}
if ($article !== '') {
    if (!isset($data['articles'][$article]) || !is_array($data['articles'][$article])) $data['articles'][$article] = [];
    inc($data['articles'][$article], $event);
}
if ($track !== '') {
    if (!isset($data['tracks'][$track]) || !is_array($data['tracks'][$track])) $data['tracks'][$track] = [];
    inc($data['tracks'][$track], $event);
    if ($album !== '') $data['tracks'][$track]['_album'] = $album;
}
if ($domain !== '') inc($data['external'], $domain);
if ($label !== '') inc_nested($data['labels'], $event, $label);

if ($event === 'reader_progress' && $book !== '' && $valueNum !== null) {
    $bucket = (string)(int)$valueNum;
    if (in_array($bucket, ['25','50','75','100'], true)) {
        if (!isset($data['progress'][$book]) || !is_array($data['progress'][$book])) $data['progress'][$book] = [];
        inc($data['progress'][$book], $bucket);
    }
}

if ($event === 'page_summary' && $valueNum !== null) {
    $seconds = max(0, min(3600, (int)$valueNum));
    $data['value_sums']['page_summary'] = (int)($data['value_sums']['page_summary'] ?? 0) + $seconds;
    $data['value_counts']['page_summary'] = (int)($data['value_counts']['page_summary'] ?? 0) + 1;
    if ($scroll !== null) {
        $bucket = $scroll >= 100 ? '100' : ($scroll >= 75 ? '75+' : ($scroll >= 50 ? '50+' : ($scroll >= 25 ? '25+' : '<25')));
        inc($data['scroll'], $bucket);
    }
}

rewind($fh);
ftruncate($fh, 0);
fwrite($fh, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
fflush($fh);
flock($fh, LOCK_UN);
fclose($fh);

http_response_code(204);

<?php
declare(strict_types=1);

function mavik_reader_plain_text(string $html): string {
  $html=preg_replace('~<(h[1-6]|p|li|blockquote|br|div|section|article)[^>]*>~iu', "\n", $html) ?? $html;
  $html=preg_replace('~</(h[1-6]|p|li|blockquote|div|section|article)>~iu', "\n\n", $html) ?? $html;
  $text=html_entity_decode(strip_tags($html),ENT_QUOTES|ENT_HTML5,'UTF-8');
  $text=str_replace(["\r\n","\r"],"\n",$text);
  $text=preg_replace('/[ \t]+/u',' ',$text) ?? $text;
  $text=preg_replace('/\n[ \t]+/u',"\n",$text) ?? $text;
  $text=preg_replace('/\n{3,}/u',"\n\n",$text) ?? $text;
  return trim($text)."\n";
}

function mavik_reader_split_text(string $text,int $limit=48000): array {
  $paras=preg_split('/\n{2,}/u',$text,-1,PREG_SPLIT_NO_EMPTY) ?: [];
  $parts=[];$cur='';
  foreach($paras as $p){
    $piece=trim($p)."\n\n";
    if($cur!=='' && strlen($cur.$piece)>$limit){$parts[]=rtrim($cur)."\n";$cur='';}
    if(strlen($piece)>$limit){
      $words=preg_split('/\s+/u',trim($piece),-1,PREG_SPLIT_NO_EMPTY) ?: [];
      $frag='';
      foreach($words as $w){
        $candidate=$frag.($frag===''?'':' ').$w;
        if($frag!=='' && strlen($candidate)>$limit){$parts[]=$frag."\n";$frag=$w;}else{$frag=$candidate;}
      }
      if($frag!=='')$cur=$frag."\n\n";
    }else{$cur.=$piece;}
  }
  if(trim($cur)!=='')$parts[]=rtrim($cur)."\n";
  return $parts;
}


function mavik_reader_text_publish(string $root,string $slug,string $title,string $bodyHtml,string $statusLabel='',bool $continuation=false): void {
  if(!preg_match('/^[a-z0-9-]+$/',$slug))throw new RuntimeException('Некоректний slug текстової версії.');
  $dir=rtrim($root,'/').'/books/'.$slug.'/read/text';
  if(!is_dir($dir)&&!mkdir($dir,0755,true)&&!is_dir($dir))throw new RuntimeException('Не вдалося створити текстову версію.');
  $plain=mavik_reader_plain_text($bodyHtml);
  if($continuation)$plain=rtrim($plain)."\n\nДАЛІ БУДЕ…\n";
  $base='https://mavik.name/books/'.$slug.'/';
  $statusLine=$statusLabel!==''?'Статус: '.$statusLabel."\n":'';
  $header=$title."\nМакарчук Віктор · MaVik\n".$statusLine."Картка книги: ".$base."\nВеб-читанка: ".$base."read/\nТекстовий вхід: ".$base."read/text/\n".str_repeat('=',72)."\n\n";
  file_put_contents($dir.'/full.txt',$header.$plain,LOCK_EX);
  foreach(glob($dir.'/part-*.txt')?:[] as $old)@unlink($old);
  $parts=mavik_reader_split_text($plain);
  $manifest=["# ".$title,"","AUTHOR: Макарчук Віктор · MaVik"];if($statusLabel!=='')$manifest[]="STATUS: ".$statusLabel;$manifest=array_merge($manifest,["BOOK: ".$base,"READER: ".$base."read/","FULL_TEXT: ".$base."read/text/full.txt","","PARTS:"]);
  foreach($parts as $i=>$part){
    $name='part-'.str_pad((string)($i+1),3,'0',STR_PAD_LEFT).'.txt';
    file_put_contents($dir.'/'.$name,$header.$part,LOCK_EX);
    $manifest[]=$base.'read/text/'.$name;
  }
  $manifest[]='';
  file_put_contents($dir.'/index.txt',implode("\n",$manifest),LOCK_EX);

  $items='';
  foreach($parts as $i=>$part){$n=$i+1;$name='part-'.str_pad((string)$n,3,'0',STR_PAD_LEFT).'.txt';$items.='<li><a href="'.$name.'">Частина '.$n.'</a></li>';}
  $safe=htmlspecialchars($title,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');
  $statusHtml=$statusLabel!==''?'<p class="meta">Статус: '.htmlspecialchars($statusLabel,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8').'</p>':'';
  $index='<!doctype html><html lang="uk"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,follow"><title>'.$safe.' — спрощена текстова версія | MaVik</title><link rel="alternate" type="text/plain" href="full.txt" title="Повний текст TXT"><style>body{max-width:820px;margin:40px auto;padding:0 18px;background:#111;color:#eee;font:18px/1.6 Georgia,serif}a{color:#d9bd86}.meta{color:#aaa;font:14px/1.5 Arial,sans-serif}li{margin:.45rem 0}</style></head><body><h1>'.$safe.'</h1><p class="meta">Макарчук Віктор · MaVik</p>'.$statusHtml.'<nav><a href="../">← Веб-читанка</a> · <a href="../../">Картка книги</a> · <a href="full.txt">Повний TXT</a></nav><p>Спрощена версія без оформлення і JavaScript. Повний текст поділено на невеликі частини.</p><ol>'.$items.'</ol></body></html>';
  file_put_contents($dir.'/index.html',$index,LOCK_EX);


  $ht="Options -Indexes\nDirectoryIndex index.html index.txt\nAddDefaultCharset UTF-8\n\n<IfModule mod_mime.c>\n  AddType text/plain .txt\n</IfModule>\n\n<IfModule mod_headers.c>\n  Header always set X-Robots-Tag \"noindex, follow\"\n  Header always set X-Content-Type-Options \"nosniff\"\n  Header always set Cache-Control \"public, max-age=300, stale-while-revalidate=86400\"\n  Header always set Access-Control-Allow-Origin \"*\"\n</IfModule>\n";
  file_put_contents($dir.'/.htaccess',$ht,LOCK_EX);
}

function mavik_reader_rebuild_llms(string $root): void {
  $root=rtrim($root,'/');
  $lines=[
    '# MaVik — авторський сайт Віктора Макарчука',
    '',
    '> Українські книги, веб-читанки, блог і музика. Публічний контент доступний без авторизації.',
    '',
    '## Основні сторінки',
    '- https://mavik.name/',
    '- https://mavik.name/books/',
    '- https://mavik.name/blog/',
    '- https://mavik.name/music/',
    '- https://mavik.name/about/',
    '',
    '## Книги та машинно-дружні текстові версії'
  ];
  $files=glob($root.'/books/*/read/index.html') ?: [];
  sort($files,SORT_NATURAL|SORT_FLAG_CASE);
  foreach($files as $reader){
    $slug=basename(dirname(dirname($reader)));
    if(!is_file($root.'/books/'.$slug.'/read/text/index.html'))continue;
    $raw=file_get_contents($reader) ?: '';
    $title=$slug;
    if(preg_match('~<(?:section|div)[^>]*class="[^"]*book-hero[^"]*"[^>]*>.*?<h1[^>]*>(.*?)</h1>~isu',$raw,$m)){
      $title=trim(html_entity_decode(preg_replace('~<[^>]+>~',' ',$m[1])??$m[1],ENT_QUOTES|ENT_HTML5,'UTF-8'));$title=preg_replace('/\s+/u',' ',$title)??$title;
    }
    $base='https://mavik.name/books/'.$slug.'/';
    $lines[]='- '.$title;
    $lines[]='  - Картка: '.$base;
    $lines[]='  - Веб-читанка: '.$base.'read/';
    $lines[]='  - Легка текстова версія: '.$base.'read/text/';
    $lines[]='  - Повний TXT: '.$base.'read/text/full.txt';
  }
  $lines[]='';
  file_put_contents($root.'/llms.txt',implode("\n",$lines),LOCK_EX);
}

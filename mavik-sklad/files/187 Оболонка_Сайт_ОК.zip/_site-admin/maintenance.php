<?php
declare(strict_types=1);

const MAVIK_MAINTENANCE_PREVIEW_COOKIE = 'mavik_maintenance_preview';
const MAVIK_MAINTENANCE_PREVIEW_TOKEN = 'b00163085f65597875d41ebe7d92bcb1114bd82dbaa7e99b';

function mavik_maintenance_flag(string $root): string { return rtrim($root,'/').'/.maintenance-on'; }
function mavik_maintenance_active(string $root): bool { return is_file(mavik_maintenance_flag($root)); }
function mavik_maintenance_preview_cookie(bool $enable=true): void {
  $secure=!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off';
  if($enable){
    setcookie(MAVIK_MAINTENANCE_PREVIEW_COOKIE,MAVIK_MAINTENANCE_PREVIEW_TOKEN,[
      'expires'=>time()+86400*30,'path'=>'/','secure'=>$secure,'httponly'=>true,'samesite'=>'Strict'
    ]);
    $_COOKIE[MAVIK_MAINTENANCE_PREVIEW_COOKIE]=MAVIK_MAINTENANCE_PREVIEW_TOKEN;
  }else{
    setcookie(MAVIK_MAINTENANCE_PREVIEW_COOKIE,'',['expires'=>time()-3600,'path'=>'/','secure'=>$secure,'httponly'=>true,'samesite'=>'Strict']);
    unset($_COOKIE[MAVIK_MAINTENANCE_PREVIEW_COOKIE]);
  }
}
function mavik_maintenance_enable(string $root): void {
  $f=mavik_maintenance_flag($root);
  if(file_put_contents($f,"MaVik maintenance mode\n",LOCK_EX)===false) throw new RuntimeException('Не вдалося увімкнути технічну перерву.');
  @chmod($f,0644);mavik_maintenance_preview_cookie(true);
}
function mavik_maintenance_disable(string $root): void {
  $f=mavik_maintenance_flag($root);if(is_file($f)&&!@unlink($f)) throw new RuntimeException('Не вдалося вимкнути технічну перерву.');
  mavik_maintenance_preview_cookie(false);
}

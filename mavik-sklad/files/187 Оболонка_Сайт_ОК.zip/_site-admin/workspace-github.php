<?php
declare(strict_types=1);

function mavik_workspace_github_config_file(string $root): string { return mavik_state_path($root,'workspace-github.json'); }
function mavik_workspace_github_defaults(): array { return ['enabled'=>true,'owner'=>'mavik-name','repo'=>'sklad_open','branch'=>'main','prefix'=>'mavik-sklad','token'=>'']; }
function mavik_workspace_github_load(string $root): array {
  $cfg=mavik_workspace_github_defaults(); $f=mavik_workspace_github_config_file($root);
  if(is_file($f)){ $j=json_decode((string)@file_get_contents($f),true); if(is_array($j)&&!empty($j['token']))$cfg['token']=(string)$j['token']; }
  return $cfg;
}
function mavik_workspace_github_save_token(string $root,string $token): array {
  $cfg=mavik_workspace_github_defaults(); $token=trim($token); if($token==='')throw new RuntimeException('Вкажіть GitHub token.');
  $cfg['token']=$token; $cfg['updated_at']=date(DATE_ATOM); mavik_workspace_atomic_json(mavik_workspace_github_config_file($root),$cfg); @chmod(mavik_workspace_github_config_file($root),0600); return $cfg;
}
function mavik_workspace_github_ready(array $cfg): bool { return trim((string)$cfg['token'])!==''; }
function mavik_workspace_github_api_path(string $path): string { return implode('/',array_map('rawurlencode',explode('/',trim($path,'/')))); }
function mavik_workspace_github_request(array $cfg,string $method,string $endpoint,?array $body=null): array {
  if(!mavik_workspace_github_ready($cfg))throw new RuntimeException('GitHub token ще не збережено.');
  $url='https://api.github.com'.$endpoint; $headers=['Accept: application/vnd.github+json','Authorization: Bearer '.trim((string)$cfg['token']),'X-GitHub-Api-Version: 2022-11-28','User-Agent: MaVik-Boss/1.0'];
  $payload=$body===null?null:json_encode($body,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); if($payload===false)throw new RuntimeException('Не вдалося сформувати GitHub-запит.'); if($payload!==null)$headers[]='Content-Type: application/json';
  if(function_exists('curl_init')){ $ch=curl_init($url); curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>$method,CURLOPT_HTTPHEADER=>$headers,CURLOPT_TIMEOUT=>45,CURLOPT_CONNECTTIMEOUT=>10]); if($payload!==null)curl_setopt($ch,CURLOPT_POSTFIELDS,$payload); $raw=curl_exec($ch);$err=curl_error($ch);$status=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);curl_close($ch); if($raw===false)throw new RuntimeException('GitHub недоступний: '.$err); }
  else { $ctx=stream_context_create(['http'=>['method'=>$method,'header'=>implode("\r\n",$headers),'content'=>$payload??'','ignore_errors'=>true,'timeout'=>45]]); $raw=@file_get_contents($url,false,$ctx);$status=0;foreach(($http_response_header??[]) as $h)if(preg_match('#^HTTP/\\S+\\s+(\\d+)#',$h,$m))$status=(int)$m[1]; if($raw===false&&$status===0)throw new RuntimeException('GitHub недоступний з цього хостингу.'); }
  $data=is_string($raw)&&$raw!==''?json_decode($raw,true):null; if($status<200||$status>=300){$msg=is_array($data)?trim((string)($data['message']??'')):'';throw new RuntimeException('GitHub API: '.($msg?:'HTTP '.$status).' ('.$status.').');} return is_array($data)?$data:[];
}
function mavik_workspace_github_base_path(array $cfg): string { return trim((string)$cfg['prefix'],'/'); }
function mavik_workspace_github_repo_url(array $cfg): string { return 'https://github.com/mavik-name/sklad_open/tree/main/mavik-sklad'; }
function mavik_workspace_github_raw_url(array $cfg,string $path): string { return 'https://raw.githubusercontent.com/mavik-name/sklad_open/main/'.implode('/',array_map('rawurlencode',explode('/',trim($path,'/')))); }
function mavik_workspace_github_existing_sha(array $cfg,string $path): ?string { $ep='/repos/mavik-name/sklad_open/contents/'.mavik_workspace_github_api_path($path).'?ref=main'; try{$j=mavik_workspace_github_request($cfg,'GET',$ep);return isset($j['sha'])?(string)$j['sha']:null;}catch(RuntimeException $e){if(str_contains($e->getMessage(),'(404)'))return null;throw $e;} }
function mavik_workspace_github_list_files(string $root): array {
  $cfg=mavik_workspace_github_load($root); if(!mavik_workspace_github_ready($cfg))return [];
  $ep='/repos/mavik-name/sklad_open/contents/mavik-sklad/files?ref=main'; try{$j=mavik_workspace_github_request($cfg,'GET',$ep);}catch(RuntimeException $e){if(str_contains($e->getMessage(),'(404)'))return [];throw $e;}
  if(!array_is_list($j))return []; $out=[]; foreach($j as $x){if(!is_array($x)||($x['type']??'')!=='file')continue; $out[]=['name'=>(string)($x['name']??''),'path'=>(string)($x['path']??''),'sha'=>(string)($x['sha']??''),'size'=>(int)($x['size']??0),'html_url'=>(string)($x['html_url']??''),'download_url'=>(string)($x['download_url']??'')];} usort($out,fn($a,$b)=>strnatcasecmp($a['name'],$b['name'])); return $out;
}
function mavik_workspace_github_safe_filename(string $name): string { $name=trim(basename(str_replace('\\','/',$name))); if($name===''||$name==='.'||$name==='..')throw new RuntimeException('Некоректна назва файла.'); if(preg_match('/\\.(php[0-9]?|phtml|phar|cgi|pl|py|sh|js)$/i',$name))throw new RuntimeException('Цей тип файла не дозволений.'); return $name; }
function mavik_workspace_github_upload(string $root,array $file): string {
  if(empty($file['tmp_name'])||!is_uploaded_file((string)$file['tmp_name']))throw new RuntimeException('Оберіть файл.'); if((int)($file['error']??UPLOAD_ERR_OK)!==UPLOAD_ERR_OK)throw new RuntimeException('Помилка завантаження файла.'); if((int)($file['size']??0)>100*1024*1024)throw new RuntimeException('Файл має бути до 100 МБ.');
  $cfg=mavik_workspace_github_load($root); if(!mavik_workspace_github_ready($cfg))throw new RuntimeException('Спочатку один раз збережіть GitHub token.'); $name=mavik_workspace_github_safe_filename((string)($file['name']??'')); $bytes=@file_get_contents((string)$file['tmp_name']); if(!is_string($bytes))throw new RuntimeException('Не вдалося прочитати файл.'); $path='mavik-sklad/files/'.$name; $sha=mavik_workspace_github_existing_sha($cfg,$path); $body=['message'=>'MaVik: upload '.$name,'content'=>base64_encode($bytes),'branch'=>'main'];if($sha!==null)$body['sha']=$sha; mavik_workspace_github_request($cfg,'PUT','/repos/mavik-name/sklad_open/contents/'.mavik_workspace_github_api_path($path),$body); return $name;
}
function mavik_workspace_github_delete(string $root,string $path,string $sha=''): void { $cfg=mavik_workspace_github_load($root); if(!str_starts_with($path,'mavik-sklad/files/')||str_contains($path,'..'))throw new RuntimeException('Некоректний шлях файла.'); if($sha==='')$sha=mavik_workspace_github_existing_sha($cfg,$path)??''; if($sha==='')return; mavik_workspace_github_request($cfg,'DELETE','/repos/mavik-name/sklad_open/contents/'.mavik_workspace_github_api_path($path),['message'=>'MaVik: delete '.basename($path),'sha'=>$sha,'branch'=>'main']); }
function mavik_workspace_human_bytes(int $bytes): string { if($bytes<1024)return $bytes.' Б'; if($bytes<1048576)return number_format($bytes/1024,1,',',' ').' КБ'; return number_format($bytes/1048576,1,',',' ').' МБ'; }

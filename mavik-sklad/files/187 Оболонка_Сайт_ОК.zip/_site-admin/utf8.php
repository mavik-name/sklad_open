<?php
declare(strict_types=1);

/** Lightweight UTF-8 helpers that do not require ext-mbstring. */
function mavik_utf8_lower(string $s): string {
  if (function_exists('mb_strtolower')) return mb_strtolower($s, 'UTF-8');
  static $map = [
    'А'=>'а','Б'=>'б','В'=>'в','Г'=>'г','Ґ'=>'ґ','Д'=>'д','Е'=>'е','Є'=>'є','Ж'=>'ж','З'=>'з','И'=>'и','І'=>'і','Ї'=>'ї','Й'=>'й','К'=>'к','Л'=>'л','М'=>'м','Н'=>'н','О'=>'о','П'=>'п','Р'=>'р','С'=>'с','Т'=>'т','У'=>'у','Ф'=>'ф','Х'=>'х','Ц'=>'ц','Ч'=>'ч','Ш'=>'ш','Щ'=>'щ','Ь'=>'ь','Ю'=>'ю','Я'=>'я',
    'Ё'=>'ё','Ъ'=>'ъ','Ы'=>'ы','Э'=>'э',
  ];
  return strtolower(strtr($s, $map));
}

function mavik_utf8_strlen(string $s): int {
  if (function_exists('mb_strlen')) return mb_strlen($s, 'UTF-8');
  if ($s === '') return 0;
  $n = preg_match_all('/./us', $s, $m);
  return $n === false ? strlen($s) : $n;
}

function mavik_utf8_substr(string $s, int $start, ?int $length = null): string {
  if (function_exists('mb_substr')) return $length === null ? mb_substr($s, $start, null, 'UTF-8') : mb_substr($s, $start, $length, 'UTF-8');
  if ($s === '') return '';
  $chars = preg_split('//u', $s, -1, PREG_SPLIT_NO_EMPTY);
  if (!is_array($chars)) return $length === null ? substr($s, $start) : substr($s, $start, $length);
  $slice = $length === null ? array_slice($chars, $start) : array_slice($chars, $start, $length);
  return implode('', $slice);
}

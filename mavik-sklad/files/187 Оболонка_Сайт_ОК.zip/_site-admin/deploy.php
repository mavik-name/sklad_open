<?php
declare(strict_types=1);

/*
 * MaVik release deployer.
 * Accepts only full MaVik release ZIPs, stages them under protected _site-state,
 * creates a pre-deploy backup, preserves runtime data, and removes the uploaded
 * release archive only after a successful deployment.
 */

function mavik_deploy_supported(): bool {
  return class_exists('ZipArchive') || class_exists('PharData');
}

function mavik_deploy_state_dir(string $root): string {
  $dir=rtrim($root,'/').'/_site-state/deploy';
  if(!is_dir($dir)&&!mkdir($dir,0700,true)&&!is_dir($dir))throw new RuntimeException('Не вдалося створити захищений каталог оновлень.');
  @chmod($dir,0700);
  $guard=dirname($dir).'/.htaccess';
  if(!is_file($guard)){
    @file_put_contents($guard,"Options -Indexes\n<IfModule mod_authz_core.c>\n  Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n  Deny from all\n</IfModule>\n",LOCK_EX);
  }
  return $dir;
}

function mavik_deploy_backup_dir(string $root): string {
  $dir=rtrim($root,'/').'/_site-state/backups';
  if(!is_dir($dir)&&!mkdir($dir,0700,true)&&!is_dir($dir))throw new RuntimeException('Не вдалося створити каталог резервних копій.');
  @chmod($dir,0700);
  return $dir;
}

function mavik_deploy_norm(string $path): string {
  if($path===''||str_contains($path,"\0")||str_contains($path,'\\')||str_starts_with($path,'/')||preg_match('/^[A-Za-z]:/',$path))throw new RuntimeException('Архів містить небезпечний шлях.');
  $path=rtrim($path,'/');
  if($path==='')return '';
  $parts=explode('/',$path);
  foreach($parts as $p)if($p===''||$p==='.'||$p==='..')throw new RuntimeException('Архів містить небезпечний шлях.');
  if(strlen($path)>700)throw new RuntimeException('Архів містить надто довгий шлях.');
  return implode('/',$parts);
}

function mavik_deploy_protected(string $rel): bool {
  $rel=ltrim($rel,'/');
  return $rel==='_site-state'||str_starts_with($rel,'_site-state/')
    ||$rel==='analytics/data'||str_starts_with($rel,'analytics/data/')
    ||$rel==='reactions/data'||str_starts_with($rel,'reactions/data/');
}

function mavik_deploy_entries(string $zipPath): array {
  $out=[];
  if(class_exists('ZipArchive')){
    $z=new ZipArchive();
    if($z->open($zipPath)!==true)throw new RuntimeException('Не вдалося відкрити ZIP.');
    try{
      for($i=0;$i<$z->numFiles;$i++){
        $name=(string)$z->getNameIndex($i);
        $isDir=str_ends_with($name,'/');
        $rel=mavik_deploy_norm($name);
        if($rel==='')continue;
        if(method_exists($z,'getExternalAttributesIndex')){
          $opsys=0;$attr=0;
          if($z->getExternalAttributesIndex($i,$opsys,$attr)){
            $mode=($attr>>16)&0170000;
            if($mode===0120000)throw new RuntimeException('Символічні посилання в ZIP не дозволені.');
          }
        }
        $stat=$z->statIndex($i);
        $out[]=['path'=>$rel,'dir'=>$isDir,'size'=>(int)($stat['size']??0)];
      }
    }finally{$z->close();}
    return $out;
  }
  if(!class_exists('PharData'))throw new RuntimeException('На сервері немає підтримки ZIP.');
  try{
    $p=new PharData($zipPath);
    $prefix='phar://'.str_replace('\\','/',$zipPath).'/';
    $it=new RecursiveIteratorIterator($p,RecursiveIteratorIterator::SELF_FIRST);
    foreach($it as $file){
      $full=str_replace('\\','/',$file->getPathName());
      $name=str_starts_with($full,$prefix)?substr($full,strlen($prefix)):basename($full);
      $rel=mavik_deploy_norm($name);
      if($rel==='')continue;
      if(method_exists($file,'isLink')&&$file->isLink())throw new RuntimeException('Символічні посилання в ZIP не дозволені.');
      $out[]=['path'=>$rel,'dir'=>$file->isDir(),'size'=>$file->isFile()?(int)$file->getSize():0];
    }
  }catch(Throwable $e){throw new RuntimeException('Не вдалося прочитати ZIP: '.$e->getMessage());}
  return $out;
}

function mavik_deploy_extract(string $zipPath,string $stage): void {
  if(is_dir($stage))mavik_deploy_rm_tree($stage);
  if(!mkdir($stage,0700,true)&&!is_dir($stage))throw new RuntimeException('Не вдалося створити тимчасову папку.');
  if(class_exists('ZipArchive')){
    $z=new ZipArchive();
    if($z->open($zipPath)!==true)throw new RuntimeException('Не вдалося відкрити ZIP.');
    try{if(!$z->extractTo($stage))throw new RuntimeException('Не вдалося розпакувати ZIP.');}
    finally{$z->close();}
    return;
  }
  try{$p=new PharData($zipPath);$p->extractTo($stage,null,true);}
  catch(Throwable $e){throw new RuntimeException('Не вдалося розпакувати ZIP: '.$e->getMessage());}
}

function mavik_deploy_rm_tree(string $path): void {
  if(!file_exists($path)&&!is_link($path))return;
  if(is_file($path)||is_link($path)){@unlink($path);return;}
  $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);
  foreach($it as $f){$p=$f->getPathname();if($f->isDir()&&!$f->isLink())@rmdir($p);else @unlink($p);}
  @rmdir($path);
}

function mavik_deploy_manifest(string $base): array {
  $f=rtrim($base,'/').'/.mavik-release.json';
  if(!is_file($f))throw new RuntimeException('Це не повна збірка MaVik: немає .mavik-release.json.');
  $raw=file_get_contents($f);$j=$raw!==false?json_decode($raw,true):null;
  if(!is_array($j)||($j['schema']??null)!==1||empty($j['release'])||!is_array($j['managed_files']??null))throw new RuntimeException('Некоректний маніфест збірки.');
  $managed=[];
  foreach($j['managed_files'] as $rel){
    if(!is_string($rel)||$rel==='')continue;
    $n=mavik_deploy_norm($rel);
    if($n!==''&&!mavik_deploy_protected($n)){
      if(!is_file(rtrim($base,'/').'/'.$n))throw new RuntimeException('Маніфест посилається на відсутній файл: '.$n);
      $managed[$n]=1;
    }
  }
  $j['managed_files']=array_keys($managed);
  return $j;
}

function mavik_deploy_validate(string $zipPath): array {
  if(!mavik_deploy_supported())throw new RuntimeException('На сервері немає PHP-підтримки ZIP/Phar.');
  $entries=mavik_deploy_entries($zipPath);
  if(!$entries)throw new RuntimeException('ZIP порожній.');
  if(count($entries)>12000)throw new RuntimeException('У ZIP забагато файлів.');
  $total=0;$seen=[];
  foreach($entries as $e){
    $rel=(string)$e['path'];
    if(isset($seen[$rel]))throw new RuntimeException('У ZIP дублюється шлях: '.$rel);
    $seen[$rel]=1;
    $total+=(int)$e['size'];
    if($total>2*1024*1024*1024)throw new RuntimeException('Розпакований ZIP завеликий.');
  }
  foreach(['index.html','boss/index.php','_site-admin/state.php','robots.txt','sitemap.xml','.mavik-release.json'] as $required)
    if(!isset($seen[$required]))throw new RuntimeException('У збірці бракує обов’язкового файла: '.$required);
  return ['entries'=>$entries,'unpacked_bytes'=>$total];
}

function mavik_deploy_copy_file(string $src,string $dest): void {
  $dir=dirname($dest);
  if(!is_dir($dir)&&!mkdir($dir,0755,true)&&!is_dir($dir))throw new RuntimeException('Не вдалося створити '.$dir);
  $tmp=$dest.'.deploy-'.bin2hex(random_bytes(4));
  if(!copy($src,$tmp)){@unlink($tmp);throw new RuntimeException('Не вдалося записати '.basename($dest));}
  @chmod($tmp,fileperms($src)&0777 ?: 0644);
  if(!rename($tmp,$dest)){@unlink($tmp);throw new RuntimeException('Не вдалося замінити '.basename($dest));}
  if(function_exists('opcache_invalidate')&&str_ends_with(strtolower($dest),'.php'))@opcache_invalidate($dest,true);
}

function mavik_deploy_copy_tree(string $from,string $root,array $managedOnly=[]): int {
  $count=0;$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($from,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::SELF_FIRST);
  foreach($it as $f){
    $abs=$f->getPathname();$rel=str_replace('\\','/',substr($abs,strlen(rtrim($from,DIRECTORY_SEPARATOR))+1));
    $rel=mavik_deploy_norm($rel);if($rel===''||mavik_deploy_protected($rel))continue;
    if($f->isDir()){if(!is_dir($root.'/'.$rel))@mkdir($root.'/'.$rel,0755,true);continue;}
    if($managedOnly&&!isset($managedOnly[$rel]))continue;
    mavik_deploy_copy_file($abs,$root.'/'.$rel);$count++;
  }
  return $count;
}

function mavik_deploy_remove_obsolete(string $root,array $oldManaged,array $newManaged): int {
  $removed=0;
  foreach($oldManaged as $rel){
    if(isset($newManaged[$rel])||mavik_deploy_protected($rel))continue;
    $p=$root.'/'.$rel;
    if(is_file($p)||is_link($p)){if(@unlink($p))$removed++;}
  }
  /* One obsolete helper existed before release manifests were introduced. */
  $legacy=$root.'/_site-admin/local-files.php';
  if(is_file($legacy)&&!isset($newManaged['_site-admin/local-files.php'])){@unlink($legacy);}
  return $removed;
}

function mavik_deploy_add_to_zip($zip,string $file,string $rel): void {
  if($zip instanceof ZipArchive){
    if(!$zip->addFile($file,$rel))throw new RuntimeException('Не вдалося додати файл у резервну копію.');
  }else{
    $zip->addFile($file,$rel);
  }
}

function mavik_deploy_backup(string $root,string $release): string {
  $dir=mavik_deploy_backup_dir($root);
  $safe=preg_replace('/[^A-Za-z0-9._-]+/','-',trim($release))?:'release';
  $path=$dir.'/before-'.$safe.'-'.date('Ymd-His').'.zip';
  try{
    if(class_exists('ZipArchive')){
      $z=new ZipArchive();
      if($z->open($path,ZipArchive::CREATE|ZipArchive::OVERWRITE)!==true)throw new RuntimeException('Не вдалося створити резервну ZIP-копію.');
      $zip=$z;
    }else{$zip=new PharData($path,0,null,Phar::ZIP);}
    $base=rtrim($root,DIRECTORY_SEPARATOR);$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($base,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::LEAVES_ONLY);
    foreach($it as $f){
      if(!$f->isFile()||$f->isLink())continue;
      $abs=$f->getPathname();$rel=str_replace('\\','/',substr($abs,strlen($base)+1));
      if(str_starts_with($rel,'_site-state/backups/')||str_starts_with($rel,'_site-state/deploy/'))continue;
      mavik_deploy_add_to_zip($zip,$abs,$rel);
    }
    if($zip instanceof ZipArchive){$zip->close();}else{unset($zip);}
  }catch(Throwable $e){@unlink($path);throw new RuntimeException('Резервну копію не створено: '.$e->getMessage());}
  if(!is_file($path)||filesize($path)<100)throw new RuntimeException('Резервна копія не створилася.');
  mavik_deploy_prune_backups($root,3);
  return $path;
}

function mavik_deploy_prune_backups(string $root,int $keep=3): void {
  $files=glob(mavik_deploy_backup_dir($root).'/*.zip')?:[];
  usort($files,fn($a,$b)=>filemtime($b)<=>filemtime($a));
  foreach(array_slice($files,$keep) as $f)@unlink($f);
}

function mavik_deploy_backups(string $root): array {
  $files=glob(mavik_deploy_backup_dir($root).'/*.zip')?:[];
  usort($files,fn($a,$b)=>filemtime($b)<=>filemtime($a));$out=[];
  foreach($files as $f)$out[]=['name'=>basename($f),'size'=>(int)filesize($f),'mtime'=>(int)filemtime($f)];
  return $out;
}

function mavik_deploy_failed_archives(string $root): array {
  $files=glob(mavik_deploy_state_dir($root).'/failed-*.zip')?:[];
  usort($files,fn($a,$b)=>filemtime($b)<=>filemtime($a));$out=[];
  foreach($files as $f)$out[]=['name'=>basename($f),'size'=>(int)filesize($f),'mtime'=>(int)filemtime($f)];
  return $out;
}

function mavik_deploy_delete_failed(string $root,string $name): void {
  if(!preg_match('/^failed-[A-Za-z0-9._-]+\.zip$/',$name))throw new RuntimeException('Некоректне ім’я архіву.');
  $p=mavik_deploy_state_dir($root).'/'.$name;
  if(!is_file($p)||!@unlink($p))throw new RuntimeException('Не вдалося видалити архів.');
}

function mavik_deploy_log(string $root,array $row): void {
  $f=mavik_deploy_state_dir($root).'/history.json';
  $raw=is_file($f)?file_get_contents($f):false;$j=$raw?json_decode($raw,true):null;
  if(!is_array($j))$j=[];$j[]=$row;$j=array_slice($j,-30);
  @file_put_contents($f,json_encode($j,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES),LOCK_EX);
}

function mavik_deploy_restore_backup(string $root,string $backup,array $newManaged): void {
  $stage=mavik_deploy_state_dir($root).'/rollback-'.bin2hex(random_bytes(5));
  try{
    mavik_deploy_entries($backup); /* validate paths before extraction */
    mavik_deploy_extract($backup,$stage);
    foreach(array_keys($newManaged) as $rel){if(!mavik_deploy_protected($rel)&&is_file($root.'/'.$rel))@unlink($root.'/'.$rel);}
    mavik_deploy_copy_tree($stage,$root);
  }finally{mavik_deploy_rm_tree($stage);}
}

function mavik_deploy_archive(string $root,string $zipPath,string $originalName='release.zip'): array {
  @set_time_limit(0);@ignore_user_abort(true);
  $check=mavik_deploy_validate($zipPath);
  $state=mavik_deploy_state_dir($root);$id=date('Ymd-His').'-'.bin2hex(random_bytes(4));
  $stage=$state.'/stage-'.$id;$backup='';$newManaged=[];$release='?';
  try{
    mavik_deploy_extract($zipPath,$stage);
    $manifest=mavik_deploy_manifest($stage);$release=(string)$manifest['release'];
    $newManaged=array_fill_keys($manifest['managed_files'],1);
    foreach(['index.html','boss/index.php','_site-admin/deploy.php'] as $required)
      if(!isset($newManaged[$required])||!is_file($stage.'/'.$required))throw new RuntimeException('Маніфест не охоплює обов’язковий файл: '.$required);
    $oldManaged=[];
    $currentManifest=$root.'/.mavik-release.json';
    if(is_file($currentManifest)){
      $raw=file_get_contents($currentManifest);$old=$raw!==false?json_decode($raw,true):null;
      if(is_array($old)&&is_array($old['managed_files']??null))foreach($old['managed_files'] as $r){try{$n=mavik_deploy_norm((string)$r);if($n!==''&&!mavik_deploy_protected($n))$oldManaged[]=$n;}catch(Throwable $e){}}
    }
    $backup=mavik_deploy_backup($root,$release);
    $removed=mavik_deploy_remove_obsolete($root,$oldManaged,$newManaged);
    $copied=mavik_deploy_copy_tree($stage,$root,$newManaged);
    foreach(['index.html','boss/index.php','robots.txt','sitemap.xml','.mavik-release.json'] as $f)if(!is_file($root.'/'.$f)||filesize($root.'/'.$f)<1)throw new RuntimeException('Контроль після розгортання не пройдено: '.$f);
    mavik_deploy_log($root,['at'=>date(DATE_ATOM),'status'=>'success','release'=>$release,'archive'=>$originalName,'copied'=>$copied,'removed'=>$removed,'backup'=>basename($backup)]);
    mavik_deploy_rm_tree($stage);
    return ['release'=>$release,'copied'=>$copied,'removed'=>$removed,'backup'=>basename($backup),'unpacked_bytes'=>(int)$check['unpacked_bytes']];
  }catch(Throwable $e){
    $rollback='';
    if($backup!==''&&is_file($backup)){
      try{mavik_deploy_restore_backup($root,$backup,$newManaged);$rollback=' Попередню версію автоматично відновлено.';}
      catch(Throwable $r){$rollback=' Автовідновлення не вдалося: '.$r->getMessage();}
    }
    mavik_deploy_rm_tree($stage);
    mavik_deploy_log($root,['at'=>date(DATE_ATOM),'status'=>'failed','release'=>$release,'archive'=>$originalName,'error'=>$e->getMessage(),'backup'=>$backup?basename($backup):null]);
    throw new RuntimeException($e->getMessage().$rollback);
  }
}

function mavik_deploy_from_upload(string $root,array $file): array {
  if(!mavik_deploy_supported())throw new RuntimeException('На сервері немає PHP-підтримки ZIP/Phar.');
  $err=(int)($file['error']??UPLOAD_ERR_NO_FILE);
  if($err!==UPLOAD_ERR_OK)throw new RuntimeException('Не вдалося отримати ZIP (код '.$err.').');
  $tmp=(string)($file['tmp_name']??'');$name=(string)($file['name']??'');
  if($tmp===''||!is_uploaded_file($tmp))throw new RuntimeException('Оберіть ZIP-збірку.');
  if(strtolower(pathinfo($name,PATHINFO_EXTENSION))!=='zip')throw new RuntimeException('Потрібен файл .zip.');
  $size=(int)($file['size']??0);if($size<1000)throw new RuntimeException('ZIP виглядає порожнім.');
  if($size>350*1024*1024)throw new RuntimeException('ZIP має бути до 350 МБ.');
  $state=mavik_deploy_state_dir($root);$safe=preg_replace('/[^A-Za-z0-9._-]+/','-',pathinfo($name,PATHINFO_FILENAME))?:'release';
  $saved=$state.'/failed-'.date('Ymd-His').'-'.$safe.'.zip';
  if(!move_uploaded_file($tmp,$saved))throw new RuntimeException('Не вдалося перенести ZIP у захищену папку.');
  try{
    $result=mavik_deploy_archive($root,$saved,$name);
    /* User requirement: release archive is deleted only after successful deploy. */
    if(!@unlink($saved))$result['archive_cleanup_warning']='Збірку розгорнуто, але ZIP не вдалося видалити автоматично.';
    return $result;
  }catch(Throwable $e){
    throw new RuntimeException($e->getMessage().' Архів залишено у захищеній папці Boss для діагностики.');
  }
}

function mavik_deploy_ini_limit(): string {
  return 'upload_max_filesize='.ini_get('upload_max_filesize').' · post_max_size='.ini_get('post_max_size');
}

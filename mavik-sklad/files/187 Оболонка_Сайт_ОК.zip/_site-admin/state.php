<?php
declare(strict_types=1);

function mavik_state_dir(string $root): string {
  $dir=rtrim($root,'/').'/_site-state';
  if(!is_dir($dir)){
    if(!mkdir($dir,0755,true)&&!is_dir($dir)) throw new RuntimeException('Не вдалося створити каталог стану сайту.');
    @chmod($dir,0750);
  }
  $guard=$dir.'/.htaccess';
  if(!is_file($guard)) @file_put_contents($guard,"Options -Indexes\n<IfModule mod_authz_core.c>\n  Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n  Deny from all\n</IfModule>\n");
  return $dir;
}

function mavik_state_path(string $root,string $name): string {
  if(!preg_match('/^[a-z0-9][a-z0-9._-]*$/i',$name)) throw new InvalidArgumentException('Некоректне ім’я файла стану.');
  return mavik_state_dir($root).'/'.$name;
}

function mavik_state_seed(string $root,string $name): string {
  $dest=mavik_state_path($root,$name);
  if(is_file($dest)) return $dest;
  $src=rtrim($root,'/').'/_site-admin/state-defaults/'.$name;
  if(is_file($src)){
    $raw=file_get_contents($src);
    if($raw!==false){
      $tmp=$dest.'.tmp-'.bin2hex(random_bytes(3));
      if(file_put_contents($tmp,$raw,LOCK_EX)!==false&&rename($tmp,$dest)){@chmod($dest,0640);return $dest;}
      @unlink($tmp);
    }
  }
  return $dest;
}

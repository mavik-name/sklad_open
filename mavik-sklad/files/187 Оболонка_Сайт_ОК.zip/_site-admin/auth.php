<?php
declare(strict_types=1);
require_once __DIR__.'/state.php';
require_once __DIR__.'/utf8.php';
require_once __DIR__.'/maintenance.php';

function mavik_owner_session_start(): void {
  if (session_status() === PHP_SESSION_ACTIVE) return;
  session_name('mavik_owner');
  session_set_cookie_params([
    'lifetime'=>0,
    'path'=>'/',
    'secure'=>(!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
    'httponly'=>true,
    'samesite'=>'Strict'
  ]);
  session_start();
  if(!empty($_SESSION['mavik_owner_auth'])) mavik_maintenance_preview_cookie(true);
}
function mavik_owner_file(string $root): string { return mavik_state_seed($root,'owner.json'); }
function mavik_owner_load(string $root): ?array {
  $f=mavik_owner_file($root); if(!is_file($f)) return null;
  $raw=file_get_contents($f); if($raw===false) return null;
  $j=json_decode($raw,true); return is_array($j)?$j:null;
}
function mavik_owner_exists(string $root): bool { $x=mavik_owner_load($root); return is_array($x)&&!empty($x['password_hash'])&&!empty($x['email']); }
function mavik_owner_authed(): bool { return !empty($_SESSION['mavik_owner_auth']); }
function mavik_owner_csrf(): string {
  if(empty($_SESSION['mavik_owner_csrf'])) $_SESSION['mavik_owner_csrf']=bin2hex(random_bytes(24));
  return (string)$_SESSION['mavik_owner_csrf'];
}
function mavik_owner_csrf_ok(string $v): bool { return isset($_SESSION['mavik_owner_csrf'])&&hash_equals((string)$_SESSION['mavik_owner_csrf'],$v); }
function mavik_owner_atomic_write(string $file,string $data): void {
  $dir=dirname($file); if(!is_dir($dir)&&!mkdir($dir,0755,true)&&!is_dir($dir)) throw new RuntimeException('Не вдалося створити каталог власника.');
  $tmp=$file.'.tmp-'.bin2hex(random_bytes(4));
  if(file_put_contents($tmp,$data,LOCK_EX)===false) throw new RuntimeException('Не вдалося записати обліковий запис.');
  @chmod($tmp,0600);
  if(!rename($tmp,$file)){@unlink($tmp);throw new RuntimeException('Не вдалося зберегти обліковий запис.');}
  @chmod($file,0600);
}
function mavik_owner_register(string $root,string $name,string $email,string $password): void {
  if(mavik_owner_exists($root)) throw new RuntimeException('Власник сайту вже зареєстрований.');
  $email=mavik_utf8_lower(trim($email));
  if(!filter_var($email,FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Вкажіть коректну email-адресу.');
  if(mavik_utf8_strlen($password)<12) throw new RuntimeException('Пароль має містити щонайменше 12 символів.');
  $data=['version'=>1,'role'=>'owner','name'=>trim($name)?:'Власник MaVik','email'=>$email,'password_hash'=>password_hash($password,PASSWORD_DEFAULT),'created_at'=>date(DATE_ATOM),'updated_at'=>date(DATE_ATOM)];
  mavik_owner_atomic_write(mavik_owner_file($root),json_encode($data,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
}
function mavik_owner_login(string $root,string $email,string $password): bool {
  $o=mavik_owner_load($root); if(!$o) return false;
  $email=mavik_utf8_lower(trim($email));
  if(!hash_equals(mavik_utf8_lower((string)($o['email']??'')),$email)) return false;
  if(!password_verify($password,(string)($o['password_hash']??''))) return false;
  session_regenerate_id(true); $_SESSION['mavik_owner_auth']=1; $_SESSION['mavik_owner_email']=$email; $_SESSION['mavik_owner_name']=(string)($o['name']??'Власник MaVik');
  $_SESSION['mavik_boss_auth']=1; $_SESSION['mavik_stats_auth']=1;
  mavik_maintenance_preview_cookie(true);
  return true;
}
function mavik_owner_logout(): void {
  mavik_maintenance_preview_cookie(false);
  $_SESSION=[];
  if(ini_get('session.use_cookies')){$p=session_get_cookie_params();setcookie(session_name(),'',time()-42000,$p['path'],$p['domain']??'',(bool)$p['secure'],(bool)$p['httponly']);}
  session_destroy();
}
function mavik_safe_next(string $v,string $fallback='/'): string {
  $v=trim($v); if($v===''||$v[0]!=='/'||str_starts_with($v,'//')||str_contains($v,"\r")||str_contains($v,"\n")) return $fallback;
  return $v;
}

<?php
declare(strict_types=1);
require_once __DIR__.'/state.php';
require_once __DIR__.'/utf8.php';
function mavik_reader_errors_file(string $root): string { return mavik_state_path($root,'reader-errors.json'); }
function mavik_reader_error_rate_file(string $root): string { return mavik_state_path($root,'reader-errors-rate.json'); }
function mavik_reader_errors_load(string $root): array {
  $f=mavik_reader_errors_file($root);$raw=is_file($f)?file_get_contents($f):false;$j=$raw?json_decode($raw,true):null;
  if(!is_array($j))$j=['version'=>1,'items'=>[]];if(!isset($j['items'])||!is_array($j['items']))$j['items']=[];return $j;
}
function mavik_reader_errors_save(string $root,array $data): void {
  $data['version']=1;$dir=dirname(mavik_reader_errors_file($root));if(!is_dir($dir)&&!mkdir($dir,0755,true)&&!is_dir($dir))throw new RuntimeException('Не вдалося створити журнал помилок.');$f=mavik_reader_errors_file($root);$tmp=$f.'.tmp-'.bin2hex(random_bytes(4));if(file_put_contents($tmp,json_encode($data,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES),LOCK_EX)===false)throw new RuntimeException('Не вдалося записати повідомлення.');@chmod($tmp,0600);if(!rename($tmp,$f)){@unlink($tmp);throw new RuntimeException('Не вдалося оновити журнал помилок.');}@chmod($f,0600);
}
function mavik_reader_error_trim(string $v,int $max): string {$v=trim(preg_replace('/\s+/u',' ',$v)??$v);return mavik_utf8_substr($v,0,$max);}
function mavik_reader_error_title(string $root,string $slug): string {
  $f=rtrim($root,'/').'/books/'.$slug.'/index.html';if(!is_file($f))return $slug;$s=file_get_contents($f)?:'';if(preg_match('~<h1[^>]*>(.*?)</h1>~isu',$s,$m))return mavik_reader_error_trim(html_entity_decode(strip_tags($m[1]),ENT_QUOTES|ENT_HTML5,'UTF-8'),180);return $slug;
}
function mavik_reader_error_rate_key(string $root): string {
  $ip=(string)($_SERVER['REMOTE_ADDR']??'unknown');$saltFile=mavik_state_path($root,'reader-error-salt.txt');if(!is_file($saltFile)){@file_put_contents($saltFile,bin2hex(random_bytes(24)),LOCK_EX);@chmod($saltFile,0600);}$salt=trim((string)@file_get_contents($saltFile));return hash_hmac('sha256',$ip,$salt?:'mavik-reader-errors');
}
function mavik_reader_error_allow(string $root): bool {
  $today=date('Y-m-d');$key=mavik_reader_error_rate_key($root);$f=mavik_reader_error_rate_file($root);$raw=is_file($f)?file_get_contents($f):false;$j=$raw?json_decode($raw,true):null;if(!is_array($j)||($j['date']??'')!==$today)$j=['date'=>$today,'items'=>[]];$n=(int)($j['items'][$key]??0);if($n>=12)return false;$j['items'][$key]=$n+1;$tmp=$f.'.tmp-'.bin2hex(random_bytes(3));file_put_contents($tmp,json_encode($j,JSON_UNESCAPED_SLASHES),LOCK_EX);@chmod($tmp,0600);rename($tmp,$f);@chmod($f,0600);return true;
}
function mavik_reader_error_add(string $root,array $p): array {
  $slug=preg_replace('/[^a-z0-9-]/','',(string)($p['book']??''))??'';if($slug===''||!is_file(rtrim($root,'/').'/books/'.$slug.'/read/index.html'))throw new RuntimeException('Книгу не знайдено.');
  if(trim((string)($p['website']??''))!=='')throw new RuntimeException('Повідомлення не прийнято.');$ts=(int)($p['ts']??0);if($ts>0&&((int)floor(microtime(true)*1000)-$ts)<2500)throw new RuntimeException('Спробуйте ще раз за кілька секунд.');if(!mavik_reader_error_allow($root))throw new RuntimeException('Забагато повідомлень. Спробуйте пізніше.');
  $fragment=mavik_reader_error_trim((string)($p['fragment']??''),1000);$note=mavik_reader_error_trim((string)($p['note']??''),1000);if($fragment===''&&$note==='')throw new RuntimeException('Виділіть фрагмент або опишіть помилку.');$path=(string)($p['url']??'');if(!preg_match('#^/books/'.preg_quote($slug,'#').'/read/?#',$path))$path='/books/'.$slug.'/read/';
  $item=['id'=>'err-'.bin2hex(random_bytes(8)),'created_at'=>date(DATE_ATOM),'status'=>'new','book'=>$slug,'title'=>mavik_reader_error_title($root,$slug),'url'=>$path,'section'=>mavik_reader_error_trim((string)($p['section']??''),240),'fragment'=>$fragment,'note'=>$note,'contact'=>mavik_reader_error_trim((string)($p['contact']??''),200),'ip_hash'=>substr(mavik_reader_error_rate_key($root),0,20)];
  $data=mavik_reader_errors_load($root);$data['items'][]=$item;if(count($data['items'])>3000)$data['items']=array_slice($data['items'],-3000);mavik_reader_errors_save($root,$data);return $item;
}
function mavik_reader_error_set_status(string $root,string $id,string $status): void {
  $allowed=['new','in_progress','fixed','rejected'];if(!in_array($status,$allowed,true))throw new RuntimeException('Некоректний статус.');$data=mavik_reader_errors_load($root);$found=false;foreach($data['items'] as &$x){if(!is_array($x)||(string)($x['id']??'')!==$id)continue;$x['status']=$status;$x['updated_at']=date(DATE_ATOM);$found=true;break;}unset($x);if(!$found)throw new RuntimeException('Повідомлення не знайдено.');mavik_reader_errors_save($root,$data);
}

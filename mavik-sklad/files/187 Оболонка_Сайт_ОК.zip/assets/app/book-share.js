(()=>{
  'use strict';
  const m=location.pathname.match(/^\/books\/([^/]+)\/?$/);
  if(!m)return;
  const slug=m[1], book=document.querySelector('.book');
  if(!book||book.querySelector('.book-share-center'))return;
  const info=book.children[1]||book, actions=info.querySelector('.actions');
  if(!actions)return;
  const wrap=document.createElement('div');wrap.className='book-share-center';
  const share=document.createElement('button');share.type='button';share.className='book-share-btn';share.title='Поділитися книгою';share.setAttribute('aria-label','Поділитися книгою');
  share.innerHTML='<svg aria-hidden="true" viewBox="0 0 24 24"><circle cx="18" cy="5" r="2.5"></circle><circle cx="6" cy="12" r="2.5"></circle><circle cx="18" cy="19" r="2.5"></circle><path d="m8.2 10.9 7.6-4.6M8.2 13.1l7.6 4.6"></path></svg>';
  wrap.appendChild(share);
  const reaction=info.querySelector('.mavik-reaction');
  if(reaction)reaction.insertAdjacentElement('beforebegin',wrap);else actions.insertAdjacentElement('afterend',wrap);
  const url=location.origin+'/books/'+slug+'/';
  const title=(document.querySelector('.book h1')?.textContent||document.title||'Книга').trim();
  share.onclick=async()=>{try{
    if(navigator.share){await navigator.share({title,text:`«${title}» — Віктор Макарчук (MaVik)`,url});return;}
    if(navigator.clipboard&&window.isSecureContext){await navigator.clipboard.writeText(url);share.classList.add('is-done');setTimeout(()=>share.classList.remove('is-done'),1300);return;}
    window.prompt('Скопіюйте посилання на книгу:',url);
  }catch(e){}};
})();

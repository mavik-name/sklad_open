(() => {
  const path = location.pathname.replace(/\/+/g, '/');
  const parts = path.split('/').filter(Boolean);
  let type = '', slug = '';

  if (parts[0] === 'books' && parts.length === 2 && parts[1]) {
    type = 'book'; slug = parts[1];
  } else if (parts[0] === 'blog' && parts.length === 2 && parts[1]) {
    type = 'blog'; slug = parts[1];
  } else {
    return;
  }

  const root = document.createElement('div');
  root.className = 'mavik-reaction';
  root.setAttribute('data-reaction-type', type);
  root.setAttribute('data-reaction-slug', slug);
  root.innerHTML = '<button class="mavik-reaction-btn" type="button" aria-pressed="false"><span class="mavik-reaction-heart" aria-hidden="true">♡</span><span class="mavik-reaction-label">Сподобалось</span></button><span class="mavik-reaction-proof" aria-live="polite"></span>';

  const target = type === 'book' ? document.querySelector('.book .actions') : document.querySelector('.article-body');
  if (!target) return;
  if (type === 'book') {
    target.insertAdjacentElement('afterend', root);
  } else {
    const before = target.querySelector('.article-share-bottom, .article-nav');
    if (before) target.insertBefore(root, before); else target.appendChild(root);
  }

  const btn = root.querySelector('.mavik-reaction-btn');
  const heart = root.querySelector('.mavik-reaction-heart');
  const label = root.querySelector('.mavik-reaction-label');
  const proof = root.querySelector('.mavik-reaction-proof');

  const randomId = () => {
    try {
      const b = new Uint8Array(24); crypto.getRandomValues(b);
      return [...b].map(x => x.toString(16).padStart(2,'0')).join('');
    } catch(e) {
      return (Math.random().toString(16).slice(2) + Date.now().toString(16)).padEnd(32,'0').slice(0,48);
    }
  };

  const reactionId = () => {
    try {
      let id = localStorage.getItem('mavik-reaction-id');
      if (!id || !/^[a-f0-9]{32,64}$/i.test(id)) {
        id = randomId(); localStorage.setItem('mavik-reaction-id', id);
      }
      return id;
    } catch(e) {
      let id = '';
      try { id = sessionStorage.getItem('mavik-reaction-id') || ''; } catch(e2) {}
      if (!/^[a-f0-9]{32,64}$/i.test(id)) id = randomId();
      try { sessionStorage.setItem('mavik-reaction-id', id); } catch(e2) {}
      return id;
    }
  };

  const rid = reactionId();
  let liked = false;

  const paint = state => {
    liked = !!state.liked;
    root.classList.toggle('is-liked', liked);
    btn.setAttribute('aria-pressed', liked ? 'true' : 'false');
    heart.textContent = liked ? '♥' : '♡';
    label.textContent = liked ? 'Вам сподобалось' : 'Сподобалось';
    proof.textContent = state.proof || '';
    proof.classList.remove('mavik-reaction-error');
  };

  const request = async op => {
    const res = await fetch('/reactions/', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      credentials: 'same-origin',
      cache: 'no-store',
      body: JSON.stringify({op, type, slug, rid})
    });
    if (!res.ok) throw new Error('reaction_http_' + res.status);
    const data = await res.json();
    if (!data || data.ok !== true) throw new Error('reaction_payload');
    return data;
  };

  const fail = () => {
    proof.textContent = 'Реакція тимчасово недоступна';
    proof.classList.add('mavik-reaction-error');
  };

  btn.disabled = true;
  request('status').then(paint).catch(fail).finally(() => { btn.disabled = false; });

  btn.addEventListener('click', async () => {
    if (btn.disabled) return;
    btn.disabled = true;
    const wasLiked = liked;
    try {
      const state = await request('toggle');
      paint(state);
      if (window.MaVikAnalytics && typeof window.MaVikAnalytics.track === 'function') {
        window.MaVikAnalytics.track(state.liked ? 'reaction_like' : 'reaction_unlike', {label:type + ':' + slug});
      }
    } catch(e) {
      liked = wasLiked;
      fail();
    } finally {
      btn.disabled = false;
    }
  });
})();

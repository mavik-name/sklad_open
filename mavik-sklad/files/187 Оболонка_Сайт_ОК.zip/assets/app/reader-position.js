(() => {
  'use strict';
  const reader=document.getElementById('reader'), resume=document.getElementById('resumeBtn');
  if(!reader||!resume)return;
  const m=location.pathname.match(/^\/books\/([^/]+)\/read\/?$/); if(!m)return;
  const slug=m[1], key='mavik-reader-position-v3:'+slug, oldKey='mavik-last-'+slug;
  const blocks=[...reader.children].filter(el=>/^(H1|H2|H3|H4|P|BLOCKQUOTE|DIV|UL|OL|TABLE)$/i.test(el.tagName));
  if(!blocks.length)return;
  const norm=s=>(s||'').replace(/\s+/g,' ').trim();
  const fp=el=>norm(el.textContent).slice(0,120);
  const load=()=>{try{const v=JSON.parse(localStorage.getItem(key)||'null');return v&&typeof v==='object'?v:null}catch(_){return null}};
  const save=v=>{try{localStorage.setItem(key,JSON.stringify(v))}catch(_){}};
  const maxScroll=()=>Math.max(1,document.documentElement.scrollHeight-innerHeight);
  const anchorRatio=.38;
  const current=()=>{
    const anchorY=scrollY+innerHeight*anchorRatio;
    let idx=0;
    for(let i=0;i<blocks.length;i++){ if(blocks[i].offsetTop<=anchorY) idx=i; else break; }
    const el=blocks[idx], h=Math.max(1,el.offsetHeight);
    const ratio=Math.max(0,Math.min(1,(anchorY-el.offsetTop)/h));
    return {v:3,index:idx,ratio,fp:fp(el),percent:Math.round(scrollY/maxScroll()*10000)/100,scrollY:Math.round(scrollY),at:Date.now()};
  };
  const good=s=>s&&Number.isFinite(Number(s.index))&&Number(s.percent)>1&&Number(s.percent)<99.7;
  const resolve=s=>{
    let idx=Math.max(0,Math.min(blocks.length-1,Number(s.index)||0));
    if(s.fp){
      const exact=blocks.findIndex(el=>fp(el)===s.fp);
      if(exact>=0) idx=exact;
      else {
        const prefix=String(s.fp).slice(0,64);
        const near=blocks.findIndex(el=>fp(el).startsWith(prefix));
        if(near>=0) idx=near;
      }
    }
    return {el:blocks[idx],idx};
  };
  const targetY=s=>{
    const {el}=resolve(s), ratio=Math.max(0,Math.min(1,Number(s.ratio)||0));
    return Math.max(0,Math.min(maxScroll(),el.offsetTop+el.offsetHeight*ratio-innerHeight*anchorRatio));
  };
  const flash=el=>{
    if(!el)return;
    el.classList.remove('reader-resume-highlight'); void el.offsetWidth; el.classList.add('reader-resume-highlight');
    setTimeout(()=>el.classList.remove('reader-resume-highlight'),1900);
  };
  let stored=load(), dirty=false, timer=0, startY=scrollY, resumed=false;
  // Migration fallback from old heading-only R165 position.
  if(!good(stored)){
    try{
      const old=localStorage.getItem(oldKey), el=old&&document.getElementById(old);
      if(el){ const idx=blocks.indexOf(el); if(idx>=0) stored={v:2,index:idx,ratio:0,fp:fp(el),percent:2,scrollY:el.offsetTop,at:Date.now()}; }
    }catch(_){}
  }
  if(good(stored)&&scrollY<160){
    resume.style.display='block';
    resume.onclick=()=>{
      const {el}=resolve(stored); resumed=true;
      window.scrollTo({top:targetY(stored),behavior:'smooth'});
      resume.style.display='none';
      setTimeout(()=>{flash(el);dirty=true;save(current())},780);
    };
  } else resume.style.display='none';
  const flush=()=>{ if(dirty) save(current()); };
  const queue=()=>{ if(!dirty)return; clearTimeout(timer); timer=setTimeout(flush,320); };
  ['touchstart','pointerdown','wheel','keydown'].forEach(ev=>addEventListener(ev,()=>{dirty=true},{passive:true}));
  addEventListener('scroll',()=>{
    if(Math.abs(scrollY-startY)>24)dirty=true;
    if(scrollY>180&&!resumed)resume.style.display='none';
    queue();
  },{passive:true});
  addEventListener('pagehide',flush);
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')flush()});
})();

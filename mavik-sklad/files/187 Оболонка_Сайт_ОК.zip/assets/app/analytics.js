(() => {
  const ENDPOINT = '/analytics/event.php';
  const KEY = '47cb7a2a1e39ea4b2fb4e80c25923196';

  const started = Date.now();
  let maxScroll = 0;
  let summarySent = false;

  const path = location.pathname.replace(/\/+/g,'/');
  const parts = path.split('/').filter(Boolean);

  const pageMeta = () => {
    let section = 'home', book = '', article = '';
    if (parts[0] === 'books' && parts[1]) {
      book = parts[1];
      section = parts[2] === 'read' ? 'reader' : 'book';
    } else if (parts[0] === 'blog') {
      article = parts[1] || '';
      section = article ? 'blog_article' : 'blog';
    } else if (parts[0] === 'music') {
      section = 'music';
    }

    let device = 'desktop';
    if (matchMedia('(max-width: 680px)').matches) device = 'mobile';
    else if (matchMedia('(max-width: 1024px)').matches) device = 'tablet';

    let mode = 'browser';
    if (matchMedia('(display-mode: standalone)').matches || navigator.standalone === true) mode = 'pwa';

    let referrer = 'direct';
    try {
      if (document.referrer) {
        const r = new URL(document.referrer);
        referrer = r.hostname === location.hostname ? 'internal' : r.hostname.replace(/^www\./,'');
      }
    } catch(e) {}

    const q = new URLSearchParams(location.search);

    return {
      section, book, article, device, mode, referrer,
      utm_source: q.get('utm_source') || '',
      utm_medium: q.get('utm_medium') || '',
      utm_campaign: q.get('utm_campaign') || ''
    };
  };

  const baseMeta = pageMeta();

  const send = (event, meta = {}, value = null) => {
    const body = JSON.stringify({
      key: KEY,
      event,
      path,
      value,
      meta: {...baseMeta, ...meta}
    });

    try {
      if (navigator.sendBeacon) {
        const blob = new Blob([body], {type:'application/json'});
        if (navigator.sendBeacon(ENDPOINT, blob)) return;
      }
    } catch(e) {}

    try {
      fetch(ENDPOINT, {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body,
        credentials:'same-origin',
        keepalive:true
      }).catch(()=>{});
    } catch(e) {}
  };

  window.MaVikAnalytics = { track: send };

  send('page_view');

  // Engagement milestones.
  setTimeout(() => send('engaged_30s'), 30000);
  setTimeout(() => send('engaged_120s'), 120000);

  // Reading/page scroll depth.
  const progressSeen = new Set();
  const readerBook = baseMeta.section === 'reader' ? baseMeta.book : '';

  const updateScroll = () => {
    const max = Math.max(1, document.documentElement.scrollHeight - innerHeight);
    const pct = Math.max(0, Math.min(100, Math.round(scrollY / max * 100)));
    if (pct > maxScroll) maxScroll = pct;

    if (readerBook) {
      [25,50,75,100].forEach(mark => {
        if (pct < mark || progressSeen.has(mark)) return;
        progressSeen.add(mark);
        send('reader_progress', {book: readerBook}, mark);
      });
    }
  };
  addEventListener('scroll', updateScroll, {passive:true});
  updateScroll();

  // Click events.
  document.addEventListener('click', e => {
    const el = e.target.closest && e.target.closest('a,button');
    if (!el) return;

    const href = el.tagName === 'A' ? (el.getAttribute('href') || '') : '';
    let url = null;
    try { if (href) url = new URL(href, location.href); } catch(e) {}

    const cls = el.classList;

    // Any Ding control.
    if (
      cls.contains('js-ding') ||
      cls.contains('mavik-site-ding') ||
      cls.contains('floating-ding') ||
      cls.contains('reader-floating-ding') ||
      cls.contains('reader-ding-link') ||
      cls.contains('mavik-global-ding')
    ) send('ding_click');

    // Reader CTA.
    if (url && url.origin === location.origin && /\/books\/[^/]+\/read\/?$/.test(url.pathname)) {
      const m = url.pathname.match(/\/books\/([^/]+)\/read/);
      send('read_click', {book: m ? m[1] : ''});
    }

    // EPUB.
    if (url && url.origin === location.origin && /\.epub(?:$|\?)/i.test(url.pathname)) {
      const name = url.pathname.split('/').pop().replace(/\.epub$/i,'');
      send('epub_download', {book:name});
    }

    // Blog article.
    if (url && url.origin === location.origin && /^\/blog\/[^/]+\/?$/.test(url.pathname)) {
      send('blog_article_click', {article:url.pathname.split('/').filter(Boolean)[1] || ''});
    }

    // Support interactions.
    if (url && /(^|\.)send\.monobank\.ua$/i.test(url.hostname)) {
      const amount = url.searchParams.get('a') || 'custom';
      send('support_monobank_click', {label:amount, domain:'send.monobank.ua'});
    }
    if (cls.contains('copy-btn')) send('support_copy_field', {label:el.dataset.copy || el.getAttribute('data-copy') || 'field'});
    if (cls.contains('privat-qr-item') || el.closest('.privat-qr-item')) send('support_qr_open');

    // Reader controls.
    if (el.id === 'resumeBtn') send('reader_resume', {book:readerBook});
    if (cls.contains('toc-link')) send('reader_toc', {book:readerBook});
    if (['plus','minus','themeBtn','settingsBtn'].includes(el.id)) send('reader_setting', {book:readerBook, label:el.id});

    // Blog tag.
    if (el.hasAttribute('data-tag')) send('blog_tag', {label:el.getAttribute('data-tag') || 'tag'});

    // Outbound domain (domain only; never full URL).
    if (url && /^https?:$/.test(url.protocol) && url.hostname !== location.hostname) {
      send('external_click', {domain:url.hostname.replace(/^www\./,'')});
    }
  }, true);

  // Blog search: count searches, do not send the user's query.
  const blogSearch = document.getElementById('blogSearch');
  if (blogSearch) {
    let timer = null, last = '';
    blogSearch.addEventListener('input', () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        const q = blogSearch.value.trim();
        if (!q || q === last) return;
        last = q;
        const visible = [...document.querySelectorAll('.post-card')].filter(x => !x.hidden).length;
        send('blog_search', {label:'text'}, visible);
      }, 900);
    });
  }

  // Music.
  const audio = document.getElementById('audio');
  if (audio) {
    const played = new Set();
    const heard30 = new Set();

    const trackInfo = () => {
      const track = (document.getElementById('trackTitle')?.textContent || '').trim();
      let album = '';
      const active = document.querySelector('.track-row.active .track-album');
      if (active) album = (active.textContent || '').trim();
      return {track, album};
    };

    audio.addEventListener('play', () => {
      const info = trackInfo();
      if (!info.track || info.track === 'Трек не вибрано') return;
      const key = info.album + '|' + info.track;
      if (!played.has(key)) {
        played.add(key);
        send('music_play', info);
      }
    });

    audio.addEventListener('timeupdate', () => {
      if (audio.currentTime < 30) return;
      const info = trackInfo();
      if (!info.track || info.track === 'Трек не вибрано') return;
      const key = info.album + '|' + info.track;
      if (!heard30.has(key)) {
        heard30.add(key);
        send('music_30s', info);
      }
    });

    audio.addEventListener('ended', () => {
      const info = trackInfo();
      if (info.track && info.track !== 'Трек не вибрано') send('music_complete', info);
    });
  }

  // One summary per page lifetime.
  const sendSummary = () => {
    if (summarySent) return;
    summarySent = true;
    updateScroll();
    const seconds = Math.max(0, Math.min(3600, Math.round((Date.now() - started) / 1000)));
    if (seconds >= 3) send('page_summary', {scroll:maxScroll}, seconds);
  };
  addEventListener('pagehide', sendSummary);
})();

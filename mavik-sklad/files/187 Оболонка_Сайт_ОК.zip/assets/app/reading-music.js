(()=>{
  const hero=document.querySelector('.book-hero');
  if(!hero) return;

  const pathParts=location.pathname.split('/').filter(Boolean);
  const bookSlug=pathParts[0]==='books'?(pathParts[1]||''):'';
  const KEY='mavik-reading-music-v3:'+bookSlug;

  const toggle=document.createElement('button');
  toggle.type='button';
  toggle.className='reader-music-toggle reader-hero-music';
  toggle.id='readerMusicToggle';
  toggle.title='Музика для читання';
  toggle.setAttribute('aria-label','Музика для читання');
  toggle.innerHTML='<svg aria-hidden="true" viewBox="0 0 24 24"><path d="M9 18V6l10-2v12"></path><circle cx="6.5" cy="18" r="2.5"></circle><circle cx="16.5" cy="16" r="2.5"></circle></svg>';
  hero.insertBefore(toggle,hero.firstChild);

  const panel=document.createElement('div');
  panel.className='reader-music-panel';
  panel.id='readerMusicPanel';
  panel.setAttribute('aria-hidden','true');
  panel.innerHTML=
    '<div class="reader-music-transport">'+
      '<button class="reader-music-btn" id="readerMusicPrev" aria-label="Попередній трек">‹</button>'+
      '<button class="reader-music-btn play" id="readerMusicPlay" aria-label="Відтворити">▶</button>'+
      '<button class="reader-music-btn" id="readerMusicNext" aria-label="Наступний трек">›</button>'+
    '</div>'+
    '<div class="reader-music-meta">'+
      '<div class="reader-music-label">Музика для читання · MaVik_AI</div>'+
      '<div class="reader-music-title" id="readerMusicTitle">Завантаження…</div>'+
      '<div class="reader-music-album" id="readerMusicAlbum"></div>'+
    '</div>'+
    '<div class="reader-music-side">'+
      '<button class="reader-music-choose" id="readerMusicChoose" type="button" aria-label="Обрати музику" title="Обрати музику"><span aria-hidden="true">☰</span></button>'+
      '<input class="reader-music-volume" id="readerMusicVolume" aria-label="Гучність" type="range" min="0" max="1" step="0.05" value="0.75">'+
      '<button class="reader-music-close" id="readerMusicClose" aria-label="Згорнути плеєр">×</button>'+
    '</div>';
  document.body.appendChild(panel);

  const chooser=document.createElement('div');
  chooser.className='reader-music-chooser';
  chooser.id='readerMusicChooser';
  chooser.setAttribute('aria-hidden','true');
  document.body.appendChild(chooser);

  const audio=new Audio();
  audio.preload='metadata';

  let tracks=[];
  let recommendations=[];
  let idx=0;
  let pendingSeek=0;
  let musicOff=false;
  let selectedCollection=null;

  const title=document.getElementById('readerMusicTitle');
  const album=document.getElementById('readerMusicAlbum');
  const play=document.getElementById('readerMusicPlay');
  const vol=document.getElementById('readerMusicVolume');
  const chooseBtn=document.getElementById('readerMusicChoose');

  const restore=()=>{
    try{return JSON.parse(localStorage.getItem(KEY)||'{}')}
    catch(e){return {}}
  };
  const save=()=>{
    try{
      localStorage.setItem(KEY,JSON.stringify({
        trackId:tracks[idx]?.id||'',
        seconds:audio.currentTime||0,
        volume:audio.volume,
        off:musicOff
      }));
    }catch(e){}
  };

  const open=()=>{
    panel.classList.add('open');
    panel.setAttribute('aria-hidden','false');
    toggle.classList.add('is-active');
    document.body.classList.add('reader-music-open');
    window.dispatchEvent(new CustomEvent('mavik:reading-music-state',{detail:{open:true}}));
  };
  const close=()=>{
    panel.classList.remove('open');
    panel.setAttribute('aria-hidden','true');
    toggle.classList.remove('is-active');
    document.body.classList.remove('reader-music-open');
    window.dispatchEvent(new CustomEvent('mavik:reading-music-state',{detail:{open:false}}));
    closeChooser();
  };
  const openChooser=()=>{
    renderChooser();
    chooser.classList.add('open');
    chooser.setAttribute('aria-hidden','false');
  };
  const closeChooser=()=>{
    chooser.classList.remove('open');
    chooser.setAttribute('aria-hidden','true');
  };

  toggle.onclick=()=>panel.classList.contains('open')?close():open();
  document.getElementById('readerMusicClose').onclick=close;
  chooseBtn.onclick=()=>chooser.classList.contains('open')?closeChooser():openChooser();

  const spotifyEmbed=url=>{
    try{
      const u=new URL(url);
      if(u.hostname!=='open.spotify.com')return '';
      const p=u.pathname.split('/').filter(Boolean);
      if(p.length<2||!['track','album','playlist','episode','show'].includes(p[0]))return '';
      return 'https://open.spotify.com/embed/'+p[0]+'/'+encodeURIComponent(p[1])+'?utm_source=generator';
    }catch(e){return ''}
  };

  const stopOwnAudio=()=>{
    if(!audio.paused) audio.pause();
    play.textContent='▶';
    play.setAttribute('aria-label','Відтворити');
  };

  const chooseOff=()=>{
    stopOwnAudio();
    musicOff=true;
    title.textContent='Без музики';
    album.textContent='Музичний супровід вимкнено';
    save();
    renderChooser();
  };

  const render=()=>{
    const t=tracks[idx];
    if(!t)return;
    title.textContent=t.title||'Трек';
    album.textContent=(t.album||'')+' · '+(t.artist||'MaVik_AI');
    if('mediaSession' in navigator){
      try{
        navigator.mediaSession.metadata=new MediaMetadata({
          title:t.title||'',
          artist:t.artist||'MaVik_AI',
          album:t.album||'',
          artwork:t.cover?[{src:t.cover,sizes:'1254x1254',type:'image/jpeg'}]:[]
        });
      }catch(e){}
    }
  };

  const load=(i,seek=0,autoplay=false)=>{
    if(!tracks.length)return;
    musicOff=false;
    idx=(i+tracks.length)%tracks.length;
    const t=tracks[idx];
    pendingSeek=Math.max(0,seek||0);
    audio.src=t.src;
    render();
    save();
    if(autoplay){
      audio.play().then(()=>{
        play.textContent='❚❚';
        play.setAttribute('aria-label','Пауза');
      }).catch(()=>{});
    }
  };

  const chooseTrack=i=>{
    load(i,0,true);
    closeChooser();
    open();
  };

  const renderChooser=()=>{
    chooser.innerHTML='';

    const head=document.createElement('div');
    head.className='reader-choice-head';
    head.innerHTML='<div><b>Обрати музику</b><small>Лише варіанти, підібрані автором для цієї книги</small></div><button type="button" aria-label="Закрити">×</button>';
    head.querySelector('button').onclick=closeChooser;
    chooser.appendChild(head);

    const off=document.createElement('button');
    off.type='button';
    off.className='reader-choice-off'+(musicOff?' active':'');
    off.innerHTML='<b>Без музики</b><small>Продовжити читання у тиші</small>';
    off.onclick=chooseOff;
    chooser.appendChild(off);

    if(tracks.length){
      const section=document.createElement('section');
      section.className='reader-choice-section';
      const h=document.createElement('h3');
      h.textContent='Авторський саундтрек';
      section.appendChild(h);

      tracks.forEach((t,i)=>{
        const b=document.createElement('button');
        b.type='button';
        b.className='reader-choice-track'+(!musicOff&&i===idx?' active':'');
        const name=document.createElement('b');
        name.textContent=t.title||'Трек';
        const meta=document.createElement('small');
        meta.textContent=[t.album,t.artist||'MaVik_AI'].filter(Boolean).join(' · ');
        b.append(name,meta);
        b.onclick=()=>chooseTrack(i);
        section.appendChild(b);
      });
      chooser.appendChild(section);
    }

    if(recommendations.length){
      const section=document.createElement('section');
      section.className='reader-choice-section';
      const h=document.createElement('h3');
      h.textContent='Рекомендовано автором';
      section.appendChild(h);

      recommendations.forEach(r=>{
        const card=document.createElement('div');
        card.className='reader-choice-external';

        const meta=document.createElement('div');
        meta.className='reader-choice-external-meta';
        const b=document.createElement('b');
        b.textContent=r.title||'Музика';
        const small=document.createElement('small');
        small.textContent=[r.source,r.note].filter(Boolean).join(' · ');
        meta.append(b,small);
        card.appendChild(meta);

        const embed=r.provider==='spotify'?spotifyEmbed(r.url||''):'';
        if(embed){
          const activate=document.createElement('button');
          activate.type='button';
          activate.className='reader-choice-activate';
          activate.textContent='Слухати тут';
          activate.onclick=()=>{
            stopOwnAudio();
            const holder=document.createElement('div');
            holder.className='reader-choice-embed';
            const frame=document.createElement('iframe');
            frame.src=embed;
            frame.loading='lazy';
            frame.allow='autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture';
            frame.setAttribute('title',r.title||'Spotify');
            frame.setAttribute('sandbox','allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox allow-forms');
            holder.appendChild(frame);
            activate.replaceWith(holder);
          };
          card.appendChild(activate);
        }else{
          const a=document.createElement('a');
          a.href=r.url||'#';
          a.target='_blank';
          a.rel='noopener noreferrer';
          a.className='reader-choice-link';
          a.textContent='Відкрити джерело ↗';
          card.appendChild(a);
        }

        section.appendChild(card);
      });
      chooser.appendChild(section);
    }
  };

  const togglePlay=()=>{
    if(!tracks.length)return;
    open();
    if(musicOff){
      load(idx,0,true);
      return;
    }
    if(audio.paused){
      audio.play().then(()=>{
        play.textContent='❚❚';
        play.setAttribute('aria-label','Пауза');
        try{window.MaVikAnalytics?.track?.('reading_music_play',{label:tracks[idx].title||''})}catch(e){}
      }).catch(()=>{});
    }else{
      audio.pause();
      play.textContent='▶';
      play.setAttribute('aria-label','Відтворити');
    }
  };

  const openAndPlay=()=>{
    open();
    if(!tracks.length)return;
    if(musicOff){load(idx,0,true);return;}
    if(audio.paused){
      audio.play().then(()=>{play.textContent='❚❚';play.setAttribute('aria-label','Пауза')}).catch(()=>{});
    }
  };
  const pauseAndClose=()=>{if(!audio.paused)audio.pause();close();};
  window.MaVikReadingMusic={open,close,isOpen:()=>panel.classList.contains('open'),openAndPlay,pauseAndClose,togglePlay};
  window.dispatchEvent(new Event('mavik:reading-music-ready'));

  play.onclick=togglePlay;
  document.getElementById('readerMusicPrev').onclick=()=>{
    load(idx-1,0,true);
  };
  document.getElementById('readerMusicNext').onclick=()=>{
    load(idx+1,0,true);
  };

  vol.oninput=()=>{
    audio.volume=Number(vol.value);
    save();
  };

  audio.addEventListener('loadedmetadata',()=>{
    if(pendingSeek&&pendingSeek<audio.duration)audio.currentTime=pendingSeek;
    pendingSeek=0;
  });
  audio.addEventListener('pause',()=>{
    play.textContent='▶';
    save();
  });
  audio.addEventListener('play',()=>{
    window.dispatchEvent(new CustomEvent('mavik:music-start'));
    play.textContent='❚❚';
  });
  window.addEventListener('mavik:listen-start',()=>{if(!audio.paused)audio.pause()});
  audio.addEventListener('timeupdate',()=>{if(Math.floor(audio.currentTime)%10===0)save()});
  audio.addEventListener('ended',()=>{load(idx+1,0,true)});
  window.addEventListener('beforeunload',save);

  if('mediaSession' in navigator){
    try{
      navigator.mediaSession.setActionHandler('play',()=>togglePlay());
      navigator.mediaSession.setActionHandler('pause',()=>audio.pause());
      navigator.mediaSession.setActionHandler('previoustrack',()=>load(idx-1,0,true));
      navigator.mediaSession.setActionHandler('nexttrack',()=>load(idx+1,0,true));
    }catch(e){}
  }

  fetch('/music-data.php?book='+encodeURIComponent(bookSlug),{cache:'no-store'})
    .then(r=>{if(!r.ok)throw new Error('tracks');return r.json()})
    .then(data=>{
      tracks=Array.isArray(data.tracks)?data.tracks:[];
      recommendations=Array.isArray(data.recommendations)?data.recommendations:[];
      selectedCollection=data.collection||null;

      const st=restore();
      const restoredIndex=tracks.findIndex(t=>t.id&&t.id===st.trackId);
      idx=restoredIndex>=0?restoredIndex:0;
      audio.volume=Math.max(0,Math.min(1,Number(st.volume??.75)));
      vol.value=audio.volume;

      if(selectedCollection&&selectedCollection.name){
        document.querySelector('.reader-music-label').textContent=selectedCollection.name+' · MaVik_AI';
      }

      if(st.off){
        musicOff=true;
        title.textContent='Без музики';
        album.textContent='Музичний супровід вимкнено';
      }else if(tracks.length){
        load(idx,restoredIndex>=0?Number(st.seconds)||0:0,false);
      }else{
        title.textContent=recommendations.length?'Рекомендовано автором':'Музика ще не підібрана';
        album.textContent=recommendations.length?'Відкрийте меню ☰, щоб переглянути варіанти':'Для цієї книги поки немає музичного супроводу';
        play.disabled=true;
        document.getElementById('readerMusicPrev').disabled=true;
        document.getElementById('readerMusicNext').disabled=true;
      }

      if(location.hash==='#music')open();
    })
    .catch(()=>{
      title.textContent='Музика зараз недоступна';
      album.textContent='Відкрийте розділ «Музика»';
      chooseBtn.disabled=true;
    });
})();
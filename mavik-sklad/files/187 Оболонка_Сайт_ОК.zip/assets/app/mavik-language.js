(() => {
  'use strict';
  const LANGS=['uk','en','fr','es','de','pl'];
  const CODE={uk:'UA',en:'EN',fr:'FR',es:'ES',de:'DE',pl:'PL'};
  const NAME={uk:'Українська',en:'English',fr:'Français',es:'Español',de:'Deutsch',pl:'Polski'};
  const SOURCE='https://mavik.name',PROXY='mavik-name.translate.goog',KEY='mavik-language-v180';
  const proxy=/\.translate\.goog$/i.test(location.hostname),source=/^(?:www\.)?mavik\.name$/i.test(location.hostname),local=location.hostname==='localhost'||location.hostname.startsWith('127.');
  const reader=/^\/books\/[^/]+\/read\/?$/.test(location.pathname);
  const qp=()=>new URLSearchParams(location.search);
  const clean=()=>{const p=qp();[...p.keys()].forEach(k=>{if(k==='mavik_lang'||k.startsWith('_x_tr_'))p.delete(k)});return p};
  const remember=x=>{try{localStorage.setItem(KEY,x)}catch(_){}};
  const remembered=()=>{try{const x=localStorage.getItem(KEY);return LANGS.includes(x)?x:null}catch(_){return null}};
  const detected=()=>{const a=(navigator.languages&&navigator.languages.length?navigator.languages:[navigator.language||'uk']);for(const x of a){const c=String(x||'').toLowerCase().split('-')[0];if(LANGS.includes(c))return c}return'uk'};
  const targetOnProxy=()=>{const c=qp().get('_x_tr_tl');return LANGS.includes(c)?c:'en'};
  const proxyUrl=lang=>{const p=clean();p.set('_x_tr_sl','uk');p.set('_x_tr_tl',lang);p.set('_x_tr_hl',lang);return'https://'+PROXY+location.pathname+'?'+p.toString()+location.hash};
  const sourceChoice=lang=>{const p=clean();p.set('mavik_lang',lang);return SOURCE+location.pathname+'?'+p.toString()+location.hash};
  const go=lang=>{if(!LANGS.includes(lang))return;if(local){remember(lang);setActive(lang);return}location.assign(sourceChoice(lang))};
  function makeItems(active,cls){const f=document.createDocumentFragment();LANGS.forEach(l=>{const b=document.createElement('button');b.type='button';b.className=cls+(l===active?' active':'');b.dataset.mvkLang=l;b.setAttribute('translate','no');b.classList.add('notranslate');if(cls==='mvk-lang-item')b.innerHTML='<span class="mvk-lang-code">'+CODE[l]+'</span><span>'+NAME[l]+'</span>';else b.textContent=CODE[l];b.title=NAME[l];b.setAttribute('aria-label',NAME[l]);b.onclick=()=>go(l);f.appendChild(b)});return f}
  function setActive(active){document.documentElement.dataset.mavikLanguage=active;document.querySelectorAll('[data-mvk-lang]').forEach(x=>x.classList.toggle('active',x.dataset.mvkLang===active))}
  function desktop(active){if(document.querySelector('.mvk-lang-desktop'))return;const host=reader?document.querySelector('.controls'):(document.querySelector('.mavik-site-desktop-nav')||document.querySelector('nav.menu'));const w=document.createElement('div');w.className='mvk-lang-desktop notranslate';w.setAttribute('translate','no');const t=document.createElement('button');t.type='button';t.className='mvk-lang-trigger';t.textContent='文';t.title='Language / Мова';t.setAttribute('aria-label','Змінити мову');t.setAttribute('aria-expanded','false');const pop=document.createElement('div');pop.className='mvk-lang-pop';pop.appendChild(makeItems(active,'mvk-lang-item'));w.append(t,pop);t.onclick=e=>{e.stopPropagation();const o=w.classList.toggle('open');t.setAttribute('aria-expanded',o?'true':'false')};document.addEventListener('click',e=>{if(!w.contains(e.target)){w.classList.remove('open');t.setAttribute('aria-expanded','false')}});document.addEventListener('keydown',e=>{if(e.key==='Escape'){w.classList.remove('open');t.setAttribute('aria-expanded','false')}});if(host){const before=reader?host.querySelector('#settingsBtn'):host.querySelector('.mavik-site-ding,.ding-small,.js-ding');before&&before.parentElement===host?host.insertBefore(w,before):host.appendChild(w)}else{w.classList.add('mvk-lang-fallback');document.body.appendChild(w)}}
  function mobileReader(active){if(!reader)return;const s=document.getElementById('settings');if(!s||s.querySelector('.mvk-reader-language'))return;const box=document.createElement('div');box.className='mvk-reader-language notranslate';box.setAttribute('translate','no');const title=document.createElement('div');title.className='mvk-reader-language-title';title.textContent='Мова';const grid=document.createElement('div');grid.className='mvk-reader-language-grid';grid.appendChild(makeItems(active,'mvk-reader-language-choice'));box.append(title,grid);const theme=s.querySelector('.reader-theme-setting');theme?theme.insertAdjacentElement('afterend',box):s.prepend(box)}
  function mobileMenu(active){
    if(reader)return;
    const hosts=document.querySelectorAll('.mavik-site-mobile-inner,.mobile-menu-inner');
    hosts.forEach(host=>{
      if(host.querySelector('.mvk-mobile-language-row'))return;
      host.querySelectorAll('.mavik-site-ding,.ding-small,.js-ding').forEach(el=>el.remove());
      const row=document.createElement('div');
      row.className='mvk-mobile-language-row notranslate';
      row.setAttribute('translate','no');
      row.setAttribute('aria-label','Вибір мови');
      row.appendChild(makeItems(active,'mvk-mobile-language-choice'));
      host.appendChild(row);
    });
  }
  const mount=active=>{setActive(active);desktop(active);mobileReader(active);mobileMenu(active)};
  document.addEventListener('DOMContentLoaded',()=>{
    if(proxy){mount(targetOnProxy());return}
    if(!source&&!local)return;
    const requested=qp().get('mavik_lang');
    if(LANGS.includes(requested)){remember(requested);const p=clean().toString(),url=location.pathname+(p?'?'+p:'')+location.hash;if(requested==='uk'||local){history.replaceState(null,'',url);mount(requested)}else location.replace(proxyUrl(requested));return}
    const pref=remembered()||detected();
    if(pref==='uk'||local)mount(pref);else location.replace(proxyUrl(pref));
  });
})();

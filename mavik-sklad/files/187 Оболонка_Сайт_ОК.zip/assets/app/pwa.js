(() => {
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js', {
        scope:'/',
        updateViaCache:'none'
      }).then(reg => reg.update()).catch(() => {});
    });
  }
})();
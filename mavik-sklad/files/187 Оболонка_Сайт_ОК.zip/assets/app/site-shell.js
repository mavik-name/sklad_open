
(() => {
  const buttons = document.querySelectorAll('.mavik-site-mobile-toggle');
  buttons.forEach(btn => {
    const id = btn.getAttribute('aria-controls');
    const menu = id ? document.getElementById(id) : null;
    if (!menu) return;

    const close = () => {
      menu.classList.remove('open');
      btn.classList.remove('open');
      btn.setAttribute('aria-expanded','false');
      btn.setAttribute('aria-label','Відкрити меню');
      menu.setAttribute('aria-hidden','true');
      document.body.classList.remove('mavik-menu-open');
    };
    const open = () => {
      menu.classList.add('open');
      btn.classList.add('open');
      btn.setAttribute('aria-expanded','true');
      btn.setAttribute('aria-label','Закрити меню');
      menu.setAttribute('aria-hidden','false');
      document.body.classList.add('mavik-menu-open');
    };

    btn.addEventListener('click', () => menu.classList.contains('open') ? close() : open());
    menu.querySelectorAll('a').forEach(a => a.addEventListener('click', close));
    document.addEventListener('keydown', e => { if (e.key === 'Escape') close(); });
    window.addEventListener('resize', () => { if (window.innerWidth > 780) close(); });
  });
})();

// r73 — reliable top-menu Ding bridge
document.querySelectorAll('.mavik-site-ding').forEach(link => {
  link.addEventListener('click', () => {
    try { sessionStorage.setItem('mavik-open-ding', '1'); } catch(e) {}
  });
});


// R115 — owner account bridge. Shows "Адмінка" only to an authenticated owner.
(() => {
  const addLink = (host, mobile, authenticated) => {
    if (!host || host.querySelector('.mavik-owner-access')) return;
    const a=document.createElement('a');
    a.className='mavik-owner-access';
    const next=encodeURIComponent(location.pathname+location.search+location.hash);
    a.href=authenticated?'/boss/':'/account/?next='+next;
    if(mobile){const marker=host.classList.contains('mobile-menu-inner')?'span':'b';const b=document.createElement(marker);b.textContent='06';a.appendChild(b);a.append(document.createTextNode(authenticated?'Адмінка':'Вхід'));}
    else a.textContent=authenticated?'Адмінка':'Вхід';
    const lang=host.querySelector('.mvk-mobile-language-row');
    const ding=host.querySelector('.mavik-site-ding,.ding-small');
    if(mobile&&lang)host.insertBefore(a,lang);else if(ding)host.insertBefore(a,ding);else host.appendChild(a);
  };
  fetch('/account/status.php',{credentials:'same-origin',cache:'no-store'})
    .then(r=>r.ok?r.json():Promise.reject())
    .then(s=>{
      const auth=!!s.authenticated;
      document.querySelectorAll('.mavik-site-desktop-nav').forEach(x=>addLink(x,false,auth));
      document.querySelectorAll('.mavik-site-mobile-inner').forEach(x=>addLink(x,true,auth));
      document.querySelectorAll('.mobile-menu-inner').forEach(x=>addLink(x,true,auth));
      document.querySelectorAll('.menu').forEach(x=>addLink(x,false,auth));
    }).catch(()=>{});
})();

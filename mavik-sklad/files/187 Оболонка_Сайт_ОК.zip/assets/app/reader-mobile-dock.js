(()=>{
  'use strict';
  const reader=document.getElementById('reader');
  if(!reader)return;
  const m=location.pathname.match(/^\/books\/([^/]+)\/read\/?$/);
  if(!m)return;
  const slug=m[1];
  const icon=body=>`<svg aria-hidden="true" viewBox="0 0 24 24">${body}</svg>`;

  const dock=document.createElement('nav');
  dock.className='reader-mobile-dock';
  dock.setAttribute('aria-label','Нижнє меню читанки');
  dock.innerHTML=
    `<button class="reader-mobile-dock-btn reader-mobile-error-btn" type="button" aria-label="Повідомити про помилку" title="Помилка">${icon('<circle cx="12" cy="12" r="8.5"></circle><path d="M12 7.5v6"></path><path d="M12 17h.01"></path>')}</button>`+
    `<a class="reader-mobile-dock-btn reader-mobile-home-btn" href="/books/${encodeURIComponent(slug)}/" aria-label="До сторінки книги" title="До книги">${icon('<path d="M4.5 10.8 12 4.8l7.5 6"></path><path d="M6.8 9.7v9h10.4v-9"></path><path d="M10 18.7v-5h4v5"></path>')}</a>`+
    `<button class="reader-mobile-dock-btn reader-mobile-back-btn" type="button" aria-label="Назад по тексту" title="Назад">${icon('<path d="m13.5 6-6 6 6 6"></path>')}</button>`+
    `<button class="reader-mobile-dock-btn reader-mobile-bookmark-btn" type="button" aria-label="Закладка" title="Закладка">${icon('<path d="M7 4.5h10v15l-5-3.3L7 19.5Z"></path>')}</button>`+
    `<button class="reader-mobile-dock-btn reader-mobile-forward-btn" type="button" aria-label="Вперед по тексту" title="Вперед">${icon('<path d="m10.5 6 6 6-6 6"></path>')}</button>`+
    `<button class="reader-mobile-dock-btn reader-mobile-music-btn" type="button" aria-label="Музика" title="Музика">${icon('<path d="M9 18V6l10-2v12"></path><circle cx="6.5" cy="18" r="2.5"></circle><circle cx="16.5" cy="16" r="2.5"></circle>')}</button>`+
    `<a class="reader-mobile-dock-btn reader-mobile-coffee-btn" href="/#support" aria-label="Пригостити автора кавою" title="Кава">${icon('<path d="M6.5 8.5h10v4.1a4.5 4.5 0 0 1-4.5 4.5h-1a4.5 4.5 0 0 1-4.5-4.5Z"></path><path d="M16.5 10h1.4a2.4 2.4 0 0 1 0 4.8h-1.8"></path><path d="M6 19h12"></path><path d="M9 5.2c0 1 1.1 1.1 1.1 2.1M13.2 4.7c0 1.1 1.1 1.2 1.1 2.3"></path>')}</a>`;
  document.body.appendChild(dock);
  document.body.classList.add('reader-mobile-dock-active');

  dock.querySelector('.reader-mobile-error-btn').onclick=()=>{
    const trigger=document.querySelector('.reader-error-trigger');
    if(trigger)trigger.click();
  };

  const bookmarkKey='mavik-reader-bookmark-v1:'+slug;
  const bmBtn=dock.querySelector('.reader-mobile-bookmark-btn');
  const bmPop=document.createElement('div');
  bmPop.className='reader-mobile-bookmark-pop';bmPop.setAttribute('aria-hidden','true');document.body.appendChild(bmPop);
  const loadBookmark=()=>{try{return JSON.parse(localStorage.getItem(bookmarkKey)||'null')}catch(_){return null}};
  const saveBookmark=()=>{try{localStorage.setItem(bookmarkKey,JSON.stringify({y:Math.round(scrollY),at:Date.now()}))}catch(_){}};
  const clearBookmark=()=>{try{localStorage.removeItem(bookmarkKey)}catch(_){}};
  const syncBookmark=()=>bmBtn.classList.toggle('has-bookmark',!!loadBookmark());
  const closeBookmark=()=>{bmPop.classList.remove('open');bmPop.setAttribute('aria-hidden','true')};
  const renderBookmark=()=>{const b=loadBookmark();bmPop.innerHTML='<div class="reader-mobile-bookmark-title">Закладка</div><div class="reader-mobile-bookmark-actions"></div><div class="reader-mobile-bookmark-note"></div>';const actions=bmPop.querySelector('.reader-mobile-bookmark-actions'),note=bmPop.querySelector('.reader-mobile-bookmark-note');const add=(label,fn)=>{const x=document.createElement('button');x.type='button';x.textContent=label;x.onclick=fn;actions.appendChild(x)};if(b){add('Перейти',()=>{scrollTo({top:Math.max(0,Number(b.y)||0),behavior:'smooth'});closeBookmark()});add('Замінити тут',()=>{saveBookmark();syncBookmark();note.textContent='Закладку оновлено.'});add('Видалити',()=>{clearBookmark();syncBookmark();renderBookmark()});note.textContent='Є збережена позиція в цій книзі.'}else{add('Зберегти тут',()=>{saveBookmark();syncBookmark();renderBookmark()});note.textContent='Закладки для цієї книги ще немає.'}add('Закрити',closeBookmark)};
  bmBtn.onclick=()=>{renderBookmark();const o=!bmPop.classList.contains('open');bmPop.classList.toggle('open',o);bmPop.setAttribute('aria-hidden',o?'false':'true')};
  syncBookmark();

  const step=dir=>scrollBy({top:dir*Math.max(280,innerHeight*.78),behavior:'smooth'});
  dock.querySelector('.reader-mobile-back-btn').onclick=()=>step(-1);
  dock.querySelector('.reader-mobile-forward-btn').onclick=()=>step(1);

  const musicBtn=dock.querySelector('.reader-mobile-music-btn');
  const invokeMusic=()=>{const api=window.MaVikReadingMusic;if(!api)return;closeBookmark();api.isOpen()?api.pauseAndClose():api.openAndPlay()};
  musicBtn.onclick=invokeMusic;
  window.addEventListener('mavik:reading-music-state',e=>musicBtn.classList.toggle('is-active',!!e.detail?.open));
})();

(() => {
  const GAP = 10;
  const BOTTOM_COFFEE_SELECTOR = '.floating-ding, .reader-floating-ding';
  const DESKTOP_HEADER_COFFEE_SELECTOR = '.mavik-site-ding, .ding-small';
  const FALLBACK_ID = 'mavikGlobalDing';

  const isVisible = el => {
    if (!el) return false;
    const style = getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden') return false;
    return !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
  };

  const visible = selector => [...document.querySelectorAll(selector)].find(isVisible) || null;

  const removeFallbacks = () => {
    document.querySelectorAll('.mavik-global-ding').forEach(el => el.remove());
  };

  const desktopHeaderCoffee = () =>
    window.innerWidth > 780 ? visible(DESKTOP_HEADER_COFFEE_SELECTOR) : null;

  const ensureBottomCoffee = () => {
    const nativeBottom = window.innerWidth <= 780
      ? document.querySelector(BOTTOM_COFFEE_SELECTOR)
      : visible(BOTTOM_COFFEE_SELECTOR);
    if (nativeBottom) {
      removeFallbacks();
      return nativeBottom;
    }

    // Desktop uses only the compact coffee icon in the header.
    // Do not add a second floating coffee shortcut there.
    if (desktopHeaderCoffee()) {
      removeFallbacks();
      return null;
    }

    let fallback = document.getElementById(FALLBACK_ID);
    if (!fallback) {
      removeFallbacks();
      fallback = document.createElement('a');
      fallback.id = FALLBACK_ID;
      fallback.className = 'mavik-global-ding';
      fallback.href = '/#support';
      fallback.setAttribute('aria-label','Пригостити автора кавою');
      fallback.setAttribute('title','Пригостити автора кавою');
      fallback.innerHTML =
        '<img aria-hidden="true" alt="" class="mavik-coffee-icon" src="/assets/icons/coffee.svg?v=185"/>';
      document.body.appendChild(fallback);
    }
    return fallback;
  };

  // Remove old blog-only arrow and stale global arrow duplicates.
  document.querySelectorAll('.back-to-top').forEach(el => el.remove());
  const oldTops = [...document.querySelectorAll('.mavik-global-top')];
  oldTops.slice(1).forEach(el => el.remove());

  let top = oldTops[0] || null;
  if (!top) {
    top = document.createElement('button');
    top.className = 'mavik-global-top';
    top.type = 'button';
    top.setAttribute('aria-label','Повернутися догори');
    top.setAttribute('title','Догори');
    top.innerHTML =
      '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5.5 14.5 12 8l6.5 6.5"/></svg>';
    document.body.appendChild(top);
  }

  const hideResumeAfterManualScroll = () => {
    const resume = document.getElementById('resumeBtn');
    if (!resume) return;
    if (window.scrollY > 180) resume.style.display = 'none';
  };

  const position = () => {
    const coffee = ensureBottomCoffee();
    const tr = top.getBoundingClientRect();

    if (!coffee) {
      // Desktop site pages: coffee is in the header, so the chevron stands alone.
      top.style.bottom = '18px';
      top.style.right = '18px';
      top.style.left = 'auto';
      return;
    }

    const dr = coffee.getBoundingClientRect();
    const bottom = Math.max(0, window.innerHeight - dr.top + GAP);
    let left = dr.left + (dr.width - tr.width) / 2;
    left = Math.max(4, Math.min(left, window.innerWidth - tr.width - 4));

    top.style.bottom = `${bottom}px`;
    top.style.left = `${left}px`;
    top.style.right = 'auto';
  };

  const homeMobileReveal = () => {
    if (window.innerWidth > 780) return null;
    const recommend = document.getElementById('shareSiteBtn');
    if (!recommend) return null;
    const header = document.querySelector('.nav, .mavik-site-header');
    const headerBottom = header ? header.getBoundingClientRect().bottom : 0;
    return recommend.getBoundingClientRect().bottom <= headerBottom;
  };

  const visibility = () => {
    const homeReveal = homeMobileReveal();
    const show = homeReveal === null ? window.scrollY > 420 : homeReveal;
    top.classList.toggle('is-visible', show);

    if (homeReveal !== null) {
      const coffee = document.querySelector(BOTTOM_COFFEE_SELECTOR) || document.getElementById(FALLBACK_ID);
      if (coffee) coffee.classList.toggle('is-visible', show);
    }
  };

  top.addEventListener('click', () =>
    window.scrollTo({top:0, behavior:'smooth'})
  );

  const sync = () => {
    hideResumeAfterManualScroll();
    position();
    visibility();
  };

  window.addEventListener('scroll', sync, {passive:true});
  window.addEventListener('resize', sync, {passive:true});
  window.addEventListener('orientationchange', () => setTimeout(sync, 80));

  window.addEventListener('load', () => {
    sync();
    setTimeout(sync, 120);
    setTimeout(sync, 500);
  });

  sync();
})();

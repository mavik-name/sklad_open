(()=>{
  const canonical=()=>document.querySelector('link[rel="canonical"]')?.href||location.href.split('#')[0];
  const title=()=>document.querySelector('.article-title-row h1,.article-hero h1')?.textContent?.trim()||document.title.replace(/\s*\|.*$/,'');
  const payload=()=>({title:title(),text:title(),url:canonical()});
  const qs=(s,r=document)=>r.querySelector(s);
  const qsa=(s,r=document)=>[...r.querySelectorAll(s)];
  const toast=msg=>{let t=qs('.share-toast');if(!t){t=document.createElement('div');t.className='share-toast';t.setAttribute('role','status');t.setAttribute('aria-live','polite');document.body.appendChild(t)}t.textContent=msg;t.classList.add('show');clearTimeout(t._x);t._x=setTimeout(()=>t.classList.remove('show'),1800)};
  async function copyLink(){const u=canonical();try{await navigator.clipboard.writeText(u);toast('Посилання скопійовано')}catch(e){const ta=document.createElement('textarea');ta.value=u;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();try{document.execCommand('copy');toast('Посилання скопійовано')}catch(_){prompt('Скопіюйте посилання:',u)}ta.remove()}}
  function shareUrl(kind){const u=canonical(),t=title();if(kind==='facebook')return 'https://www.facebook.com/sharer/sharer.php?u='+encodeURIComponent(u);if(kind==='telegram')return 'https://t.me/share/url?url='+encodeURIComponent(u)+'&text='+encodeURIComponent(t);if(kind==='viber')return 'viber://forward?text='+encodeURIComponent(t+' — '+u);return u}
  async function mainShare(btn){const p=payload();if(navigator.share){try{await navigator.share(p);return}catch(e){if(e&&e.name==='AbortError')return}}const wrap=btn.closest('.share-compact');const menu=wrap?.querySelector('.share-fallback');if(menu){menu.classList.toggle('is-open');btn.setAttribute('aria-expanded',menu.classList.contains('is-open')?'true':'false')}else{copyLink()}}
  qsa('[data-share-main]').forEach(b=>b.addEventListener('click',()=>mainShare(b)));
  qsa('[data-share-copy]').forEach(b=>b.addEventListener('click',e=>{e.preventDefault();copyLink();b.closest('.share-fallback')?.classList.remove('is-open')}));
  qsa('[data-share-network]').forEach(a=>{const k=a.dataset.shareNetwork;a.href=shareUrl(k);if(k!=='viber'){a.target='_blank';a.rel='noopener noreferrer'}a.addEventListener('click',()=>a.closest('.share-fallback')?.classList.remove('is-open'))});
  document.addEventListener('click',e=>{qsa('.share-fallback.is-open').forEach(m=>{const w=m.closest('.share-compact');if(w&&!w.contains(e.target)){m.classList.remove('is-open');w.querySelector('[data-share-main]')?.setAttribute('aria-expanded','false')}})});
  document.addEventListener('keydown',e=>{if(e.key==='Escape')qsa('.share-fallback.is-open').forEach(m=>{m.classList.remove('is-open');m.closest('.share-compact')?.querySelector('[data-share-main]')?.setAttribute('aria-expanded','false')})});
})();

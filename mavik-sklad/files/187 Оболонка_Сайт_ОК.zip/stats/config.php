<?php
return [
  'password_hash' => '$2y$12$4X1G2cOlsrBVKws/IKxryez.tj4LEFgimSO0KtXnk.SH5nLheDtau',
  'data_dir' => dirname(__DIR__) . '/analytics/data',
];

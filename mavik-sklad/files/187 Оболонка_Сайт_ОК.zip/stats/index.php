<?php
declare(strict_types=1);
date_default_timezone_set('Europe/Kyiv');
header('Cache-Control: no-store, max-age=0');
header('X-Robots-Tag: noindex, nofollow', true);
$config = require __DIR__ . '/config.php';
$root=realpath(dirname(__DIR__));
require $root . '/_site-admin/auth.php';
mavik_owner_session_start();
$dataDir = $config['data_dir'];

function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function n(int|float $v): string { return number_format($v, 0, ',', ' '); }

if(isset($_GET['logout'])){mavik_owner_logout();header('Location: /');exit;}
if(!mavik_owner_authed()){header('Location: /account/?next='.rawurlencode('/stats/'));exit;}

$range = $_GET['range'] ?? '30';
$allowed = ['1','7','30','90','all'];
if (!in_array($range, $allowed, true)) $range = '30';

$files = glob($dataDir . '/*.json') ?: [];
sort($files);

$today = new DateTimeImmutable('today');
$selected = [];
foreach ($files as $f) {
  $date = basename($f, '.json');
  try { $d = new DateTimeImmutable($date); } catch (Throwable $e) { continue; }
  if ($range !== 'all') {
    $days = (int)$range;
    $from = $today->modify('-' . ($days - 1) . ' days');
    if ($d < $from || $d > $today) continue;
  }
  $raw = file_get_contents($f);
  $j = $raw ? json_decode($raw, true) : null;
  if (is_array($j)) $selected[] = $j;
}

$agg = [
  'events'=>[], 'pages'=>[], 'sections'=>[], 'devices'=>[], 'modes'=>[],
  'referrers'=>[], 'campaigns'=>[], 'books'=>[], 'articles'=>[], 'tracks'=>[],
  'external'=>[], 'labels'=>[], 'progress'=>[], 'scroll'=>[],
  'value_sums'=>[], 'value_counts'=>[], 'last_event'=>''
];

function addMap(array &$dst, array $src): void {
  foreach ($src as $k=>$v) {
    if (is_numeric($v)) $dst[$k] = (int)($dst[$k] ?? 0) + (int)$v;
  }
}
function addNested(array &$dst, array $src): void {
  foreach ($src as $k=>$sub) {
    if (!is_array($sub)) continue;
    if (!isset($dst[$k]) || !is_array($dst[$k])) $dst[$k] = [];
    foreach ($sub as $sk=>$v) {
      if (str_starts_with((string)$sk, '_')) {
        if (!isset($dst[$k][$sk])) $dst[$k][$sk] = $v;
      } elseif (is_numeric($v)) {
        $dst[$k][$sk] = (int)($dst[$k][$sk] ?? 0) + (int)$v;
      }
    }
  }
}

foreach ($selected as $d) {
  foreach (['events','sections','devices','modes','referrers','campaigns','external','scroll','value_sums','value_counts'] as $k) {
    addMap($agg[$k], is_array($d[$k] ?? null) ? $d[$k] : []);
  }
  foreach (['pages','books','articles','tracks','labels','progress'] as $k) {
    addNested($agg[$k], is_array($d[$k] ?? null) ? $d[$k] : []);
  }
  if (($d['last_event'] ?? '') > $agg['last_event']) $agg['last_event'] = (string)$d['last_event'];
}

function eventCount(array $agg, string $event): int { return (int)($agg['events'][$event] ?? 0); }
function sectionCount(array $agg, string $section): int { return (int)($agg['sections'][$section] ?? 0); }

function pageViews(array $pages): array {
  $out=[];
  foreach($pages as $path=>$events) {
    $v=(int)($events['page_view'] ?? 0);
    if($v>0)$out[$path]=$v;
  }
  arsort($out);
  return $out;
}
function nestedEvent(array $map, string $event): array {
  $out=[];
  foreach($map as $name=>$events) {
    $v=(int)($events[$event] ?? 0);
    if($v>0)$out[$name]=$v;
  }
  arsort($out);
  return $out;
}

$topPages = pageViews($agg['pages']);
$bookViews = nestedEvent($agg['books'], 'page_view');
$readerProgress = $agg['progress'];
$musicPlays = nestedEvent($agg['tracks'], 'music_play');
$articleViews = nestedEvent($agg['articles'], 'page_view');

$summarySum = (int)($agg['value_sums']['page_summary'] ?? 0);
$summaryCount = (int)($agg['value_counts']['page_summary'] ?? 0);
$avgSeconds = $summaryCount ? (int)round($summarySum / $summaryCount) : 0;
$avgTime = sprintf('%d:%02d', intdiv($avgSeconds,60), $avgSeconds%60);

if (isset($_GET['export'])) {
  $type = (string)$_GET['export'];
  header('Content-Type: text/csv; charset=UTF-8');
  header('Content-Disposition: attachment; filename="mavik-stats-' . date('Y-m-d') . '-' . $type . '.csv"');
  echo "\xEF\xBB\xBF";
  $o = fopen('php://output','w');
  if ($type === 'pages') {
    fputcsv($o,['Сторінка','Перегляди'],';');
    foreach($topPages as $k=>$v) fputcsv($o,[$k,$v],';');
  } elseif ($type === 'events') {
    arsort($agg['events']);
    fputcsv($o,['Подія','Кількість'],';');
    foreach($agg['events'] as $k=>$v) fputcsv($o,[$k,$v],';');
  } elseif ($type === 'books') {
    fputcsv($o,['Книга','Перегляди','Поширення','25%','50%','75%','100%'],';');
    foreach($bookViews as $book=>$v) {
      $p=$readerProgress[$book] ?? [];
      fputcsv($o,[$book,$v,$agg['books'][$book]['share_book']??0,$p['25']??0,$p['50']??0,$p['75']??0,$p['100']??0],';');
    }
  }
  fclose($o);
  exit;
}

$rangeLabel = ['1'=>'сьогодні','7'=>'7 днів','30'=>'30 днів','90'=>'90 днів','all'=>'весь час'][$range];
$writable = is_dir($dataDir) && is_writable($dataDir);
?><!doctype html>
<html lang="uk"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>MaVik · Статистика</title><link href="/favicon.ico?v=93" rel="icon" type="image/x-icon"/>
<link href="/assets/app/mavik-icon-192.png?v=93" rel="icon" sizes="192x192" type="image/png"/>
<link href="/assets/app/apple-touch-icon.png?v=93" rel="apple-touch-icon" sizes="180x180"/>
<style>
:root{--bg:#09090a;--panel:#111113;--line:#2a2824;--text:#eee9df;--muted:#9b968d;--gold:#d9bd86}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:14px/1.45 Arial,sans-serif}.wrap{width:min(1480px,calc(100% - 56px));margin:auto;padding:32px 0 70px}.top{display:flex;align-items:flex-end;justify-content:space-between;gap:20px;margin-bottom:26px}.brand{font:500 32px Georgia,serif}.sub{color:var(--muted);margin-top:4px}.actions{display:flex;gap:8px;flex-wrap:wrap}.pill,a.pill{display:inline-flex;align-items:center;border:1px solid var(--line);border-radius:999px;padding:9px 12px;color:var(--text);text-decoration:none;background:#0e0e10}.pill.active{border-color:#806b45;color:var(--gold)}.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:18px 0}.card,.panel{border:1px solid var(--line);background:var(--panel);border-radius:18px}.card{padding:18px}.card b{display:block;font:500 30px Georgia,serif;margin-bottom:4px}.card span{color:var(--muted);font-size:12px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.panel{padding:18px;min-width:0}.panel h2{font:500 20px Georgia,serif;margin:0 0 14px}.table{width:100%;border-collapse:collapse}.table th,.table td{padding:9px 6px;border-top:1px solid #24221f;text-align:left;vertical-align:top}.table th{color:var(--muted);font-size:11px;font-weight:600}.table td:last-child,.table th:last-child{text-align:right}.path{word-break:break-word}.small{font-size:11px;color:var(--muted)}.status{margin:10px 0 18px;color:var(--muted)}.ok{color:#9ccc9c}.bad{color:#ff9f9f}.bar{height:5px;background:#222;border-radius:9px;overflow:hidden;margin-top:5px}.bar i{display:block;height:100%;background:var(--gold);opacity:.75}.footer{color:var(--muted);font-size:11px;margin-top:22px}.exports{margin:18px 0;display:flex;gap:8px;flex-wrap:wrap}@media(max-width:950px){.cards{grid-template-columns:repeat(2,1fr)}.grid{grid-template-columns:1fr}.top{align-items:flex-start;flex-direction:column}}@media(max-width:680px){.wrap{width:calc(100% - 28px);padding-top:22px}.cards{grid-template-columns:1fr 1fr}.card b{font-size:25px}.brand{font-size:28px}.panel{padding:14px}.table{font-size:12px}}
</style></head><body><main class="wrap">
<div class="top"><div><div class="brand">MaVik · Статистика</div><div class="sub">Власна агрегована аналітика · <?=$rangeLabel?></div></div><div class="actions">
<?php foreach(['1'=>'Сьогодні','7'=>'7 днів','30'=>'30 днів','90'=>'90 днів','all'=>'Весь час'] as $k=>$v): ?><a class="pill <?=$range===$k?'active':''?>" href="?range=<?=$k?>"><?=$v?></a><?php endforeach; ?>
<a class="pill" href="/boss/">Boss</a><a class="pill" href="?logout=1">Вийти</a></div></div>

<div class="status">Collector: <b class="<?=$writable?'ok':'bad'?>"><?=$writable?'працює, каталог доступний для запису':'каталог analytics/data не доступний для запису PHP'?></b>
<?php if($agg['last_event']): ?> · остання подія <?=h($agg['last_event'])?><?php endif; ?></div>

<section class="cards">
<div class="card"><b><?=n(eventCount($agg,'page_view'))?></b><span>переглядів сторінок</span></div>
<div class="card"><b><?=n(eventCount($agg,'engaged_30s'))?></b><span>переглядів 30+ секунд</span></div>
<div class="card"><b><?=n(sectionCount($agg,'reader'))?></b><span>відкриттів читанок</span></div>
<div class="card"><b><?=n(eventCount($agg,'ding_click'))?></b><span>натискань «Кава»</span></div>
<div class="card"><b><?=n(eventCount($agg,'epub_download'))?></b><span>завантажень EPUB</span></div>
<div class="card"><b><?=n(eventCount($agg,'music_play'))?></b><span>запусків треків</span></div>
<div class="card"><b><?=n(sectionCount($agg,'blog')+sectionCount($agg,'blog_article'))?></b><span>переглядів блогу</span></div>
<div class="card"><b><?=h($avgTime)?></b><span>середній час сторінки**</span></div>
</section>

<div class="exports"><a class="pill" href="?range=<?=h($range)?>&export=pages">CSV · сторінки</a><a class="pill" href="?range=<?=h($range)?>&export=books">CSV · книги</a><a class="pill" href="?range=<?=h($range)?>&export=events">CSV · події</a></div>

<section class="grid">
<div class="panel"><h2>Найпопулярніші сторінки</h2><table class="table"><tr><th>Сторінка</th><th>Перегляди</th></tr>
<?php foreach(array_slice($topPages,0,15,true) as $k=>$v): ?><tr><td class="path"><?=h($k)?></td><td><?=n($v)?></td></tr><?php endforeach; ?>
</table></div>

<div class="panel"><h2>Книги та дочитування</h2><table class="table"><tr><th>Книга</th><th>Перегляди / поширення / 25 / 50 / 75 / 100%</th></tr>
<?php foreach(array_slice($bookViews,0,20,true) as $book=>$v): $p=$readerProgress[$book]??[]; ?><tr><td><?=h($book)?></td><td><?=n($v)?> / <?=n((int)($agg['books'][$book]['share_book']??0))?> / <?=n((int)($p['25']??0))?> / <?=n((int)($p['50']??0))?> / <?=n((int)($p['75']??0))?> / <?=n((int)($p['100']??0))?></td></tr><?php endforeach; ?>
</table></div>

<div class="panel"><h2>Музика</h2><table class="table"><tr><th>Трек</th><th>Запуски</th></tr>
<?php foreach(array_slice($musicPlays,0,15,true) as $k=>$v): ?><tr><td><?=h($k)?></td><td><?=n($v)?></td></tr><?php endforeach; ?>
</table><div class="small">30 секунд: <?=n(eventCount($agg,'music_30s'))?> · завершено: <?=n(eventCount($agg,'music_complete'))?></div></div>

<div class="panel"><h2>Блог</h2><table class="table"><tr><th>Матеріал</th><th>Перегляди</th></tr>
<?php foreach(array_slice($articleViews,0,15,true) as $k=>$v): ?><tr><td><?=h($k)?></td><td><?=n($v)?></td></tr><?php endforeach; ?>
</table><div class="small">Пошуки: <?=n(eventCount($agg,'blog_search'))?> · кліки тегів: <?=n(eventCount($agg,'blog_tag'))?></div></div>

<div class="panel"><h2>Джерела переходів</h2><table class="table"><tr><th>Джерело</th><th>Перегляди</th></tr>
<?php arsort($agg['referrers']); foreach(array_slice($agg['referrers'],0,15,true) as $k=>$v): ?><tr><td><?=h($k)?></td><td><?=n((int)$v)?></td></tr><?php endforeach; ?>
</table></div>

<div class="panel"><h2>UTM-кампанії</h2><table class="table"><tr><th>source / medium / campaign</th><th>Перегляди</th></tr>
<?php arsort($agg['campaigns']); foreach(array_slice($agg['campaigns'],0,15,true) as $k=>$v): ?><tr><td><?=h($k)?></td><td><?=n((int)$v)?></td></tr><?php endforeach; ?>
</table></div>

<div class="panel"><h2>Пристрої</h2><table class="table"><tr><th>Тип</th><th>Перегляди</th></tr>
<?php arsort($agg['devices']); foreach($agg['devices'] as $k=>$v): ?><tr><td><?=h($k)?></td><td><?=n((int)$v)?></td></tr><?php endforeach; ?>
</table><div class="small">PWA: <?=n((int)($agg['modes']['pwa']??0))?> · браузер: <?=n((int)($agg['modes']['browser']??0))?></div></div>

<div class="panel"><h2>Підтримка</h2><table class="table"><tr><th>Дія</th><th>Кількість</th></tr>
<tr><td>Кава</td><td><?=n(eventCount($agg,'ding_click'))?></td></tr>
<tr><td>Перехід у monobank</td><td><?=n(eventCount($agg,'support_monobank_click'))?></td></tr>
<tr><td>Скопійовано всі реквізити</td><td><?=n(eventCount($agg,'support_copy_all'))?></td></tr>
<tr><td>Відкрито QR</td><td><?=n(eventCount($agg,'support_qr_open'))?></td></tr>
</table></div>

<div class="panel"><h2>Глибина сторінок</h2><table class="table"><tr><th>Максимальна прокрутка</th><th>Сторінки</th></tr>
<?php foreach(['<25','25+','50+','75+','100'] as $k): ?><tr><td><?=h($k)?>%</td><td><?=n((int)($agg['scroll'][$k]??0))?></td></tr><?php endforeach; ?>
</table></div>

<div class="panel"><h2>Зовнішні переходи</h2><table class="table"><tr><th>Домен</th><th>Кліки</th></tr>
<?php arsort($agg['external']); foreach(array_slice($agg['external'],0,15,true) as $k=>$v): ?><tr><td><?=h($k)?></td><td><?=n((int)$v)?></td></tr><?php endforeach; ?>
</table></div>

<div class="panel"><h2>Усі ключові події</h2><table class="table"><tr><th>Подія</th><th>Кількість</th></tr>
<?php arsort($agg['events']); foreach(array_slice($agg['events'],0,25,true) as $k=>$v): ?><tr><td><?=h($k)?></td><td><?=n((int)$v)?></td></tr><?php endforeach; ?>
</table></div>
</section>

<div class="footer">Аналітика сайту зберігає лише агреговані події без cookies і без постійного ідентифікатора читача. Пошуковий текст не передається. ** Середній час рахується для сторінок, де браузер встиг надіслати подію виходу. Cloudflare Web Analytics окремо дає агреговані показники та Web Vitals.</div>
</main></body></html>

<?php
require __DIR__.'/app/bootstrap.php';
maintenance_gate();
$pdo=db();
$categories=$pdo->query("SELECT c.*, (SELECT COUNT(*) FROM topics t WHERE t.category_id=c.id AND t.is_hidden=0) topic_count, (SELECT COUNT(*) FROM posts p JOIN topics t2 ON t2.id=p.topic_id WHERE t2.category_id=c.id AND p.is_hidden=0) post_count, (SELECT t3.title FROM topics t3 WHERE t3.category_id=c.id AND t3.is_hidden=0 ORDER BY t3.updated_at DESC LIMIT 1) latest_title, (SELECT t3.updated_at FROM topics t3 WHERE t3.category_id=c.id AND t3.is_hidden=0 ORDER BY t3.updated_at DESC LIMIT 1) latest_at FROM categories c WHERE c.is_visible=1 ORDER BY sort_order,title")->fetchAll();
$latest=$pdo->query("SELECT t.id,t.title,t.slug,t.updated_at,t.is_pinned,c.title category_title,(SELECT COUNT(*) FROM posts p WHERE p.topic_id=t.id AND p.is_hidden=0) replies FROM topics t JOIN categories c ON c.id=t.category_id WHERE t.is_hidden=0 AND c.is_visible=1 ORDER BY t.is_pinned DESC,t.updated_at DESC LIMIT 6")->fetchAll();
forum_header('Форум');
?>
<section class="forum-hero">
  <div class="forum-hero-copy">
    <h1>Форум</h1>
    <p>Розмови про книги, тексти, музику й читання.</p>
    <form class="search" method="get"><input name="q" placeholder="Пошук по форуму…"><button>Пошук</button></form>
  </div>
  <div class="forum-hero-visual" aria-hidden="true"><img src="/assets/forum-hero.jpg" alt="" width="1160" height="286"></div>
</section>
<div class="hero-actions-row">
  <?php if(is_logged_in() && (setting('maintenance_mode','1')!=='1' || is_admin())): ?><a class="btn primary" href="/new-topic.php">＋ Створити тему</a><?php endif; ?>
</div>
<div class="content-grid">
<section>
  <div class="section-head"><h2>Категорії форуму</h2></div>
  <div class="category-list">
  <?php foreach($categories as $c): ?>
    <a class="category-card" href="/category.php?slug=<?=urlencode($c['slug'])?>">
      <div class="cat-icon"><?=category_icon($c['slug'])?></div>
      <div class="cat-copy"><h3><?=e($c['title'])?></h3><p><?=e($c['description'])?></p></div>
      <div class="cat-count"><strong><?=e((string)$c['topic_count'])?></strong><span>тем</span></div>
      <div class="cat-count replies"><strong><?=e((string)$c['post_count'])?></strong><span>відповідей</span></div>
      <div class="cat-latest"><strong><?=e($c['latest_title'] ?: 'Поки без тем')?></strong><?php if($c['latest_at']):?><span><?=e(format_forum_date($c['latest_at']))?></span><?php endif;?></div>
      <div class="arrow">›</div>
    </a>
  <?php endforeach; ?>
  </div>
  <div class="section-head recent-head"><h2>Останні теми</h2></div>
  <div class="topic-list">
  <?php foreach($latest as $t): ?>
    <a class="topic-row" href="/topic.php?slug=<?=urlencode($t['slug'])?>">
      <div><strong><?=e($t['title'])?></strong><span><?=e($t['category_title'])?><?=($t['is_pinned']?' · закріплено':'')?></span></div>
      <div class="topic-meta"><span><?=e((string)$t['replies'])?> відповідей</span><span><?=e(format_forum_date($t['updated_at']))?></span></div>
    </a>
  <?php endforeach; ?>
  </div>
</section>
<aside>
  <div class="panel welcome-panel"><h3>Ласкаво просимо!</h3><p>Приєднуйтесь до спільноти, щоб брати участь в обговореннях, ділитися думками та знаходити однодумців.</p><?php if(is_admin()): ?><a class="btn primary block" href="/admin/">Адмінка форуму</a><?php elseif(is_logged_in()): ?><a class="btn primary block" href="/new-topic.php">Створити тему</a><?php else: ?><a class="btn primary block" href="/auth.php">Увійти</a><?php endif; ?></div>
  <div class="panel"><h3>Останні обговорення</h3><div class="aside-discussions"><?php foreach(array_slice($latest,0,5) as $t):?><a href="/topic.php?slug=<?=urlencode($t['slug'])?>"><strong><?=e($t['title'])?></strong><span><?=e(format_forum_date($t['updated_at']))?></span></a><?php endforeach;?></div></div>
  <div class="panel"><h3>Правила форуму</h3><p>Писати можна про все. Головне — не ображати ближнього.</p><a class="quiet-link" href="/rules.php">Читати правила →</a></div>
  <div class="panel"><h3>Популярні теги</h3><div class="tags"><span>#книги</span><span>#українська_література</span><span>#поезія</span><span>#музика</span><span>#читання</span><span>#дискусія</span></div></div>
</aside>
</div>
<?php forum_footer(); ?>

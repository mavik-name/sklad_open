<?php
require __DIR__.'/../app/bootstrap.php'; admin_required(); $pdo=db(); $notice=''; $error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 csrf_check();$action=(string)($_POST['action']??'');$id=(int)($_POST['id']??0);
 if($action==='toggle'&&$id){$pdo->prepare('UPDATE categories SET is_visible=CASE is_visible WHEN 1 THEN 0 ELSE 1 END WHERE id=?')->execute([$id]);$notice='Статус категорії змінено.';}
 elseif($action==='add'){$title=trim((string)($_POST['title']??''));$desc=trim((string)($_POST['description']??''));if($title!==''){$base=iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$title)?:'category';$slug=trim(preg_replace('/[^a-z0-9]+/','-',strtolower($base)),'-').'-'.substr(bin2hex(random_bytes(2)),0,4);$max=(int)$pdo->query('SELECT COALESCE(MAX(sort_order),0) FROM categories')->fetchColumn()+10;$pdo->prepare('INSERT INTO categories(slug,title,description,sort_order) VALUES(?,?,?,?)')->execute([$slug,$title,$desc,$max]);$notice='Категорію створено.';}}
 elseif($action==='edit'&&$id){$title=trim((string)($_POST['title']??''));$desc=trim((string)($_POST['description']??''));if($title!==''){$pdo->prepare('UPDATE categories SET title=?,description=? WHERE id=?')->execute([$title,$desc,$id]);$notice='Категорію оновлено.';}}
 elseif($action==='move'&&$id){$dir=(string)($_POST['dir']??'');$current=$pdo->prepare('SELECT id,sort_order FROM categories WHERE id=?');$current->execute([$id]);$c=$current->fetch();if($c){$op=$dir==='up'?'<': '>';$ord=$dir==='up'?'DESC':'ASC';$q=$pdo->prepare("SELECT id,sort_order FROM categories WHERE sort_order $op ? ORDER BY sort_order $ord LIMIT 1");$q->execute([$c['sort_order']]);$other=$q->fetch();if($other){$pdo->beginTransaction();$pdo->prepare('UPDATE categories SET sort_order=? WHERE id=?')->execute([$other['sort_order'],$c['id']]);$pdo->prepare('UPDATE categories SET sort_order=? WHERE id=?')->execute([$c['sort_order'],$other['id']]);$pdo->commit();$notice='Порядок категорій змінено.';}}}
 elseif($action==='reorder'){
   $raw=(string)($_POST['order']??'');
   $ids=array_values(array_filter(array_map('intval',explode(',',$raw))));
   if($ids){$pdo->beginTransaction();$st=$pdo->prepare('UPDATE categories SET sort_order=? WHERE id=?');foreach($ids as $i=>$catId){$st->execute([($i+1)*10,$catId]);}$pdo->commit();$notice='Порядок категорій збережено.';}
 }
 elseif($action==='delete'&&$id){$count=$pdo->prepare('SELECT COUNT(*) FROM topics WHERE category_id=?');$count->execute([$id]);$n=(int)$count->fetchColumn();if($n>0){$error='Категорія містить теми. Спочатку перенесіть їх в іншу категорію або просто приховайте цю.';}else{$pdo->prepare('DELETE FROM categories WHERE id=?')->execute([$id]);$notice='Категорію видалено.';}}
}
$cats=$pdo->query('SELECT c.*,(SELECT COUNT(*) FROM topics t WHERE t.category_id=c.id) topics FROM categories c ORDER BY sort_order,title')->fetchAll();forum_header('Категорії — Admin');
?>
<section class="page-title admin-title"><div><a href="/admin/">← Адмінка</a><h1>Категорії</h1><p>Порядок тут визначає порядок категорій у публічному форумі.</p></div></section>
<?php if($notice):?><div class="notice success"><?=e($notice)?></div><?php endif;?><?php if($error):?><div class="notice danger"><?=e($error)?></div><?php endif;?>
<form method="post" class="panel stack settings-form"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="add"><h3>Нова категорія</h3><label>Назва<input name="title" required></label><label>Опис<textarea name="description" rows="3"></textarea></label><button class="btn primary">Додати</button></form>
<form method="post" id="categoryOrderForm" class="category-order-form"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="reorder"><input type="hidden" name="order" id="categoryOrderValue" value=""></form>
<div class="admin-table category-admin-list" id="categorySortable">
<?php foreach($cats as $index=>$c):?><div class="admin-row category-admin-row" draggable="true" data-category-id="<?=e((string)$c['id'])?>"><div class="drag-handle" title="Перетягнути" aria-label="Перетягнути">⋮⋮</div><div class="category-admin-main"><strong><?=e($c['title'])?></strong><span><?=e((string)$c['topics'])?> тем · <?=($c['is_visible']?'видима':'прихована')?></span><small><?=e($c['description'])?></small></div><div class="row-actions">
<details class="edit-details"><summary class="btn">Редагувати</summary><form method="post" class="edit-category-form"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="edit"><input type="hidden" name="id" value="<?=e((string)$c['id'])?>"><input name="title" value="<?=e($c['title'])?>" required><textarea name="description" rows="3"><?=e($c['description'])?></textarea><button class="btn primary">Зберегти</button></form></details>
<form method="post"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?=e((string)$c['id'])?>"><button class="btn"><?=$c['is_visible']?'Приховати':'Показати'?></button></form>
<form method="post" onsubmit="return confirm('Видалити порожню категорію?');"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=e((string)$c['id'])?>"><button class="btn danger-btn">Видалити</button></form>
</div></div><?php endforeach;?>
</div>
<div class="category-order-actions"><button class="btn primary" type="submit" form="categoryOrderForm">Зберегти порядок</button><span>Перетягни категорії у потрібному порядку.</span></div>
<script>
(()=>{const box=document.getElementById('categorySortable'),out=document.getElementById('categoryOrderValue'),form=document.getElementById('categoryOrderForm');if(!box||!out||!form)return;let drag=null;const sync=()=>out.value=[...box.querySelectorAll('[data-category-id]')].map(x=>x.dataset.categoryId).join(',');sync();box.querySelectorAll('[draggable="true"]').forEach(row=>{row.addEventListener('dragstart',()=>{drag=row;row.classList.add('dragging')});row.addEventListener('dragend',()=>{row.classList.remove('dragging');drag=null;sync()});row.addEventListener('dragover',e=>{e.preventDefault();if(!drag||drag===row)return;const r=row.getBoundingClientRect();const after=e.clientY>r.top+r.height/2;box.insertBefore(drag,after?row.nextSibling:row)});});form.addEventListener('submit',sync);})();
</script>
<?php forum_footer(); ?>

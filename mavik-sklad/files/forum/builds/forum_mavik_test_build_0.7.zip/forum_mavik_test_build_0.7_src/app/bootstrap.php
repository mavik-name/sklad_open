<?php
declare(strict_types=1);

session_start();

const APP_ROOT = __DIR__ . '/..';
const DB_PATH = APP_ROOT . '/storage/forum.sqlite';

function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    if (!file_exists(DB_PATH)) {
        header('Location: /install.php');
        exit;
    }
    $pdo = new PDO('sqlite:' . DB_PATH, null, null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    $pdo->exec('PRAGMA foreign_keys = ON');
    $pdo->exec('PRAGMA journal_mode = WAL');
    forum_migrate($pdo);
    return $pdo;
}


function forum_migrate(PDO $pdo): void {
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        $cols = $pdo->query("PRAGMA table_info(posts)")->fetchAll();
        $names = array_column($cols, 'name');
        if (!in_array('parent_post_id', $names, true)) {
            $pdo->exec('ALTER TABLE posts ADD COLUMN parent_post_id INTEGER');
        }
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_topics_activity ON topics(is_hidden, is_pinned DESC, updated_at DESC)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_categories_sort ON categories(is_visible, sort_order, title)');
    } catch (Throwable $e) {
        // Installation/upgrade remains usable even if an optional index cannot be created.
    }
}

function setting(string $key, ?string $default = null): ?string {
    $stmt = db()->prepare('SELECT value FROM settings WHERE key = :key');
    $stmt->execute([':key' => $key]);
    $row = $stmt->fetch();
    return $row ? (string)$row['value'] : $default;
}

function set_setting(string $key, string $value): void {
    $stmt = db()->prepare('INSERT INTO settings(key, value) VALUES(:key,:value) ON CONFLICT(key) DO UPDATE SET value=excluded.value');
    $stmt->execute([':key'=>$key, ':value'=>$value]);
}

function e(?string $v): string {
    return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
function is_admin(): bool { return !empty($_SESSION['admin_id']); }
function is_logged_in(): bool { return !empty($_SESSION['user_id']) || is_admin(); }
function current_user_id(): ?int {
    return isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : (isset($_SESSION['admin_id']) ? (int)$_SESSION['admin_id'] : null);
}
function member_required(): void { if (!is_logged_in()) { header('Location: /auth.php'); exit; } }
function admin_required(): void { if (!is_admin()) { header('Location: /admin/login.php'); exit; } }

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(24));
    return (string)$_SESSION['csrf'];
}
function csrf_check(): void {
    if (!hash_equals((string)($_SESSION['csrf'] ?? ''), (string)($_POST['csrf'] ?? ''))) {
        http_response_code(419);
        exit('Невірний CSRF-токен. Оновіть сторінку.');
    }
}

function maintenance_gate(): void {
    if (is_admin()) return;
    if (setting('maintenance_mode', '1') !== '1') return;
    $guestPassHash = setting('maintenance_password_hash', '');
    if (!empty($_SESSION['maintenance_ok'])) return;
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['maintenance_password']) && $guestPassHash) {
        if (password_verify((string)$_POST['maintenance_password'], $guestPassHash)) {
            $_SESSION['maintenance_ok'] = true;
            header('Location: /');
            exit;
        }
    }
    header('X-Robots-Tag: noindex, nofollow, noarchive', true);
    http_response_code(503);
    header('Retry-After: 3600');
    require APP_ROOT . '/maintenance.php';
    exit;
}

function category_icon(string $slug): string {
    $common = 'viewBox="0 0 24 24" aria-hidden="true" focusable="false"';
    $icons = [
        'knyhy' => '<svg '.$common.'><path d="M3.5 5.5c2.7-1 5.5-.6 8 1.2v12c-2.5-1.8-5.3-2.2-8-1.2zM20.5 5.5c-2.7-1-5.5-.6-8 1.2v12c2.5-1.8 5.3-2.2 8-1.2z"/></svg>',
        'poeziia' => '<svg '.$common.'><path d="M20 4C13 4 7 8 5 15c4 1 8 0 11-3 2-2 3-5 4-8ZM5 19c3-5 7-8 12-11"/></svg>',
        'blog-i-teksty' => '<svg '.$common.'><path d="M6 3.5h8l4 4V20.5H6zM14 3.5v4h4M9 12h6M9 15.5h6"/></svg>',
        'muzyka' => '<svg '.$common.'><path d="M9 18V6l9-2v12M9 9l9-2M6.5 20a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5ZM15.5 18a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z"/></svg>',
        'shcho-chytaiete' => '<svg '.$common.'><path d="M5 8h11v7a4 4 0 0 1-4 4H9a4 4 0 0 1-4-4zM16 10h2a2 2 0 0 1 0 4h-2M7 4c0 1 1 1 1 2M11 4c0 1 1 1 1 2M15 4c0 1 1 1 1 2M4 21h14"/></svg>',
        'pytannia-do-avtora' => '<svg '.$common.'><circle cx="12" cy="12" r="9"/><path d="M9.8 9a2.4 2.4 0 1 1 3.6 2.1c-.9.5-1.4 1-1.4 2M12 17h.01"/></svg>',
        'vilne' => '<svg '.$common.'><path d="M4 5.5h16v10H9l-4.5 3v-3H4z"/></svg>',
    ];
    return $icons[$slug] ?? '<svg '.$common.'><circle cx="12" cy="12" r="8"/></svg>';
}

function render_forum_text(string $text): string {
    $lines = preg_split('/\R/u', $text) ?: [];
    $out = '';
    $quote = [];
    $flushQuote = static function() use (&$quote, &$out): void {
        if (!$quote) return;
        $out .= '<blockquote class="post-quote">' . implode('<br>', array_map('e', $quote)) . '</blockquote>';
        $quote = [];
    };
    foreach ($lines as $line) {
        if (preg_match('/^>\s?(.*)$/u', $line, $m)) {
            $quote[] = $m[1];
            continue;
        }
        $flushQuote();
        if (trim($line) === '') $out .= '<br>';
        else $out .= '<div class="post-line">'.e($line).'</div>';
    }
    $flushQuote();
    return $out;
}

function format_forum_date(string $date): string {
    $ts = strtotime($date);
    if (!$ts) return $date;
    return date('d.m.Y · H:i', $ts);
}

function forum_header(string $title): void {
    $maintenance = setting('maintenance_mode','1') === '1';
    $accountLabel = is_admin() ? 'Адмінка' : (is_logged_in() ? 'Вийти' : 'Увійти');
    $accountUrl = is_admin() ? '/admin/' : (is_logged_in() ? '/auth.php?logout=1' : '/auth.php');
    ?>
<!doctype html>
<html lang="uk">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title><?=e($title)?> — Форум MaVik</title>
<meta name="theme-color" content="#0b0b0c">
<link rel="stylesheet" href="/assets/style.css?v=0.6">
<?php if ($maintenance): ?><meta name="robots" content="noindex,nofollow,noarchive"><?php endif; ?>
</head>
<body>
<header class="site-header nav">
  <div class="wrap header-inner nav-inner">
    <a class="site-brand" href="https://mavik.name/" aria-label="MaVik — Макарчук Віктор">
      <img src="/assets/mavik-logo.png" width="227" height="80" alt="MaVik — Макарчук Віктор">
    </a>
    <nav class="desktop-menu menu" aria-label="Головне меню">
      <a href="https://mavik.name/books/">Книги</a>
      <a href="https://mavik.name/music/">Музика</a>
      <a href="https://mavik.name/blog/">Блог</a>
      <a href="https://mavik.name/about/">Автор</a>
      <a href="https://mavik.name/announcements/">Анонси</a>
      <a class="active" href="/">Форум</a>
      <a class="coffee-nav" href="https://mavik.name/support" aria-label="Пригостити автора кавою" title="Пригостити автора кавою"><img src="/assets/icons/coffee.svg" alt="" width="42" height="42"></a>
    </nav>
    <a class="account-link" href="<?=e($accountUrl)?>"><?=e($accountLabel)?></a>
    <button aria-controls="mobileMenu" aria-expanded="false" aria-label="Відкрити меню" class="mobile-menu-toggle" id="mobileMenuToggle" type="button"><span></span><span></span><span></span></button>
  </div>
  <nav aria-hidden="true" aria-label="Мобільне меню" class="mobile-menu" id="mobileMenu">
    <div class="mobile-menu-inner">
      <a href="https://mavik.name/books/">Книги</a>
      <a href="https://mavik.name/music/">Музика</a>
      <a href="https://mavik.name/blog/">Блог</a>
      <a href="https://mavik.name/about/">Автор</a>
      <a href="https://mavik.name/announcements/">Анонси</a>
      <a class="active" href="/">Форум</a>
      <a href="<?=e($accountUrl)?>"><?=e($accountLabel)?></a>
    </div>
  </nav>
</header>
<?php if ($maintenance && is_admin()): ?><div class="maintenance-bar">Форум закритий для публіки · <a href="/admin/settings.php">Режим доступу</a></div><?php endif; ?>
<main class="wrap site-main" id="top">
<?php
}

function forum_footer(): void { ?>
</main>
<footer class="site-footer">
  <div class="wrap footer-copy">
    <div>© 2026 · Макарчук Віктор - MaVik®</div>
    <div>Всі права застережено</div>
    <div class="footer-links"><a href="https://mavik.name/mavik/">Про MaVik</a><i>·</i><a href="https://mavik.name/copyright/">Правова охорона творчого доробку</a><i>·</i><a href="https://mavik.name/privacy/">Приватність</a><i>·</i><a href="mailto:viktor@mavik.name">viktor@mavik.name</a><i>·</i><a href="/rules.php">Правила форуму</a></div>
  </div>
</footer>
<div class="floating-controls" aria-label="Швидкі дії">
  <a class="floating-btn coffee-float" href="https://mavik.name/support" aria-label="Пригостити автора кавою" title="Кава"><img src="/assets/icons/coffee.svg" alt="" width="48" height="48"></a>
  <button class="floating-btn to-top" id="toTop" type="button" aria-label="Догори" title="Догори"><img src="/assets/icons/arrow-up.svg" alt="" width="48" height="48"></button>
</div>
<script>
(()=>{
  const toggle=document.getElementById('mobileMenuToggle');
  const menu=document.getElementById('mobileMenu');
  const close=()=>{if(!toggle||!menu)return;menu.classList.remove('open');toggle.classList.remove('open');toggle.setAttribute('aria-expanded','false');toggle.setAttribute('aria-label','Відкрити меню');menu.setAttribute('aria-hidden','true');document.documentElement.classList.remove('menu-open')};
  if(toggle&&menu){toggle.addEventListener('click',()=>{const isOpen=menu.classList.contains('open');if(isOpen){close();return;}menu.classList.add('open');toggle.classList.add('open');toggle.setAttribute('aria-expanded','true');toggle.setAttribute('aria-label','Закрити меню');menu.setAttribute('aria-hidden','false');document.documentElement.classList.add('menu-open')});menu.querySelectorAll('a').forEach(a=>a.addEventListener('click',close));window.addEventListener('resize',()=>{if(window.innerWidth>780)close()});}
  const top=document.getElementById('toTop');
  if(top){const sync=()=>top.classList.toggle('visible',window.scrollY>420);window.addEventListener('scroll',sync,{passive:true});sync();top.addEventListener('click',()=>window.scrollTo({top:0,behavior:'smooth'}));}
  document.querySelectorAll('[data-reply-to]').forEach(btn=>btn.addEventListener('click',()=>{
    const form=document.getElementById('replyForm'), ta=document.getElementById('replyBody'), meta=document.getElementById('replyTarget'), parent=document.getElementById('parentPostId');
    if(!form||!ta)return; if(parent)parent.value=btn.dataset.replyTo||''; if(meta)meta.textContent='Відповідь на повідомлення '+(btn.dataset.author||'учасника'); form.scrollIntoView({behavior:'smooth',block:'center'}); setTimeout(()=>ta.focus(),250);
  }));
  document.querySelectorAll('[data-quote]').forEach(btn=>btn.addEventListener('click',()=>{
    const form=document.getElementById('replyForm'), ta=document.getElementById('replyBody'), parent=document.getElementById('parentPostId'); if(!form||!ta)return;
    const author=btn.dataset.author||'Учасник'; const text=(btn.dataset.quote||'').trim().replace(/\s+/g,' '); const excerpt=text.length>280?text.slice(0,280)+'…':text;
    const quoted='> '+author+': '+excerpt.replace(/\n/g,'\n> ')+'\n\n'; ta.value=quoted+ta.value; if(parent)parent.value=btn.dataset.replyTo||''; form.scrollIntoView({behavior:'smooth',block:'center'}); setTimeout(()=>ta.focus(),250);
  }));
})();
</script>
</body></html>
<?php }

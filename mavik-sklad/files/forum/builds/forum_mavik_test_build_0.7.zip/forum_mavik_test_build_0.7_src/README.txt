forum.mavik.name — TEST BUILD 0.1

1. Завантажити в document root піддомену forum.mavik.name.
2. Переконатися, що PHP має PDO_SQLite та право запису в /storage.
3. Відкрити https://forum.mavik.name/install.php
4. Створити адміністратора.
5. Увійти в /admin/
6. Форум після встановлення ЗА ЗАМОВЧУВАННЯМ закритий (maintenance).
7. Після першого успішного встановлення видалити install.php.

Важливо:
- SQLite: /storage/forum.sqlite (закрито .htaccess).
- До публічного запуску robots.txt блокує весь форум.
- Maintenance повертає HTTP 503 і X-Robots-Tag: noindex, nofollow, noarchive.
- Адмін може задати окремий пароль тестового перегляду.
- Google/Telegram у цій збірці не активовані без реальних credentials.

<?php
declare(strict_types=1);
date_default_timezone_set('Europe/Kyiv');

$config = require __DIR__ . '/config.php';
$root = realpath((string)$config['site_root']);
if (!$root) { http_response_code(500); exit('Site root error'); }
require_once $root . '/_site-admin/state.php';
require_once $root . '/_site-admin/workspace-github.php';
require $root . '/_site-admin/auth.php';
require_once $root . '/_site-admin/reader-text.php';
require_once $root . '/_site-admin/reader-errors.php';
require_once $root . '/_site-admin/deploy.php';
require_once $root . '/_site-admin/seo-tools.php';
require_once $root . '/_site-admin/core.php';
require_once $root . '/_site-admin/mail-client.php';
require_once $root . '/_site-admin/contact-inbox.php';
require_once $root . '/_site-admin/stats-lite.php';
mavik_owner_session_start();
header('Cache-Control: no-store, private');
header('X-Robots-Tag: noindex, nofollow, noarchive');

function mavik_cleanup_obsolete_tts(string $root): void {
  foreach(['azure-tts.json','tts-usage.json','tts-usage.lock'] as $name){$q=$root.'/_site-state/'.$name;if(is_file($q))@unlink($q);}
  $q=$root.'/_site-admin/tts-generate.lock';if(is_file($q))@unlink($q);
  $dir=$root.'/assets/audiobooks';if(is_dir($dir)){$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);foreach($it as $f){$q=$f->getPathname();if($f->isDir()&&!$f->isLink())@rmdir($q);else @unlink($q);}@rmdir($dir);}
}

function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function mavik_editor_internal_picker_html(): string {
  global $manifest;
  $fixed=[
    '/'=>'Головна','/books/'=>'Книги','/books/new/'=>'Новинки','/books/free/'=>'Безкоштовні книги','/blog/'=>'Блог',
    '/shcho-pochytaty/'=>'Що почитати','/fantastyka-ukrainskoyu/'=>'Фантастика українською','/sotsialna-fantastyka/'=>'Соціальна фантастика','/antiutopiia/'=>'Антиутопія',
    '/about/'=>'Автор','/contact/'=>'Контакт','/copyright/'=>'Авторські права','/privacy/'=>'Приватність','/platforms/'=>'Платформи'
  ];
  $out='<select class="link-picker internal-link-picker" data-mavik-internal-link aria-label="Внутрішнє посилання"><option value="">Внутрішнє посилання…</option><optgroup label="Сторінки">';
  foreach($fixed as $url=>$title)$out.='<option value="'.h($url).'" data-title="'.h($title).'">'.h($title).'</option>';
  $out.='</optgroup>';
  $books=(array)($manifest['books']??[]); if($books){$out.='<optgroup label="Книги">';foreach($books as $b){if(!is_array($b)||!empty($b['deleted'])||!empty($b['hidden'])||(string)($b['placement']??'books')==='direct')continue;$slug=trim((string)($b['slug']??''));$title=trim((string)($b['title']??''));if($slug===''||$title==='')continue;$out.='<option value="/books/'.h($slug).'/" data-title="'.h($title).'">'.h($title).'</option>';}$out.='</optgroup>';}
  $posts=blog_sorted((array)($manifest['blog']??[])); if($posts){$out.='<optgroup label="Блог">';foreach($posts as $b){if(!is_array($b))continue;$slug=trim((string)($b['slug']??''));$title=trim((string)($b['title']??''));if($slug===''||$title==='')continue;$out.='<option value="/blog/'.h($slug).'/" data-title="'.h($title).'">'.h($title).'</option>';}$out.='</optgroup>';}
  return $out.'</select>';
}
function mavik_editor_toolbar_html(string $extra=''): string {
  return '<button type="button" data-editor-mode="visual" class="wide active">Візуальний</button>'
    .'<button type="button" data-editor-mode="html" class="wide">&lt;/&gt; HTML</button>'
    .'<button type="button" data-cmd="bold" title="Жирний"><b>B</b></button>'
    .'<button type="button" data-cmd="italic" title="Курсив"><i>I</i></button>'
    .'<button type="button" data-cmd="underline" title="Підкреслення"><u>U</u></button>'
    .'<button type="button" data-block="p" class="wide">Абзац</button>'
    .'<button type="button" data-block="h2" class="wide">H2</button>'
    .'<button type="button" data-block="h3" class="wide">H3</button>'
    .'<button type="button" data-block="blockquote" title="Цитата">❝</button>'
    .'<button type="button" data-cmd="insertUnorderedList" title="Маркований список">• Список</button>'
    .'<button type="button" data-cmd="insertOrderedList" title="Нумерований список">1. Список</button>'
    .'<button type="button" data-cmd="justifyLeft" title="Вирівняти ліворуч">Ліво</button>'
    .'<button type="button" data-cmd="justifyCenter" title="Вирівняти по центру">Центр</button>'
    .'<button type="button" data-cmd="justifyRight" title="Вирівняти праворуч">Право</button>'
    .'<button type="button" data-link class="wide">Зовнішнє / URL</button>'
    .mavik_editor_internal_picker_html()
    .$extra
    .'<button type="button" data-cmd="unlink" title="Прибрати посилання">× link</button>'
    .'<select data-mavik-text-style aria-label="Колір тексту"><option value="">Колір тексту</option><option value="mavik-text-gold">Золотий</option><option value="mavik-text-light">Світло-сірий</option><option value="mavik-text-black">Чорний</option><option value="mavik-text-white">Білий</option></select>'
    .'<select data-mavik-bg-style aria-label="Фонове виділення"><option value="">Фон</option><option value="mavik-bg-gold">Золотий</option><option value="mavik-bg-light">Світло-сірий</option></select>'
    .'<button type="button" data-cmd="undo" title="Скасувати">↶</button>'
    .'<button type="button" data-cmd="redo" title="Повторити">↷</button>'
    .'<button type="button" data-cmd="removeFormat" class="wide">Очистити формат</button>';
}
function mavik_editor_externalize_links(string $html): string {
  if(trim($html)==='')return '';
  return preg_replace_callback('#<a\\b([^>]*)>#iu',static function($m){
    $attrs=(string)$m[1];$href='';
    if(preg_match('/\\bhref\\s*=\\s*(["\\\'])(.*?)\\1/iu',$attrs,$hm))$href=html_entity_decode((string)$hm[2],ENT_QUOTES|ENT_HTML5,'UTF-8');
    if($href!==''&&preg_match('#^https?://#i',$href)){
      $host=strtolower((string)(parse_url($href,PHP_URL_HOST)??''));
      $attrs=preg_replace('/\\s+target\\s*=\\s*(["\\\']).*?\\1/iu','',$attrs)??$attrs;
      $attrs=preg_replace('/\\s+rel\\s*=\\s*(["\\\']).*?\\1/iu','',$attrs)??$attrs;
      if($host!==''&&!in_array($host,['mavik.name','www.mavik.name'],true))$attrs.=' target="_blank" rel="noopener noreferrer"';
    }
    return '<a'.$attrs.'>';
  },$html)??$html;
}
function mavik_reader_heading_looks_like_prose(string $text): bool {
  $text=trim(preg_replace('/\s+/u',' ',strip_tags(html_entity_decode($text,ENT_QUOTES|ENT_HTML5,'UTF-8')))??$text);$len=mavik_utf8_strlen($text);$sent=preg_match_all('/[.!?…](?:\s|$)/u',$text,$m)?:0;return ($len>120&&$sent>=3)||$len>220;
}
function mavik_editor_prepare_book_html(string $raw): array {
  $body=mavik_core_sanitize_html($raw);$body=mavik_editor_externalize_links($body);$body=mavik_reader_normalize_headings($body);
  if(trim(strip_tags($body))==='')throw new RuntimeException('Текст книги порожній.');
  return ['body'=>$body,'toc'=>mavik_reader_toc_from_body($body)];
}
function mavik_img_attrs(string $root,string $src,bool $lazy=true,bool $priority=false): string {
  $path=(string)(parse_url($src,PHP_URL_PATH)??$src);$dims=false;if($path!==''&&str_starts_with($path,'/'))$dims=@getimagesize(rtrim($root,'/').'/'.ltrim(rawurldecode($path),'/'));$wh=is_array($dims)&&!empty($dims[0])&&!empty($dims[1])?' width="'.(int)$dims[0].'" height="'.(int)$dims[1].'"':'';return $wh.' decoding="async"'.($lazy?' loading="lazy"':' loading="eager"').($priority?' fetchpriority="high"':'');
}
function mavik_display_image_url(string $url): string {
  $url=trim($url);if($url===''||str_contains($url,'?'))return $url;$path=(string)(parse_url($url,PHP_URL_PATH)??'');if(str_starts_with($path,'/images/covers/')||str_starts_with($path,'/images/blog/'))return $url.'?v=250v20c3';return $url;
}

function mavik_release_info(string $root): array {
  $f=$root.'/.mavik-release.json';$raw=is_file($f)?file_get_contents($f):false;$j=$raw?json_decode($raw,true):null;
  if(!is_array($j))return ['release'=>'?','generated_at'=>''];
  $label=trim((string)($j['release_label']??''));if($label==='')$label=(string)($j['release']??'?');return ['release'=>$label,'generated_at'=>(string)($j['generated_at']??'')];
}
function mavik_release_time_ua(string $iso): string {
  if($iso==='')return 'час невідомий';
  try{$d=new DateTimeImmutable($iso);$d=$d->setTimezone(new DateTimeZone('Europe/Kyiv'));return $d->format('d.m.Y H:i');}
  catch(Throwable $e){return $iso;}
}
function authed(): bool { return mavik_owner_authed(); }
function csrf(): string {
  if (empty($_SESSION['mavik_boss_csrf'])) $_SESSION['mavik_boss_csrf'] = bin2hex(random_bytes(24));
  return $_SESSION['mavik_boss_csrf'];
}
function csrf_ok(string $s): bool { return isset($_SESSION['mavik_boss_csrf']) && hash_equals($_SESSION['mavik_boss_csrf'], $s); }
function slugify(string $s): string {
  $map=['а'=>'a','б'=>'b','в'=>'v','г'=>'h','ґ'=>'g','д'=>'d','е'=>'e','є'=>'ye','ж'=>'zh','з'=>'z','и'=>'y','і'=>'i','ї'=>'yi','й'=>'i','к'=>'k','л'=>'l','м'=>'m','н'=>'n','о'=>'o','п'=>'p','р'=>'r','с'=>'s','т'=>'t','у'=>'u','ф'=>'f','х'=>'kh','ц'=>'ts','ч'=>'ch','ш'=>'sh','щ'=>'shch','ь'=>'','ю'=>'iu','я'=>'ia','’'=>'','\''=>'','`'=>''];
  $s=mavik_utf8_lower(trim($s)); $s=strtr($s,$map); $s=preg_replace('/[^a-z0-9]+/','-',$s)??''; return trim($s,'-');
}
function book_platform_links_from_post(): array {
  $labels=array_values(array_map('strval',(array)($_POST['platform_label']??[])));$urls=array_values(array_map('strval',(array)($_POST['platform_url']??[])));$out=[];$n=max(count($labels),count($urls));
  for($i=0;$i<$n&&$i<20;$i++){$label=trim($labels[$i]??'');$url=trim($urls[$i]??'');if($label===''&&$url==='')continue;if($label===''||$url==='')throw new RuntimeException('Для посилання на платформу заповніть і назву, і URL.');if(mavik_utf8_strlen($label)>80)throw new RuntimeException('Назва платформи має бути до 80 символів.');if(!filter_var($url,FILTER_VALIDATE_URL)||!preg_match('#^https://#i',$url))throw new RuntimeException('Посилання платформи має бути повною адресою https://.');$out[]=['label'=>$label,'url'=>$url];}
  return $out;
}
function book_language_value(string $lang): string {
  $lang=strtolower(trim(str_replace('_','-',$lang)));
  if(in_array($lang,['pl','pl-pl'],true))return 'pl-PL';
  return 'uk-UA';
}
function book_og_locale(string $lang): string {
  return book_language_value($lang)==='pl-PL'?'pl_PL':'uk_UA';
}
function book_language_placement_guard(string $language,string $placement): void {
  if($language==='pl-PL'&&$placement!=='direct')throw new RuntimeException('Польська мова дозволена лише для окремої книги за прямим посиланням. Сайт не має міжнародної версії.');
}
function book_platform_rows_html(array $links=[]): string {
  if(!$links)$links=[['label'=>'','url'=>'']];$out='';foreach($links as $x)$out.='<div class="platform-link-row"><label>Платформа<input name="platform_label[]" maxlength="80" value="'.h((string)($x['label']??'')).'" placeholder="Наприклад: Аркуш"></label><label>Посилання<input type="url" name="platform_url[]" value="'.h((string)($x['url']??'')).'" placeholder="https://..."></label><button class="mini-btn danger platform-remove" type="button" aria-label="Видалити посилання">×</button></div>';return $out;
}
function atomic_write(string $file,string $data): void {
  $dir=dirname($file);
  if(!is_dir($dir) && !mkdir($dir,0755,true) && !is_dir($dir)) throw new RuntimeException('Не вдалося створити каталог.');
  $tmp=$file.'.tmp-'.bin2hex(random_bytes(4));
  if(file_put_contents($tmp,$data,LOCK_EX)===false) throw new RuntimeException('Помилка запису.');
  if(!rename($tmp,$file)){@unlink($tmp);throw new RuntimeException('Помилка заміни файлу.');}
}
function load_manifest(array $config): array {
  $f=(string)$config['manifest'];$seed=(string)($config['manifest_seed']??'');
  // LIVE DATA is authoritative. state-defaults are used once, only when live state does not exist.
  if(!is_file($f)&&$seed!==''&&is_file($seed)){$raw=file_get_contents($seed);if($raw!==false)atomic_write($f,$raw);}
  $raw=is_file($f)?file_get_contents($f):false;$j=$raw?json_decode($raw,true):null;if(!is_array($j))$j=['version'=>7,'blog'=>[],'books'=>[]];
  if(!isset($j['blog'])||!is_array($j['blog']))$j['blog']=[];if(!isset($j['books'])||!is_array($j['books']))$j['books']=[];$changed=false;
  foreach($j['blog'] as &$x)if(is_array($x)){$x['hidden']=!empty($x['hidden']);$x['deleted']=!empty($x['deleted']);$seoChanged=false;$x=blog_normalize_seo_post($x,$seoChanged);if($seoChanged)$changed=true;}unset($x);
  foreach($j['books'] as &$x)if(is_array($x)){$x['hidden']=!empty($x['hidden']);$x['deleted']=!empty($x['deleted']);$pl=(string)($x['placement']??'books');$x['placement']=in_array($pl,['books','announcements','direct'],true)?$pl:'books';$x['language']=book_language_value((string)($x['language']??'uk-UA'));if($x['placement']==='direct')$x['is_new']=false;}unset($x);
  if((int)($j['version']??0)<7){$j['version']=7;$changed=true;}
  if($changed){$stateJson=json_encode($j,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE);if($stateJson===false)throw new RuntimeException('Не вдалося зберегти Boss state: '.json_last_error_msg());atomic_write($f,$stateJson);}
  return $j;
}
function mavik_orphan_live_books(string $root,array $manifest): array {
  $registered=[];foreach((array)($manifest['books']??[]) as $b)if(is_array($b)&&($slug=(string)($b['slug']??''))!=='')$registered[]=$slug;
  return function_exists('mavik_live_find_orphan_books')?mavik_live_find_orphan_books($root,$registered):[];
}
function mavik_adopt_live_book_into_manifest(string $root,array $config,array &$manifest,string $slug): array {
  $slug=preg_replace('/[^a-z0-9-]/','',$slug)??'';if($slug==='')throw new RuntimeException('Некоректний slug книги.');
  if(manifest_book_index($manifest,$slug)>=0)throw new RuntimeException('Книга вже є в реєстрі Boss.');
  $orphans=mavik_orphan_live_books($root,$manifest);if(!isset($orphans[$slug]))throw new RuntimeException('Live-книгу для відновлення не знайдено. Її файли не змінено.');
  $book=(array)$orphans[$slug];$book['genre_keys']=function_exists('mavik_live_genre_keys_for_book')?mavik_live_genre_keys_for_book($book):array_values(array_unique(array_map('strval',(array)($book['genre_keys']??[]))));
  if(book_language_value((string)($book['language']??'uk-UA'))==='pl-PL'){$book['language']='pl-PL';$book['placement']='direct';$book['is_new']=false;}
  $book['hidden']=false;$book['deleted']=false;$book['managed']=true;$book['recovered_from_live']=true;$book['recovered_at']=date(DATE_ATOM);
  $manifest['books'][]=$book;save_manifest($config,$manifest);rebuild_indexes($root,$manifest);render_announcements($root,load_announcements($root));
  return $book;
}
function mavik_adopt_selected_live_books_into_manifest(string $root,array $config,array &$manifest,array $selected): int {
  $orphans=mavik_orphan_live_books($root,$manifest);$wanted=[];foreach($selected as $slug){$slug=preg_replace('/[^a-z0-9-]/','',(string)$slug)??'';if($slug!==''&&isset($orphans[$slug]))$wanted[$slug]=true;}
  if(!$wanted)throw new RuntimeException('Оберіть щонайменше одну live-книгу для відновлення.');$n=0;
  foreach(array_keys($wanted) as $slug){$book=(array)$orphans[$slug];$book['genre_keys']=function_exists('mavik_live_genre_keys_for_book')?mavik_live_genre_keys_for_book($book):array_values(array_unique(array_map('strval',(array)($book['genre_keys']??[]))));if(book_language_value((string)($book['language']??'uk-UA'))==='pl-PL'){$book['language']='pl-PL';$book['placement']='direct';$book['is_new']=false;}$book['hidden']=false;$book['deleted']=false;$book['managed']=true;$book['recovered_from_live']=true;$book['recovered_at']=date(DATE_ATOM);$manifest['books'][]=$book;$n++;}
  save_manifest($config,$manifest);if(function_exists('mavik_live_reapply_book_order'))mavik_live_reapply_book_order($root);$manifest=load_manifest($config);rebuild_indexes($root,$manifest);render_announcements($root,load_announcements($root));return $n;
}
function mavik_orphan_live_blog_posts(string $root,array $manifest): array {
  $known=[];foreach((array)($manifest['blog']??[]) as $p)if(is_array($p)&&($slug=(string)($p['slug']??''))!=='')$known[$slug]=true;$out=[];
  foreach(glob(rtrim($root,'/').'/blog/*/index.html')?:[] as $file){$slug=basename(dirname($file));if($slug===''||isset($known[$slug])||!preg_match('/^[a-z0-9-]+$/',$slug))continue;if(!function_exists('mavik_live_blog_public_post'))continue;$p=mavik_live_blog_public_post($root,$slug,$file);if(!is_array($p)||trim((string)($p['title']??''))==='')continue;$out[$slug]=$p;}
  uasort($out,static fn($a,$b)=>strcmp((string)($b['published_at']??$b['date']??''),(string)($a['published_at']??$a['date']??'')));return $out;
}
function mavik_adopt_live_blog_into_manifest(string $root,array $config,array &$manifest,string $slug): array {
  $slug=preg_replace('/[^a-z0-9-]/','',$slug)??'';if($slug==='')throw new RuntimeException('Некоректний slug допису.');
  foreach((array)($manifest['blog']??[]) as $p)if(is_array($p)&&(string)($p['slug']??'')===$slug)throw new RuntimeException('Допис уже є в реєстрі Boss.');
  $orphans=mavik_orphan_live_blog_posts($root,$manifest);if(!isset($orphans[$slug]))throw new RuntimeException('Live-допис для відновлення не знайдено. Його файли не змінено.');
  $post=(array)$orphans[$slug];$post['hidden']=false;$post['deleted']=false;$post['managed']=true;$post['recovered_from_live']=true;$post['recovered_at']=date(DATE_ATOM);$seoChanged=false;$post=blog_normalize_seo_post($post,$seoChanged);
  $manifest['blog'][]=$post;$manifest['blog']=blog_sorted((array)$manifest['blog']);save_manifest($config,$manifest);rebuild_indexes($root,$manifest);return $post;
}
function mavik_adopt_all_live_blogs_into_manifest(string $root,array $config,array &$manifest): int {
  $orphans=mavik_orphan_live_blog_posts($root,$manifest);$n=0;foreach(array_keys($orphans) as $slug){mavik_adopt_live_blog_into_manifest($root,$config,$manifest,(string)$slug);$n++;}return $n;
}
function mavik_adopt_selected_live_blogs_into_manifest(string $root,array $config,array &$manifest,array $selected): int {
  $orphans=mavik_orphan_live_blog_posts($root,$manifest);$wanted=[];foreach($selected as $slug){$slug=preg_replace('/[^a-z0-9-]/','',(string)$slug)??'';if($slug!==''&&isset($orphans[$slug]))$wanted[$slug]=true;}
  if(!$wanted)throw new RuntimeException('Оберіть щонайменше один live-допис для відновлення.');$n=0;
  foreach(array_keys($wanted) as $slug){$post=(array)$orphans[$slug];$post['hidden']=false;$post['deleted']=false;$post['managed']=true;$post['recovered_from_live']=true;$post['recovered_at']=date(DATE_ATOM);$seoChanged=false;$post=blog_normalize_seo_post($post,$seoChanged);$manifest['blog'][]=$post;$n++;}
  $manifest['blog']=blog_sorted((array)$manifest['blog']);save_manifest($config,$manifest);rebuild_indexes($root,$manifest);return $n;
}
function save_manifest(array $config,array $m): void {$m['version']=7;$json=json_encode($m,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE);if($json===false)throw new RuntimeException('Не вдалося зберегти Boss state: '.json_last_error_msg());atomic_write((string)$config['manifest'],$json);}

function load_reactions_data(string $root): array {
  $f=mavik_state_path($root,'reactions.json');$raw=is_file($f)?file_get_contents($f):false;$j=$raw?json_decode($raw,true):null;
  if(!is_array($j))$j=[];if(!isset($j['items'])||!is_array($j['items']))$j['items']=[];if(!isset($j['log'])||!is_array($j['log']))$j['log']=[];return $j;
}
function reaction_pct(int $likes,int $views): string {return '—';}
function music_library_file(string $root): string { return mavik_state_seed($root,'music-library.json'); }
function music_seed_tracks(string $root): array {
  $f=$root.'/assets/app/music-tracks.json';$raw=is_file($f)?file_get_contents($f):false;$j=$raw?json_decode($raw,true):null;$out=[];
  if(!is_array($j))return $out;
  foreach($j as $i=>$t){if(!is_array($t))continue;$src=(string)($t['src']??'');if($src==='')continue;$out[]=['id'=>'legacy-'.substr(sha1($src),0,14),'title'=>(string)($t['title']??'Трек'),'artist'=>(string)($t['artist']??'MaVik_AI'),'album'=>(string)($t['album']??'Окремі треки'),'track'=>(int)($t['track']??($i+1)),'duration'=>(float)($t['duration']??0),'src'=>$src,'cover'=>(string)($t['cover']??'/assets/images/mavik-music.jpg'),'managed'=>false];}
  return $out;
}
function load_music_library(string $root): array {
  $f=music_library_file($root);$raw=is_file($f)?file_get_contents($f):false;$j=$raw?json_decode($raw,true):null;
  if(is_array($j)&&isset($j['tracks'])&&is_array($j['tracks'])){$j['collections']=isset($j['collections'])&&is_array($j['collections'])?$j['collections']:[];$j['book_collections']=isset($j['book_collections'])&&is_array($j['book_collections'])?$j['book_collections']:[];$j['external_recommendations']=isset($j['external_recommendations'])&&is_array($j['external_recommendations'])?$j['external_recommendations']:[];return $j;}
  return ['version'=>1,'updated_at'=>null,'tracks'=>music_seed_tracks($root),'collections'=>[],'book_collections'=>[],'external_recommendations'=>[]];
}
function save_music_library(string $root,array $lib): void {$lib['version']=1;$lib['updated_at']=date(DATE_ATOM);atomic_write(music_library_file($root),json_encode($lib,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));sync_music_public($root,$lib);if(function_exists('sitemap_touch_urls'))sitemap_touch_urls($root,['/music/','/']);}
function sync_music_public(string $root,array $lib): void {
  $simple=[];foreach((array)($lib['tracks']??[]) as $i=>$t){if(!is_array($t)||!empty($t['hidden']))continue;$simple[]=['title'=>(string)($t['title']??'Трек'),'artist'=>(string)($t['artist']??'MaVik_AI'),'album'=>(string)($t['album']??'Окремі треки'),'track'=>(int)($t['track']??($i+1)),'duration'=>(float)($t['duration']??0),'src'=>(string)($t['src']??''),'cover'=>(string)($t['cover']??'/assets/images/mavik-music.jpg')];}
  atomic_write($root.'/assets/app/music-tracks.json',json_encode($simple,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
  sync_music_page_seo($root,$simple);
}
function music_duration_iso(float $seconds): string {$seconds=max(0,(int)round($seconds));$h=intdiv($seconds,3600);$m=intdiv($seconds%3600,60);$s=$seconds%60;return 'PT'.($h?($h.'H'):'').($m?($m.'M'):'').($s||(!$h&&!$m)?($s.'S'):'');}
function music_count_ua(int $n): string {$a=$n%10;$b=$n%100;$w=($a===1&&$b!==11)?'трек':(($a>=2&&$a<=4&&!($b>=12&&$b<=14))?'треки':'треків');return $n.' '.$w;}
function replace_meta_content(string $html,string $attr,string $key,string $value): string {
  return preg_replace_callback('#<meta\\b[^>]*>#ui',function($m)use($attr,$key,$value){$tag=$m[0];if(!preg_match('#\\b'.preg_quote($attr,'#').'\\s*=\\s*(["\\\'])'.preg_quote($key,'#').'\\1#ui',$tag))return $tag;$safe=h($value);if(preg_match('#\\bcontent\\s*=\\s*(["\\\']).*?\\1#ui',$tag))return preg_replace('#\\bcontent\\s*=\\s*(["\\\']).*?\\1#ui','content="'.$safe.'"',$tag,1)??$tag;return rtrim(substr($tag,0,-1)).' content="'.$safe.'">';},$html)??$html;
}
function sync_music_page_seo(string $root,array $tracks): void {
  $file=$root.'/music/index.html';if(!is_file($file))return;$html=file_get_contents($file);if($html===false)return;$n=count($tracks);$count=music_count_ua($n);$title='Українська авторська музика MaVik_AI — '.$count.' слухати онлайн';$desc=$n.' авторських треків MaVik_AI / Макарчука Віктора: українські й англомовні композиції, альбоми, збірки та музика для читання. Слухати онлайн на mavik.name.';
  $html=preg_replace('#<title>.*?</title>#su','<title>'.h($title).'</title>',$html,1)??$html;
  foreach([['name','description',$desc],['property','og:title',$title],['property','og:description',$desc],['name','twitter:title',$title],['name','twitter:description',$desc]] as $m)$html=replace_meta_content($html,$m[0],$m[1],$m[2]);
  $html=preg_replace('#<span\\s+id=(["\\\'])trackCount\\1>.*?</span>#su','<span id="trackCount">'.h($count).'</span>',$html,1)??$html;
  $html=preg_replace('#<p\\s+class=(["\\\'])lead\\1>.*?</p>#su','<p class="lead">'.h($n.' авторських треків MaVik_AI: слухайте онлайн, обирайте альбоми й збірки або вмикайте музику прямо під час читання книг на mavik.name.').'</p>',$html,1)??$html;
  $albums=[];$recs=[];foreach($tracks as $i=>$t){$album=(string)($t['album']??'Окремі треки');$albums[$album]=($albums[$album]??0)+1;$rec=['@type'=>'MusicRecording','position'=>$i+1,'name'=>(string)($t['title']??'Трек'),'byArtist'=>['@id'=>'https://mavik.name/music/#artist'],'inAlbum'=>['@type'=>'MusicAlbum','name'=>$album],'audio'=>['@type'=>'AudioObject','contentUrl'=>'https://mavik.name'.(string)($t['src']??'')]];if((float)($t['duration']??0)>0)$rec['duration']=music_duration_iso((float)$t['duration']);$recs[]=$rec;}
  $same=['https://soundcloud.com/mavik_ai','https://www.youtube.com/@mavik_ua','https://music.youtube.com/@mavik_ua','https://open.spotify.com/artist/6qEDCkbMZ4wsHOybCuuC0W','https://music.apple.com/ru/artist/mavik-ai/1896018072','https://music.apple.com/ru/artist/mavik-ai/6772969013'];$parts=[];foreach($albums as $name=>$cnt)$parts[]=['@type'=>'MusicAlbum','name'=>$name,'numTracks'=>$cnt,'byArtist'=>['@id'=>'https://mavik.name/music/#artist']];$data=['@context'=>'https://schema.org','@graph'=>[['@type'=>'MusicGroup','@id'=>'https://mavik.name/music/#artist','name'=>'MaVik_AI','alternateName'=>'MaVik','url'=>'https://mavik.name/music/','sameAs'=>$same],['@type'=>'MusicPlaylist','@id'=>'https://mavik.name/music/#playlist','name'=>'Музика MaVik_AI','url'=>'https://mavik.name/music/','numTracks'=>$n,'byArtist'=>['@id'=>'https://mavik.name/music/#artist'],'hasPart'=>$parts,'track'=>$recs]]];$json=json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);$html=preg_replace('#<script\\s+type=(["\\\'])application/ld\\+json\\1>.*?</script>#su','<script type="application/ld+json">'.$json.'</script>',$html,1)??$html;atomic_write($file,$html);
  $reading=$root.'/music/reading/index.html';if(is_file($reading)){$r=file_get_contents($reading);if($r!==false){$r=preg_replace('#<a\\s+class=(["\\\'])btn\\1\\s+href=(["\\\'])/music/\\2>.*?</a>#su','<a class="btn" href="/music/">'.h($count).' MaVik_AI →</a>',$r,1)??$r;atomic_write($reading,$r);}}
}
function music_track_map(array $lib): array {$out=[];foreach((array)($lib['tracks']??[]) as $t)if(is_array($t)&&($id=(string)($t['id']??''))!=='')$out[$id]=$t;return $out;}
function external_music_url(string $url): string {
  $url=trim($url);if($url===''||strlen($url)>1600||!filter_var($url,FILTER_VALIDATE_URL))throw new RuntimeException('Вкажіть коректне https-посилання на музику.');
  $p=parse_url($url);if(strtolower((string)($p['scheme']??''))!=='https')throw new RuntimeException('Для зовнішньої музики дозволені лише https-посилання.');
  return $url;
}
function external_music_provider(string $url): string {
  $host=strtolower((string)(parse_url($url,PHP_URL_HOST)??''));$host=preg_replace('/^www\./','',$host)??$host;
  if($host==='open.spotify.com')return 'spotify';
  if($host==='spotify.link')return 'spotify-link';
  if($host==='youtube.com'||$host==='youtu.be'||$host==='music.youtube.com')return 'youtube';
  if($host==='soundcloud.com'||str_ends_with($host,'.soundcloud.com'))return 'soundcloud';
  if(str_contains($host,'music.apple.com'))return 'apple-music';
  return 'link';
}
function upload_audio(array $f,string $root,string $title): array {
  if(empty($f['tmp_name'])||!is_uploaded_file($f['tmp_name']))throw new RuntimeException('Додайте аудіофайл.');if((int)($f['size']??0)>100*1024*1024)throw new RuntimeException('Аудіофайл має бути до 100 MB.');
  $ext=strtolower(pathinfo((string)($f['name']??''),PATHINFO_EXTENSION));$allowed=['mp3','m4a','aac','wav','ogg'];if(!in_array($ext,$allowed,true))throw new RuntimeException('Підтримуються MP3, M4A, AAC, WAV або OGG.');
  $dir=$root.'/assets/music/user';if(!is_dir($dir)&&!mkdir($dir,0755,true)&&!is_dir($dir))throw new RuntimeException('Не вдалося створити каталог музики.');$base=slugify($title)?:'track';$name=$base.'-'.substr(bin2hex(random_bytes(5)),0,8).'.'.$ext;$dest=$dir.'/'.$name;if(!move_uploaded_file($f['tmp_name'],$dest))throw new RuntimeException('Не вдалося зберегти аудіофайл.');return [$dest,'/assets/music/user/'.$name];
}
function upload_music_cover(array $f,string $root,string $base): string {
  if(empty($f['tmp_name'])||!is_uploaded_file((string)$f['tmp_name']))return '/assets/images/mavik-music.jpg';$dir=$root.'/assets/music/user-covers';$stem=(slugify($base)?:'cover').'-'.substr(bin2hex(random_bytes(4)),0,6);$name=mavik_core_store_uploaded_image($f,$dir,$stem,8*1024*1024,false,92);return '/assets/music/user-covers/'.$name;
}
function delete_managed_music_file(string $root,string $url): void {if(!str_starts_with($url,'/assets/music/user/'))return;$file=$root.$url;if(is_file($file))@unlink($file);}
function delete_managed_music_cover(string $root,string $url): void {if(!str_starts_with($url,'/assets/music/user-covers/'))return;$file=$root.$url;if(is_file($file))@unlink($file);}
function book_order_file(string $root): string { return mavik_state_seed($root,'book-order.json'); }
function catalog_slug_from_href(string $href): string {
  $path=(string)(parse_url($href,PHP_URL_PATH)??$href);$parts=array_values(array_filter(explode('/',trim($path,'/')),'strlen'));
  if(!$parts)return ''; if(($parts[0]??'')==='books')return (string)($parts[1]??''); return (string)$parts[0];
}
function catalog_cover_admin_url(string $cover): string { if($cover==='')return ''; if(str_starts_with($cover,'../'))return '/'.substr($cover,3); if(str_starts_with($cover,'/'))return $cover; return '/books/'.ltrim($cover,'/'); }
function extract_catalog_books(string $root): array {
  $file=$root.'/books/index.html';$html=is_file($file)?file_get_contents($file):false;if($html===false)return [];$out=[];
  preg_match_all('#<a\\b(?=[^>]*\\bclass=["\\\'][^"\\\']*\\bcard\\b[^"\\\']*["\\\'])(?=[^>]*\\bhref=["\\\']([^"\\\']+)["\\\'])[^>]*>(.*?)</a>#si',$html,$matches,PREG_SET_ORDER);
  foreach($matches as $m){$href=html_entity_decode((string)$m[1],ENT_QUOTES|ENT_HTML5,'UTF-8');$slug=catalog_slug_from_href($href);if($slug==='')continue;$inner=(string)$m[2];
    $title=$slug;$type='';$cover='';
    if(preg_match('#<div\\b[^>]*class=["\\\'][^"\\\']*\\btitle\\b[^"\\\']*["\\\'][^>]*>(.*?)</div>#si',$inner,$x))$title=trim(html_entity_decode(strip_tags($x[1]),ENT_QUOTES|ENT_HTML5,'UTF-8'));
    if(preg_match('#<div\\b[^>]*class=["\\\'][^"\\\']*\\btype\\b[^"\\\']*["\\\'][^>]*>(.*?)</div>#si',$inner,$x))$type=trim(html_entity_decode(strip_tags($x[1]),ENT_QUOTES|ENT_HTML5,'UTF-8'));
    if(preg_match('#<img\\b[^>]*src=["\\\']([^"\\\']+)["\\\']#si',$inner,$x))$cover=html_entity_decode((string)$x[1],ENT_QUOTES|ENT_HTML5,'UTF-8');
    $out[$slug]=['slug'=>$slug,'title'=>$title,'type'=>$type,'cover'=>$cover,'href'=>$href];
  }
  return $out;
}
function extract_admin_catalog_books(string $root): array {
  // Admin must keep hidden books visible. Public /books/ intentionally does not.
  $out=extract_catalog_books($root);
  $paths=[$root.'/_site-state/boss-content.json',$root.'/_site-admin/state-defaults/boss-content.json'];
  $manifest=null;
  foreach($paths as $path){if(!is_file($path))continue;$raw=@file_get_contents($path);$j=$raw!==false?json_decode($raw,true):null;if(is_array($j)){$manifest=$j;break;}}
  if(!is_array($manifest))return $out;
  foreach((array)($manifest['books']??[]) as $b){
    if(!is_array($b)||!empty($b['deleted']))continue;
    $placement=(string)($b['placement']??'books');if(!in_array($placement,['books','announcements','direct'],true))continue;
    $slug=(string)($b['slug']??'');if($slug==='')continue;
    $beta=(string)($b['publication_mode']??'final')==='beta';$isAnnouncement=$placement==='announcements';$isDirect=$placement==='direct';
    $out[$slug]=[
      'slug'=>$slug,
      'title'=>(string)($b['title']??$slug),
      'type'=>(string)($b['genre']??'').($isAnnouncement?' · Анонс':($isDirect?' · прихована · пряме посилання':($beta?' · тестове читання':''))),
      'cover'=>(string)($b['cover_catalog']??''),
      'href'=>$slug.'/'
    ];
  }
  return $out;
}
function manifest_book_index(array $manifest,string $slug): int {
  foreach((array)($manifest['books']??[]) as $i=>$b)if(is_array($b)&&(string)($b['slug']??'')===$slug)return (int)$i;
  return -1;
}
function manifest_unique_books(array $books): array {
  $out=[];$seen=[];
  foreach($books as $b){
    if(!is_array($b))continue;$slug=(string)($b['slug']??'');
    if($slug===''||isset($seen[$slug]))continue;
    $seen[$slug]=true;$out[]=$b;
  }
  return $out;
}
function manifest_visible_books(array $manifest): array {
  return array_values(array_filter(manifest_unique_books((array)($manifest['books']??[])),fn($x)=>empty($x['hidden'])&&empty($x['deleted'])&&($x['placement']??'books')==='books'));
}
function manifest_announcement_books(array $manifest): array {return array_values(array_filter(manifest_unique_books((array)($manifest['books']??[])),fn($x)=>empty($x['hidden'])&&empty($x['deleted'])&&($x['placement']??'books')==='announcements'));}
function book_announcement_reason(array $book): string {
  $reason=trim((string)($book['announcement_reason']??''));
  return $reason!==''?$reason:trim((string)($book['description']??''));
}
function mavik_announcement_body_prepare(string $raw): string {
  $body=mavik_core_sanitize_html($raw);$body=mavik_editor_externalize_links($body);$body=trim($body);if(trim(strip_tags(html_entity_decode($body,ENT_QUOTES|ENT_HTML5,'UTF-8')))==='')return '';
  return $body;
}
function announcement_combined_items(array $manifest,array $state): array {
  $map=[];
  foreach(manifest_announcement_books($manifest) as $b){$id=(string)($b['slug']??'');if($id!=='')$map[$id]=['kind'=>'book','id'=>$id,'book'=>$b];}
  foreach((array)($state['items']??[]) as $a){if(!is_array($a)||!empty($a['deleted'])||($id=(string)($a['id']??''))==='')continue;if(!isset($map[$id]))$map[$id]=['kind'=>'generic','id'=>$id,'item'=>$a];}
  $out=[];$seen=[];foreach((array)($state['order']??[]) as $id){$id=(string)$id;if(isset($map[$id])&&!isset($seen[$id])){$seen[$id]=1;$out[]=$map[$id];}}
  foreach($map as $id=>$x)if(!isset($seen[$id]))$out[]=$x;
  return $out;
}
function mavik_announcement_body_section(array $book): string {
  if((string)($book['placement']??'books')!=='announcements')return '';$body=trim((string)($book['announcement_body_html']??''));if($body==='')return '';
  return '<!-- BOSS_ANNOUNCEMENT_BODY_START --><section class="announcement-body-wrap"><div class="announcement-body">'.$body.'</div></section><!-- BOSS_ANNOUNCEMENT_BODY_END -->';
}
function mavik_patch_announcement_body(string $html,array $book): string {
  $section=mavik_announcement_body_section($book);$start='<!-- BOSS_ANNOUNCEMENT_BODY_START -->';$end='<!-- BOSS_ANNOUNCEMENT_BODY_END -->';
  if(str_contains($html,$start)&&str_contains($html,$end)){$a=strpos($html,$start);$b=strpos($html,$end,$a);if($a!==false&&$b!==false)$html=substr($html,0,$a).$section.substr($html,$b+strlen($end));}
  elseif($section!==''&&str_contains($html,'</main>'))$html=str_replace('</main>',$section.'</main>',$html);
  if($section!==''&&!str_contains($html,'id="mavikAnnouncementBodyStyle"')){$css='<style id="mavikAnnouncementBodyStyle">.announcement-body-wrap{width:min(940px,calc(100% - 56px));margin:-28px auto 80px;padding:30px 34px;border:1px solid var(--line);border-radius:18px;background:#111114}.announcement-body{font:18px/1.72 Georgia,serif;color:#d5cfc5}.announcement-body p{margin:0 0 1.15em}.announcement-body h2{font:500 32px/1.2 Georgia,serif;margin:1.45em 0 .55em;color:var(--text)}.announcement-body h3{font:500 24px/1.25 Georgia,serif;margin:1.35em 0 .5em}.announcement-body blockquote{border-left:3px solid var(--gold);margin:1.2em 0;padding:2px 0 2px 18px;color:#c8c0b5}.announcement-body a{color:var(--gold2);text-decoration:underline}.announcement-body ul,.announcement-body ol{padding-left:28px}@media(max-width:760px){.announcement-body-wrap{width:min(100% - 28px,620px);margin:-24px auto 60px;padding:22px 20px}.announcement-body{font-size:16px}}</style>';$html=str_replace('</head>',$css.'</head>',$html);}
  return $html;
}

function manifest_visible_blog(array $manifest): array {
  return array_values(array_filter((array)($manifest['blog']??[]),fn($x)=>is_array($x)&&empty($x['hidden'])&&empty($x['deleted'])));
}
function mavik_remove_tree(string $path): void {
  if(!file_exists($path))return;if(is_file($path)||is_link($path)){@unlink($path);return;}
  $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);
  foreach($it as $f){$q=$f->getPathname();if($f->isDir()&&!$f->isLink())@rmdir($q);else @unlink($q);}@rmdir($path);
}
function mavik_sync_static_hidden_links(string $root,array $manifest): void {
  $hiddenBooks=[];$hiddenBlogs=[];
  foreach((array)($manifest['books']??[]) as $x)if(is_array($x)&&(!empty($x['hidden'])||!empty($x['deleted'])||(string)($x['placement']??'books')==='direct')&&($slug=(string)($x['slug']??''))!=='')$hiddenBooks[$slug]=true;
  foreach((array)($manifest['blog']??[]) as $x)if(is_array($x)&&(!empty($x['hidden'])||!empty($x['deleted']))&&($slug=(string)($x['slug']??''))!=='')$hiddenBlogs[$slug]=true;
  // Only index/discovery pages can expose a hidden card. Never scan full reader texts.
  $files=[$root.'/index.html',$root.'/books/index.html',$root.'/books/free/index.html',$root.'/books/new/index.html',$root.'/blog/index.html',$root.'/announcements/index.html',$root.'/shcho-pochytaty/index.html',$root.'/fantastyka-ukrainskoyu/index.html',$root.'/sotsialna-fantastyka/index.html',$root.'/antiutopiia/index.html'];
  foreach([$root.'/genres/*/index.html',$root.'/themes/*/index.html',$root.'/announcements/*/index.html'] as $g)foreach(glob($g)?:[] as $q)$files[]=$q;
  $files=array_values(array_unique(array_filter($files,'is_file')));
  foreach($files as $path){$html=@file_get_contents($path);if($html===false)continue;
    $new=preg_replace_callback("~<a\\b[^>]*\\bhref=([\"'])([^\"']+)\\1[^>]*>~iu",function($m)use($hiddenBooks,$hiddenBlogs){$tag=$m[0];$href=html_entity_decode((string)$m[2],ENT_QUOTES|ENT_HTML5,'UTF-8');$path=(string)(parse_url($href,PHP_URL_PATH)??$href);$hide=false;
      if(preg_match('#(?:^|/)books/([a-z0-9-]+)/?#i',$path,$x)&&isset($hiddenBooks[strtolower($x[1])]))$hide=true;
      elseif(preg_match('#(?:^|/)blog/([a-z0-9-]+)/?#i',$path,$x)&&isset($hiddenBlogs[strtolower($x[1])]))$hide=true;
      $marked=str_contains($tag,'data-mavik-hidden-content');
      if($hide&&!$marked)return substr($tag,0,-1).' hidden data-mavik-hidden-content="1">';
      if(!$hide&&$marked){$tag=preg_replace('/\\s+data-mavik-hidden-content="1"/i','',$tag)??$tag;$tag=preg_replace('/\\s+hidden(?=\\s|>)/i','',$tag)??$tag;}
      return $tag;
    },$html)??$html;
    if($new!==$html)atomic_write($path,$new);
  }
}
function book_reader_body_bounds(string $html): ?array {
  if(!preg_match('#<article\b[^>]*class=["\'][^"\']*\breader\b[^"\']*["\'][^>]*id=["\']reader["\'][^>]*>#i',$html,$m,PREG_OFFSET_CAPTURE))return null;
  $open=(string)$m[0][0];$openPos=(int)$m[0][1];$bodyStart=$openPos+strlen($open);$closePos=strpos($html,'</article>',$bodyStart);if($closePos===false)return null;
  return [$bodyStart,$closePos];
}
function book_reader_replace_body(string $html,string $body): string {
  $b=book_reader_body_bounds($html);if(!$b)return $html;return substr($html,0,$b[0]).$body.substr($html,$b[1]);
}
function book_existing_reader_parts(string $root,string $slug): array {
  $file=$root.'/books/'.$slug.'/read/index.html';$html=is_file($file)?file_get_contents($file):false;if($html===false)return ['body'=>'','toc'=>''];$body='';$toc='';
  $b=book_reader_body_bounds($html);if($b)$body=substr($html,$b[0],$b[1]-$b[0]);
  if(preg_match('#<aside\b[^>]*class=["\'][^"\']*\bsidebar\b[^"\']*["\'][^>]*>.*?<div\b[^>]*class=["\']sidebar-title["\'][^>]*>Зміст</div>(.*?)</aside>#si',$html,$m))$toc=(string)$m[1];
  return ['body'=>$body,'toc'=>$toc];
}
function update_book_jsonld(string $html,string $title,string $desc,string $genre,string $cover,string $slug,bool $announcement=false): string {
  return preg_replace_callback('#(<script\b[^>]*type=["\']application/ld\+json["\'][^>]*>)(.*?)(</script>)#si',function($m)use($title,$desc,$genre,$cover,$slug,$announcement){$data=json_decode(trim($m[2]),true);if(!is_array($data))return $m[0];$walk=function(&$node)use(&$walk,$title,$desc,$genre,$cover,$slug,$announcement){if(!is_array($node))return;$type=(string)($node['@type']??'');if($type==='Book'||($announcement&&$type==='CreativeWork')){if($announcement){$node['@type']='CreativeWork';$node['@id']='https://mavik.name/books/'.$slug.'/#announcement';unset($node['bookFormat'],$node['isAccessibleForFree'],$node['potentialAction']);}else{$node['@type']='Book';}$node['name']=$title;$node['description']=$desc;$node['genre']=$genre;if($cover!=='')$node['image']='https://mavik.name'.$cover;else unset($node['image']);$node['url']='https://mavik.name/books/'.$slug.'/';}elseif(($node['@type']??'')==='BreadcrumbList'){$node['itemListElement']=[['@type'=>'ListItem','position'=>1,'name'=>'MaVik','item'=>'https://mavik.name/'],['@type'=>'ListItem','position'=>2,'name'=>$announcement?'Анонси':'Книги','item'=>'https://mavik.name/'.($announcement?'announcements':'books').'/'],['@type'=>'ListItem','position'=>3,'name'=>$title,'item'=>'https://mavik.name/books/'.$slug.'/']];}foreach($node as &$v)if(is_array($v))$walk($v);unset($v);};$walk($data);return $m[1].json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).$m[3];},$html)??$html;
}
function patch_book_landing(string $root,array $book): void {
  if((string)($book['placement']??'books')==='announcements'){render_book_announcement_detail($root,$book);return;}
  $slug=(string)$book['slug'];$file=$root.'/books/'.$slug.'/index.html';if(!is_file($file))return;$html=file_get_contents($file);if($html===false)return;$title=(string)$book['title'];$genre=(string)$book['genre'];$desc=(string)$book['description'];$cover=trim((string)($book['cover_catalog']??''));$isBeta=(string)($book['publication_mode']??'final')==='beta';$isAnnouncement=(string)($book['placement']??'books')==='announcements';$language=book_language_value((string)($book['language']??'uk-UA'));$html=preg_replace('#<html\b[^>]*\blang=["\'][^"\']*["\']#i','<html lang="'.h($language).'"',$html,1)??$html;$html=replace_meta_content($html,'property','og:locale',book_og_locale($language));
  $pageTitle=mavik_book_page_title($title,$isAnnouncement);$metaDesc=mavik_meta_description($desc);$html=preg_replace('#<title>.*?</title>#su','<title>'.h($pageTitle).'</title>',$html,1)??$html;
  $html=replace_meta_content($html,'property','og:type',$isAnnouncement?'website':'book');
  foreach([['name','description',$metaDesc],['property','og:title',$pageTitle],['property','og:description',$metaDesc],['name','twitter:title',$pageTitle],['name','twitter:description',$metaDesc]] as $m)$html=replace_meta_content($html,$m[0],$m[1],$m[2]);if($cover!=='')foreach([['property','og:image','https://mavik.name'.$cover],['name','twitter:image','https://mavik.name'.$cover]] as $m)$html=replace_meta_content($html,$m[0],$m[1],$m[2]);
  $html=preg_replace('#(<div\b[^>]*class=["\'][^"\']*\beyebrow\b[^"\']*["\'][^>]*>).*?(</div>)#su','$1'.h($genre).'$2',$html,1)??$html;
  $html=preg_replace('#(<h1\b[^>]*>).*?(</h1>)#su','$1'.h($title).'$2',$html,1)??$html;
  $html=preg_replace('#(<p\b[^>]*class=["\'][^"\']*\bdesc\b[^"\']*["\'][^>]*>).*?(</p>)#su','$1'.h($desc).'$2',$html,1)??$html;
  if($cover!=='')$html=preg_replace_callback('#<img\b[^>]*class=["\'][^"\']*\bcover\b[^"\']*["\'][^>]*>#iu',function($m)use($cover,$title){$tag=$m[0];$tag=preg_replace('#\bsrc=["\'][^"\']*["\']#iu','src="'.h(mavik_display_image_url($cover)).'"',$tag,1)??$tag;$tag=preg_replace('#\balt=["\'][^"\']*["\']#iu','alt="Обкладинка — '.h($title).'"',$tag,1)??$tag;return $tag;},$html,1)??$html;
  $html=preg_replace('#<div class="book-beta-badge(?: book-announcement-badge)?">.*?</div>#su','',$html)??$html;$announcementReason=book_announcement_reason($book);$announcementBadge=trim((string)(preg_split('/\s*·\s*/u',$announcementReason,2)[0]??$announcementReason));$badge=$isAnnouncement?'<div class="book-beta-badge book-announcement-badge">'.h($announcementBadge).'</div>':($isBeta?'<div class="book-beta-badge">Тестове читання · бета-публікація</div>':'');if($badge!=='')$html=preg_replace('#(<div\b[^>]*class=["\'][^"\']*\beyebrow\b[^"\']*["\'][^>]*>.*?</div>)#su','$1'.$badge,$html,1)??$html;
  $hasReader=is_file($root.'/books/'.$slug.'/read/index.html');$hasEpub=is_file($root.'/downloads/'.$slug.'.epub');if($isAnnouncement){$note=$announcementReason;$actions='<a class="btn primary" href="/announcements/">Усі анонси →</a>';}elseif($hasReader){$note=$isBeta?'Тестове читання · текст у роботі · без реєстрації':'Повний текст · безкоштовно · без реєстрації';$duration=mavik_live_book_duration($root,$slug);$actions=mavik_live_book_actions_html($slug,!$isBeta,$hasEpub,$duration);}else{$note='Сторінка книги · матеріали до читання ще не опубліковано';$actions='';}
  $html=preg_replace('#(<p\b[^>]*class=["\'][^"\']*\bbook-free-note\b[^"\']*["\'][^>]*>).*?(</p>)#su','$1'.h($note).'$2',$html,1)??$html;
  $html=preg_replace('#<div\b[^>]*class=["\'][^"\']*\bactions\b[^"\']*["\'][^>]*>.*?</div>#su','<div class="actions">'.$actions.'</div>',$html,1)??$html;
  $html=preg_replace('#<link\b[^>]*rel=["\']alternate["\'][^>]*type=["\']application/epub\+zip["\'][^>]*?/?>#iu','',$html)??$html;if(!$isAnnouncement&&!$isBeta&&$hasEpub)$html=str_replace('</head>','<link href="https://mavik.name/downloads/'.h($slug).'.epub" rel="alternate" title="EPUB" type="application/epub+zip"/></head>',$html);
  $html=preg_replace('#<body\b([^>]*)\sdata-book-placement=["\'][^"\']*["\']([^>]*)>#iu','<body$1$2>',$html,1)??$html;$placement=(string)($book['placement']??'books');$placement=in_array($placement,['books','announcements','direct'],true)?$placement:'books';$html=preg_replace('#<body\b([^>]*)>#iu','<body$1 data-book-placement="'.$placement.'">',$html,1)??$html;
  $platformBlock=mavik_live_platform_html($book);if(str_contains($html,'data-book-platforms="1"'))$html=preg_replace('#<section class="platforms" data-book-platforms="1">.*?</section>#s',$platformBlock,$html,1)??$html;else $html=preg_replace('#<section class="platforms">.*?</section>#s',$platformBlock,$html,1)??$html;$html=update_book_jsonld($html,$title,$desc,$genre,$cover,$slug,$isAnnouncement);$html=mavik_live_patch_book_jsonld($html,$book);$html=mavik_patch_announcement_body($html,$book);atomic_write($file,$html);
}
function patch_book_reader(string $root,array $book,?array $parsed=null): array {
  $slug=(string)$book['slug'];$file=$root.'/books/'.$slug.'/read/index.html';if(!is_file($file))throw new RuntimeException('Читанку книги не знайдено.');$html=file_get_contents($file);if($html===false)throw new RuntimeException('Не вдалося прочитати читанку.');$title=(string)$book['title'];$genre=(string)$book['genre'];$desc=(string)$book['description'];$isBeta=(string)($book['publication_mode']??'final')==='beta';$language=book_language_value((string)($book['language']??'uk-UA'));$html=preg_replace('#<html\b[^>]*\blang=["\'][^"\']*["\']#i','<html lang="'.h($language).'"',$html,1)??$html;
  $readerTitle=mavik_reader_page_title($title);$html=preg_replace('#<title>.*?</title>#su','<title>'.h($readerTitle).'</title>',$html,1)??$html;$html=replace_meta_content($html,'name','description',mavik_meta_description($desc));
  $pos=strpos($html,'<section class="book-hero">');if($pos!==false){$head=substr($html,0,$pos);$tail=substr($html,$pos);$tail=preg_replace('#(<div\b[^>]*class=["\'][^"\']*\beyebrow\b[^"\']*["\'][^>]*>).*?(</div>)#su','$1'.h($genre).'$2',$tail,1)??$tail;$tail=preg_replace('#(<h1\b[^>]*>).*?(</h1>)#su','$1'.h($title).'$2',$tail,1)??$tail;$status=$isBeta?'Тестове читання · бета-публікація · текст у роботі':'Повний текст · веб-читанка mavik.name';$tail=preg_replace('#(<div\b[^>]*class=["\'][^"\']*\bgenre\b[^"\']*["\'][^>]*>).*?(</div>)#su','$1'.h($status).'$2',$tail,1)??$tail;$html=$head.$tail;}
  $sourceBody=$parsed?(string)$parsed['body']:(string)(book_existing_reader_parts($root,$slug)['body']??'');if($sourceBody!==''){$cleanBody=mavik_reader_normalize_headings($sourceBody);$toc=mavik_reader_toc_from_body($cleanBody);$html=book_reader_replace_body($html,$cleanBody);$html=preg_replace('#(<div\b[^>]*class=["\']sidebar-title["\'][^>]*>Зміст</div>).*?(</aside>)#su','$1'.$toc.'$2',$html,2)??$html;}
  $html=preg_replace('#<div class="reader-continuation"[^>]*>.*?</div>#su','',$html)??$html;if(!empty($book['show_continuation'])&&$isBeta)$html=preg_replace('#(<section\b[^>]*class=["\'][^"\']*\bfooter-card\b)#u','<div class="reader-continuation" role="note"><span>Далі буде…</span></div>$1',$html,1)??$html;
  atomic_write($file,$html);if(function_exists('mavik_live_sync_reader_state'))mavik_live_sync_reader_state($root,$book);$parts=book_existing_reader_parts($root,$slug);return $parts;
}
function save_book_order(string $root,array $order): void {
  $order=array_values($order);
  atomic_write(book_order_file($root),json_encode(['version'=>1,'updated_at'=>date(DATE_ATOM),'order'=>$order],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
  $raw=@file_get_contents(book_order_file($root));$check=$raw!==false?json_decode($raw,true):null;$saved=is_array($check)&&is_array($check['order']??null)?array_values($check['order']):[];
  if($saved!==$order)throw new RuntimeException('Порядок книг не підтвердився після запису. Зміни не прийнято.');
}
function manifest_apply_book_order(array $manifest,array $order): array {
  $rank=array_flip(array_values($order));$ordered=[];$slots=[];
  foreach((array)($manifest['books']??[]) as $i=>$b){if(!is_array($b))continue;$slug=(string)($b['slug']??'');if($slug!==''&&isset($rank[$slug])){$ordered[$slug]=$b;$slots[]=(int)$i;}}
  $queue=[];foreach($order as $slug){$slug=(string)$slug;if(isset($ordered[$slug]))$queue[]=$ordered[$slug];}
  foreach($slots as $n=>$slot)if(isset($queue[$n]))$manifest['books'][$slot]=$queue[$n];
  return $manifest;
}
function load_book_order(string $root): array {
  $catalog=extract_admin_catalog_books($root);$valid=array_keys($catalog);$raw=is_file(book_order_file($root))?file_get_contents(book_order_file($root)):false;$j=$raw?json_decode($raw,true):null;$saved=is_array($j)?(array)($j['order']??[]):[];
  $seen=[];$out=[];foreach($saved as $slug){$slug=(string)$slug;if(isset($catalog[$slug])&&!isset($seen[$slug])){$seen[$slug]=1;$out[]=$slug;}}
  foreach($valid as $slug)if(!isset($seen[$slug])){$seen[$slug]=1;$out[]=$slug;}
  if($out!==$saved)save_book_order($root,$out);return $out;
}
function book_focus_file(string $root): string { return mavik_state_seed($root,'book-focus.json'); }
function save_book_focus(string $root,string $slug): void {
  atomic_write(book_focus_file($root),json_encode(['version'=>1,'updated_at'=>date(DATE_ATOM),'slug'=>$slug],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
}
function load_book_focus(string $root): string {
  $catalog=extract_catalog_books($root);if(!$catalog)return '';
  $raw=is_file(book_focus_file($root))?file_get_contents(book_focus_file($root)):false;$j=$raw?json_decode($raw,true):null;$slug=is_array($j)?(string)($j['slug']??''):'';
  return $slug!==''&&isset($catalog[$slug])?$slug:'';
}
function blog_focus_file(string $root): string { return mavik_state_seed($root,'blog-focus.json'); }
function save_blog_focus(string $root,string $slug): void {
  atomic_write(blog_focus_file($root),json_encode(['version'=>1,'updated_at'=>date(DATE_ATOM),'slug'=>$slug],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
}
function load_blog_focus(string $root,array $blog): string {
  $valid=[];foreach($blog as $x)if(is_array($x)&&($slug=(string)($x['slug']??''))!=='')$valid[$slug]=true;if(!$valid)return '';
  $raw=is_file(blog_focus_file($root))?file_get_contents(blog_focus_file($root)):false;$j=$raw?json_decode($raw,true):null;$slug=is_array($j)?(string)($j['slug']??''):'';
  if(isset($valid[$slug]))return $slug;
  $preferred='vlasnyi-sait-shchob-zalyshatysia-liudynoiu';$fallback=isset($valid[$preferred])?$preferred:(string)array_key_first($valid);if($fallback!=='')save_blog_focus($root,$fallback);return $fallback;
}
function reorder_itemlist_jsonld(string $html,array $order): string {
  $rank=array_flip($order);
  return preg_replace_callback('#(<script\\b[^>]*type=["\\\']application/ld\\+json["\\\'][^>]*>)(.*?)(</script>)#si',function($m)use($rank){
    $data=json_decode(trim($m[2]),true);if(!is_array($data)||!isset($data['@graph'])||!is_array($data['@graph']))return $m[0];$changed=false;
    foreach($data['@graph'] as &$node){if(!is_array($node)||($node['@type']??'')!=='CollectionPage')continue;$list=&$node['mainEntity'];if(!is_array($list)||($list['@type']??'')!=='ItemList'||!isset($list['itemListElement'])||!is_array($list['itemListElement']))continue;
      $els=$list['itemListElement'];usort($els,function($a,$b)use($rank){$sa=catalog_slug_from_href((string)($a['item']['url']??''));$sb=catalog_slug_from_href((string)($b['item']['url']??''));$ra=$rank[$sa]??PHP_INT_MAX;$rb=$rank[$sb]??PHP_INT_MAX;return $ra<=>$rb;});
      foreach($els as $i=>&$el)$el['position']=$i+1;unset($el);$list['itemListElement']=$els;$list['numberOfItems']=count($els);$changed=true;
    }unset($node);
    if(!$changed)return $m[0];return $m[1].json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).$m[3];
  },$html)??$html;
}
function sync_book_order(string $root,array $order): void {
  $json=json_encode(array_values($order),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);

  // Both public views read the same live order endpoint. The embedded order is
  // only a safe fallback if PHP/order storage is temporarily unavailable.
  $f=$root.'/books/index.html';$t=file_get_contents($f);if($t===false)throw new RuntimeException('Не вдалося прочитати каталог книг.');
  $script="\n<script id=\"bossBookOrder\">(()=>{const fallback=".$json.";const slugOf=a=>{const p=(a.getAttribute('href')||'').split('?')[0].split('#')[0].replace(/^\\/+|\\/+$/g,'').split('/');return p[0]==='books'?(p[1]||''):(p[0]||'')};const apply=order=>{const grid=document.querySelector('section.grid');if(!grid)return;const rank=new Map(order.map((s,i)=>[s,i]));grid.querySelectorAll(':scope > a.card[href]').forEach((card,i)=>{const slug=slugOf(card);card.style.order=String(rank.has(slug)?rank.get(slug):10000+i);card.dataset.catalogOrder=String(rank.has(slug)?rank.get(slug)+1:10001+i)})};const run=()=>fetch('/book-order.php',{cache:'no-store'}).then(r=>r.ok?r.json():null).then(j=>apply(j&&Array.isArray(j.order)?j.order:fallback)).catch(()=>apply(fallback));document.readyState==='loading'?document.addEventListener('DOMContentLoaded',run,{once:true}):run()})();</script>\n";
  $start='<!-- BOSS_BOOK_ORDER_START -->';$end='<!-- BOSS_BOOK_ORDER_END -->';
  if(str_contains($t,$start)&&str_contains($t,$end))$t=replace_region($t,$start,$end,$script);else $t=str_replace('</body>',$start.$script.$end.'</body>',$t);
  $t=reorder_itemlist_jsonld($t,$order);atomic_write($f,$t);

  $f=$root.'/index.html';$t=file_get_contents($f);if($t===false)throw new RuntimeException('Не вдалося прочитати головну сторінку.');
  $homeScript="\n<script id=\"bossHomeBookOrder\">(()=>{const fallback=".$json.";const slugOf=card=>{const a=card.querySelector('a[href]');if(!a)return '';const p=(a.getAttribute('href')||'').split('?')[0].split('#')[0].replace(/^\\/+|\\/+$/g,'').split('/');return p[0]==='books'?(p[1]||''):(p[0]||'')};const apply=order=>{const grid=document.querySelector('#home-books .book-grid');if(!grid)return;const rank=new Map(order.map((s,i)=>[s,i]));const cards=[...grid.querySelectorAll(':scope > article.book-card')];const original=new Map(cards.map((c,i)=>[c,i]));cards.sort((a,b)=>{const sa=slugOf(a),sb=slugOf(b);const ra=rank.has(sa)?rank.get(sa):10000+(original.get(a)||0);const rb=rank.has(sb)?rank.get(sb):10000+(original.get(b)||0);return ra-rb});cards.forEach((card,i)=>{card.dataset.catalogOrder=String(i+1);grid.appendChild(card)})};const run=()=>fetch('/book-order.php',{cache:'no-store'}).then(r=>r.ok?r.json():null).then(j=>apply(j&&Array.isArray(j.order)?j.order:fallback)).catch(()=>apply(fallback));document.readyState==='loading'?document.addEventListener('DOMContentLoaded',run,{once:true}):run()})();</script>\n";
  $homeStart='<!-- BOSS_HOME_BOOK_ORDER_START -->';$homeEnd='<!-- BOSS_HOME_BOOK_ORDER_END -->';
  if(str_contains($t,$homeStart)&&str_contains($t,$homeEnd))$t=replace_region($t,$homeStart,$homeEnd,$homeScript);else $t=str_replace('</body>',$homeStart.$homeScript.$homeEnd.'</body>',$t);
  atomic_write($f,$t);
}

function replace_region(string $text,string $start,string $end,string $content): string {
  $a=strpos($text,$start); $b=strpos($text,$end);
  if($a===false||$b===false||$b<$a) throw new RuntimeException('Не знайдено службові маркери. Натисніть «Відновити індекси» після оновлення сайту.');
  $a+=strlen($start); return substr($text,0,$a).$content.substr($text,$b);
}


function ua_date(string $iso): string {
  $m=[1=>'січня',2=>'лютого',3=>'березня',4=>'квітня',5=>'травня',6=>'червня',7=>'липня',8=>'серпня',9=>'вересня',10=>'жовтня',11=>'листопада',12=>'грудня'];
  $d=new DateTimeImmutable($iso); return (int)$d->format('j').' '.$m[(int)$d->format('n')].' '.$d->format('Y');
}

function ua_date_time(string $date,string $publishedAt=''): string {
  $base=ua_date($date);
  $publishedAt=trim($publishedAt);
  if($publishedAt===''||!str_contains($publishedAt,'T'))return $base;
  try{$d=new DateTimeImmutable($publishedAt);return $base.' · '.$d->format('H:i');}catch(Throwable $e){return $base;}
}
function blog_publication_time_value(array $post): string {
  $published=trim((string)($post['published_at']??''));
  if($published!==''&&str_contains($published,'T')){
    try{return (new DateTimeImmutable($published))->format('H:i');}catch(Throwable $e){}
  }
  return '';
}
function blog_publication_atom(string $date,string $time,string $fallback=''): string {
  $date=trim($date);$time=trim($time);
  if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$date))throw new RuntimeException('Некоректна дата публікації.');
  if($time!==''&&!preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/',$time))throw new RuntimeException('Некоректний час публікації.');
  if($time===''){
    if($fallback!==''&&str_contains($fallback,'T')){try{$time=(new DateTimeImmutable($fallback))->format('H:i');}catch(Throwable $e){}}
    if($time==='')$time=date('H:i');
  }
  $tz=new DateTimeZone('Europe/Kyiv');
  return (new DateTimeImmutable($date.' '.$time.':00',$tz))->format(DATE_ATOM);
}
function mavik_blog_front_runtime_token(string $root,string $token): void {
  $files=[$root.'/blog/index.html'];
  foreach(glob($root.'/blog/page/*/index.html')?:[] as $f)$files[]=$f;
  foreach(glob($root.'/blog/*/index.html')?:[] as $f)$files[]=$f;
  foreach(array_values(array_unique($files)) as $file){
    if(!is_file($file))continue;
    $html=@file_get_contents($file);if($html===false)continue;
    $next=preg_replace('#/assets/app/site-shell\.js\?v=[^"\']+#','/assets/app/site-shell.js?v='.$token,$html,1)??$html;
    if($next!==$html)atomic_write($file,$next);
  }
}
function text_to_html(string $raw): string {
  $raw=str_replace(["\r\n","\r"],"\n",trim($raw)); $blocks=preg_split('/\n{2,}/',$raw)?:[]; $out=[]; $first=true;
  foreach($blocks as $b){$b=trim($b);if($b==='')continue;
    if(str_starts_with($b,'## ')){$out[]='<h2>'.h(trim(substr($b,3))).'</h2>';continue;}
    if(str_starts_with($b,'### ')){$out[]='<h3>'.h(trim(substr($b,4))).'</h3>';continue;}
    if(str_starts_with($b,'> ')){$out[]='<blockquote><p>'.nl2br(h(trim(substr($b,2))),false).'</p></blockquote>';continue;}
    $out[]='<p'.($first?' class="lead"':'').'>'.nl2br(h($b),false).'</p>'; $first=false;
  } return implode("\n",$out);
}
function blog_word_count(string $html): int {
  $plain=html_entity_decode(strip_tags($html),ENT_QUOTES|ENT_HTML5,'UTF-8');
  preg_match_all('/[\\p{L}\\p{N}’\\\'-]+/u',$plain,$m);return count($m[0]??[]);
}
function blog_plain_text(string $html): string {
  $plain=html_entity_decode(strip_tags(str_replace(['</p>','</h2>','</h3>','</li>','</blockquote>'],[' </p>',' </h2>',' </h3>',' </li>',' </blockquote>'],$html)),ENT_QUOTES|ENT_HTML5,'UTF-8');
  return preg_replace('/\\s+/u',' ',trim($plain))??trim($plain);
}
/* Blog SEO publication profile. Editorial body stays authoritative; these fields
 * control the search-facing wrapper and automatic internal linking. */
function blog_seo_clean(string $v,int $max=500): string {
  $v=trim(preg_replace('/\s+/u',' ',strip_tags(html_entity_decode($v,ENT_QUOTES|ENT_HTML5,'UTF-8')))??$v);
  if($max>0&&mavik_utf8_strlen($v)>$max)$v=mavik_utf8_substr($v,0,$max);return trim($v);
}
function blog_default_seo_title(string $title): string {
  $title=blog_seo_clean($title,180);$x=$title.' | Блог MaVik';return mavik_utf8_strlen($x)<=72?$x:$title.' | MaVik';
}
function blog_cluster_catalog(): array {return [
  'auto'=>['label'=>'Автоматично','url'=>''],
  'shcho-pochytaty'=>['label'=>'Що почитати українською','url'=>'/shcho-pochytaty/'],
  'antiutopiia'=>['label'=>'Українські антиутопії','url'=>'/antiutopiia/'],
  'sotsialna-fantastyka'=>['label'=>'Соціальна фантастика','url'=>'/sotsialna-fantastyka/'],
  'fantastyka-ukrainskoyu'=>['label'=>'Фантастика українською','url'=>'/fantastyka-ukrainskoyu/'],
  'none'=>['label'=>'Без тематичного хаба','url'=>'']
];}
function blog_cluster_value(string $v): string {$v=trim($v);return isset(blog_cluster_catalog()[$v])?$v:'auto';}
function blog_post_haystack(array $p): string {
  return mavik_utf8_lower(trim(implode(' ',[(string)($p['title']??''),(string)($p['seo_title']??''),(string)($p['primary_query']??''),(string)($p['category']??''),(string)($p['excerpt']??''),implode(' ',(array)($p['tags']??[])),(string)($p['search_text']??'')])));
}
function blog_resolved_cluster(array $p): string {
  $set=blog_cluster_value((string)($p['seo_cluster']??'auto'));if($set!=='auto')return $set;$hay=blog_post_haystack($p);
  if(preg_match('/антиутоп|дистоп|всесвіт\s*25/u',$hay))return 'antiutopiia';
  if(preg_match('/соціальн.{0,16}фантаст|суспільств.{0,24}(майбут|технолог)|алгоритм.{0,24}суспіль/u',$hay))return 'sotsialna-fantastyka';
  if(preg_match('/фантаст|фентез|майбутн|штучн.{0,12}інтелект|\bші\b/u',$hay))return 'fantastyka-ukrainskoyu';
  if(preg_match('/що\s+почитати|що\s+читати|почитати\s+україн|книг.{0,24}онлайн|читати.{0,24}безкоштов/u',$hay))return 'shcho-pochytaty';
  return 'none';
}
function blog_normalize_seo_post(array $p,?bool &$changed=null): array {
  $c=false;$title=blog_seo_clean((string)($p['title']??''),180);$excerpt=blog_seo_clean((string)($p['excerpt']??''),400);
  $defaults=['seo_title'=>blog_default_seo_title($title),'meta_description'=>$excerpt,'primary_query'=>$title,'image_alt'=>$title,'seo_cluster'=>'auto'];
  foreach($defaults as $k=>$v){if(!isset($p[$k])||trim((string)$p[$k])===''){$p[$k]=$v;$c=true;}}
  $p['seo_title']=blog_seo_clean((string)$p['seo_title'],180);$p['meta_description']=blog_seo_clean((string)$p['meta_description'],400);$p['primary_query']=blog_seo_clean((string)$p['primary_query'],180);$p['image_alt']=blog_seo_clean((string)$p['image_alt'],240);$cluster=blog_cluster_value((string)$p['seo_cluster']);if($cluster!==(string)$p['seo_cluster'])$c=true;$p['seo_cluster']=$cluster;if($changed!==null)$changed=$c;return $p;
}
function blog_query_tokens(string $s): array {
  $s=mavik_utf8_lower($s);preg_match_all('/[\p{L}\p{N}]{4,}/u',$s,$m);$stop=['який','яка','які','щоби','коли','після','через','своєю','своїм','українською','книга','книги','читати','почитати','блог','mavik'];$out=[];foreach($m[0]??[] as $w)if(!in_array($w,$stop,true))$out[$w]=1;return array_keys($out);
}
function blog_related_score(array $a,array $b): int {
  $score=0;$ca=blog_resolved_cluster($a);$cb=blog_resolved_cluster($b);if($ca!=='none'&&$ca===$cb)$score+=10;if(trim((string)($a['category']??''))!==''&&mavik_utf8_lower((string)$a['category'])===mavik_utf8_lower((string)($b['category']??'')))$score+=4;
  $ta=array_map('mavik_utf8_lower',array_map('strval',(array)($a['tags']??[])));$tb=array_map('mavik_utf8_lower',array_map('strval',(array)($b['tags']??[])));$score+=min(6,count(array_intersect($ta,$tb))*2);
  $qa=blog_query_tokens((string)($a['primary_query']??$a['title']??''));$qb=blog_query_tokens((string)($b['primary_query']??$b['title']??''));$score+=min(4,count(array_intersect($qa,$qb)));return $score;
}
function blog_related_html(array $blog,array $post,int $limit=3): string {
  $cluster=blog_resolved_cluster($post);$catalog=blog_cluster_catalog();$rows=[];foreach($blog as $x){if(!is_array($x)||!empty($x['hidden'])||!empty($x['deleted'])||(string)($x['slug']??'')===(string)($post['slug']??''))continue;$score=blog_related_score($post,$x);if($score>0)$rows[]=['score'=>$score,'date'=>(string)($x['date']??''),'post'=>$x];}
  usort($rows,static function($a,$b){$d=$b['score']<=>$a['score'];return $d!==0?$d:strcmp((string)$b['date'],(string)$a['date']);});$links='';if($cluster!=='none'&&isset($catalog[$cluster])&&($url=(string)$catalog[$cluster]['url'])!=='')$links.='<a href="'.h($url).'">'.h((string)$catalog[$cluster]['label']).' →</a>';$n=0;foreach($rows as $row){if($n++>=$limit)break;$x=(array)$row['post'];$links.='<a href="../'.h((string)$x['slug']).'/">'.h((string)$x['title']).' →</a>';}
  if($links==='')return '';return '<!-- BOSS_SEO_RELATED_START --><div class="relatedbox seo-related"><h3>Читайте також</h3>'.$links.'</div><!-- BOSS_SEO_RELATED_END -->';
}
function blog_image_ratio_info(string $root,string $url): array {
  $path=(string)(parse_url($url,PHP_URL_PATH)??$url);$f=$path!==''&&str_starts_with($path,'/')?rtrim($root,'/').'/'.ltrim(rawurldecode($path),'/'):'';$dim=$f!==''&&is_file($f)?@getimagesize($f):false;$w=(int)($dim[0]??0);$h=(int)($dim[1]??0);$ratio=$h>0?$w/$h:0;return ['width'=>$w,'height'=>$h,'ratio'=>$ratio,'ok'=>$w>0&&$h>0&&abs($ratio-1.5)<=0.015];
}
function blog_image_ratio_guard(string $root,string $url): void {
  $i=blog_image_ratio_info($root,$url);if(!$i['width']||!$i['height'])throw new RuntimeException('Не вдалося визначити розмір блогової ілюстрації.');if(!$i['ok'])throw new RuntimeException('Головна ілюстрація блогу має бути у форматі 3:2. Рекомендовано 1200×800 px. Поточний файл: '.$i['width'].'×'.$i['height'].' px.');
}
function blog_prepare_upload_3x2(array &$f): void {
  if(empty($f['tmp_name']))return;
  $r=mavik_core_crop_3x2_inplace((string)$f['tmp_name']);
  clearstatcache(true,(string)$f['tmp_name']);$f['size']=(int)filesize((string)$f['tmp_name']);
}

function blog_seo_status_html(string $root,array $p): string {
  $p=blog_normalize_seo_post($p);$body=(string)($p['body_html']??'');$q=mavik_utf8_lower((string)$p['primary_query']);$titleHay=mavik_utf8_lower((string)$p['title'].' '.(string)$p['seo_title']);$bodyHay=mavik_utf8_lower(blog_plain_text($body));$links=preg_match_all('~<a\b[^>]*\bhref\s*=~iu',$body,$m)?:0;$img=blog_image_ratio_info($root,(string)($p['image']??''));$checks=[
    ['SEO title',trim((string)$p['seo_title'])!==''],['Meta description',trim((string)$p['meta_description'])!==''],['Основний запит',trim((string)$p['primary_query'])!==''],['ALT ілюстрації',trim((string)$p['image_alt'])!==''],['Запит у заголовку',$q!==''&&str_contains($titleHay,$q)],['Запит у тексті',$q!==''&&str_contains($bodyHay,$q)],['Внутрішні посилання ≥ 2',$links>=2],['Ілюстрація 3:2',!empty($img['ok'])]
  ];$ok=0;$out='<div class="seo-check"><b>SEO-контроль</b><div class="seo-check-list">';foreach($checks as [$label,$yes]){$ok+=(int)$yes;$out.='<span class="'.($yes?'seo-ok':'seo-warn').'">'.($yes?'✓':'!').' '.h($label).'</span>';}$out.='</div><span class="help">'.$ok.'/'.count($checks).' перевірок. Це контроль якості, а не гарантія позиції у пошуку.</span></div>';return $out;
}

function sanitize_blog_node(DOMNode $node,array $allowed): void {
  for($child=$node->firstChild;$child;){$next=$child->nextSibling;
    if($child instanceof DOMComment){$node->removeChild($child);$child=$next;continue;}
    if($child instanceof DOMElement){$tag=strtolower($child->tagName);
      if($tag==='div'){
        $p=$child->ownerDocument->createElement('p');while($child->firstChild)$p->appendChild($child->firstChild);$node->replaceChild($p,$child);$child=$p;$tag='p';
      }
      if(!in_array($tag,$allowed,true)){
        if(in_array($tag,['script','style','iframe','object','embed','svg','math','form','input','button','textarea','select'],true)){$node->removeChild($child);$child=$next;continue;}
        sanitize_blog_node($child,$allowed);while($child->firstChild)$node->insertBefore($child->firstChild,$child);$node->removeChild($child);$child=$next;continue;
      }
      $keep=[];if($tag==='a')$keep=['href','target','rel'];elseif(in_array($tag,['span','p','h2','h3','blockquote','li'],true))$keep=['class'];
      if($child->hasAttributes())for($i=$child->attributes->length-1;$i>=0;$i--){$a=$child->attributes->item($i);if($a&&!in_array(strtolower($a->name),$keep,true))$child->removeAttributeNode($a);}if($child->hasAttribute('class')){$ok=$tag==='span'?['mavik-text-gold','mavik-text-light','mavik-text-black','mavik-text-white','mavik-bg-gold','mavik-bg-light','mavik-align-left','mavik-align-center','mavik-align-right']:['mavik-align-left','mavik-align-center','mavik-align-right'];$cls=array_values(array_intersect(preg_split('/\s+/',trim($child->getAttribute('class')))?:[],$ok));if($cls)$child->setAttribute('class',implode(' ',$cls));else $child->removeAttribute('class');}
      if($tag==='a'){$href=trim($child->getAttribute('href'));if($href!==''){$href=html_entity_decode($href,ENT_QUOTES|ENT_HTML5,'UTF-8');if(preg_match('~^(?:www\.|[A-Za-z0-9.-]+\.[A-Za-z]{2,})(?:/|$)~i',$href))$href='https://'.$href;if(!preg_match('~^(?:https?://|mailto:|/|\.\.?/|\#)~i',$href))$child->removeAttribute('href');else{$child->setAttribute('href',$href);if(preg_match('#^https?://#i',$href)){$host=strtolower((string)(parse_url($href,PHP_URL_HOST)??''));if($host!==''&&!in_array($host,['mavik.name','www.mavik.name'],true)){$child->setAttribute('target','_blank');$child->setAttribute('rel','noopener noreferrer');}else{$child->removeAttribute('target');$child->removeAttribute('rel');}}}}}
      sanitize_blog_node($child,$allowed);
    }
    $child=$next;
  }
}
function sanitize_blog_html(string $raw): string {
  $raw=trim($raw);if($raw==='')throw new RuntimeException('Додайте текст статті.');$rawHrefCount=preg_match_all('~<a\b[^>]*\bhref\s*=~iu',$raw,$__mavikHrefRaw);
  $d=new DOMDocument('1.0','UTF-8');$old=libxml_use_internal_errors(true);$d->loadHTML('<?xml encoding="UTF-8"><div id="boss-blog-root">'.$raw.'</div>',LIBXML_HTML_NOIMPLIED|LIBXML_HTML_NODEFDTD);libxml_clear_errors();libxml_use_internal_errors($old);
  $root=null;foreach($d->getElementsByTagName('div') as $x)if($x->getAttribute('id')==='boss-blog-root'){$root=$x;break;}if(!$root)throw new RuntimeException('Не вдалося прочитати форматований текст.');
  sanitize_blog_node($root,['p','h2','h3','strong','b','em','i','u','blockquote','ul','ol','li','a','span','br','hr']);
  $out='';foreach(iterator_to_array($root->childNodes) as $n)$out.=$d->saveHTML($n);$out=trim($out);$outHrefCount=preg_match_all('~<a\b[^>]*\bhref\s*=~iu',$out,$__mavikHrefOut);if($rawHrefCount!==false&&$outHrefCount!==false&&$outHrefCount<$rawHrefCount)throw new RuntimeException('Одне або кілька посилань мають неприпустиму адресу. Використайте https://, /внутрішню-адресу/, #якір або mailto:.');
  if(mavik_utf8_strlen(blog_plain_text($out))<40)throw new RuntimeException('Текст статті надто короткий.');
  // First paragraph keeps the visual lead style used by the blog.
  $out=preg_replace('/<p>/u','<p class="lead">',$out,1)??$out;return $out;
}
function blog_effective_tags(array $post): array {
  $out=[];$seen=[];
  foreach((array)($post['tags']??[]) as $tag){$tag=trim((string)$tag);if($tag==='')continue;$key=mavik_utf8_lower($tag);if(isset($seen[$key]))continue;$seen[$key]=1;$out[]=$tag;}
  if(!$out){$category=trim((string)($post['category']??''));if($category!==''&&mavik_utf8_lower($category)!=='блог'){$out[]=$category;$seen[mavik_utf8_lower($category)]=1;}}
  if(!$out){$query=trim((string)($post['primary_query']??''));if($query!=='')$out[]=$query;}
  return array_slice($out,0,8);
}
function blog_tags_html(array $tags): string {
  $tags=array_values(array_filter(array_map(static fn($x)=>trim((string)$x),$tags),static fn($x)=>$x!==''));if(!$tags)return '';
  $s='<div class="relatedbox"><h3>Теги</h3><div class="tags">';foreach($tags as $tag)$s.='<a class="tag" href="../?q='.rawurlencode((string)$tag).'">'.h((string)$tag).'</a>';$s.='</div></div>';return $s;
}
function blog_sorted(array $blog): array {usort($blog,function($a,$b){$d=strcmp((string)($b['date']??''),(string)($a['date']??''));return $d!==0?$d:strcmp((string)($b['published_at']??''),(string)($a['published_at']??''));});return $blog;}
function blog_nav_html(array $blog,string $slug): string {
  $blog=blog_sorted(array_values(array_filter($blog,fn($x)=>is_array($x)&&empty($x['hidden'])&&empty($x['deleted']))));$i=null;foreach($blog as $k=>$p)if((string)($p['slug']??'')===$slug){$i=$k;break;}if($i===null)return '';
  $left=$i>0?'<a href="../'.h((string)$blog[$i-1]['slug']).'/">← '.h((string)$blog[$i-1]['title']).'</a>':'<span></span>';
  $right=$i<count($blog)-1?'<a href="../'.h((string)$blog[$i+1]['slug']).'/">'.h((string)$blog[$i+1]['title']).' →</a>':'<a href="../">До всіх публікацій →</a>';
  return '<div class="article-nav">'.$left.$right.'</div>';
}
function render_blog_article(string $root,array $config,array $post,array $blog): void {
  $tpl=file_get_contents((string)$config['templates'].'/blog-article.tpl.html');if($tpl===false)throw new RuntimeException('Немає шаблону блогу.');$post=blog_normalize_seo_post($post);
  $title=(string)$post['title'];$slug=(string)$post['slug'];$category=(string)$post['category'];$excerpt=(string)$post['excerpt'];$seoTitle=(string)$post['seo_title'];$metaDescription=(string)$post['meta_description'];$primaryQuery=(string)$post['primary_query'];$imageAlt=(string)$post['image_alt'];$date=(string)$post['date'];$img=(string)$post['image'];$tags=blog_effective_tags($post);$body=(string)($post['body_html']??'');$prefix=(string)($post['sidebar_prefix_html']??'');$published=(string)($post['published_at']??($date.'T12:00:00+03:00'));$updated=(string)($post['updated_at']??$published);$language='uk-UA';
  $sidebar=$prefix.blog_related_html($blog,$post).blog_tags_html($tags);$nav=blog_nav_html($blog,$slug);$imgPath=$root.'/'.ltrim((string)(parse_url($img,PHP_URL_PATH)??$img),'/');$dim=is_file($imgPath)?@getimagesize($imgPath):false;$iw=(int)($dim[0]??0);$ih=(int)($dim[1]??0);$imageUrl='https://mavik.name'.$img;$keywords=array_values(array_unique(array_filter(array_merge([$primaryQuery],array_map('strval',$tags)))));
  $article=['@type'=>'BlogPosting','@id'=>'https://mavik.name/blog/'.$slug.'/#article','headline'=>$title,'description'=>$metaDescription,'datePublished'=>$published,'dateModified'=>$updated,'inLanguage'=>$language,'mainEntityOfPage'=>'https://mavik.name/blog/'.$slug.'/','isPartOf'=>['@id'=>'https://mavik.name/#website'],'image'=>['@type'=>'ImageObject','url'=>$imageUrl,'caption'=>$imageAlt],'articleSection'=>$category,'keywords'=>$keywords,'wordCount'=>blog_word_count($body),'author'=>['@type'=>'Person','@id'=>'https://mavik.name/#person','name'=>'Макарчук Віктор Вікторович','alternateName'=>['Макарчук Віктор','MaVik'],'email'=>'viktor@mavik.name']];
  $breadcrumbs=['@type'=>'BreadcrumbList','@id'=>'https://mavik.name/blog/'.$slug.'/#breadcrumbs','itemListElement'=>[['@type'=>'ListItem','position'=>1,'name'=>'MaVik','item'=>'https://mavik.name/'],['@type'=>'ListItem','position'=>2,'name'=>'Блог','item'=>'https://mavik.name/blog/'],['@type'=>'ListItem','position'=>3,'name'=>$title,'item'=>'https://mavik.name/blog/'.$slug.'/']]];
  $jsonld=json_encode(['@context'=>'https://schema.org','@graph'=>[$article,$breadcrumbs]],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
  $repl=['{{BLOG_TITLE}}'=>h($title),'{{BLOG_SEO_TITLE}}'=>h($seoTitle),'{{BLOG_EXCERPT}}'=>h($excerpt),'{{BLOG_META_DESCRIPTION}}'=>h($metaDescription),'{{BLOG_PRIMARY_QUERY}}'=>h($primaryQuery),'{{BLOG_IMAGE_ALT}}'=>h($imageAlt),'{{BLOG_SLUG}}'=>h($slug),'{{BLOG_CATEGORY}}'=>h($category),'{{BLOG_DATE_HUMAN}}'=>h(ua_date_time($date,$published)),'{{BLOG_IMAGE}}'=>h($img),'{{BLOG_IMAGE_DISPLAY}}'=>h(mavik_display_image_url($img)),'{{BLOG_IMAGE_WIDTH}}'=>$iw>0?(string)$iw:'1200','{{BLOG_IMAGE_HEIGHT}}'=>$ih>0?(string)$ih:'800','{{BLOG_IMAGE_ATTRS}}'=>mavik_img_attrs($root,$img,false,true),'{{BLOG_BODY}}'=>$body,'{{BLOG_NAV}}'=>$nav,'{{BLOG_SIDEBAR}}'=>$sidebar,'{{BLOG_JSONLD}}'=>$jsonld,'{{BLOG_PUBLISHED_AT}}'=>h($published),'{{BLOG_UPDATED_AT}}'=>h($updated)];
  atomic_write($root.'/blog/'.$slug.'/index.html',strtr($tpl,$repl));
}
function render_all_blog_articles(string $root,array $config,array $blog): void {foreach($blog as $p)if(is_array($p)&&!empty($p['slug'])&&empty($p['deleted']))render_blog_article($root,$config,$p,$blog);}
function delete_old_blog_user_image(string $root,string $url): void {if(!str_starts_with($url,'/assets/blog/user/'))return;$f=$root.$url;if(is_file($f))@unlink($f);}
function upload_blog_replacement(array $f,string $root,string $slug): string {
  $dir=$root.'/assets/blog/user';$name=mavik_core_store_uploaded_image($f,$dir,$slug.'-'.date('Ymd-His'),12*1024*1024,true,92);return '/assets/blog/user/'.$name;
}

function announcements_file(string $root): string { return mavik_state_seed($root,'announcements.json'); }
function load_announcements(string $root): array {
  $f=announcements_file($root);$raw=is_file($f)?file_get_contents($f):false;$j=$raw?json_decode($raw,true):null;
  if(!is_array($j))$j=['version'=>4,'visible'=>true,'items'=>[],'order'=>[]];
  $j['visible']=!isset($j['visible'])||!empty($j['visible']);$j['items']=array_values(array_filter((array)($j['items']??[]),'is_array'));$j['order']=array_values(array_map('strval',(array)($j['order']??[])));
  foreach($j['items'] as &$x){$x['hidden']=!empty($x['hidden']);$x['deleted']=!empty($x['deleted']);}unset($x);
  /* A book announcement is the same book object with placement=announcements. Remove a legacy stand-alone duplicate, but keep one shared order for books + generic announcements. */
  $bookSlugs=[];$announcementSlugs=[];$mf=mavik_state_seed($root,'boss-content.json');$mr=is_file($mf)?file_get_contents($mf):false;$mj=$mr?json_decode($mr,true):null;if(is_array($mj))foreach((array)($mj['books']??[]) as $b)if(is_array($b)&&($slug=(string)($b['slug']??''))!==''){$bookSlugs[$slug]=true;if(empty($b['hidden'])&&empty($b['deleted'])&&(string)($b['placement']??'books')==='announcements')$announcementSlugs[]=$slug;}
  $changed=false;$before=count($j['items']);if($bookSlugs)$j['items']=array_values(array_filter($j['items'],fn($x)=>!isset($bookSlugs[(string)($x['id']??'')])));if(count($j['items'])!==$before)$changed=true;
  $valid=[];foreach($announcementSlugs as $id)$valid[$id]=true;foreach($j['items'] as $x)if(is_array($x)&&empty($x['deleted'])&&($id=(string)($x['id']??''))!=='')$valid[$id]=true;
  $order=[];$seen=[];foreach($j['order'] as $id)if(isset($valid[$id])&&!isset($seen[$id])){$seen[$id]=1;$order[]=$id;}foreach(array_keys($valid) as $id)if(!isset($seen[$id]))$order[]=$id;if($order!==$j['order']){$j['order']=$order;$changed=true;}
  if((int)($j['version']??0)<4){$j['version']=4;$changed=true;}if($changed){$j['updated_at']=date(DATE_ATOM);atomic_write($f,json_encode($j,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));}
  return $j;
}
function announcement_index(array $state,string $id): int {foreach((array)($state['items']??[]) as $i=>$x)if(is_array($x)&&(string)($x['id']??'')===$id)return (int)$i;return -1;}
function announcement_detail_url(array $item): string {
  $id=preg_replace('/[^a-z0-9-]/','',(string)($item['id']??''))??'';return $id!==''?'/announcements/'.$id.'/':'/announcements/';
}
function announcement_detail_page_html(string $title,string $desc,string $kicker,string $cover,string $canonical,string $bodyHtml='',bool $bookAnnouncement=false,string $status=''): string {
  $img=$cover!==''?'<figure class="announcement-detail-cover"><img src="'.h(mavik_display_image_url($cover)).'" alt="Обкладинка — '.h($title).'" loading="eager" decoding="async"></figure>':'';
  $work=['@type'=>'CreativeWork','@id'=>$canonical.'#announcement','name'=>$title,'description'=>$desc,'url'=>$canonical,'inLanguage'=>'uk-UA','author'=>['@id'=>'https://mavik.name/#person']];if($cover!=='')$work['image']='https://mavik.name'.$cover;if($status!=='')$work['creativeWorkStatus']=$status;
  $crumb=['@type'=>'BreadcrumbList','itemListElement'=>[['@type'=>'ListItem','position'=>1,'name'=>'MaVik','item'=>'https://mavik.name/'],['@type'=>'ListItem','position'=>2,'name'=>'Анонси','item'=>'https://mavik.name/announcements/'],['@type'=>'ListItem','position'=>3,'name'=>$title,'item'=>$canonical]]];$schema=json_encode(['@context'=>'https://schema.org','@graph'=>[$work,$crumb]],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
  $bodyHtml=trim($bodyHtml);$body=$bodyHtml!==''?'<!-- BOSS_ANNOUNCEMENT_BODY_START --><section class="announcement-body-wrap"><div class="announcement-body">'.$bodyHtml.'</div></section><!-- BOSS_ANNOUNCEMENT_BODY_END -->':'';
  $bodyAttr=$bookAnnouncement?' data-book-placement="announcements"':'';
  return '<!DOCTYPE html><html lang="uk-UA"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>'.h($title).' — анонс | MaVik</title><meta name="description" content="'.h(mavik_meta_description($desc)).'"><meta name="robots" content="index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1"><link rel="canonical" href="'.h($canonical).'"><meta property="og:locale" content="uk_UA"><meta property="og:type" content="website"><meta property="og:site_name" content="MaVik"><meta property="og:title" content="'.h($title).' — анонс | MaVik"><meta property="og:description" content="'.h(mavik_meta_description($desc)).'"><meta property="og:url" content="'.h($canonical).'">'.($cover!==''?'<meta property="og:image" content="https://mavik.name'.h($cover).'">':'').'<script type="application/ld+json">'.$schema.'</script><link href="/assets/app/site-shell.css?v=250v20c3" rel="stylesheet"><link href="/assets/app/floating-controls.css?v=250v20c3" rel="stylesheet"><link href="/assets/app/footer-clean.css?v=250v20c3" rel="stylesheet"><link href="/assets/app/brand-lock.css?v=250v20c3" rel="stylesheet"><link href="/assets/app/discovery.css?v=250v20c3" rel="stylesheet"><link href="/assets/app/book-share.css?v=250v20c3" rel="stylesheet"><link href="/assets/app/reactions.css?v=250v20c3" rel="stylesheet"><link href="/assets/app/global-system.css?v=250v20c3" rel="stylesheet"><link href="/favicon.ico?v=250v20c3" rel="icon" type="image/x-icon"></head><body class="announcements-page announcement-detail-page"'.$bodyAttr.'><header class="mavik-site-header"><div class="mavik-site-head-inner"><a aria-label="MaVik — на головну" class="mavik-site-brand" href="/"><img alt="MVV" src="/assets/brand/mavik-mvv-gold.svg" width="1876" height="1876"><span class="mavik-site-brand-copy"><strong>MaVik</strong><span>МАКАРЧУК ВІКТОР</span></span></a><nav aria-label="Головне меню" class="mavik-site-desktop-nav"><a href="/books/">Книги</a><a href="/music/">Музика</a><a href="/blog/">Блог</a><a href="/about/">Автор</a><a href="/announcements/" aria-current="page">Анонси</a><a href="/contact/">Контакт</a></nav><button aria-controls="mavikMobileMenu" aria-expanded="false" aria-label="Відкрити меню" class="mavik-site-mobile-toggle" type="button"><i></i><i></i><i></i></button></div><nav aria-hidden="true" aria-label="Мобільне меню" class="mavik-site-mobile-menu" id="mavikMobileMenu"><div class="mavik-site-mobile-inner"><a href="/books/">Книги</a><a href="/music/">Музика</a><a href="/blog/">Блог</a><a href="/about/">Автор</a><a href="/announcements/" aria-current="page">Анонси</a><a href="/contact/">Контакт</a></div></nav></header><main class="mavik-global-page wrap"><section class="section announcement-detail-section"><div class="announcement-detail-tools"><a class="btn primary announcement-back-btn" href="/announcements/"><span aria-hidden="true">←</span><span>Усі анонси</span></a><span class="announcement-share-slot"></span></div><div class="announcement-detail-hero"><div class="announcement-detail-copy"><div class="eyebrow">'.h($kicker).'</div><h1>'.h($title).'</h1><p class="lead">'.h($desc).'</p></div>'.$img.'</div>'.$body.'</section></main><footer><span class="footer-copy-row">© 2026 · Макарчук Віктор - MaVik®<br>Всі права застережено</span><span class="footer-legal-row"><a class="footer-legal-link" href="/mavik/">Про MaVik</a> · <a class="footer-legal-link" href="/copyright/">Правова охорона творчого доробку</a> · <a class="footer-legal-link" href="/privacy/">Приватність</a></span></footer><script defer src="/assets/app/site-shell.js?v=250v20c3"></script><script defer src="/assets/app/floating-controls.js?v=250v20c3"></script><script defer src="/assets/app/book-share.js?v=250v20c3"></script><script defer src="/assets/app/reactions.js?v=250v20c3"></script></body></html>';
}

function render_generic_announcement_detail(string $root,array $item): void {
  $id=preg_replace('/[^a-z0-9-]/','',(string)($item['id']??''))??'';if($id==='')return;$dir=$root.'/announcements/'.$id;
  if(!empty($item['hidden'])||!empty($item['deleted'])){mavik_remove_tree($dir);return;}
  $title=trim((string)($item['title']??''));$desc=trim((string)($item['description']??''));$kicker=trim((string)($item['kicker']??'Анонс'));$cover=trim((string)($item['cover']??''));if($title==='')return;
  $canonical='https://mavik.name/announcements/'.$id.'/';atomic_write($dir.'/index.html',announcement_detail_page_html($title,$desc,$kicker,$cover,$canonical));
}
function render_generic_announcement_details(string $root,array $state): void {foreach((array)($state['items']??[]) as $item)if(is_array($item))render_generic_announcement_detail($root,$item);}
function render_book_announcement_detail(string $root,array $book): void {
  if(!empty($book['hidden'])||!empty($book['deleted'])||(string)($book['placement']??'books')!=='announcements')return;$slug=preg_replace('/[^a-z0-9-]/','',(string)($book['slug']??''))??'';if($slug==='')return;
  $title=trim((string)($book['title']??$slug));$desc=trim((string)($book['description']??''));$genre=trim((string)($book['genre']??'Книга'));$kicker=$genre!==''?$genre.' · анонс':'Анонс';$cover=trim((string)($book['cover_catalog']??''));$status=book_announcement_reason($book);$body=mavik_announcement_body_prepare((string)($book['announcement_body_html']??''));$canonical='https://mavik.name/books/'.$slug.'/';atomic_write($root.'/books/'.$slug.'/index.html',announcement_detail_page_html($title,$desc,$kicker,$cover,$canonical,$body,true,$status));
}

function render_announcements(string $root,array $state): void {
  $f=$root.'/announcements/index.html';if(!is_file($f))return;$html=file_get_contents($f);if($html===false)return;$visible=!empty($state['visible']);$cards='';
  $mf=mavik_state_seed($root,'boss-content.json');$mr=is_file($mf)?file_get_contents($mf):false;$manifest=$mr?json_decode($mr,true):null;if(!is_array($manifest))$manifest=['books'=>[]];
  if($visible)foreach(announcement_combined_items($manifest,$state) as $row){if(($row['kind']??'')==='book'){$b=(array)$row['book'];$title=(string)($b['title']??'');if($title==='')continue;$cover=(string)($b['cover_catalog']??'');$desc=book_announcement_reason($b);$kicker=(string)($b['genre']??'Книга').' · анонс';$href='/books/'.(string)$b['slug'].'/';$image=$cover!==''?'<img src="'.h($cover).'" alt="Обкладинка — '.h($title).'" loading="lazy">':'<div class="announcement-cover-placeholder" aria-hidden="true">MVV</div>';$cards.='<a class="announcement-card" data-book-announcement="'.h((string)$b['slug']).'" href="'.h($href).'">'.$image.'<div class="announcement-copy"><small>'.h($kicker).'</small><strong>'.h($title).'</strong><span>'.h($desc).'</span></div></a>';}else{$x=(array)$row['item'];if(!empty($x['hidden'])||!empty($x['deleted']))continue;$title=(string)($x['title']??'');if($title==='')continue;$kicker=(string)($x['kicker']??'Анонс');$desc=(string)($x['description']??'');$cover=(string)($x['cover']??'');$href=trim((string)($x['href']??''));if($href==='')$href=announcement_detail_url($x);$open='<a class="announcement-card" href="'.h($href).'">';$close='</a>';$image=$cover!==''?'<img src="'.h($cover).'" alt="Обкладинка — '.h($title).'" loading="lazy">':'<div class="announcement-cover-placeholder" aria-hidden="true">MVV</div>';$cards.=$open.$image.'<div class="announcement-copy"><small>'.h($kicker).'</small><strong>'.h($title).'</strong><span>'.h($desc).'</span></div>'.$close;}}
  if($cards==='')$cards='<p class="section-copy">Нових анонсів поки немає.</p>';
  $section='<section class="section" data-boss-announcements="1"><h2>Анонси</h2><div class="announcement-grid">'.$cards.'</div><div class="actions"><a class="btn" href="/books/new/">Нові опубліковані книги →</a><a class="btn" href="/books/">Бібліотека →</a></div></section>';
  if(str_contains($html,'data-boss-announcements="1"')){$html=preg_replace('#<section class="section" data-boss-announcements="1">.*?</section>#s',$section,$html,1)??$html;}else{$start=strpos($html,'<section class="section"><h2>Анонси</h2>');$end=$start!==false?strpos($html,'<div class="footer-space"></div>',$start):false;if($start!==false&&$end!==false)$html=substr($html,0,$start).$section.substr($html,$end);}
  $html=preg_replace('/<body(?: class="[^"]*")?>/','<body class="announcements-page">',$html,1)??$html;atomic_write($f,$html);render_generic_announcement_details($root,$state);sitemap_touch_urls($root,['/announcements/']);
}
function save_announcements(string $root,array $state): void {$state['version']=4;$state['updated_at']=date(DATE_ATOM);atomic_write(announcements_file($root),json_encode($state,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));render_announcements($root,$state);}

function book_genres_file(string $root): string { return mavik_state_seed($root,'book-genres.json'); }
function book_genres_defaults(): array { return ['poetry'=>'Поезія','mystic'=>'Містика','fantasy'=>'Фантастика / фентезі','techno'=>'Технотрилер','thriller'=>'Трилер','psychological'=>'Психологічна','philosophical'=>'Філософська','drama'=>'Драма','war'=>'Воєнна','political'=>'Політична','humor'=>'Гумор / іронія','documentary'=>'Документальна','children'=>'Дитяча','women'=>'Жіночий роман','epistolary'=>'Епістолярна','legal'=>'Юридична']; }
function load_book_genres(string $root): array {
  $f=book_genres_file($root);$raw=is_file($f)?file_get_contents($f):false;$j=$raw?json_decode($raw,true):null;$items=[];
  if(is_array($j)&&isset($j['items'])&&is_array($j['items']))$items=$j['items'];
  foreach(book_genres_defaults() as $k=>$v)if(!isset($items[$k])||trim((string)$items[$k])==='')$items[$k]=$v;
  $out=[];foreach($items as $k=>$v){$k=preg_replace('/[^a-z0-9-]/','',mavik_utf8_lower((string)$k))??'';$v=trim((string)$v);if($k!==''&&$v!=='')$out[$k]=$v;}
  return $out;
}
function save_book_genres(string $root,array $items): void {
  atomic_write(book_genres_file($root),json_encode(['version'=>1,'updated_at'=>date(DATE_ATOM),'items'=>$items],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
}
function register_book_genre(string $root,string $label): string {
  $label=trim(preg_replace('/\s+/u',' ',$label)??$label);$len=mavik_utf8_strlen($label);
  if($len<2||$len>80)throw new RuntimeException('Назва нового жанру має містити від 2 до 80 символів.');
  $items=load_book_genres($root);foreach($items as $k=>$v)if(mavik_utf8_lower(trim((string)$v))===mavik_utf8_lower($label))return (string)$k;
  $base=slugify($label);if($base==='')$base='genre';$key=$base;$n=2;while(isset($items[$key]))$key=$base.'-'.$n++;
  $items[$key]=$label;save_book_genres($root,$items);return $key;
}

function media_state_file(string $root): string { return mavik_state_seed($root,'media-library.json'); }
function media_dir(string $root,string $type): string { if(!in_array($type,['blog','covers'],true))throw new RuntimeException('Невідома медіатека.'); return $root.'/images/'.$type; }
function media_user_dir(string $root,string $type): string {$dir=media_dir($root,$type).'/user';if(!is_dir($dir)&&!mkdir($dir,0755,true)&&!is_dir($dir))throw new RuntimeException('Не вдалося створити захищену медіатеку.');return $dir;}
function media_safe_file(string $name): string {$name=trim(str_replace('\\','/',$name),'/');if(preg_match('#^(?:user/)?[A-Za-z0-9._-]+$#',$name)!==1)throw new RuntimeException('Некоректне ім’я файла.');return $name;}
function media_url(string $type,string $file): string {$file=media_safe_file($file);return '/images/'.$type.'/'.implode('/',array_map('rawurlencode',explode('/',$file)));}
function media_public_url(string $type,string $file): string { return 'https://mavik.name'.media_url($type,$file); }
function media_file_from_url(string $type,string $url): string {$prefix='/images/'.$type.'/';$path=(string)(parse_url($url,PHP_URL_PATH)??'');if(!str_starts_with($path,$prefix))return '';try{return media_safe_file(rawurldecode(substr($path,strlen($prefix))));}catch(Throwable $e){return '';}}
function load_media_state(string $root): array {
  $f=media_state_file($root);$raw=is_file($f)?file_get_contents($f):false;$j=$raw?json_decode($raw,true):null;
  return is_array($j)?$j:['version'=>1,'blog'=>[],'covers'=>[]];
}
function save_media_state(string $root,array $state): void {$state['version']=1;$state['updated_at']=date(DATE_ATOM);atomic_write(media_state_file($root),json_encode($state,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));}
function media_files(string $root,string $type): array {
  $dir=media_dir($root,$type);if(!is_dir($dir))@mkdir($dir,0755,true);$found=[];
  $scan=function(string $scanDir,string $prefix='')use(&$found,$type){if(!is_dir($scanDir))return;foreach(scandir($scanDir)?:[] as $name){if($name==='.'||$name==='..'||str_starts_with($name,'.'))continue;$p=$scanDir.'/'.$name;if(!is_file($p)||!preg_match('/\.(?:jpe?g|png)$/i',$name))continue;$rel=$prefix.$name;$dim=@getimagesize($p);$found[$rel]=['file'=>$rel,'url'=>media_url($type,$rel),'width'=>(int)($dim[0]??0),'height'=>(int)($dim[1]??0),'bytes'=>(int)(filesize($p)?:0)];}};
  $scan($dir);$scan($dir.'/user','user/');
  $st=load_media_state($root);$order=array_values(array_map('strval',(array)($st[$type]??[])));$out=[];$seen=[];foreach($order as $n)if(isset($found[$n])){$out[]=$found[$n];$seen[$n]=1;}foreach($found as $n=>$x)if(!isset($seen[$n]))$out[]=$x;return $out;
}
function media_upload_file(array $f,string $root,string $type,string $base='image'): string {
  $dir=media_user_dir($root,$type);$allowTransparent=$type!=='covers';$name=mavik_core_store_uploaded_image($f,$dir,slugify($base)?:'image',12*1024*1024,$allowTransparent,92);$rel='user/'.$name;$st=load_media_state($root);$arr=array_values((array)($st[$type]??[]));$arr[]=$rel;$st[$type]=array_values(array_unique($arr));save_media_state($root,$st);return $rel;
}
function media_replace_file(array $f,string $root,string $type,string $name): void {
  $name=media_safe_file($name);$dest=media_dir($root,$type).'/'.$name;if(!is_file($dest))throw new RuntimeException('Зображення не знайдено.');$oldExt=strtolower(pathinfo($name,PATHINFO_EXTENSION));if($oldExt==='jpeg')$oldExt='jpg';$dir=dirname($dest);$stem='.replace-'.bin2hex(random_bytes(5));$allowTransparent=$type!=='covers';$newName=mavik_core_store_uploaded_image($f,$dir,$stem,12*1024*1024,$allowTransparent,92);$tmp=$dir.'/'.$newName;$newExt=strtolower(pathinfo($newName,PATHINFO_EXTENSION));if($newExt==='jpeg')$newExt='jpg';if($newExt!==$oldExt){@unlink($tmp);throw new RuntimeException('Після перевірки зображення має формат '.$newExt.', а поточний файл — '.$oldExt.'. Додайте його як нове зображення, щоб не ламати URL.');}if(!rename($tmp,$dest)){@unlink($tmp);throw new RuntimeException('Не вдалося замінити файл.');}
}
function media_json_usage_walk($node,string $url,string $path,array &$out): void {
  if(is_string($node)){if($node===$url||str_contains($node,$url))$out[]=$path;return;}
  if(!is_array($node))return;
  foreach($node as $k=>$v){$next=is_int($k)?$path.'['.$k.']':($path===''?(string)$k:$path.'.'.$k);media_json_usage_walk($v,$url,$next,$out);}
}
function media_usage_locations(string $root,string $url): array {
  // Only authoritative live state may block deletion. Generated HTML, release seeds,
  // templates and cached output can contain stale references and must not create false locks.
  $files=['boss-content.json','announcements.json','site-core.json'];$hits=[];
  foreach($files as $name){$f=mavik_state_seed($root,$name);if(!is_file($f))continue;$raw=@file_get_contents($f);if($raw===false||!str_contains($raw,$url))continue;$j=json_decode($raw,true);if(!is_array($j))continue;$paths=[];media_json_usage_walk($j,$url,'',$paths);foreach(array_values(array_unique($paths)) as $path)$hits[]=$name.($path!==''?' → '.$path:'');}
  return array_values(array_unique($hits));
}
function media_in_use(string $root,string $url): bool {return media_usage_locations($root,$url)!==[];}
function media_delete_file(string $root,string $type,string $name): void {
  $name=media_safe_file($name);$url=media_url($type,$name);$uses=media_usage_locations($root,$url);if($uses){$shown=array_slice($uses,0,4);$suffix=count($uses)>4?' та ще '.(count($uses)-4):'';throw new RuntimeException('Це зображення справді використовується в актуальному стані сайту: '.implode('; ',$shown).$suffix.'. Спочатку змініть цю прив’язку.');}$p=media_dir($root,$type).'/'.$name;if(!is_file($p))throw new RuntimeException('Файл не знайдено.');if(!@unlink($p))throw new RuntimeException('Не вдалося видалити файл.');$st=load_media_state($root);$st[$type]=array_values(array_filter((array)($st[$type]??[]),fn($x)=>(string)$x!==$name));save_media_state($root,$st);
}
function media_save_order(string $root,string $type,array $order): void {$known=[];foreach(media_files($root,$type) as $x)$known[$x['file']]=1;$seen=[];$out=[];foreach($order as $n){$n=(string)$n;if(isset($known[$n])&&!isset($seen[$n])){$seen[$n]=1;$out[]=$n;}}foreach(array_keys($known) as $n)if(!isset($seen[$n]))$out[]=$n;$st=load_media_state($root);$st[$type]=$out;save_media_state($root,$st);}
function media_pick_url(string $root,string $type,string $selected,array $upload,string $fallbackBase): string {
  if(!empty($upload['tmp_name'])){$name=media_upload_file($upload,$root,$type,$fallbackBase);return media_url($type,$name);}$selected=trim($selected);if($selected!==''){$selected=media_safe_file($selected);if(is_file(media_dir($root,$type).'/'.$selected))return media_url($type,$selected);}throw new RuntimeException('Оберіть зображення з медіатеки або завантажте нове.');
}
function mavik_book_page_title(string $title,bool $announcement=false): string {$x=$announcement?$title.' — анонс | MaVik':$title.' — книга Макарчука Віктора | MaVik';if(mavik_utf8_strlen($x)>65)$x=$title.($announcement?' — анонс | MaVik':' — книга | MaVik');return $x;}
function mavik_reader_page_title(string $title): string {$x=$title.' — повний текст | MaVik';if(mavik_utf8_strlen($x)>65)$x=$title.' — читати | MaVik';return $x;}
function mavik_meta_description(string $text,int $limit=175): string {
  $text=trim(preg_replace('/\s+/u',' ',$text)??$text);if(mavik_utf8_strlen($text)<=$limit)return $text;$cut=mavik_utf8_substr($text,0,$limit-1);$cut=preg_replace('/\s+\S*$/u','',$cut)??$cut;$cut=rtrim($cut," \t\n\r\0\x0B,;:—–-");return $cut.'…';
}
function mavik_reader_normalize_headings(string $body): string {
  if(trim($body)==='')return '';
  $d=new DOMDocument('1.0','UTF-8');$old=libxml_use_internal_errors(true);$d->loadHTML('<?xml encoding="UTF-8"><div id="mavik-reader-normalize-root">'.$body.'</div>',LIBXML_HTML_NOIMPLIED|LIBXML_HTML_NODEFDTD);libxml_clear_errors();libxml_use_internal_errors($old);
  $r=null;foreach($d->getElementsByTagName('div') as $x)if($x->getAttribute('id')==='mavik-reader-normalize-root'){$r=$x;break;}if(!$r)return preg_replace('#<h1\b([^>]*)>#iu','<h2$1>',preg_replace('#</h1>#iu','</h2>',$body)??$body)??$body;
  $nodes=[];foreach(['h1','h2','h3'] as $tag)foreach(iterator_to_array($r->getElementsByTagName($tag)) as $h)$nodes[]=$h;
  foreach($nodes as $h){$txt=trim((string)$h->textContent);if(mavik_reader_heading_looks_like_prose($txt)){$p=$d->createElement('p');$p->appendChild($d->createTextNode($txt));$h->parentNode?->replaceChild($p,$h);continue;}if(strtolower($h->tagName)==='h1'){$n=$d->createElement('h2');foreach(iterator_to_array($h->attributes??[]) as $a)$n->setAttribute($a->name,$a->value);while($h->firstChild)$n->appendChild($h->firstChild);$h->parentNode?->replaceChild($n,$h);}}
  $used=[];$n=0;foreach(iterator_to_array($r->getElementsByTagName('h2')) as $h){$n++;$txt=trim((string)$h->textContent);$id=trim((string)$h->getAttribute('id'));if($id===''||isset($used[$id])){$base=slugify($txt);if($base==='')$base='section';$id=$base;$i=2;while(isset($used[$id])){$id=$base.'-'.$i;$i++;}$h->setAttribute('id',$id);}$used[$id]=true;$level=(int)$h->getAttribute('data-toc');if(!in_array($level,[1,2],true))$h->setAttribute('data-toc','2');}
  $out='';foreach(iterator_to_array($r->childNodes) as $node)$out.=$d->saveHTML($node);return trim($out);
}
function mavik_reader_toc_from_body(string $body): string {
  if(trim($body)==='')return '';$d=new DOMDocument('1.0','UTF-8');$old=libxml_use_internal_errors(true);$d->loadHTML('<?xml encoding="UTF-8"><div id="mavik-reader-toc-root">'.$body.'</div>',LIBXML_HTML_NOIMPLIED|LIBXML_HTML_NODEFDTD);libxml_clear_errors();libxml_use_internal_errors($old);$r=null;foreach($d->getElementsByTagName('div') as $x)if($x->getAttribute('id')==='mavik-reader-toc-root'){$r=$x;break;}if(!$r)return '';
  $toc=[];$n=0;foreach(iterator_to_array($r->getElementsByTagName('h2')) as $h){$txt=trim((string)$h->textContent);if($txt===''||mavik_reader_heading_looks_like_prose($txt))continue;$n++;$id=trim((string)$h->getAttribute('id'));if($id===''){$id='section-'.$n.'-'.slugify($txt);$id=rtrim($id,'-');}$level=(int)$h->getAttribute('data-toc');if(!in_array($level,[1,2],true))$level=2;$toc[]='<a class="toc-link level-'.$level.'" href="#'.h($id).'">'.h($txt).'</a>';}
  return implode("\n",$toc);
}

function parse_docx(string $file): array {
  if(!class_exists('ZipArchive')) throw new RuntimeException('На хостингу потрібне PHP-розширення ZipArchive для DOCX.');
  $z=new ZipArchive(); if($z->open($file)!==true) throw new RuntimeException('Не вдалося відкрити DOCX.');
  $xml=$z->getFromName('word/document.xml'); $stylesXml=$z->getFromName('word/styles.xml'); $z->close();
  if(!$xml) throw new RuntimeException('DOCX не містить document.xml.');
  $styleNames=[];
  if($stylesXml){
    $sd=new DOMDocument(); @$sd->loadXML($stylesXml); $xp=new DOMXPath($sd); $xp->registerNamespace('w','http://schemas.openxmlformats.org/wordprocessingml/2006/main');
    foreach($xp->query('//w:style') as $st){$id=$st->getAttributeNS('http://schemas.openxmlformats.org/wordprocessingml/2006/main','styleId');$name=$xp->query('./w:name',$st)->item(0);if($id&&$name)$styleNames[$id]=$name->getAttributeNS('http://schemas.openxmlformats.org/wordprocessingml/2006/main','val');}
  }
  $d=new DOMDocument(); @$d->loadXML($xml); $xp=new DOMXPath($d); $xp->registerNamespace('w','http://schemas.openxmlformats.org/wordprocessingml/2006/main'); $rows=[];
  foreach($xp->query('//w:body/w:p') as $p){
    $texts=[];foreach($xp->query('.//w:t',$p) as $t)$texts[]=$t->textContent; $text=trim(implode('',$texts)); if($text==='')continue;
    $stNode=$xp->query('./w:pPr/w:pStyle',$p)->item(0); $sid=$stNode?$stNode->getAttributeNS('http://schemas.openxmlformats.org/wordprocessingml/2006/main','val'):''; $style=$styleNames[$sid]??$sid;
    $rows[]=['text'=>$text,'style'=>$style];
  } return $rows;
}
function parse_manuscript(string $file,string $name): array {
  $ext=strtolower(pathinfo($name,PATHINFO_EXTENSION)); $rows=[];
  if($ext==='docx') $rows=parse_docx($file);
  elseif($ext==='txt'){ $raw=file_get_contents($file); if($raw===false)throw new RuntimeException('Не вдалося прочитати TXT.'); foreach(preg_split('/\R+/u',$raw)?:[] as $line){$line=trim($line);if($line!=='')$rows[]=['text'=>$line,'style'=>''];}}
  else throw new RuntimeException('Рукопис: лише DOCX або TXT.');
  $body=[];$toc=[];$used=[];$hnum=0;
  foreach($rows as $r){$text=trim((string)$r['text']);$style=mavik_utf8_lower((string)$r['style']);
    $styleHeading=(bool)preg_match('/heading|заголов/u',$style)&&!mavik_reader_heading_looks_like_prose($text);$namedHeading=(bool)preg_match('/^(?:глава|розділ|частина)\s+(?:[0-9IVXLCDM]+|[А-ЯІЇЄҐA-Z][^.!?]{0,70})$/u',$text)||(bool)preg_match('/^(?:передслово|пролог|післяслово|епілог)$/ui',$text);$isHeading=$styleHeading||$namedHeading;
    if($isHeading){$hnum++;$id='section-'.$hnum.'-'.slugify($text);if($id==='section-'.$hnum.'-')$id='section-'.$hnum;$used[$id]=true;$body[]='<h2 data-toc="2" id="'.h($id).'">'.h($text).'</h2>';$toc[]='<a class="toc-link level-2" href="#'.h($id).'">'.h($text).'</a>';}
    else $body[]='<p>'.h($text).'</p>';
  }
  if(!$body)throw new RuntimeException('У рукописі немає тексту.');
  return ['body'=>implode("\n",$body),'toc'=>implode("\n",$toc),'plain'=>implode("\n\n",array_column($rows,'text'))];
}
function mavik_remove_tmp_tree(string $path): void {
  if(!file_exists($path))return;
  if(is_file($path)||is_link($path)){@unlink($path);return;}
  $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);
  foreach($it as $f){$q=$f->getPathname();if($f->isDir()&&!$f->isLink())@rmdir($q);else @unlink($q);}@rmdir($path);
}
function create_epub(string $out,string $title,string $author,string $coverFile,string $coverExt,string $body,string $tocLinks,string $language='uk-UA'): void {
  if(!class_exists('ZipArchive'))throw new RuntimeException('Для EPUB потрібне PHP-розширення ZipArchive.');
  if(!is_file($coverFile))throw new RuntimeException('Не знайдено файл обкладинки для EPUB.');$coverExt=strtolower($coverExt);if($coverExt==='jpeg')$coverExt='jpg';if($coverExt!=='jpg')throw new RuntimeException('Обкладинка EPUB має бути JPG.');$language=book_language_value($language);$languagePrimary=strtolower(explode('-',$language)[0]);
  $siteRoot=dirname(dirname($out));$tmpBase=mavik_state_dir($siteRoot).'/tmp';
  if(!is_dir($tmpBase)&&!mkdir($tmpBase,0750,true)&&!is_dir($tmpBase))throw new RuntimeException('Не вдалося створити службовий каталог EPUB.');
  $tmp=$tmpBase.'/mavik-epub-'.bin2hex(random_bytes(5));
  try{
    if(!mkdir($tmp.'/META-INF',0750,true)&&!is_dir($tmp.'/META-INF'))throw new RuntimeException('Не вдалося підготувати EPUB.');
    if(!mkdir($tmp.'/OEBPS',0750,true)&&!is_dir($tmp.'/OEBPS'))throw new RuntimeException('Не вдалося підготувати EPUB.');
    if(file_put_contents($tmp.'/mimetype','application/epub+zip')===false)throw new RuntimeException('Не вдалося записати EPUB mimetype.');
    file_put_contents($tmp.'/META-INF/container.xml','<?xml version="1.0" encoding="UTF-8"?><container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>');
    if(!copy($coverFile,$tmp.'/OEBPS/cover.'.$coverExt))throw new RuntimeException('Не вдалося додати обкладинку до EPUB.');
    file_put_contents($tmp.'/OEBPS/cover.xhtml','<?xml version="1.0" encoding="utf-8"?><html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" xml:lang="'.$language.'"><head><title>Обкладинка</title><link rel="stylesheet" type="text/css" href="styles.css"/></head><body class="cover-page" epub:type="cover"><img src="cover.'.$coverExt.'" alt="Обкладинка — '.h($title).'"/></body></html>');
    $bodyE=str_replace(['&nbsp;'],[' '],$body);
    file_put_contents($tmp.'/OEBPS/text.xhtml','<?xml version="1.0" encoding="utf-8"?><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="'.$language.'"><head><title>'.h($title).'</title><link rel="stylesheet" type="text/css" href="styles.css"/></head><body>'.$bodyE.'</body></html>');
    file_put_contents($tmp.'/OEBPS/copyright.xhtml','<?xml version="1.0" encoding="utf-8"?><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="'.$language.'"><head><title>Авторські права</title></head><body><h1>Авторські права</h1><p>© 2026 MaVik / Макарчук Віктор Вікторович. Усі права захищено.</p><p>Контакт щодо прав та ліцензування: viktor@mavik.name</p><p>Повні умови: https://mavik.name/copyright/</p></body></html>');
    file_put_contents($tmp.'/OEBPS/styles.css','body{font-family:serif;line-height:1.6;margin:6%}h2{page-break-before:always;margin-top:2em}p{margin:.8em 0}.cover-page{margin:0;padding:0;text-align:center}.cover-page img{display:block;width:100%;height:auto;max-height:100vh;object-fit:contain;margin:0 auto}');
    $nav=preg_replace('/class="toc-link[^"]*"/','',$tocLinks)??$tocLinks;$nav=preg_replace('/href="#/','href="text.xhtml#',$nav)??$nav;
    preg_match_all('#<a\b[^>]*href="([^"]+)"[^>]*>(.*?)</a>#su',$nav,$nm,PREG_SET_ORDER);$navItems='';foreach($nm as $x)$navItems.='<li><a href="'.h(html_entity_decode((string)$x[1],ENT_QUOTES|ENT_HTML5,'UTF-8')).'">'.trim((string)$x[2]).'</a></li>';if($navItems==='')$navItems='<li><a href="text.xhtml">Початок</a></li>';
    file_put_contents($tmp.'/OEBPS/nav.xhtml','<?xml version="1.0" encoding="utf-8"?><html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" xml:lang="'.$language.'"><head><title>Зміст</title></head><body><nav epub:type="toc"><h1>Зміст</h1><ol>'.$navItems.'</ol></nav></body></html>');
    $uid='urn:uuid:'.bin2hex(random_bytes(16));
    $opf='<?xml version="1.0" encoding="UTF-8"?><package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="id" xml:lang="'.$languagePrimary.'"><metadata xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:identifier id="id">'.$uid.'</dc:identifier><dc:title>'.h($title).'</dc:title><dc:creator>'.h($author).'</dc:creator><dc:language>'.$languagePrimary.'</dc:language><dc:rights>© 2026 MaVik / Макарчук Віктор Вікторович. Усі права захищено. Контакт: viktor@mavik.name.</dc:rights><meta property="dcterms:modified">'.gmdate('Y-m-d\TH:i:s\Z').'</meta><meta name="cover" content="cover-image"/></metadata><manifest><item id="cover-image" href="cover.'.$coverExt.'" media-type="image/jpeg" properties="cover-image"/><item id="cover" href="cover.xhtml" media-type="application/xhtml+xml"/><item id="text" href="text.xhtml" media-type="application/xhtml+xml"/><item id="rights" href="copyright.xhtml" media-type="application/xhtml+xml"/><item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/><item id="css" href="styles.css" media-type="text/css"/></manifest><spine><itemref idref="cover"/><itemref idref="rights"/><itemref idref="text"/></spine><guide><reference type="cover" title="Обкладинка" href="cover.xhtml"/></guide></package>';
    file_put_contents($tmp.'/OEBPS/content.opf',$opf);
    $outDir=dirname($out);if(!is_dir($outDir)&&!mkdir($outDir,0755,true)&&!is_dir($outDir))throw new RuntimeException('Не вдалося створити каталог завантажень.');
    $outTmp=$out.'.tmp-'.bin2hex(random_bytes(4));$z=new ZipArchive();if($z->open($outTmp,ZipArchive::CREATE|ZipArchive::OVERWRITE)!==true)throw new RuntimeException('Не вдалося створити EPUB.');
    $z->addFile($tmp.'/mimetype','mimetype');$z->setCompressionName('mimetype',ZipArchive::CM_STORE);
    $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($tmp,FilesystemIterator::SKIP_DOTS));foreach($it as $f){$rel=substr($f->getPathname(),strlen($tmp)+1);if($rel==='mimetype')continue;$z->addFile($f->getPathname(),$rel);}unset($it);
    if(!$z->close())throw new RuntimeException('Не вдалося завершити EPUB.');if(!rename($outTmp,$out)){@unlink($outTmp);throw new RuntimeException('Не вдалося встановити готовий EPUB.');}@chmod($out,0644);
  }finally{mavik_remove_tmp_tree($tmp);}
}

function ensure_markers(string $root): void {
  $files=[
    [$root.'/blog/index.html','<!-- BOSS_BLOG_START -->','<!-- BOSS_BLOG_END -->','#posts',true],
    [$root.'/books/index.html','<!-- BOSS_BOOKS_START -->','<!-- BOSS_BOOKS_END -->','.grid',false],
    [$root.'/index.html','<!-- BOSS_HOME_BOOKS_START -->','<!-- BOSS_HOME_BOOKS_END -->','.book-grid',false],
  ];
  foreach($files as [$file,$start,$end,$sel,$atStart]){
    $t=file_get_contents($file);if($t===false)continue;if(str_contains($t,$start)&&str_contains($t,$end))continue;
    // Conservative fallback: insert around the first matching known container opening/closing.
    if($sel==='#posts')$t=preg_replace('/(<section[^>]+id="posts"[^>]*>)/','$1'.$start.$end,$t,1);
    elseif($sel==='.grid')$t=preg_replace('/(<section[^>]+class="grid"[^>]*>)/','$1',$t,1); // handled below
    if($sel==='.grid'&&!str_contains($t,$start)){$pos=strpos($t,'</section>',strpos($t,'class="grid"'));if($pos!==false)$t=substr($t,0,$pos).$start.$end.substr($t,$pos);}
    if($sel==='.book-grid'&&!str_contains($t,$start)){$pos=strpos($t,'</div>',strpos($t,'class="book-grid"'));if($pos!==false)$t=substr($t,0,$pos).$start.$end.substr($t,$pos);}
    atomic_write($file,$t);
  }
  $f=$root.'/index.html';$t=file_get_contents($f);if($t!==false&&!str_contains($t,'<!-- BOSS_HOME_BLOG_START -->')){$t=preg_replace('/(<article class=\"journal-feature reveal\">.*?<\/article>)/s','<!-- BOSS_HOME_BLOG_START -->$1<!-- BOSS_HOME_BLOG_END -->',$t,1)??$t;atomic_write($f,$t);}
  $f=$root.'/blog/feed.xml';$t=file_get_contents($f);if($t!==false&&!str_contains($t,'<!-- BOSS_RSS_START -->')){$pos=strpos($t,'<item>');$insert='<!-- BOSS_RSS_START --><!-- BOSS_RSS_END -->';$t=$pos!==false?substr($t,0,$pos).$insert.substr($t,$pos):str_replace('</channel>',$insert.'</channel>',$t);atomic_write($f,$t);}
  $f=$root.'/sitemap.xml';$t=file_get_contents($f);if($t!==false&&!str_contains($t,'<!-- BOSS_SITEMAP_START -->'))atomic_write($f,str_replace('</urlset>','<!-- BOSS_SITEMAP_START --><!-- BOSS_SITEMAP_END --></urlset>',$t));
}
function ensure_regions(string $root): void { ensure_markers($root); }
function state_snapshot_payload(string $root,array $config): array {
  $bookOrderRaw=is_file(book_order_file($root))?file_get_contents(book_order_file($root)):false;
  $bookOrder=$bookOrderRaw?json_decode($bookOrderRaw,true):null;
  $focusFile=book_focus_file($root);$focusRaw=is_file($focusFile)?file_get_contents($focusFile):false;$focus=$focusRaw?json_decode($focusRaw,true):null;
  $blogNow=blog_sorted((array)(load_manifest($config)['blog']??[]));$blogFocusFile=blog_focus_file($root);$blogFocusRaw=is_file($blogFocusFile)?file_get_contents($blogFocusFile):false;$blogFocus=$blogFocusRaw?json_decode($blogFocusRaw,true):null;
  return [
    'format'=>'mavik-site-state',
    'version'=>1,
    'site'=>'mavik.name',
    'exported_at'=>date(DATE_ATOM),
    'data'=>[
      'boss_content'=>load_manifest($config),
      'book_order'=>is_array($bookOrder)?$bookOrder:['version'=>1,'order'=>load_book_order($root)],
      'book_genres'=>['version'=>1,'items'=>load_book_genres($root)],
      'book_focus'=>is_array($focus)?$focus:['version'=>1,'slug'=>load_book_focus($root)],
      'blog_focus'=>is_array($blogFocus)?$blogFocus:['version'=>1,'slug'=>load_blog_focus($root,$blogNow)],
      'music_library'=>load_music_library($root),
      'media_library'=>load_media_state($root),
      'announcements'=>load_announcements($root),
      'site_core'=>mavik_core_load($root),
    ],
  ];
}
function state_snapshot_validate(array $snapshot): array {
  if(($snapshot['format']??'')!=='mavik-site-state'||(int)($snapshot['version']??0)!==1)throw new RuntimeException('Це не файл стану MaVik або його версія не підтримується.');
  $d=$snapshot['data']??null;if(!is_array($d))throw new RuntimeException('У файлі немає секції data.');
  foreach(['boss_content','book_order','book_focus','music_library','media_library'] as $k)if(!isset($d[$k])||!is_array($d[$k]))throw new RuntimeException('У файлі стану бракує секції '.$k.'.');
  if(isset($d['book_genres'])&&!is_array($d['book_genres']))throw new RuntimeException('Некоректна секція book_genres.');
  if(isset($d['blog_focus'])&&!is_array($d['blog_focus']))throw new RuntimeException('Некоректна секція blog_focus.');
  if(isset($d['announcements'])&&!is_array($d['announcements']))throw new RuntimeException('Некоректна секція announcements.');
  if(isset($d['site_core'])&&!is_array($d['site_core']))throw new RuntimeException('Некоректна секція site_core.');
  if(!isset($d['boss_content']['blog'])||!is_array($d['boss_content']['blog'])||!isset($d['boss_content']['books'])||!is_array($d['boss_content']['books']))throw new RuntimeException('Некоректний маніфест контенту.');
  if(!isset($d['book_order']['order'])||!is_array($d['book_order']['order']))throw new RuntimeException('Некоректний порядок книг.');
  if(!isset($d['music_library']['tracks'])||!is_array($d['music_library']['tracks']))throw new RuntimeException('Некоректна музична бібліотека.');
  return $d;
}
function state_snapshot_restore(string $root,array $config,array $d): void {
  $manifest=$d['boss_content'];$manifest['version']=1;save_manifest($config,$manifest);
  if(isset($d['book_genres']['items'])&&is_array($d['book_genres']['items']))save_book_genres($root,(array)$d['book_genres']['items']);
  $catalog=extract_catalog_books($root);$seen=[];$order=[];foreach((array)$d['book_order']['order'] as $slug){$slug=(string)$slug;if(isset($catalog[$slug])&&!isset($seen[$slug])){$seen[$slug]=1;$order[]=$slug;}}foreach(array_keys($catalog) as $slug)if(!isset($seen[$slug]))$order[]=$slug;if($order){save_book_order($root,$order);sync_book_order($root,$order);}
  $focus=(string)($d['book_focus']['slug']??'');if($focus==='')save_book_focus($root,'');elseif(isset($catalog[$focus]))save_book_focus($root,$focus);
  $restoredBlog=blog_sorted((array)($manifest['blog']??[]));$blogSlugs=[];foreach($restoredBlog as $x)if(is_array($x)&&($slug=(string)($x['slug']??''))!=='')$blogSlugs[$slug]=true;$blogFocus=(isset($d['blog_focus'])&&is_array($d['blog_focus']))?(string)($d['blog_focus']['slug']??''):'';if($blogFocus!==''&&isset($blogSlugs[$blogFocus]))save_blog_focus($root,$blogFocus);else{$fallbackBlogFocus=load_blog_focus($root,$restoredBlog);if($fallbackBlogFocus!=='')save_blog_focus($root,$fallbackBlogFocus);}
  $music=$d['music_library'];$music['tracks']=array_values(array_filter((array)($music['tracks']??[]),'is_array'));$music['collections']=array_values(array_filter((array)($music['collections']??[]),'is_array'));$music['book_collections']=is_array($music['book_collections']??null)?$music['book_collections']:[];$music['external_recommendations']=is_array($music['external_recommendations']??null)?$music['external_recommendations']:[];save_music_library($root,$music);
  $media=$d['media_library'];$media['blog']=array_values(array_map('strval',(array)($media['blog']??[])));$media['covers']=array_values(array_map('strval',(array)($media['covers']??[])));save_media_state($root,$media);
  if(isset($d['announcements'])&&is_array($d['announcements']))save_announcements($root,$d['announcements']);else render_announcements($root,load_announcements($root));
  if(isset($d['site_core'])&&is_array($d['site_core']))mavik_core_save($root,$d['site_core']);
  mavik_core_render_all_pages($root);
  rebuild_indexes($root,$manifest);
}


function sitemap_touch_urls(string $root,array $paths,?string $date=null): void {
  $f=$root.'/sitemap.xml';if(!is_file($f))return;$xml=file_get_contents($f);if($xml===false)return;$date=$date?:date('Y-m-d');
  foreach($paths as $path){$url='https://mavik.name'.($path==='/'?'/':('/'.trim((string)$path,'/').'/'));$q=preg_quote($url,'#');$xml=preg_replace_callback('#<url>(?:(?!</url>).)*?<loc>'.$q.'</loc>(?:(?!</url>).)*?</url>#s',function($m)use($date){$x=$m[0];if(preg_match('#<lastmod>.*?</lastmod>#s',$x))return preg_replace('#<lastmod>.*?</lastmod>#s','<lastmod>'.$date.'</lastmod>',$x,1)??$x;return preg_replace('#</loc>#','</loc><lastmod>'.$date.'</lastmod>',$x,1)??$x;},$xml,1)??$xml;}
  atomic_write($f,$xml);
  if(function_exists('mavik_indexnow_submit')){try{mavik_indexnow_submit($root,$paths);}catch(Throwable $e){}}
}


function mavik_core_sync_managed_sitemap(string $root,?array $core=null): void {
  $core=$core??mavik_core_load($root);$f=$root.'/sitemap.xml';if(!is_file($f))return;$xml=(string)file_get_contents($f);
  $start='<!-- BOSS_STATIC_PAGES_START -->';$end='<!-- BOSS_STATIC_PAGES_END -->';$rows='';$paths=[];
    if(str_contains($xml,$start)&&str_contains($xml,$end))$xml=replace_region($xml,$start,$end,$rows);else $xml=str_replace('</urlset>',$start.$rows.$end.'</urlset>',$xml);
  atomic_write($f,$xml);if($paths&&function_exists('mavik_indexnow_submit')){try{mavik_indexnow_submit($root,$paths);}catch(Throwable $e){}}
}

function sitemap_remove_legacy_book_urls(string $xml,array $manifest): string {
  $start='<!-- BOSS_SITEMAP_START -->';$end='<!-- BOSS_SITEMAP_END -->';
  if(str_contains($xml,$start)&&str_contains($xml,$end))$xml=replace_region($xml,$start,$end,'');
  foreach((array)($manifest['books']??[]) as $b){if(!is_array($b)||($slug=(string)($b['slug']??''))==='')continue;$q=preg_quote('https://mavik.name/books/'.$slug.'/','#');$xml=preg_replace('#<url>(?:(?!</url>).)*?<loc>'.$q.'</loc>(?:(?!</url>).)*?</url>#s','',$xml)??$xml;}
  return $xml;
}

function sync_home_book_limits(string $root,int $desktop,int $mobile): void {
  $desktop=max(1,min(40,$desktop));$mobile=max(1,min(40,$mobile));
  $f=$root.'/index.html';$t=file_get_contents($f);if($t===false)throw new RuntimeException('Не вдалося прочитати головну сторінку.');
  $style='<style id="bossHomeBookLimits">@media (min-width:769px){#home-books .book-grid>article.book-card:nth-child(n+'.($desktop+1).'){display:none!important}}@media (max-width:768px){#home-books .book-grid>article.book-card:nth-child(n+'.($mobile+1).'){display:none!important}}</style>';
  if(preg_match('#<style id="bossHomeBookLimits">.*?</style>#s',$t))$t=preg_replace('#<style id="bossHomeBookLimits">.*?</style>#s',$style,$t,1)??$t;else $t=str_replace('</head>',$style."
</head>",$t);
  atomic_write($f,$t);
}


function mavik_blog_topic_parts(string $category): array {
  $parts=preg_split('/\s*,\s*/u',trim($category))?:[];
  $out=[];$seen=[];
  $labels=[
    'література'=>'Література',
    'читання'=>'Читання',
    'особисте'=>'Особисте',
    'поезія'=>'Поезія',
    'творчість'=>'Творчість',
    'письменництво'=>'Письменництво',
    'суспільство'=>'Суспільство',
    'технології'=>'Технології',
    'музика'=>'Музика',
    'соціальна'=>'Соціальна',
  ];
  foreach($parts as $topic){
    $topic=trim((string)$topic);
    if($topic==='')continue;
    $key=mavik_utf8_lower($topic);
    if(isset($seen[$key]))continue;
    $seen[$key]=true;
    $out[]=$labels[$key]??$topic;
  }
  return $out;
}
function mavik_blog_topic_counts(array $blog): array {
  $counts=[];$labels=[];
  foreach($blog as $post){
    if(!is_array($post)||!empty($post['deleted'])||!empty($post['hidden']))continue;
    foreach(mavik_blog_topic_parts((string)($post['category']??'')) as $topic){
      $key=mavik_utf8_lower($topic);
      $labels[$key]=$topic;
      $counts[$key]=($counts[$key]??0)+1;
    }
  }
  $keys=array_keys($counts);
  usort($keys,static function($a,$b)use($counts,$labels){
    $byCount=($counts[$b]??0)<=>($counts[$a]??0);
    return $byCount!==0?$byCount:strnatcasecmp((string)($labels[$a]??$a),(string)($labels[$b]??$b));
  });
  $out=[];
  foreach($keys as $key)$out[(string)$labels[$key]]=(int)$counts[$key];
  return $out;
}
function mavik_blog_topic_cloud_html(array $blog): string {
  $html='';
  foreach(mavik_blog_topic_counts($blog) as $topic=>$n){
    $html.='<button class="tag" data-tag="'.h($topic).'" type="button">'.h($topic).' · '.$n.'</button>';
  }
  return $html;
}
function mavik_blog_refresh_topic_regions(string $root,array $manifest): void {
  $cloud=mavik_blog_topic_cloud_html(manifest_visible_blog($manifest));
  $files=[$root.'/blog/index.html'];
  foreach(glob($root.'/blog/page/*/index.html')?:[] as $file)$files[]=$file;
  foreach(array_values(array_unique($files)) as $file){
    if(!is_file($file))continue;
    $html=file_get_contents($file);
    if($html===false)continue;
    if(!str_contains($html,'<!-- BOSS_BLOG_TAGS_START -->')||!str_contains($html,'<!-- BOSS_BLOG_TAGS_END -->'))continue;
    $next=replace_region($html,'<!-- BOSS_BLOG_TAGS_START -->','<!-- BOSS_BLOG_TAGS_END -->',$cloud);
    if($next!==$html)atomic_write($file,$next);
  }
}

function mavik_blog_page_url(int $page): string { return $page<=1?'/blog/':'/blog/page/'.$page.'/'; }
function mavik_blog_pager_html(int $page,int $pages): string {
  if($pages<=1)return '<nav class="blog-pagination" id="blogPagination" aria-label="Сторінки блогу" hidden></nav>';
  $out='<nav class="blog-pagination" id="blogPagination" aria-label="Сторінки блогу">';
  if($page>1)$out.='<a class="page-btn" href="'.h(mavik_blog_page_url($page-1)).'" aria-label="Попередня сторінка">←</a>';
  for($n=1;$n<=$pages;$n++){if($pages>9&&abs($n-$page)>2&&$n!==1&&$n!==$pages){if($n===2||$n===$pages-1)$out.='<span class="page-gap">…</span>';continue;}$out.='<a class="page-btn'.($n===$page?' active':'').'" href="'.h(mavik_blog_page_url($n)).'"'.($n===$page?' aria-current="page"':'').'>'.$n.'</a>';}
  if($page<$pages)$out.='<a class="page-btn" href="'.h(mavik_blog_page_url($page+1)).'" aria-label="Наступна сторінка">→</a>';
  return $out.'</nav>';
}
function mavik_blog_page_meta(string $html,int $page): string {
  $url='https://mavik.name'.mavik_blog_page_url($page);
  if($page>1&&preg_match('#<title>(.*?)</title>#su',$html,$m)){$base=preg_replace('/\s*[—-]\s*сторінка\s+\d+\s*\|\s*MaVik$/u','',(string)$m[1])??(string)$m[1];$base=preg_replace('/\s*\|\s*MaVik$/u','',$base)??$base;$title=trim($base).' — сторінка '.$page.' | MaVik';$html=preg_replace('#<title>.*?</title>#su','<title>'.h($title).'</title>',$html,1)??$html;}
  $canonical='<link rel="canonical" href="'.h($url).'"/>';
  if(preg_match('#<link\b[^>]*\brel=["\']canonical["\'][^>]*>#iu',$html))$html=preg_replace('#<link\b[^>]*\brel=["\']canonical["\'][^>]*>#iu',$canonical,$html,1)??$html;else$html=str_replace('</head>',$canonical.'</head>',$html);
  return replace_meta_content($html,'property','og:url',$url);
}
function rebuild_indexes(string $root,array $manifest): void {
  ensure_regions($root);
  if(function_exists('mavik_live_sync_book_publication_state'))mavik_live_sync_book_publication_state($root,$manifest);
  $blog=blog_sorted(manifest_visible_blog($manifest));$cards='';$focusCard='';$focusSearch=null;$otherCards=[];$otherSearch=[];$rss='';$site='';$focusedBlogSlug=load_blog_focus($root,$blog);
  foreach($blog as $x){if(!is_array($x))continue;$tags=(array)($x['tags']??[]);$search=mavik_utf8_lower(trim(implode(' ',[(string)($x['title']??''),(string)($x['seo_title']??''),(string)($x['primary_query']??''),(string)($x['category']??''),(string)($x['excerpt']??''),implode(' ',$tags)])));
    $isFocus=(string)($x['slug']??'')===$focusedBlogSlug;$href='/blog/'.h((string)$x['slug']).'/';$card='<article class="post-card'.($isFocus?' post-card-focused':'').'" data-search="'.h($search).'"><a class="post-img" href="'.$href.'"><img src="'.h(mavik_display_image_url((string)$x['image'])).'" alt="'.h((string)($x['image_alt']??$x['title'])).'"'.mavik_img_attrs($root,(string)$x['image'],true).' /></a><div class="post-copy">'.($isFocus?'<div class="post-focus-badge">У фокусі</div>':'').'<div class="post-meta"><span>'.h(ua_date_time((string)$x['date'],(string)($x['published_at']??''))).'</span><b>'.h((string)$x['category']).'</b></div><h2 class="post-title"><a href="'.$href.'">'.h((string)$x['title']).'</a></h2><p class="post-excerpt">'.h((string)$x['excerpt']).'</p><a class="readmore" href="'.$href.'">Читати далі →</a></div></article>';$searchRow=['slug'=>(string)$x['slug'],'title'=>(string)$x['title'],'category'=>(string)$x['category'],'date'=>ua_date_time((string)$x['date'],(string)($x['published_at']??'')),'excerpt'=>(string)$x['excerpt'],'image'=>mavik_display_image_url((string)$x['image']),'image_alt'=>(string)($x['image_alt']??$x['title']),'search'=>$search,'focused'=>$isFocus];if($isFocus){$focusCard=$card;$focusSearch=$searchRow;}else{$otherCards[]=$card;$otherSearch[]=$searchRow;}
    $pub=(string)($x['published_at']??((string)$x['date'].'T12:00:00+03:00'));$stamp=strtotime($pub)?:strtotime((string)$x['date'].' 12:00:00');
    $rss.='<item><title>'.h((string)$x['title']).'</title><link>https://mavik.name/blog/'.h((string)$x['slug']).'/</link><guid isPermaLink="true">https://mavik.name/blog/'.h((string)$x['slug']).'/</guid><pubDate>'.date(DATE_RSS,$stamp).'</pubDate><description>'.h((string)$x['excerpt']).'</description></item>';
    $site.='<url><loc>https://mavik.name/blog/'.h((string)$x['slug']).'/</loc><lastmod>'.h(substr((string)($x['updated_at']??$x['date']),0,10)).'</lastmod>'.(!empty($x['image'])?'<image:image><image:loc>https://mavik.name'.h((string)$x['image']).'</image:loc><image:caption>'.h((string)($x['image_alt']??$x['title'])).'</image:caption><image:title>'.h((string)$x['title']).'</image:title></image:image>':'').'</url>';
  }
  $cardRows=array_merge($focusCard!==''?[$focusCard]:[],$otherCards);$searchRows=array_merge(is_array($focusSearch)?[$focusSearch]:[],$otherSearch);$perPage=7;$count=count($cardRows);$pages=max(1,(int)ceil($count/$perPage));$cards=implode('',array_slice($cardRows,0,$perPage));
  $f=$root.'/blog/index.html';$t=file_get_contents($f);$t=replace_region($t,'<!-- BOSS_BLOG_START -->','<!-- BOSS_BLOG_END -->',$cards);$word=($count%10===1&&$count%100!==11)?'публікація':(($count%10>=2&&$count%10<=4&&!in_array($count%100,[12,13,14],true))?'публікації':'публікацій');$t=preg_replace('/<div class="search-status" id="searchStatus">.*?<\/div>/u','<div class="search-status" id="searchStatus">'.$count.' '.$word.'</div>',$t,1)??$t;$topicCloud=mavik_blog_topic_cloud_html($blog);$t=replace_region($t,'<!-- BOSS_BLOG_TAGS_START -->','<!-- BOSS_BLOG_TAGS_END -->',$topicCloud);$t=preg_replace('#<nav class="blog-pagination" id="blogPagination"[^>]*>.*?</nav>#su',mavik_blog_pager_html(1,$pages),$t,1)??$t;$t=mavik_blog_page_meta($t,1);atomic_write($f,$t);
  atomic_write($root.'/blog/search-index.json',json_encode(['version'=>1,'generated_at'=>date(DATE_ATOM),'per_page'=>$perPage,'items'=>$searchRows],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
  $pageRoot=$root.'/blog/page';if(is_dir($pageRoot))mavik_remove_tree($pageRoot);if($pages>1){if(!mkdir($pageRoot,0755,true)&&!is_dir($pageRoot))throw new RuntimeException('Не вдалося створити пагінацію блогу.');for($page=2;$page<=$pages;$page++){$dir=$pageRoot.'/'.$page;if(!mkdir($dir,0755,true)&&!is_dir($dir))throw new RuntimeException('Не вдалося створити сторінку пагінації блогу.');$pt=$t;$pt=replace_region($pt,'<!-- BOSS_BLOG_START -->','<!-- BOSS_BLOG_END -->',implode('',array_slice($cardRows,($page-1)*$perPage,$perPage)));$pt=preg_replace('/<div class="search-status" id="searchStatus">.*?<\/div>/u','<div class="search-status" id="searchStatus">'.$count.' '.$word.' · сторінка '.$page.' з '.$pages.'</div>',$pt,1)??$pt;$pt=preg_replace('#<nav class="blog-pagination" id="blogPagination"[^>]*>.*?</nav>#su',mavik_blog_pager_html($page,$pages),$pt,1)??$pt;$pt=mavik_blog_page_meta($pt,$page);atomic_write($dir.'/index.html',$pt);}}
  if(function_exists('mavik_live_sync_blog_index'))mavik_live_sync_blog_index($root,$manifest);
  $f=$root.'/blog/feed.xml';$t=file_get_contents($f);$t=replace_region($t,'<!-- BOSS_RSS_START -->','<!-- BOSS_RSS_END -->',$rss);if($blog){$stamp=strtotime((string)($blog[0]['updated_at']??$blog[0]['published_at']??($blog[0]['date'].'T12:00:00+03:00')));if($stamp!==false)$t=preg_replace('/<lastBuildDate>.*?<\\/lastBuildDate>/','<lastBuildDate>'.date(DATE_RSS,$stamp).'</lastBuildDate>',$t,1)??$t;}atomic_write($f,$t);
  $f=$root.'/sitemap.xml';$t=file_get_contents($f);$t=replace_region($t,'<!-- BOSS_SITEMAP_START -->','<!-- BOSS_SITEMAP_END -->',$site);atomic_write($f,$t);
  if(function_exists('mavik_live_sync_blog_hubs'))mavik_live_sync_blog_hubs($root,$manifest);
  if($blog){$x=$blog[0];foreach($blog as $candidate)if(is_array($candidate)&&(string)($candidate['slug']??'')===$focusedBlogSlug){$x=$candidate;break;}$mins=max(1,(int)($x['reading_minutes']??5));$feature='<article class="journal-feature reveal"><a class="journal-media" href="blog/'.h((string)$x['slug']).'/"><img alt="'.h((string)($x['image_alt']??$x['title'])).'" src="'.h(mavik_display_image_url((string)$x['image'])).'"'.mavik_img_attrs($root,(string)$x['image'],false,true).' /></a><div class="journal-copy"><div class="journal-meta"><span>У фокусі</span><span>'.$mins.' хв</span></div><h3><a href="blog/'.h((string)$x['slug']).'/">'.h((string)$x['title']).'</a></h3><p>'.h((string)$x['excerpt']).'</p><div class="hero-actions" style="margin-top:22px"><a class="btn btn-primary" href="blog/'.h((string)$x['slug']).'/">Читати статтю →</a><a class="btn" href="blog/">Увесь блог</a></div></div></article>';$homeList='';$shown=0;foreach($blog as $candidate){if(!is_array($candidate)||(string)($candidate['slug']??'')===(string)($x['slug']??''))continue;$cm=max(1,(int)($candidate['reading_minutes']??5));$homeList.='<article class="reveal"><div class="journal-meta"><span>'.h((string)($candidate['category']??'Література')).'</span><span>'.$cm.' хв</span></div><h3><a href="blog/'.h((string)$candidate['slug']).'/">'.h((string)$candidate['title']).'</a></h3><p>'.h((string)($candidate['excerpt']??'')).'</p></article>';if(++$shown>=3)break;}$f=$root.'/index.html';$t=file_get_contents($f);$t=replace_region($t,'<!-- BOSS_HOME_BLOG_START -->','<!-- BOSS_HOME_BLOG_END -->',$feature);$t=replace_region($t,'<!-- BOSS_HOME_BLOG_LIST_START -->','<!-- BOSS_HOME_BLOG_LIST_END -->',$homeList);atomic_write($f,$t);}
  $bookCards='';$homeCards='';$newBookCards='';$books=manifest_visible_books($manifest);$homeLimits=mavik_core_home_book_limits($root);$homeLimit=max((int)$homeLimits['desktop'],(int)$homeLimits['mobile']);$homeIx=0;
  foreach($books as $x){
    $keys=implode(' ',(array)($x['genre_keys']??[]));$search=h(mavik_utf8_lower(($x['title']??'').' '.($x['genre']??'').' '.($x['description']??'')));
    $isBeta=(string)($x['publication_mode']??'final')==='beta';$availability=$isBeta?'тестове читання · без EPUB':'читати на сайті · EPUB';$typeLabel=(string)$x['genre'].($isBeta?' · тестове читання':'');$bookCards.='<a class="card" data-genres="'.h($keys).'" data-search="'.$search.'" href="'.h($x['slug']).'/"><img src="'.h(mavik_display_image_url((string)$x['cover_catalog'])).'" alt="'.h($x['title']).'"'.mavik_img_attrs($root,(string)$x['cover_catalog'],true).' /><div class="meta"><div class="type">'.h($typeLabel).'</div><div class="title">'.h($x['title']).'</div><div class="availability">'.h($availability).'</div></div></a>';
    if($homeIx<$homeLimit)$homeCards.='<article class="book-card reveal"><a href="books/'.h($x['slug']).'/"><div class="cover-shell"><img src="'.h(mavik_display_image_url((string)$x['cover_home'])).'" alt="'.h($x['title']).'"'.mavik_img_attrs($root,(string)$x['cover_home'],true).' /></div></a><div class="card-meta"><div class="card-type">'.h($typeLabel).'</div><h3 class="card-title"><a href="books/'.h($x['slug']).'/">'.h($x['title']).'</a></h3><p class="card-copy">'.h($x['description']).'</p></div></article>';$homeIx++;
    if(!empty($x['is_new'])){$newBookCards.='<a class="book-card" href="/books/'.h($x['slug']).'/"><img alt="Обкладинка — '.h($x['title']).'" src="'.h(mavik_display_image_url((string)$x['cover_catalog'])).'"'.mavik_img_attrs($root,(string)$x['cover_catalog'],true).' /><div class="book-copy"><div class="book-type">'.h($typeLabel).'</div><h3 class="book-title">'.h($x['title']).'</h3><p class="book-desc">'.h($x['description']).'</p><span class="book-free">'.($isBeta?'Тестове читання →':'Читати онлайн безкоштовно →').'</span></div></a>';}$site='<url><loc>https://mavik.name/books/'.h($x['slug']).'/</loc><lastmod>'.h($x['date']).'</lastmod></url>'.$site;
  }
  $f=$root.'/books/index.html';$t=file_get_contents($f);$t=replace_region($t,'<!-- BOSS_BOOKS_START -->','<!-- BOSS_BOOKS_END -->',$bookCards);$count=count($books);$t=preg_replace('/<span[^>]+id="bookResultCount"[^>]*>\d+ [^<]+<\/span>/u','<span id="bookResultCount" class="genre-result-count">'.$count.' творів</span>',$t,1)??$t;atomic_write($f,$t);
  $f=$root.'/index.html';$t=file_get_contents($f);$t=replace_region($t,'<!-- BOSS_HOME_BOOKS_START -->','<!-- BOSS_HOME_BOOKS_END -->',$homeCards);atomic_write($f,$t);sync_home_book_limits($root,(int)$homeLimits['desktop'],(int)$homeLimits['mobile']);
  $f=$root.'/books/new/index.html';if(is_file($f)){$t=file_get_contents($f);if($t!==false&&str_contains($t,'<!-- BOSS_NEW_BOOKS_START -->')){$t=replace_region($t,'<!-- BOSS_NEW_BOOKS_START -->','<!-- BOSS_NEW_BOOKS_END -->',$newBookCards);atomic_write($f,$t);}}
  if(function_exists('mavik_live_sync_books_page')){$newBooks=array_values(array_filter($books,static fn($b)=>!empty($b['is_new'])));mavik_live_sync_books_page($root,$books,false);mavik_live_sync_books_page($root,$newBooks,true);}
  if(function_exists('mavik_seo_sync_free_books'))mavik_seo_sync_free_books($root,$manifest);
  $f=$root.'/sitemap.xml';$t=file_get_contents($f);$t=sitemap_remove_legacy_book_urls($t,$manifest);$t=replace_region($t,'<!-- BOSS_SITEMAP_START -->','<!-- BOSS_SITEMAP_END -->',$site);atomic_write($f,$t);
  if(function_exists('mavik_live_sync_sitemap'))mavik_live_sync_sitemap($root,$manifest);
  $order=load_book_order($root);sync_book_order($root,$order);
  mavik_reader_rebuild_llms($root);
  mavik_sync_static_hidden_links($root,$manifest);
  sitemap_touch_urls($root,['/','/books/','/books/new/','/blog/','/genres/']);
}

if(isset($_GET['logout'])){mavik_owner_logout();header('Location: /');exit;}
$error='';$success='';$mailSendResult=null;
if(!authed()){header('Location: /account/?next='.rawurlencode('/boss/'.(isset($_SERVER['QUERY_STRING'])&&$_SERVER['QUERY_STRING']!==''?'?'.$_SERVER['QUERY_STRING']:'')));exit;}
if(($_SERVER['REQUEST_METHOD']??'GET')!=='POST'){try{mavik_deploy_daily_backup_if_due($root,24);}catch(Throwable $backupError){error_log('Daily backup: '.$backupError->getMessage());}}
try{mavik_live_bootstrap_current($root);}catch(Throwable $bootstrapError){error_log('Site bootstrap: '.$bootstrapError->getMessage());}
if(isset($_GET['mail_unread'])){
  header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store, private');
  try{$site=mavik_contact_inbox_unread_count($root);$imap=0;try{$imap=mavik_mail_unread_count($root);}catch(Throwable $ignore){}$n=max(0,$site)+max(0,$imap);echo json_encode(['ok'=>true,'count'=>$n],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);}catch(Throwable $e){echo json_encode(['ok'=>false,'count'=>0],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);}exit;
}





if(isset($_GET['attachment'],$_GET['uid'])&&($_GET['tab']??'')==='mail'){
  try{$folder=(string)($_GET['folder']??'INBOX');$uid=max(1,(int)$_GET['uid']);$section=preg_replace('/[^0-9.]/','',(string)$_GET['attachment'])??'';$a=mavik_mail_attachment($root,$folder,$uid,$section);header('Content-Type: '.($a['mime']?:'application/octet-stream'));header('Content-Disposition: attachment; filename*=UTF-8\'\''.rawurlencode((string)$a['name']));header('Content-Length: '.strlen((string)$a['data']));echo $a['data'];exit;}catch(Throwable $e){$error=$e->getMessage();}
}

mavik_cleanup_obsolete_tts($root);
if(function_exists('mavik_live_apply_current_cleanup'))mavik_live_apply_current_cleanup($root);
// cleanup: remove obsolete maintenance artifacts from older releases.
foreach([$root.'/.maintenance-uk-on',$root.'/.maintenance-en-on',$root.'/maintenance/index.php'] as $obsoleteLocaleMaintenance){if(is_file($obsoleteLocaleMaintenance))@unlink($obsoleteLocaleMaintenance);}
$manifest=load_manifest($config);
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['action'])){
  try{
    if(!csrf_ok((string)($_POST['csrf']??'')))throw new RuntimeException('Сесію форми втрачено.');
    $action=(string)$_POST['action'];
    if($action==='owner_password_change'){
      $current=(string)($_POST['current_password']??'');$newPass=(string)($_POST['new_password']??'');$newPass2=(string)($_POST['new_password2']??'');
      if($newPass!==$newPass2)throw new RuntimeException('Нові паролі не збігаються.');
      mavik_owner_change_password($root,$current,$newPass);
      $success='Пароль власника змінено.';
    }
    elseif($action==='owner_sessions_revoke_others'){
      mavik_owner_persistent_revoke_all($root);mavik_owner_persistent_issue($root);$success='Інші довгі сесії власника завершено. Цей браузер залишився авторизованим.';
    }
    elseif($action==='core_home_limit'){
      $core=mavik_core_load($root);
      $core['home']['books_limit_desktop']=max(1,min(40,(int)($_POST['books_limit_desktop']??8)));
      $core['home']['books_limit_mobile']=max(1,min(40,(int)($_POST['books_limit_mobile']??8)));
      mavik_core_save($root,$core);rebuild_indexes($root,$manifest);$success='Кількість книг на головній для desktop і mobile змінено.';$_GET['tab']='book_home';
    }
    elseif($action==='mail_config_save'){
      mavik_mail_config_save($root,['email'=>$_POST['mail_email']??'','sender_name'=>$_POST['mail_sender_name']??'MaVik','username'=>$_POST['mail_username']??'','password'=>$_POST['mail_password']??'','imap_host'=>$_POST['imap_host']??'mx1.cityhost.com.ua','imap_port'=>$_POST['imap_port']??993,'imap_security'=>$_POST['imap_security']??'ssl','smtp_host'=>$_POST['smtp_host']??'mx1.cityhost.com.ua','smtp_port'=>$_POST['smtp_port']??587,'smtp_security'=>$_POST['smtp_security']??'starttls','webmail_url'=>$_POST['webmail_url']??'https://mx1.cityhost.com.ua/mail/']);$success='Налаштування пошти збережено тільки на сервері.';
    }
    elseif($action==='mail_test'){
      $r=mavik_mail_test($root);$success=($r['imap']?'✓ ':'✗ ').$r['imap_message'].' · '.($r['smtp']?'✓ ':'✗ ').$r['smtp_message'];
    }
    elseif($action==='mail_send'){
      $mode=(string)($_POST['mail_mode']??'send');
      $draftId=preg_replace('/[^A-Za-z0-9_-]/','',(string)($_POST['mail_draft_id']??''))??'';
      $msg=['to'=>$_POST['mail_to']??'','bcc'=>$_POST['mail_bcc']??'','subject'=>$_POST['mail_subject']??'','body'=>$_POST['mail_body']??'','html'=>$_POST['mail_body_html']??'','in_reply_to'=>$_POST['mail_in_reply_to']??''];
      if($mode==='draft'){$saved=mavik_mail_draft_save($root,$msg,$draftId);$success='Чернетку збережено.';}
      else{
        $mailSendResult=mavik_mail_send($root,$msg,(array)($_FILES['mail_attachment']??[]));
        if($draftId!=='')mavik_mail_draft_delete($root,$draftId);
        $accepted=(int)($mailSendResult['accepted']??0);$total=(int)($mailSendResult['total']??0);$failed=(int)($mailSendResult['failed']??0);
        if($accepted>0)$success='Сервер прийняв '.$accepted.' із '.$total.' окремих листів.'.($failed?' Помилок: '.$failed.'.':'');
        else $error='Жоден лист не був прийнятий сервером. Перевір результати по адресах нижче.';
      }
    }
    elseif($action==='mail_contact_save'){
      mavik_mail_contact_save($root,(string)($_POST['contact_email']??''),(string)($_POST['contact_name']??''),(string)($_POST['contact_old_email']??''));$success='Контакт збережено.';$_GET['tab']='mail';$_GET['source']='mail';$_GET['contacts']='1';
    }
    elseif($action==='mail_contact_delete'){
      mavik_mail_contact_delete($root,(string)($_POST['contact_email']??''));$success='Контакт видалено.';$_GET['tab']='mail';$_GET['source']='mail';$_GET['contacts']='1';
    }
    elseif($action==='mail_draft_delete'){
      mavik_mail_draft_delete($root,(string)($_POST['mail_draft_id']??''));$success='Чернетку видалено.';
    }
    elseif($action==='mail_delete'){
      $folder=(string)($_POST['mail_folder']??'INBOX');$uid=max(1,(int)($_POST['mail_uid']??0));mavik_mail_delete($root,$folder,$uid);$success='Лист видалено.';$_GET['tab']='mail';$_GET['source']='mail';$_GET['folder']=$folder;unset($_GET['uid'],$_GET['reply']);
    }
    elseif($action==='contact_reply'){
      $id=(string)($_POST['contact_id']??'');$m=mavik_contact_inbox_get($root,$id,false);if(!$m)throw new RuntimeException('Повідомлення не знайдено.');$html=mavik_mail_html_sanitize((string)($_POST['contact_reply_html']??''));$body=trim(html_entity_decode(strip_tags(preg_replace('#<(br|/p|/div)>#i',"\n",$html)??$html),ENT_QUOTES|ENT_HTML5,'UTF-8'));if($body==='')throw new RuntimeException('Напишіть текст відповіді.');$email=trim((string)($m['email']??''));if(!filter_var($email,FILTER_VALIDATE_EMAIL))throw new RuntimeException('У повідомленні немає коректної адреси для відповіді.');$subject=trim((string)($m['subject']??''));if($subject==='')$subject='Повідомлення з mavik.name';if(!preg_match('/^Re:/i',$subject))$subject='Re: '.$subject;mavik_mail_send($root,['to'=>$email,'subject'=>$subject,'body'=>$body,'html'=>$html]);mavik_contact_inbox_patch($root,$id,['seen'=>true,'seen_at'=>(string)($m['seen_at']??date(DATE_ATOM))?:date(DATE_ATOM),'replied'=>true,'replied_at'=>date(DATE_ATOM)]);$success='Відповідь надіслано.';
    }
    elseif($action==='contact_delete'){
      $id=(string)($_POST['contact_id']??'');mavik_contact_inbox_delete($root,$id);$success='Повідомлення видалено.';
    }
    elseif($action==='workspace_upload'){
      $name=mavik_workspace_github_upload($root,(array)($_FILES['workspace_file']??[]));$success='Файл «'.$name.'» завантажено.';
    }
    elseif($action==='workspace_delete'){
      mavik_workspace_github_delete($root,(string)($_POST['workspace_path']??''),(string)($_POST['workspace_sha']??''));$success='Файл видалено.';
    }
    elseif($action==='workspace_github_token'){
      mavik_workspace_github_save_token($root,(string)($_POST['github_token']??''));$success='GitHub token збережено.';
    }
    elseif($action==='reader_error_status'){
      mavik_reader_error_set_status($root,(string)($_POST['error_id']??''),(string)($_POST['status']??'new'));$success='Статус повідомлення оновлено.';
    }
    elseif($action==='seo_bing_key'){
      mavik_seo_save_bing_key($root,(string)($_POST['bing_api_key']??''));$success='Bing API key збережено лише в захищеному _site-state.';
    }
    elseif($action==='seo_scan'){
      $r=mavik_seo_run_scan($root,$manifest,500);$s=(array)($r['summary']??[]);$success='Робот-аудит завершено: '.(int)($s['crawled']??0).' URL, HTTP-помилок '.(int)($s['http_errors']??0).', книги '.(int)($s['books_ok']??0).'/'.(int)($s['books_expected']??0).'.';
    }
    elseif($action==='seo_indexnow_all'){
      $urls=['/'];$sx=@simplexml_load_file($root.'/sitemap.xml');if($sx)foreach($sx->url as $u){$loc=trim((string)$u->loc);if($loc!=='')$urls[]=$loc;}
      $r=mavik_indexnow_submit($root,$urls);$success=$r['message'].' · URL: '.(int)($r['count']??0).'.';
    }
    elseif($action==='seo_bing_submit_all'){
      $urls=['/'];$sx=@simplexml_load_file($root.'/sitemap.xml');if($sx)foreach($sx->url as $u){$loc=trim((string)$u->loc);if($loc!=='')$urls[]=$loc;}
      $r=mavik_bing_submit_urls($root,$urls);if((int)($r['status']??0)<200||(int)($r['status']??0)>=300)throw new RuntimeException((string)$r['message']);$success=$r['message'].' · URL: '.(int)($r['count']??0).'.';
    }
    elseif($action==='backup_create'){
      $path=mavik_deploy_manual_backup($root,'manual');$success='Повний backup LIVE DATA створено й перевірено: '.basename($path).'.';
    }
    elseif($action==='backup_create_download'){
      $path=mavik_deploy_manual_backup($root,'manual-download');mavik_deploy_stream_backup($root,basename($path));
    }
    elseif($action==='backup_create_golden_download'){
      $path=mavik_deploy_manual_backup($root,'golden');mavik_deploy_stream_backup($root,basename($path));
    }
    elseif($action==='backup_download'){
      mavik_deploy_stream_backup($root,(string)($_POST['backup']??''));
    }
    elseif($action==='backup_delete'){
      $deleted=mavik_deploy_delete_backups($root,[(string)($_POST['backup']??'')]);$success='Backup видалено: '.count($deleted).'.';
    }
    elseif($action==='backup_delete_selected'){
      $deleted=mavik_deploy_delete_backups($root,(array)($_POST['backups']??[]));$success='Вибрані backup-и видалено: '.count($deleted).'.';
    }
    elseif($action==='backup_restore'){
      $r=mavik_deploy_restore_named_backup($root,(string)($_POST['backup']??''));$manifest=load_manifest($config);
      $success='LIVE DATA відновлено з '.(string)$r['restored'].'. Safety-backup: '.(string)$r['safety_backup'].'. Після звірки: книг '.(int)($r['books_after']??0).', дописів '.(int)($r['blog_after']??0).'. Новіші фізичні матеріали не викинуто; поточний порядок і фокус збережено.';
    }
    elseif($action==='site_deploy'){
      $r=mavik_deploy_from_upload($root,(array)($_FILES['release_zip']??[]));
      $deployDiscovery='';if(empty($r['waiting'])){try{$sx=@file_get_contents($root.'/sitemap.xml');$urls=is_string($sx)&&function_exists('mavik_seo_sitemap_urls')?mavik_seo_sitemap_urls($sx):[];if($urls&&function_exists('mavik_indexnow_submit')){$ir=mavik_indexnow_submit($root,$urls);$deployDiscovery.=' IndexNow: '.(string)($ir['message']??'').'.';}if($urls&&function_exists('mavik_bing_submit_urls')){$br=mavik_bing_submit_urls($root,$urls);$bs=(int)($br['status']??0);if($bs>=200&&$bs<300)$deployDiscovery.=' Bing: '.(string)($br['message']??'').'.';elseif($bs>0)$deployDiscovery.=' Bing: не вдалося надіслати (HTTP '.$bs.'), deploy не скасовано.';}}catch(Throwable $e){$deployDiscovery.=' Пошукове сповіщення: помилка, deploy не скасовано.';}}
      if(!empty($r['waiting'])){$success='Частину '.(int)$r['part'].' із '.(int)$r['total_parts'].' для R'.(string)$r['release'].' прийнято. Завантажте решту частин — після останньої Boss автоматично збере й розгорне реліз.';}
      elseif(!empty($r['patch'])){$success='Overlay-патч «'.(string)$r['patch_id'].'» успішно встановлено поверх R'.(string)$r['release'].'. Змінено файлів: '.(int)$r['copied'].', видалено: '.(int)($r['deleted']??0).'. Резервна копія: '.(string)$r['backup'].'.';if(!empty($r['archive_cleanup_warning']))$success.=' '.(string)$r['archive_cleanup_warning'];}
      else{$deployedLabel=trim((string)($r['release_label']??''));if($deployedLabel==='')$deployedLabel='R'.(string)$r['release'];$success='Збірку '.$deployedLabel.' успішно розгорнуто. Резервна копія: '.(string)$r['backup'].'. ZIP-пакети після розгортання видалено.';if(!empty($r['archive_cleanup_warning']))$success.=' '.(string)$r['archive_cleanup_warning'];}
      if(empty($r['waiting']))$success.=$deployDiscovery;
    }
    elseif($action==='deploy_failed_delete'){
      mavik_deploy_delete_failed($root,(string)($_POST['archive']??''));$success='Невдалий ZIP видалено.';
    }
    elseif($action==='state_export'){
      $payload=state_snapshot_payload($root,$config);$json=json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES);if($json===false)throw new RuntimeException('Не вдалося створити файл стану.');
      $name='mavik-state-'.date('Y-m-d_H-i-s').'.json';header('Content-Type: application/json; charset=utf-8');header('Content-Disposition: attachment; filename="'.$name.'"');header('Content-Length: '.strlen($json));echo $json;exit;
    }
    elseif($action==='state_import'){
      $f=$_FILES['state_file']??[];if(empty($f['tmp_name'])||!is_uploaded_file($f['tmp_name']))throw new RuntimeException('Оберіть файл стану .json.');if((int)($f['size']??0)>5*1024*1024)throw new RuntimeException('Файл стану завеликий.');$raw=file_get_contents((string)$f['tmp_name']);$snap=$raw!==false?json_decode($raw,true):null;if(!is_array($snap))throw new RuntimeException('Не вдалося прочитати JSON стану.');$data=state_snapshot_validate($snap);state_snapshot_restore($root,$config,$data);$manifest=load_manifest($config);$success='Стан сайту відновлено. Порядок книг, музика, блог і медіатека синхронізовані.';
    }
    elseif($action==='genre_add'){
      $label=trim((string)($_POST['genre_label']??''));$key=register_book_genre($root,$label);$allGenres=load_book_genres($root);$success='Жанр «'.(string)($allGenres[$key]??$label).'» додано до постійного переліку.';
    }
    elseif($action==='maintenance_toggle'){
      $mode=(string)($_POST['mode']??'');
      if($mode==='on'){mavik_maintenance_enable($root);$success='Технічну перерву увімкнено. Відвідувачі бачать заглушку, а цей авторизований браузер бачить увесь сайт.';}
      elseif($mode==='off'){mavik_maintenance_disable($root);$success='Технічну перерву вимкнено. Сайт знову відкритий для всіх.';}
      else throw new RuntimeException('Невідомий режим технічної перерви.');
    }
    elseif($action==='rebuild'){rebuild_indexes($root,$manifest);$success='Індекси відновлено з файлового маніфесту.';}
    elseif($action==='book_adopt_live'){
      $slug=preg_replace('/[^a-z0-9-]/','',(string)($_POST['slug']??''))??'';$book=mavik_adopt_live_book_into_manifest($root,$config,$manifest,$slug);$success='Книгу «'.(string)$book['title'].'» відновлено в Boss без повторного завантаження. Live-сторінку, читанку та EPUB не видаляли.';
    }
    elseif($action==='book_adopt_live_selected'){
      $count=mavik_adopt_selected_live_books_into_manifest($root,$config,$manifest,(array)($_POST['slugs']??[]));$success='Відновлено книг у Boss: '.$count.'. Чинний порядок, фокус, обкладинки та наявні записи збережено.';
    }
    elseif($action==='blog_adopt_live'){
      $slug=preg_replace('/[^a-z0-9-]/','',(string)($_POST['slug']??''))??'';$post=mavik_adopt_live_blog_into_manifest($root,$config,$manifest,$slug);$success='Допис «'.(string)$post['title'].'» відновлено в Boss. Публічну сторінку та зображення не перезаписували.';
    }
    elseif($action==='blog_adopt_live_all'){
      $count=mavik_adopt_all_live_blogs_into_manifest($root,$config,$manifest);$success=$count>0?'Відновлено дописів у Boss: '.$count.'. Публічні сторінки не перезаписували.':'Відсутніх live-дописів не знайдено.';
    }
    elseif($action==='blog_adopt_live_selected'){
      $count=mavik_adopt_selected_live_blogs_into_manifest($root,$config,$manifest,(array)($_POST['slugs']??[]));$success='Відновлено дописів у Boss: '.$count.'. Чинний фокус, зображення та наявні записи збережено.';
    }
    elseif($action==='book_order'){
      $catalog=extract_admin_catalog_books($root);$posted=json_decode((string)($_POST['order']??'[]'),true);if(!is_array($posted))throw new RuntimeException('Не вдалося прочитати новий порядок книг.');
      $seen=[];$order=[];foreach($posted as $slug){$slug=(string)$slug;if(isset($catalog[$slug])&&!isset($seen[$slug])){$seen[$slug]=1;$order[]=$slug;}}foreach(array_keys($catalog) as $slug)if(!isset($seen[$slug]))$order[]=$slug;
      if(!$order)throw new RuntimeException('Каталог книг порожній.');save_book_order($root,$order);$manifest=manifest_apply_book_order($manifest,$order);save_manifest($config,$manifest);rebuild_indexes($root,$manifest);$verified=load_book_order($root);if(array_slice($verified,0,count($order))!==$order)throw new RuntimeException('Порядок книг не пройшов контрольне читання після збереження.');$success='Порядок книг збережено й фізично застосовано до бібліотеки та головної сторінки.';
    }
    elseif($action==='book_focus'){
      $catalog=extract_catalog_books($root);$slug=(string)($_POST['focus_slug']??'');
      if($slug===''){save_book_focus($root,'');sitemap_touch_urls($root,['/']);$success='Книгу у фокусі прибрано. На головній лишається порожнє місце.';}
      else{if(!isset($catalog[$slug]))throw new RuntimeException('Книгу для фокусу не знайдено.');save_book_focus($root,$slug);sitemap_touch_urls($root,['/']);$success='Книгу у фокусі змінено на «'.$catalog[$slug]['title'].'».';}
    }
    elseif($action==='blog_focus'){
      $blog=blog_sorted(manifest_visible_blog($manifest));$slug=(string)($_POST['focus_slug']??'');$selected=null;foreach($blog as $x)if(is_array($x)&&(string)($x['slug']??'')===$slug){$selected=$x;break;}
      if(!$selected)throw new RuntimeException('Оберіть допис блогу.');
      save_blog_focus($root,$slug);rebuild_indexes($root,$manifest);$success='Блог у фокусі змінено на «'.(string)$selected['title'].'».';
    }
    elseif($action==='music_add_track'){
      $lib=load_music_library($root);$title=trim((string)($_POST['title']??''));$artist=trim((string)($_POST['artist']??'MaVik_AI'))?:'MaVik_AI';$album=trim((string)($_POST['album']??'Окремі треки'))?:'Окремі треки';$duration=max(0,(float)($_POST['duration']??0));if(mavik_utf8_strlen($title)<1)throw new RuntimeException('Вкажіть назву треку.');[, $src]=upload_audio($_FILES['audio']??[],$root,$title);$cover=upload_music_cover($_FILES['cover']??[],$root,$title);$id='user-'.substr(bin2hex(random_bytes(8)),0,14);$num=1;foreach($lib['tracks'] as $t)if(is_array($t)&&($t['album']??'')===$album)$num=max($num,(int)($t['track']??0)+1);$lib['tracks'][]=['id'=>$id,'title'=>$title,'artist'=>$artist,'album'=>$album,'track'=>$num,'duration'=>$duration,'src'=>$src,'cover'=>$cover,'managed'=>true,'hidden'=>false];save_music_library($root,$lib);$success='Трек «'.$title.'» додано.';
    }
    elseif($action==='music_external_add'){
      $lib=load_music_library($root);$book=preg_replace('/[^a-z0-9-]/','',(string)($_POST['book_slug']??''))??'';$title=trim((string)($_POST['title']??''));$source=trim((string)($_POST['source']??''));$note=trim((string)($_POST['note']??''));$url=external_music_url((string)($_POST['url']??''));
      if($book===''||!isset(extract_catalog_books($root)[$book]))throw new RuntimeException('Оберіть книгу.');if($title==='')throw new RuntimeException('Вкажіть назву рекомендації.');
      $id='ext-'.substr(bin2hex(random_bytes(8)),0,14);$item=['id'=>$id,'title'=>$title,'source'=>$source,'note'=>$note,'url'=>$url,'provider'=>external_music_provider($url),'added_at'=>date(DATE_ATOM)];
      if(!isset($lib['external_recommendations'][$book])||!is_array($lib['external_recommendations'][$book]))$lib['external_recommendations'][$book]=[];$lib['external_recommendations'][$book][]=$item;save_music_library($root,$lib);$success='Зовнішню музичну рекомендацію додано.';
    }
    elseif($action==='music_external_delete'){
      $lib=load_music_library($root);$book=preg_replace('/[^a-z0-9-]/','',(string)($_POST['book_slug']??''))??'';$id=(string)($_POST['recommendation_id']??'');$items=(array)($lib['external_recommendations'][$book]??[]);$lib['external_recommendations'][$book]=array_values(array_filter($items,fn($x)=>!is_array($x)||($x['id']??'')!==$id));save_music_library($root,$lib);$success='Рекомендацію прибрано.';
    }
    elseif($action==='music_track_order'){
      $lib=load_music_library($root);$map=music_track_map($lib);$posted=json_decode((string)($_POST['order']??'[]'),true);if(!is_array($posted))throw new RuntimeException('Не вдалося прочитати порядок треків.');$seen=[];$tracks=[];foreach($posted as $id){$id=(string)$id;if(isset($map[$id])&&!isset($seen[$id])){$seen[$id]=1;$tracks[]=$map[$id];}}foreach($map as $id=>$t)if(!isset($seen[$id]))$tracks[]=$t;$lib['tracks']=$tracks;save_music_library($root,$lib);$success='Порядок треків збережено.';
    }
    elseif($action==='music_track_update'){
      $lib=load_music_library($root);$id=(string)($_POST['track_id']??'');$found=false;foreach($lib['tracks'] as &$t){if(!is_array($t)||($t['id']??'')!==$id)continue;$title=trim((string)($_POST['title']??''));if($title==='')throw new RuntimeException('Назва треку не може бути порожньою.');$t['title']=$title;$t['artist']=trim((string)($_POST['artist']??''))?:'MaVik_AI';$t['album']=trim((string)($_POST['album']??''))?:'Окремі треки';$t['duration']=max(0,(float)($_POST['duration']??0));if(!empty($_FILES['cover']['tmp_name'])){$old=(string)($t['cover']??'');$t['cover']=upload_music_cover($_FILES['cover'],$root,$title);delete_managed_music_cover($root,$old);}$found=true;break;}unset($t);if(!$found)throw new RuntimeException('Трек не знайдено.');save_music_library($root,$lib);$success='Дані треку оновлено.';
    }
    elseif($action==='music_track_visibility'){
      $lib=load_music_library($root);$id=(string)($_POST['track_id']??'');$found=false;$hidden=false;foreach($lib['tracks'] as &$t){if(!is_array($t)||($t['id']??'')!==$id)continue;$t['hidden']=empty($t['hidden']);$hidden=!empty($t['hidden']);$found=true;break;}unset($t);if(!$found)throw new RuntimeException('Трек не знайдено.');save_music_library($root,$lib);$success=$hidden?'Трек приховано з публічної музики.':'Трек знову показується публічно.';
    }
    elseif($action==='music_track_delete'){
      $lib=load_music_library($root);$id=(string)($_POST['track_id']??'');$removed=null;$tracks=[];foreach($lib['tracks'] as $t){if(is_array($t)&&($t['id']??'')===$id){$removed=$t;continue;}$tracks[]=$t;}if(!$removed)throw new RuntimeException('Трек не знайдено.');$lib['tracks']=$tracks;foreach($lib['collections'] as &$c)if(is_array($c))$c['tracks']=array_values(array_filter((array)($c['tracks']??[]),fn($x)=>(string)$x!==$id));unset($c);save_music_library($root,$lib);if(!empty($removed['managed'])){delete_managed_music_file($root,(string)($removed['src']??''));delete_managed_music_cover($root,(string)($removed['cover']??''));}$success='Трек «'.(string)($removed['title']??'').'» прибрано з каталогу та збірок.';
    }
    elseif($action==='music_collection_create'){
      $lib=load_music_library($root);$name=trim((string)($_POST['name']??''));if($name==='')throw new RuntimeException('Вкажіть назву збірки.');$base=slugify($name)?:'collection';$id=$base;$used=array_column((array)$lib['collections'],'id');$n=2;while(in_array($id,$used,true))$id=$base.'-'.$n++;$cover=upload_music_cover($_FILES['cover']??[],$root,$name);$lib['collections'][]=['id'=>$id,'name'=>$name,'description'=>trim((string)($_POST['description']??'')),'cover'=>$cover,'tracks'=>[],'hidden'=>false];save_music_library($root,$lib);$success='Збірку «'.$name.'» створено. Тепер додайте до неї треки.';
    }
    elseif($action==='music_collection_update'){
      $lib=load_music_library($root);$id=(string)($_POST['collection_id']??'');$found=false;foreach($lib['collections'] as &$c){if(!is_array($c)||($c['id']??'')!==$id)continue;$name=trim((string)($_POST['name']??''));if($name==='')throw new RuntimeException('Назва збірки не може бути порожньою.');$c['name']=$name;$c['description']=trim((string)($_POST['description']??''));if(!empty($_FILES['cover']['tmp_name'])){$old=(string)($c['cover']??'');$c['cover']=upload_music_cover($_FILES['cover'],$root,$name);delete_managed_music_cover($root,$old);}$found=true;break;}unset($c);if(!$found)throw new RuntimeException('Збірку не знайдено.');save_music_library($root,$lib);$success='Збірку оновлено.';
    }
    elseif($action==='music_collection_visibility'){
      $lib=load_music_library($root);$id=(string)($_POST['collection_id']??'');$found=false;$hidden=false;foreach($lib['collections'] as &$c){if(!is_array($c)||($c['id']??'')!==$id)continue;$c['hidden']=empty($c['hidden']);$hidden=!empty($c['hidden']);$found=true;break;}unset($c);if(!$found)throw new RuntimeException('Збірку не знайдено.');save_music_library($root,$lib);$success=$hidden?'Збірку приховано з публічного сайту.':'Збірку знову показано публічно.';
    }
    elseif($action==='music_collection_add_track'){
      $lib=load_music_library($root);$cid=(string)($_POST['collection_id']??'');$tid=(string)($_POST['track_id']??'');$map=music_track_map($lib);if(!isset($map[$tid]))throw new RuntimeException('Трек не знайдено.');$found=false;foreach($lib['collections'] as &$c){if(!is_array($c)||($c['id']??'')!==$cid)continue;$ids=array_values((array)($c['tracks']??[]));if(!in_array($tid,$ids,true))$ids[]=$tid;$c['tracks']=$ids;$found=true;break;}unset($c);if(!$found)throw new RuntimeException('Збірку не знайдено.');save_music_library($root,$lib);$success='Трек додано до збірки.';
    }
    elseif($action==='music_collection_remove_track'){
      $lib=load_music_library($root);$cid=(string)($_POST['collection_id']??'');$tid=(string)($_POST['track_id']??'');$found=false;foreach($lib['collections'] as &$c){if(!is_array($c)||($c['id']??'')!==$cid)continue;$c['tracks']=array_values(array_filter((array)($c['tracks']??[]),fn($x)=>(string)$x!==$tid));$found=true;break;}unset($c);if(!$found)throw new RuntimeException('Збірку не знайдено.');save_music_library($root,$lib);$success='Трек прибрано зі збірки.';
    }
    elseif($action==='music_collection_order'){
      $lib=load_music_library($root);$cid=(string)($_POST['collection_id']??'');$posted=json_decode((string)($_POST['order']??'[]'),true);if(!is_array($posted))throw new RuntimeException('Не вдалося прочитати порядок збірки.');$map=music_track_map($lib);$found=false;foreach($lib['collections'] as &$c){if(!is_array($c)||($c['id']??'')!==$cid)continue;$allowed=array_flip(array_map('strval',(array)($c['tracks']??[])));$seen=[];$ids=[];foreach($posted as $tid){$tid=(string)$tid;if(isset($allowed[$tid],$map[$tid])&&!isset($seen[$tid])){$seen[$tid]=1;$ids[]=$tid;}}foreach(array_keys($allowed) as $tid)if(isset($map[$tid])&&!isset($seen[$tid]))$ids[]=$tid;$c['tracks']=$ids;$found=true;break;}unset($c);if(!$found)throw new RuntimeException('Збірку не знайдено.');save_music_library($root,$lib);$success='Порядок у збірці збережено.';
    }
    elseif($action==='music_collection_delete'){
      $lib=load_music_library($root);$cid=(string)($_POST['collection_id']??'');$removed=null;$out=[];foreach($lib['collections'] as $c){if(is_array($c)&&($c['id']??'')===$cid){$removed=$c;continue;}$out[]=$c;}if(!$removed)throw new RuntimeException('Збірку не знайдено.');$lib['collections']=$out;foreach($lib['book_collections'] as $slug=>$x)if((string)$x===$cid)$lib['book_collections'][$slug]='all';delete_managed_music_cover($root,(string)($removed['cover']??''));save_music_library($root,$lib);$success='Збірку «'.(string)($removed['name']??'').'» видалено. Самі треки залишилися.';
    }
    elseif($action==='music_book_assign'){
      $lib=load_music_library($root);$valid=['all'=>1,'none'=>1];
      foreach($lib['collections'] as $c)if(is_array($c)&&($id=(string)($c['id']??''))!=='')$valid[$id]=1;
      foreach($lib['tracks'] as $t)if(is_array($t)&&($id=(string)($t['id']??''))!=='')$valid['track:'.$id]=1;
      $catalog=extract_catalog_books($root);$posted=(array)($_POST['book_music']??[]);$assign=[];
      foreach($catalog as $slug=>$x){$v=(string)($posted[$slug]??'all');$assign[$slug]=isset($valid[$v])?$v:'all';}
      $lib['book_collections']=$assign;save_music_library($root,$lib);$success='Музику для книг збережено.';
    }
    elseif($action==='media_add'){
      $type=(string)($_POST['media_type']??'');$label=trim((string)($_POST['label']??''));$name=media_upload_file($_FILES['media']??[],$root,$type,$label!==''?$label:(string)($_FILES['media']['name']??'image'));$success='Зображення «'.$name.'» додано до медіатеки.';
    }
    elseif($action==='media_replace'){
      $type=(string)($_POST['media_type']??'');if($type==='covers')throw new RuntimeException('Обкладинку змінюйте через «Редагувати книгу». Окремий дублюючий інструмент вимкнено.');$name=(string)($_POST['file']??'');media_replace_file($_FILES['media']??[],$root,$type,$name);$success='Зображення «'.basename($name).'» замінено без зміни адреси.';
    }
    elseif($action==='media_delete'){
      $type=(string)($_POST['media_type']??'');$name=(string)($_POST['file']??'');media_delete_file($root,$type,$name);$success='Зображення видалено.';
    }
    elseif($action==='media_order'){
      $type=(string)($_POST['media_type']??'');$posted=json_decode((string)($_POST['order']??'[]'),true);if(!is_array($posted))throw new RuntimeException('Не вдалося прочитати порядок зображень.');media_save_order($root,$type,$posted);$success='Порядок медіатеки збережено.';
    }
    elseif($action==='blog'){
      $title=trim((string)($_POST['title']??''));$category=trim((string)($_POST['category']??''));$excerpt=trim((string)($_POST['excerpt']??''));$seoTitle=blog_seo_clean((string)($_POST['seo_title']??''),180);$metaDescription=blog_seo_clean((string)($_POST['meta_description']??''),400);$primaryQuery=blog_seo_clean((string)($_POST['primary_query']??''),180);$imageAlt=blog_seo_clean((string)($_POST['image_alt']??''),240);$seoCluster=blog_cluster_value((string)($_POST['seo_cluster']??'auto'));$date=(string)($_POST['date']??date('Y-m-d'));$publishedTime=trim((string)($_POST['published_time']??date('H:i')));$slug=slugify(trim((string)($_POST['slug']??''))?:$title);$body=sanitize_blog_html((string)($_POST['body_html']??''));
      if(mavik_utf8_strlen($title)<3||mavik_utf8_strlen($excerpt)<20||$category===''||$slug==='')throw new RuntimeException('Заповніть заголовок, категорію, опис і текст.');$seoMissing=[];if($seoTitle==='')$seoMissing[]='SEO title';if($metaDescription==='')$seoMissing[]='Meta description';if($primaryQuery==='')$seoMissing[]='Основний пошуковий запит';if($imageAlt==='')$seoMissing[]='ALT ілюстрації';if($seoMissing)throw new RuntimeException('Не заповнено: '.implode(', ',$seoMissing).'.');if(is_dir($root.'/blog/'.$slug))throw new RuntimeException('Такий slug уже існує.');
      $blogImageUpload=$_FILES['image']??[];blog_prepare_upload_3x2($blogImageUpload);$imgUrl=media_pick_url($root,'blog',(string)($_POST['image_library']??''),$blogImageUpload,$slug);blog_image_ratio_guard($root,$imgUrl);$tags=array_values(array_filter(array_unique(array_map('trim',explode(',',(string)($_POST['tags']??''))))));if(!$tags)$tags=[$category];$now=blog_publication_atom($date,$publishedTime);
      $post=['title'=>$title,'slug'=>$slug,'category'=>$category,'excerpt'=>$excerpt,'seo_title'=>$seoTitle,'meta_description'=>$metaDescription,'primary_query'=>$primaryQuery,'image_alt'=>$imageAlt,'seo_cluster'=>$seoCluster,'date'=>$date,'tags'=>$tags,'image'=>$imgUrl,'body_html'=>$body,'sidebar_prefix_html'=>'','search_text'=>trim($seoTitle.' '.$primaryQuery.' '.blog_plain_text($body)),'reading_minutes'=>max(1,(int)round(blog_word_count($body)/140)),'published_at'=>$now,'updated_at'=>$now,'managed'=>true];$manifest['blog'][]=$post;$manifest['blog']=blog_sorted((array)$manifest['blog']);save_manifest($config,$manifest);render_all_blog_articles($root,$config,$manifest['blog']);rebuild_indexes($root,$manifest);$success='Статтю опубліковано з SEO-профілем: /blog/'.$slug.'/';
    }
    elseif($action==='blog_edit'){
      $slug=(string)($_POST['slug']??'');$idx=null;foreach((array)($manifest['blog']??[]) as $k=>$p)if(is_array($p)&&($p['slug']??'')===$slug){$idx=$k;break;}if($idx===null)throw new RuntimeException('Статтю не знайдено в маніфесті.');$post=blog_normalize_seo_post((array)$manifest['blog'][$idx]);
      $title=trim((string)($_POST['title']??''));$category=trim((string)($_POST['category']??''));$excerpt=trim((string)($_POST['excerpt']??''));$seoTitle=blog_seo_clean((string)($_POST['seo_title']??''),180);$metaDescription=blog_seo_clean((string)($_POST['meta_description']??''),400);$primaryQuery=blog_seo_clean((string)($_POST['primary_query']??''),180);$imageAlt=blog_seo_clean((string)($_POST['image_alt']??''),240);$seoCluster=blog_cluster_value((string)($_POST['seo_cluster']??'auto'));$date=(string)($_POST['date']??(string)$post['date']);$publishedTime=trim((string)($_POST['published_time']??blog_publication_time_value($post)));$body=sanitize_blog_html((string)($_POST['body_html']??''));if(mavik_utf8_strlen($title)<3||mavik_utf8_strlen($excerpt)<20||$category==='')throw new RuntimeException('Заповніть заголовок, категорію, опис і текст.');$seoMissing=[];if($seoTitle==='')$seoMissing[]='SEO title';if($metaDescription==='')$seoMissing[]='Meta description';if($primaryQuery==='')$seoMissing[]='Основний пошуковий запит';if($imageAlt==='')$seoMissing[]='ALT ілюстрації';if($seoMissing)throw new RuntimeException('Не заповнено: '.implode(', ',$seoMissing).'.');$tags=array_values(array_filter(array_unique(array_map('trim',explode(',',(string)($_POST['tags']??''))))));if(!$tags)$tags=[$category];$oldImage=(string)($post['image']??'');$image=$oldImage;$selectedImage=trim((string)($_POST['image_library']??''));$imageChanged=false;
      if(!empty($_FILES['image']['tmp_name'])){$blogImageUpload=$_FILES['image'];blog_prepare_upload_3x2($blogImageUpload);$image=media_pick_url($root,'blog','',$blogImageUpload,$slug);$imageChanged=true;}elseif($selectedImage!==''){$selectedImage=media_safe_file($selectedImage);if(is_file(media_dir($root,'blog').'/'.$selectedImage)){$candidate=media_url('blog',$selectedImage);if($candidate!==$oldImage){$image=$candidate;$imageChanged=true;}}}if($imageChanged)blog_image_ratio_guard($root,$image);
      $oldDate=(string)($post['date']??$date);$oldPublished=(string)($post['published_at']??'');$post['published_at']=blog_publication_atom($date,$publishedTime,$oldPublished);$post['title']=$title;$post['category']=$category;$post['excerpt']=$excerpt;$post['seo_title']=$seoTitle;$post['meta_description']=$metaDescription;$post['primary_query']=$primaryQuery;$post['image_alt']=$imageAlt;$post['seo_cluster']=$seoCluster;$post['date']=$date;$post['tags']=$tags;$post['image']=$image;unset($post['stamp_type'],$post['stamp_position'],$post['stamp_rotation'],$post['stamp_opacity'],$post['stamp_embedded']);$post['body_html']=$body;$post['search_text']=trim($seoTitle.' '.$primaryQuery.' '.blog_plain_text($body));$post['reading_minutes']=max(1,(int)round(blog_word_count($body)/140));$post['updated_at']=date(DATE_ATOM);$post['managed']=true;$manifest['blog'][$idx]=$post;$manifest['blog']=blog_sorted((array)$manifest['blog']);save_manifest($config,$manifest);render_all_blog_articles($root,$config,$manifest['blog']);rebuild_indexes($root,$manifest);$success='Зміни та SEO-профіль збережено: /blog/'.$slug.'/';
    }
    elseif($action==='blog_seo_rebuild'){
      $changed=0;$all=(array)($manifest['blog']??[]);foreach($all as $i=>$p){if(!is_array($p))continue;$n=blog_normalize_seo_post($p);if($n!==$p){$all[$i]=$n;$changed++;}}$manifest['blog']=blog_sorted($all);$manifest['version']=max(7,(int)($manifest['version']??0));save_manifest($config,$manifest);render_all_blog_articles($root,$config,(array)$manifest['blog']);rebuild_indexes($root,$manifest);$success='SEO-обгортку перебудовано для всіх дописів. Оновлено записів: '.$changed.'. Тексти статей не переписувалися.';
    }
    elseif($action==='announcement_visibility'){
      $state=load_announcements($root);$id=preg_replace('/[^a-z0-9-]/','',(string)($_POST['id']??''))??'';$idx=announcement_index($state,$id);if($idx<0)throw new RuntimeException('Анонс не знайдено.');$state['items'][$idx]['hidden']=empty($state['items'][$idx]['hidden']);$hidden=!empty($state['items'][$idx]['hidden']);save_announcements($root,$state);$success=$hidden?'Анонс приховано.':'Анонс показується на сайті.';
    }
    elseif($action==='announcement_delete'){
      $state=load_announcements($root);$id=preg_replace('/[^a-z0-9-]/','',(string)($_POST['id']??''))??'';$idx=announcement_index($state,$id);if($idx<0)throw new RuntimeException('Анонс не знайдено.');array_splice($state['items'],$idx,1);mavik_remove_tree($root.'/announcements/'.$id);save_announcements($root,$state);$success='Анонс видалено.';
    }
    elseif($action==='announcement_order'){
      $state=load_announcements($root);$posted=json_decode((string)($_POST['order']??'[]'),true);if(!is_array($posted))throw new RuntimeException('Не вдалося прочитати порядок анонсів.');$valid=[];foreach(announcement_combined_items($manifest,$state) as $row)$valid[(string)$row['id']]=true;$seen=[];$order=[];foreach($posted as $id){$id=(string)$id;if(isset($valid[$id])&&!isset($seen[$id])){$seen[$id]=1;$order[]=$id;}}foreach(array_keys($valid) as $id)if(!isset($seen[$id]))$order[]=$id;$state['order']=$order;save_announcements($root,$state);$success='Порядок анонсів збережено.';
    }
    elseif($action==='announcements_toggle'){
      $state=load_announcements($root);$state['visible']=empty($state['visible']);save_announcements($root,$state);$success=!empty($state['visible'])?'Блок анонсів увімкнено.':'Блок анонсів приховано.';
    }
    elseif($action==='blog_visibility'){
      $slug=preg_replace('/[^a-z0-9-]/','',(string)($_POST['slug']??''))??'';$idx=-1;foreach((array)($manifest['blog']??[]) as $i=>$p)if(is_array($p)&&(string)($p['slug']??'')===$slug){$idx=(int)$i;break;}if($idx<0)throw new RuntimeException('Допис не знайдено.');$manifest['blog'][$idx]['hidden']=empty($manifest['blog'][$idx]['hidden']);$hidden=!empty($manifest['blog'][$idx]['hidden']);save_manifest($config,$manifest);render_all_blog_articles($root,$config,(array)$manifest['blog']);rebuild_indexes($root,$manifest);$success=$hidden?'Допис приховано з публічного сайту.':'Допис знову опубліковано.';
    }
    elseif($action==='blog_delete'){
      $slug=preg_replace('/[^a-z0-9-]/','',(string)($_POST['slug']??''))??'';$idx=-1;foreach((array)($manifest['blog']??[]) as $i=>$p)if(is_array($p)&&(string)($p['slug']??'')===$slug){$idx=(int)$i;break;}if($idx<0)throw new RuntimeException('Допис не знайдено.');$old=(array)$manifest['blog'][$idx];$manifest['blog'][$idx]['hidden']=true;$manifest['blog'][$idx]['deleted']=true;$manifest['blog'][$idx]['deleted_at']=date(DATE_ATOM);mavik_remove_tree($root.'/blog/'.$slug);delete_old_blog_user_image($root,(string)($old['image']??''));save_manifest($config,$manifest);rebuild_indexes($root,$manifest);$success='Допис видалено.';
    }
    elseif($action==='book_placement'){
      $slug=preg_replace('/[^a-z0-9-]/','',(string)($_POST['slug']??''))??'';$idx=manifest_book_index($manifest,$slug);if($idx<0)throw new RuntimeException('Книгу не знайдено.');$to=(string)($_POST['placement']??'books');$to=in_array($to,['books','announcements','direct'],true)?$to:'books';if($to!=='announcements'&&!is_file($root.'/books/'.$slug.'/read/index.html'))throw new RuntimeException('Цей анонс не має тексту книги. Спочатку відкрийте «Редагувати», додайте текст або рукопис і лише тоді переносьте його в бібліотеку.');$manifest['books'][$idx]['placement']=$to;if($to==='announcements'&&trim((string)($manifest['books'][$idx]['announcement_reason']??''))==='')$manifest['books'][$idx]['announcement_reason']=trim((string)($manifest['books'][$idx]['description']??''));save_manifest($config,$manifest);patch_book_landing($root,(array)$manifest['books'][$idx]);rebuild_indexes($root,$manifest);render_announcements($root,load_announcements($root));if(in_array($to,['announcements','direct'],true)){$focus=load_book_focus($root);if($focus===$slug)save_book_focus($root,'');}$success=$to==='announcements'?'Книга тепер у анонсах.':($to==='direct'?'Книга прихована з внутрішнього каталогу, але доступна за прямим посиланням та для пошуковиків.':'Книга тепер у бібліотеці.');
    }
    elseif($action==='book_announcement_reason'){
      $slug=preg_replace('/[^a-z0-9-]/','',(string)($_POST['slug']??''))??'';$idx=manifest_book_index($manifest,$slug);if($idx<0)throw new RuntimeException('Книгу не знайдено.');if((string)($manifest['books'][$idx]['placement']??'books')!=='announcements')throw new RuntimeException('Книга зараз не перебуває в анонсах.');$reason=trim((string)($_POST['announcement_reason']??''));if(mavik_utf8_strlen($reason)<3||mavik_utf8_strlen($reason)>500)throw new RuntimeException('Опис для анонсу має містити від 3 до 500 символів.');$manifest['books'][$idx]['announcement_reason']=$reason;save_manifest($config,$manifest);patch_book_landing($root,(array)$manifest['books'][$idx]);render_announcements($root,load_announcements($root));$success='Причину анонсу збережено.';
    }
    elseif($action==='book_visibility'){
      $slug=preg_replace('/[^a-z0-9-]/','',(string)($_POST['slug']??''))??'';$idx=manifest_book_index($manifest,$slug);if($idx<0)throw new RuntimeException('Книгу не знайдено.');$manifest['books'][$idx]['hidden']=empty($manifest['books'][$idx]['hidden']);$hidden=!empty($manifest['books'][$idx]['hidden']);save_manifest($config,$manifest);rebuild_indexes($root,$manifest);render_announcements($root,load_announcements($root));$success=$hidden?'Книгу приховано з публічного сайту.':'Книга знову показується на сайті.';
    }
    elseif($action==='book_delete'){
      $slug=preg_replace('/[^a-z0-9-]/','',(string)($_POST['slug']??''))??'';$idx=manifest_book_index($manifest,$slug);if($idx<0)throw new RuntimeException('Книгу не знайдено.');$manifest['books'][$idx]['hidden']=true;$manifest['books'][$idx]['deleted']=true;$manifest['books'][$idx]['deleted_at']=date(DATE_ATOM);mavik_remove_tree($root.'/books/'.$slug);@unlink($root.'/downloads/'.$slug.'.epub');if(load_book_focus($root)===$slug)save_book_focus($root,'');$order=array_values(array_filter(load_book_order($root),fn($x)=>(string)$x!==$slug));save_book_order($root,$order);save_manifest($config,$manifest);rebuild_indexes($root,$manifest);render_announcements($root,load_announcements($root));$success='Книгу видалено з публічного сайту.';
    }
    elseif($action==='book_edit'){
      $slug=preg_replace('/[^a-z0-9-]/','',(string)($_POST['slug']??''))??'';$idx=manifest_book_index($manifest,$slug);if($idx<0)throw new RuntimeException('Книгу не знайдено.');$book=(array)$manifest['books'][$idx];$title=trim((string)($_POST['title']??''));$genre=trim((string)($_POST['genre']??''));$desc=trim((string)($_POST['description']??''));$date=(string)($_POST['date']??($book['date']??date('Y-m-d')));$keys=array_values(array_filter(array_map('strval',(array)($_POST['genre_keys']??[]))));$newGenre=trim((string)($_POST['new_genre']??''));if($newGenre!=='')$keys[]=register_book_genre($root,$newGenre);if(!$keys&&$genre!=='')$keys[]=register_book_genre($root,mavik_utf8_substr($genre,0,80));$keys=array_values(array_unique($keys));$publicationMode=(string)($_POST['publication_mode']??($book['publication_mode']??'final'));if(!in_array($publicationMode,['final','beta'],true))$publicationMode='final';$placement=(string)($_POST['placement']??($book['placement']??'books'));$placement=in_array($placement,['books','announcements','direct'],true)?$placement:'books';$language=book_language_value((string)($_POST['language']??($book['language']??'uk-UA')));book_language_placement_guard($language,$placement);$announcementReason=trim((string)($_POST['announcement_reason']??($book['announcement_reason']??'')));if($announcementReason==='')$announcementReason=$desc;if(mavik_utf8_strlen($announcementReason)>500)throw new RuntimeException('Опис для анонсу має бути до 500 символів.');$announcementBody=mavik_announcement_body_prepare((string)($_POST['announcement_body_html']??($book['announcement_body_html']??'')));$platformLinks=book_platform_links_from_post();$isNew=$placement==='books'&&!empty($_POST['is_new']);$showContinuation=!empty($_POST['show_continuation'])&&$publicationMode==='beta';if(mavik_utf8_strlen($title)<2||mavik_utf8_strlen($desc)<20||$genre===''||!$keys)throw new RuntimeException('Заповніть назву, жанр і опис книги.');
      $cover=(string)($book['cover_catalog']??'');if(!empty($_FILES['cover']['tmp_name'])||trim((string)($_POST['cover_library']??''))!=='')$cover=media_pick_url($root,'covers',(string)($_POST['cover_library']??''),$_FILES['cover']??[],$slug);
      $requestedWithoutText=!empty($_POST['without_text']);if($requestedWithoutText&&$placement!=='announcements')throw new RuntimeException('Галочка «Без тексту» доступна лише для книги в розділі «Анонси».');$parsed=null;if(!empty($_FILES['manuscript']['tmp_name'])){if((int)($_FILES['manuscript']['size']??0)>20*1024*1024)throw new RuntimeException('Рукопис має бути до 20 MB.');$parsed=parse_manuscript((string)$_FILES['manuscript']['tmp_name'],(string)$_FILES['manuscript']['name']);}elseif(trim((string)($_POST['book_body_html']??''))!==''){$parsed=mavik_editor_prepare_book_html((string)$_POST['book_body_html']);}$withoutText=!$parsed&&!is_file($root.'/books/'.$slug.'/read/index.html')&&($requestedWithoutText||!empty($book['without_text'])||(string)($book['placement']??'books')==='announcements');if($placement!=='announcements'&&$withoutText)throw new RuntimeException('Цей анонс не має тексту. Додайте текст книги або рукопис перед перенесенням у бібліотеку.');if($parsed)$withoutText=false;
      $book['title']=$title;$book['genre']=$genre;$book['genre_keys']=$keys;$book['description']=$desc;$book['date']=$date;$book['cover_catalog']=$cover;$book['cover_home']=$cover;$book['publication_mode']=$publicationMode;$book['placement']=$placement;$book['language']=$language;$book['announcement_reason']=$announcementReason;$book['announcement_body_html']=$announcementBody;$book['without_text']=$withoutText;$book['platform_links']=$platformLinks;$book['is_new']=$isNew;$book['show_continuation']=$showContinuation;$book['search_text']=mavik_utf8_lower($title.' '.$genre.' '.$desc.' '.strip_tags($announcementBody));$book['availability']=$placement==='announcements'?$announcementReason:($publicationMode==='beta'?'тестове читання · без EPUB':'читати безкоштовно · EPUB');$book['managed']=true;$manifest['books'][$idx]=$book;
      patch_book_landing($root,$book);$readerFile=$root.'/books/'.$slug.'/read/index.html';if(!is_file($readerFile)&&$parsed){$readTpl=file_get_contents((string)$config['templates'].'/book-reader.tpl.html');if($readTpl===false)throw new RuntimeException('Немає шаблону читанки.');if(!is_dir(dirname($readerFile))&&!mkdir(dirname($readerFile),0755,true)&&!is_dir(dirname($readerFile)))throw new RuntimeException('Не вдалося створити каталог читанки.');$readerStatus=$publicationMode==='beta'?'Тестове читання · бета-публікація · текст у роботі':'Повний текст · веб-читанка mavik.name';$continuation=$showContinuation?'<div class="reader-continuation" role="note"><span>Далі буде…</span></div>':'';$rr=['{{BOOK_TITLE}}'=>h($title),'{{BOOK_LANG}}'=>h($language),'{{BOOK_READER_TITLE}}'=>h(mavik_reader_page_title($title)),'{{BOOK_DESCRIPTION}}'=>h($desc),'{{BOOK_META_DESCRIPTION}}'=>h(mavik_meta_description($desc)),'{{BOOK_GENRE}}'=>h($genre),'{{BOOK_BODY}}'=>mavik_reader_normalize_headings((string)$parsed['body']),'{{BOOK_TOC}}'=>(string)$parsed['toc'],'{{BOOK_CONTINUATION}}'=>$continuation,'{{BOOK_READER_STATUS}}'=>h($readerStatus),'{{BOOK_DURATION}}'=>mavik_live_reader_duration_html(mavik_live_book_duration_from_html((string)$parsed['body']))];$readerHtml=strtr($readTpl,$rr);$readerHtml=str_replace('{{BOOK_DURATION}}','',$readerHtml);$readerHtml=str_replace('</style></link>','</style>',$readerHtml);atomic_write($readerFile,$readerHtml);}
      $parts=is_file($readerFile)?patch_book_reader($root,$book,$parsed):['body'=>'','toc'=>''];$body=(string)$parts['body'];$toc=(string)$parts['toc'];$status=$publicationMode==='beta'?'Тестове читання · бета-публікація':'';if($body!=='')mavik_reader_text_publish($root,$slug,$title,$body,$status,$showContinuation);
      $epub=$root.'/downloads/'.$slug.'.epub';if($publicationMode==='beta'){@unlink($epub);}elseif($body!==''){$coverAbs=$root.rawurldecode($cover);$ext=strtolower(pathinfo($coverAbs,PATHINFO_EXTENSION));if(!is_dir($root.'/downloads'))@mkdir($root.'/downloads',0755,true);create_epub($epub,$title,'Макарчук Віктор Вікторович',$coverAbs,$ext,$body,$toc,$language);}
      save_manifest($config,$manifest);if(in_array($placement,['announcements','direct'],true)&&load_book_focus($root)===$slug)save_book_focus($root,'');rebuild_indexes($root,$manifest);render_announcements($root,load_announcements($root));$success='Книгу оновлено: /books/'.$slug.'/';
    }
    elseif($action==='book'){
      $title=trim((string)($_POST['title']??''));$genre=trim((string)($_POST['genre']??''));$desc=trim((string)($_POST['description']??''));$date=(string)($_POST['date']??date('Y-m-d'));$slug=slugify(trim((string)($_POST['slug']??''))?:$title);$keys=array_values(array_filter(array_map('strval',(array)($_POST['genre_keys']??[]))));$newGenre=trim((string)($_POST['new_genre']??''));if($newGenre!=='')$keys[]=register_book_genre($root,$newGenre);if(!$keys&&$genre!=='')$keys[]=register_book_genre($root,mavik_utf8_substr($genre,0,80));$keys=array_values(array_unique($keys));$publicationMode=(string)($_POST['publication_mode']??'final');if(!in_array($publicationMode,['final','beta'],true))$publicationMode='final';$placement=(string)($_POST['placement']??'books');$placement=in_array($placement,['books','announcements','direct'],true)?$placement:'books';$language=book_language_value((string)($_POST['language']??'uk-UA'));book_language_placement_guard($language,$placement);$announcementReason=trim((string)($_POST['announcement_reason']??''));if($announcementReason==='')$announcementReason=$desc;if(mavik_utf8_strlen($announcementReason)>500)throw new RuntimeException('Опис для анонсу має бути до 500 символів.');$announcementBody=mavik_announcement_body_prepare((string)($_POST['announcement_body_html']??''));$withoutText=!empty($_POST['without_text']);if($withoutText&&$placement!=='announcements')throw new RuntimeException('Галочка «Без тексту» доступна лише для книги в розділі «Анонси».');$platformLinks=book_platform_links_from_post();$isNew=$placement==='books'&&!empty($_POST['is_new']);$showContinuation=!empty($_POST['show_continuation'])&&$publicationMode==='beta';
      if(mavik_utf8_strlen($title)<2||mavik_utf8_strlen($desc)<20||$genre===''||$slug===''||!$keys)throw new RuntimeException('Заповніть назву, жанр і опис книги.');
      $coverUrl=media_pick_url($root,'covers',(string)($_POST['cover_library']??''),$_FILES['cover']??[],$slug);$coverName=basename($coverUrl);$coverExt=strtolower(pathinfo($coverName,PATHINFO_EXTENSION));$coverAbs=$root.rawurldecode($coverUrl);if(!is_file($coverAbs))throw new RuntimeException('Не вдалося знайти вибрану обкладинку на сервері.');
      $parsed=null;if(!$withoutText){if(!empty($_FILES['manuscript']['tmp_name'])&&is_uploaded_file($_FILES['manuscript']['tmp_name'])){if((int)($_FILES['manuscript']['size']??0)>20*1024*1024)throw new RuntimeException('Рукопис має бути до 20 MB.');$parsed=parse_manuscript((string)$_FILES['manuscript']['tmp_name'],(string)$_FILES['manuscript']['name']);}elseif(trim((string)($_POST['book_body_html']??''))!==''){$parsed=mavik_editor_prepare_book_html((string)$_POST['book_body_html']);}else throw new RuntimeException('Додайте текст книги в редакторі, завантажте DOCX/TXT або для анонсу поставте галочку «Без тексту».');}
      $land=file_get_contents((string)$config['templates'].'/book-landing.tpl.html');$read=$withoutText?'':file_get_contents((string)$config['templates'].'/book-reader.tpl.html');if($land===false||(!$withoutText&&$read===false))throw new RuntimeException('Немає шаблону книги.');
      $recoveredOrphan=false;$existingBookDir=$root.'/books/'.$slug;if(is_dir($existingBookDir)){if(manifest_book_index($manifest,$slug)>=0)throw new RuntimeException('Книга з таким slug уже зареєстрована.');throw new RuntimeException('На сервері вже існує книга /books/'.$slug.'/, але її немає в реєстрі Boss. Існуючі файли НЕ змінено. Відкрийте «Книги» та натисніть «Відновити в Boss».');}
      $bookDir=$root.'/books/'.$slug;$epub=$root.'/downloads/'.$slug.'.epub';$createdBookDir=false;
      try{
        if(!mkdir($bookDir,0755,true)&&!is_dir($bookDir))throw new RuntimeException('Не вдалося створити каталог книги.');if(!$withoutText&&!is_dir($bookDir.'/read')&&!mkdir($bookDir.'/read',0755,true)&&!is_dir($bookDir.'/read'))throw new RuntimeException('Не вдалося створити каталог читанки.');$createdBookDir=true;
        $schemaData=['@context'=>'https://schema.org','@type'=>$placement==='announcements'?'CreativeWork':'Book','name'=>$title,'description'=>$desc,'genre'=>$genre,'url'=>'https://mavik.name/books/'.$slug.'/','image'=>'https://mavik.name'.$coverUrl,'inLanguage'=>$language];if($placement!=='announcements')$schemaData['isAccessibleForFree']=true;else$schemaData['creativeWorkStatus']=$announcementReason;
        if($platformLinks)$schemaData['sameAs']=array_values(array_map(fn($x)=>(string)$x['url'],$platformLinks));
        $schemaData['author']=['@type'=>'Person','@id'=>'https://mavik.name/#person','name'=>'Макарчук Віктор Вікторович','alternateName'=>['Макарчук Віктор','MaVik'],'email'=>'viktor@mavik.name'];
        $schema=json_encode($schemaData,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        $readerBody=$withoutText?'':mavik_reader_normalize_headings((string)$parsed['body']);$readerToc=$withoutText?'':mavik_reader_toc_from_body($readerBody);
        $dim=@getimagesize($coverAbs);$cw=(int)($dim[0]??1055);$ch=(int)($dim[1]??1491);$isBeta=$publicationMode==='beta';$isAnnouncement=$placement==='announcements';$statusLabel=$isBeta?'Тестове читання · бета-публікація':'';$epubMeta=($withoutText||$isAnnouncement||$isBeta)?'':'<link href="https://mavik.name/downloads/'.h($slug).'.epub" rel="alternate" title="EPUB" type="application/epub+zip"/>';$statusBadge=$isAnnouncement?'<div class="book-beta-badge book-announcement-badge">Анонс</div>':($isBeta?'<div class="book-beta-badge">Тестове читання · бета-публікація</div>':'');$publicationNote=$isAnnouncement?$announcementReason:($isBeta?'Тестове читання · текст у роботі · без реєстрації':'Повний текст · безкоштовно · без реєстрації');$duration=$withoutText?['reading'=>0,'listening'=>0]:mavik_live_book_duration_from_html((string)$parsed['body']);$actions=$isAnnouncement?'<a class="btn primary" href="/announcements/">Усі анонси →</a>':mavik_live_book_actions_html($slug,!$isBeta,!$isBeta,$duration);$continuation=$showContinuation?'<div class="reader-continuation" role="note"><span>Далі буде…</span></div>':'';$readerStatus=$isBeta?'Тестове читання · бета-публікація · текст у роботі':'Повний текст · веб-читанка mavik.name';$r=['{{BOOK_TITLE}}'=>h($title),'{{BOOK_LANG}}'=>h($language),'{{BOOK_OG_LOCALE}}'=>h(book_og_locale($language)),'{{BOOK_PAGE_TITLE}}'=>h(mavik_book_page_title($title,$isAnnouncement)),'{{BOOK_READER_TITLE}}'=>h(mavik_reader_page_title($title)),'{{BOOK_DESCRIPTION}}'=>h($desc),'{{BOOK_META_DESCRIPTION}}'=>h(mavik_meta_description($desc)),'{{BOOK_GENRE}}'=>h($genre),'{{BOOK_SLUG}}'=>h($slug),'{{BOOK_COVER}}'=>h($coverUrl),'{{BOOK_JSONLD}}'=>$schema,'{{BOOK_BODY}}'=>$readerBody,'{{BOOK_TOC}}'=>$readerToc,'{{BOOK_EPUB_META}}'=>$epubMeta,'{{BOOK_STATUS_BADGE}}'=>$statusBadge,'{{BOOK_PUBLICATION_NOTE}}'=>h($publicationNote),'{{BOOK_ACTIONS}}'=>$actions,'{{BOOK_CONTINUATION}}'=>$continuation,'{{BOOK_READER_STATUS}}'=>h($readerStatus),'{{BOOK_READER_ROBOTS}}'=>$isBeta?'noindex,follow,max-image-preview:large':'index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1','{{BOOK_READER_CANONICAL}}'=>'https://mavik.name/books/'.h($slug).'/read/','{{BOOK_READER_JSONLD}}'=>json_encode(['@context'=>'https://schema.org','@type'=>'WebPage','@id'=>'https://mavik.name/books/'.$slug.'/read/#page','url'=>'https://mavik.name/books/'.$slug.'/read/','name'=>$title.' — читати онлайн','description'=>$desc,'inLanguage'=>$language,'isPartOf'=>['@id'=>'https://mavik.name/#website'],'about'=>['@type'=>'Book','@id'=>'https://mavik.name/books/'.$slug.'/#book','name'=>$title,'author'=>['@id'=>'https://mavik.name/#person']]],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),'{{BOOK_COVER_WIDTH}}'=>(string)$cw,'{{BOOK_COVER_HEIGHT}}'=>(string)$ch,'{{BOOK_PLATFORMS}}'=>mavik_live_platform_html(['platform_links'=>$platformLinks]),'{{BOOK_DURATION}}'=>$withoutText?'':mavik_live_reader_duration_html($duration)];
        atomic_write($bookDir.'/index.html',strtr($land,$r));if(!$withoutText){$readerHtml=strtr((string)$read,$r);$readerHtml=str_replace('{{BOOK_DURATION}}','',$readerHtml);$readerHtml=str_replace('</style></link>','</style>',$readerHtml);atomic_write($bookDir.'/read/index.html',$readerHtml);mavik_reader_text_publish($root,$slug,$title,$readerBody,$statusLabel,$showContinuation);if(!$isBeta&&!$isAnnouncement)create_epub($epub,$title,'Макарчук Віктор Вікторович',$coverAbs,$coverExt,$readerBody,$readerToc,$language);}
        $manifest['books'][]=['title'=>$title,'slug'=>$slug,'genre'=>$genre,'genre_keys'=>$keys,'description'=>$desc,'date'=>$date,'cover_catalog'=>$coverUrl,'cover_home'=>$coverUrl,'publication_mode'=>$publicationMode,'language'=>$language,'platform_links'=>$platformLinks,'is_new'=>$isNew,'show_continuation'=>$showContinuation,'search_text'=>mavik_utf8_lower($title.' '.$genre.' '.$desc.' '.strip_tags($announcementBody)),'availability'=>$placement==='announcements'?$announcementReason:($isBeta?'тестове читання · без EPUB':'читати безкоштовно · EPUB'),'placement'=>$placement,'announcement_reason'=>$announcementReason,'announcement_body_html'=>$announcementBody,'without_text'=>$withoutText,'hidden'=>false,'deleted'=>false,'managed'=>true];save_manifest($config,$manifest);patch_book_landing($root,(array)$manifest['books'][array_key_last($manifest['books'])]);rebuild_indexes($root,$manifest);render_announcements($root,load_announcements($root));$success=($placement==='announcements'?'Книгу додано в анонси':($placement==='direct'?'Книгу опубліковано за прямим посиланням та відкрито для пошуковиків':'Книгу додано в бібліотеку')).': /books/'.$slug.'/'.((!$withoutText&&$placement!=='announcements'&&!$isBeta)?' EPUB створено.':'');
      }catch(Throwable $e){if($createdBookDir)mavik_remove_tree($bookDir);@unlink($epub);throw $e;}
    }
  }catch(Throwable $e){$error=$e->getMessage();}
  $manifest=load_manifest($config);
}
$tab=(string)($_GET['tab']??'home');
$blogTabs=['blog','blog_add','blog_focus','images_blog'];$bookTabs=['book','book_add','book_home','announcements','focus','images_covers','errors'];$homeTabs=['home','stats','deploy','reactions','maintenance','workspace','state','seo'];$isSecurityTab=$tab==='security';$isBlogTab=in_array($tab,$blogTabs,true);$isBookTab=in_array($tab,$bookTabs,true);$isMusicTab=$tab==='music';$isMailTab=$tab==='mail';$isHomeTab=in_array($tab,$homeTabs,true);
try{mavik_blog_refresh_topic_regions($root,$manifest);}catch(Throwable $topicRefreshError){error_log('Blog topics refresh: '.$topicRefreshError->getMessage());}
try{mavik_blog_front_runtime_token($root,'250v20c6');}catch(Throwable $blogRuntimeError){error_log('Blog front runtime token: '.$blogRuntimeError->getMessage());}
$coreState=mavik_core_load($root);$adminPublicUrl='/';
$maintenanceActive=mavik_maintenance_active($root);
$blogEditSlug=preg_replace('/[^a-z0-9-]/','',(string)($_GET['edit']??''))??'';$blogEdit=null;if($blogEditSlug!=='')foreach((array)($manifest['blog']??[]) as $p)if(is_array($p)&&empty($p['deleted'])&&($p['slug']??'')===$blogEditSlug){$blogEdit=$p;break;}
$bookEditSlug=$tab==='book'?(preg_replace('/[^a-z0-9-]/','',(string)($_GET['edit']??''))??''):'';$bookEdit=null;if($bookEditSlug!=='')foreach((array)($manifest['books']??[]) as $p)if(is_array($p)&&empty($p['deleted'])&&($p['slug']??'')===$bookEditSlug){$bookEdit=$p;break;}
$bookEditReaderBody='';if($bookEdit){$__parts=book_existing_reader_parts($root,(string)$bookEdit['slug']);$bookEditReaderBody=(string)($__parts['body']??'');}
$orphanLiveBooks=mavik_orphan_live_books($root,$manifest);$orphanLiveBlogs=mavik_orphan_live_blog_posts($root,$manifest);
$catalogBooks=extract_admin_catalog_books($root);$publicCatalogBooks=extract_catalog_books($root);$bookOrder=load_book_order($root);$orderedCatalog=[];$orderedPublicCatalog=[];foreach($bookOrder as $slug){if(isset($catalogBooks[$slug]))$orderedCatalog[]=$catalogBooks[$slug];if(isset($publicCatalogBooks[$slug]))$orderedPublicCatalog[]=$publicCatalogBooks[$slug];}foreach($catalogBooks as $slug=>$x)if(!in_array($slug,$bookOrder,true))$orderedCatalog[]=$x;foreach($publicCatalogBooks as $slug=>$x)if(!in_array($slug,$bookOrder,true))$orderedPublicCatalog[]=$x;$focusedSlug=load_book_focus($root);$focusedBook=$focusedSlug!==''&&isset($publicCatalogBooks[$focusedSlug])?$publicCatalogBooks[$focusedSlug]:null;
$blogFocusPosts=blog_sorted(manifest_visible_blog($manifest));$focusedBlogSlug=load_blog_focus($root,$blogFocusPosts);$focusedBlog=null;foreach($blogFocusPosts as $x)if(is_array($x)&&(string)($x['slug']??'')===$focusedBlogSlug){$focusedBlog=$x;break;}
$musicLib=load_music_library($root);$musicTracks=(array)($musicLib['tracks']??[]);$musicCollections=(array)($musicLib['collections']??[]);$musicView=(string)($_GET['view']??'tracks');$musicCollectionId=preg_replace('/[^a-z0-9-]/','',(string)($_GET['cid']??''))??'';$musicCollection=null;foreach($musicCollections as $c)if(is_array($c)&&($c['id']??'')===$musicCollectionId){$musicCollection=$c;break;}$musicTrackMap=music_track_map($musicLib);

$blogMedia=media_files($root,'blog');$coverMedia=media_files($root,'covers');$mediaReplace=preg_replace('/[^A-Za-z0-9._-]/','',(string)($_GET['replace']??''))??'';
$announcementState=load_announcements($root);$announcementEditId=$tab==='announcements'?(preg_replace('/[^a-z0-9-]/','',(string)($_GET['edit']??''))??''):'';$announcementEdit=null;if($announcementEditId!==''){$ai=announcement_index($announcementState,$announcementEditId);if($ai>=0)$announcementEdit=$announcementState['items'][$ai];}
$workspaceGithub=mavik_workspace_github_load($root);$workspaceGithubReady=mavik_workspace_github_ready($workspaceGithub);$workspaceItems=[];if($workspaceGithubReady){try{$workspaceItems=mavik_workspace_github_list_files($root);}catch(Throwable $e){$error=$error?:$e->getMessage();}}$workspaceBytes=0;foreach($workspaceItems as $wi)$workspaceBytes+=(int)($wi['size']??0);
$readerErrorData=mavik_reader_errors_load($root);$readerErrorItems=array_reverse((array)($readerErrorData['items']??[]));$readerErrorNew=count(array_filter($readerErrorItems,fn($x)=>is_array($x)&&(string)($x['status']??'new')==='new'));
$deploySupported=mavik_deploy_supported();$deployBackups=$deploySupported?mavik_deploy_backups($root):[];$deployFailed=$deploySupported?mavik_deploy_failed_archives($root):[];
$seoState=mavik_seo_load($root);$seoReport=is_array($seoState['last_scan']??null)?$seoState['last_scan']:null;$seoSummary=is_array($seoReport['summary']??null)?$seoReport['summary']:[];
$contactUnread=mavik_contact_inbox_unread_count($root);


$reactionData=load_reactions_data($root);$reactionRows=[];$reactionTitleMap=[];
foreach($catalogBooks as $slug=>$x){$reactionTitleMap['book:'.$slug]=(string)($x['title']??$slug);}
foreach((array)($manifest['blog']??[]) as $x)if(is_array($x)&&($slug=(string)($x['slug']??''))!=='')$reactionTitleMap['blog:'.$slug]=(string)($x['title']??$slug);
foreach($reactionTitleMap as $key=>$title){[$type,$slug]=explode(':',$key,2);$item=is_array($reactionData['items'][$key]??null)?$reactionData['items'][$key]:[];$voters=is_array($item['voters']??null)?$item['voters']:[];$current=count($voters);$reactionRows[]=['key'=>$key,'type'=>$type,'slug'=>$slug,'title'=>$title,'current'=>$current,'likes_all_time'=>(int)($item['likes_all_time']??0),'unlikes_all_time'=>(int)($item['unlikes_all_time']??0),'last_action'=>(string)($item['last_action']??'')];}
usort($reactionRows,function($a,$b){$c=$b['current']<=>$a['current'];if($c!==0)return $c;$c=$b['likes_all_time']<=>$a['likes_all_time'];return $c!==0?$c:strcmp($a['title'],$b['title']);});
$reactionCurrent=array_sum(array_column($reactionRows,'current'));$reactionAdded=array_sum(array_column($reactionRows,'likes_all_time'));$reactionRemoved=array_sum(array_column($reactionRows,'unlikes_all_time'));$reactionActive=count(array_filter($reactionRows,fn($x)=>$x['current']>0));$reactionRecent=array_reverse(array_slice((array)($reactionData['log']??[]),-50));
$genres=load_book_genres($root);
$diag=['blog'=>is_writable($root.'/blog'),'books'=>is_writable($root.'/books'),'covers'=>is_writable($root.'/images/covers'),'blog_images'=>is_writable($root.'/images/blog'),'downloads'=>is_writable($root.'/downloads'),'music'=>is_writable($root.'/assets/music')||is_writable($root.'/assets'),'manifest'=>is_writable(dirname((string)$config['manifest'])),'reactions'=>is_writable(mavik_state_dir($root)),'workspace'=>$workspaceGithubReady,'reader_errors'=>is_writable($root.'/_site-state')||is_writable($root),'deploy'=>$deploySupported&&(is_writable($root.'/_site-state')||is_writable($root)),'core_state'=>is_writable($root.'/_site-state')||is_writable($root),'image_catalog'=>is_writable($root.'/images')];
?><!doctype html><html lang="uk-UA"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow,noarchive"><title>MaVik · Boss</title><link href="/favicon.ico?v=250v20c3" rel="icon" type="image/x-icon"/>
<link href="/assets/app/mavik-icon-192.png?v=250v20c3" rel="icon" sizes="192x192" type="image/png"/>
<link href="/assets/app/apple-touch-icon.png?v=250v20c3" rel="apple-touch-icon" sizes="180x180"/><style>
:root{--bg:#09090a;--panel:#111113;--line:#2a2824;--text:#eee9df;--muted:#99938b;--gold:#d9bd86;--ok:#9ccc9c;--bad:#ff9f9f}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:14px/1.5 Arial,sans-serif}.wrap{width:min(1180px,calc(100% - 36px));margin:auto;padding:28px 0 70px}.top{display:flex;justify-content:space-between;gap:20px;align-items:center;margin-bottom:24px}.brand{font:500 34px Georgia,serif}.sub{color:var(--muted);font-size:12px;margin-top:4px}.nav{display:flex;gap:8px;flex-wrap:wrap}.nav a,.btn{display:inline-flex;align-items:center;justify-content:center;border:1px solid var(--line);border-radius:999px;background:#0e0e10;color:var(--text);text-decoration:none;padding:10px 14px;cursor:pointer}.nav a.active,.btn.primary{border-color:#806b45;color:var(--gold);background:#17140f}.nav-mail{position:relative}.mail-beacon{display:none;position:absolute;right:-7px;top:-8px;z-index:3;min-width:20px;height:20px;padding:0 5px;border:2px solid var(--bg);border-radius:999px;background:#d15145;color:#fff;font:700 10px/1 Arial,sans-serif;align-items:center;justify-content:center;box-shadow:0 0 0 1px rgba(255,255,255,.08),0 0 14px rgba(209,81,69,.42)}.nav-mail.has-mail .mail-beacon{display:inline-flex}.subnav{display:flex;gap:8px;flex-wrap:wrap;margin:-12px 0 20px;padding:10px 0;border-bottom:1px solid var(--line)}.subnav a{color:var(--muted);text-decoration:none;border-radius:999px;padding:7px 10px}.subnav a.active{color:var(--gold);background:#17140f}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;margin-bottom:18px}.card,.panel{border:1px solid var(--line);border-radius:18px;background:var(--panel)}.card{padding:22px;text-decoration:none;color:var(--text)}.card b{display:block;font:500 24px Georgia,serif;margin-bottom:7px}.card span{color:var(--muted)}.card:hover{border-color:#5d513b}.panel{padding:24px;margin-bottom:14px}.panel h2{font:500 24px Georgia,serif;margin:0 0 18px}.panel-title-actions{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin:0 0 18px}.panel-title-actions h2{margin:0}.panel-title-actions .btn{flex:0 0 auto}.grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}label{display:block;color:var(--muted);font-size:12px;margin-bottom:15px}input,textarea,select{width:100%;margin-top:7px;padding:12px 13px;border:1px solid #34312c;border-radius:11px;background:#0b0b0d;color:var(--text);font:15px/1.4 Arial,sans-serif;outline:none}textarea{min-height:96px;resize:vertical;font-family:Georgia,serif}.seo-fields textarea{min-height:68px;height:68px}.announcement-rich-editor{min-height:140px;height:180px;max-height:560px}.announcement-code-editor{min-height:140px!important;height:180px!important;max-height:560px}.html-code-editor{min-height:340px}.field-invalid input,.field-invalid textarea,.field-invalid select,.field-invalid .editor-shell,.field-invalid.media-field{border-color:#a85d5d!important;box-shadow:0 0 0 1px rgba(255,159,159,.18)}.field-error{display:block;margin-top:6px;color:var(--bad);font-size:11px}.form-error-summary{margin:0 0 14px;padding:11px 13px;border:1px solid #633;border-radius:11px;background:#1a1010;color:var(--bad);font-size:12px}.help{font-size:11px;color:#777169;margin-top:6px}.genres{display:flex;flex-wrap:wrap;gap:8px;margin-top:8px}.genres label{margin:0}.genres input{display:none}.genres span{display:block;border:1px solid var(--line);border-radius:999px;padding:8px 11px;color:var(--muted);cursor:pointer}.genres input:checked+span{border-color:#806b45;color:var(--gold);background:#18150f}.msg{padding:13px 15px;border-radius:12px;margin-bottom:15px}.err{border:1px solid #633;background:#1a1010;color:var(--bad)}.success{border:1px solid #365a36;background:#0d180e;color:var(--ok)}.diag{display:flex;flex-wrap:wrap;gap:8px}.diag span{border:1px solid var(--line);border-radius:999px;padding:6px 9px;font-size:11px}.ok{color:var(--ok)}.bad{color:var(--bad)}.list{display:grid;gap:8px}.row{display:flex;justify-content:space-between;gap:12px;border-top:1px solid #24221f;padding:10px 0}.row a{color:var(--gold);text-decoration:none}.note{color:var(--muted);font-size:12px;line-height:1.6}.sort-list{display:grid;gap:9px;margin:18px 0}.sort-item{display:grid;grid-template-columns:42px 52px minmax(0,1fr) auto;align-items:center;gap:12px;border:1px solid #292722;border-radius:14px;background:#0c0c0e;padding:9px 10px;transition:border-color .15s,box-shadow .15s;touch-action:pan-y}.sort-item.dragging{position:fixed!important;z-index:9999!important;margin:0!important;pointer-events:none!important;border-color:#806b45!important;box-shadow:0 18px 44px rgba(0,0,0,.48);opacity:.96;transform:none!important}.sort-placeholder{border:1px dashed #806b45;border-radius:14px;background:rgba(217,189,134,.055);min-height:62px}.sort-list.sort-active{user-select:none;-webkit-user-select:none}.sort-list.sort-active .sort-item:not(.dragging){transition:transform .08s ease}.sort-item.touch-dragging{touch-action:none}.drag-handle,.sort-arrow{border:1px solid #38342e;background:#111113;color:var(--gold);border-radius:10px;cursor:grab}.drag-handle{width:42px;height:42px;font-size:22px;line-height:1;touch-action:none;user-select:none;-webkit-user-select:none}.drag-handle:active{cursor:grabbing}.sort-cover{width:42px;height:58px;object-fit:cover;border-radius:6px;border:1px solid #28251f}.sort-copy{min-width:0}.sort-copy b{display:block;font:500 17px Georgia,serif;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.sort-copy span{display:block;color:var(--muted);font-size:11px;margin-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.sort-actions{display:flex;align-items:center;gap:6px}.sort-arrow{width:32px;height:32px;cursor:pointer}.sort-pos{display:grid;place-items:center;min-width:34px;height:34px;border:1px solid #2d2a25;border-radius:999px;color:var(--muted);font-size:12px}.order-save{display:flex;align-items:center;gap:14px;flex-wrap:wrap;margin-top:16px}.music-add-actions{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-top:4px}.focus-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:14px;align-items:stretch}.focus-choice{display:block;min-width:0;height:100%;margin:0;cursor:pointer}.focus-choice input{position:absolute;opacity:0;pointer-events:none}.focus-card{position:relative;display:flex;flex-direction:column;box-sizing:border-box;min-width:0;height:100%;overflow:hidden;border:1px solid #2b2925;border-radius:15px;background:#0c0c0e;padding:10px;transition:border-color .15s,transform .15s,background .15s}.focus-state{display:flex;align-items:center;min-height:18px;margin:0 0 7px;color:transparent;font-size:10px;letter-spacing:.12em;text-transform:uppercase}.focus-card img{width:100%;aspect-ratio:3/4.7;object-fit:cover;border-radius:8px;display:block;margin:0 0 9px}.focus-card b{display:block;min-height:2.5em;color:var(--text);font:500 16px/1.25 Georgia,serif;overflow-wrap:anywhere}.focus-card .focus-type{display:block;color:var(--muted);font-size:11px;line-height:1.35;margin-top:auto;padding-top:6px}.focus-choice input:checked+.focus-card{border-color:#9d8354;background:#18150f;box-shadow:0 0 0 1px rgba(217,189,134,.18)}.focus-choice input:checked+.focus-card .focus-state{color:var(--gold)}.focus-card.blog-focus-card img{aspect-ratio:16/9}.focus-card.blog-focus-card b{min-height:3.7em}@media(max-width:850px){.cards{grid-template-columns:1fr}.grid{grid-template-columns:1fr}.top{align-items:flex-start;flex-direction:column}}@media(max-width:650px){.wrap{width:calc(100% - 24px);padding-top:18px}.panel{padding:18px}.brand{font-size:30px}.sort-item{grid-template-columns:42px 42px minmax(0,1fr) auto;gap:8px;padding:8px}.sort-cover{width:38px;height:52px}.sort-actions{gap:4px}.sort-arrow{width:30px;height:30px}.sort-pos{min-width:30px;height:30px}.focus-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.focus-card{padding:8px}.focus-card b{font-size:14px;min-height:2.5em}.focus-state{min-height:17px;margin-bottom:6px}}
.music-subnav{display:flex;gap:8px;flex-wrap:wrap;margin:0 0 18px}.music-subnav a{display:inline-flex;border:1px solid var(--line);border-radius:999px;padding:8px 12px;color:var(--muted);text-decoration:none}.music-subnav a.active{color:var(--gold);border-color:#806b45;background:#17140f}.music-track-item{grid-template-columns:42px 52px minmax(0,1fr) auto}.music-track-meta{display:flex;gap:8px;flex-wrap:wrap;color:var(--muted);font-size:11px;margin-top:3px}.music-track-actions{display:flex;gap:6px;align-items:center}.mini-btn{display:inline-flex;align-items:center;justify-content:center;border:1px solid #38342e;background:#111113;color:var(--text);border-radius:9px;padding:7px 9px;text-decoration:none;cursor:pointer;font-size:11px}.mini-btn.danger{color:#ffaaaa;border-color:#573232}.music-edit{display:grid;grid-template-columns:1.4fr 1fr 1fr .55fr;gap:10px;align-items:end}.music-edit label{margin:0}.music-edit input{margin-top:5px}.collection-card{display:grid;grid-template-columns:72px minmax(0,1fr) auto;gap:14px;align-items:center;border-top:1px solid #24221f;padding:12px 0}.collection-card img{width:72px;height:72px;object-fit:cover;border-radius:10px}.collection-card h3{font:500 18px Georgia,serif;margin:0 0 4px}.collection-card p{margin:0;color:var(--muted);font-size:12px}.announcement-admin-row{grid-template-columns:42px 70px minmax(0,1fr) auto}.announcement-admin-row .sort-cover{width:54px;height:76px;object-fit:cover;border-radius:7px}.announcement-admin-row .announcement-empty-cover{width:54px;height:76px;border:1px solid var(--line);border-radius:7px;display:grid;place-items:center;color:var(--gold);font:700 10px Arial,sans-serif}.announcement-admin-actions{display:flex;gap:6px;align-items:center;flex-wrap:wrap}.announcement-form-preview{display:flex;gap:14px;align-items:center}.announcement-form-preview img{width:84px;height:118px;object-fit:cover;border-radius:8px;border:1px solid var(--line)}
.book-music-grid{display:grid;gap:10px}.book-music-row{display:grid;grid-template-columns:48px minmax(0,1fr) minmax(180px,280px);gap:12px;align-items:center;border-top:1px solid #24221f;padding:10px 0}.book-music-row img{width:42px;height:58px;object-fit:cover;border-radius:6px}.book-music-row select{margin:0}.audio-add-grid{display:grid;grid-template-columns:1.1fr .8fr .8fr;gap:12px}.music-danger-zone{border-color:#4b2c2c}.music-danger-zone h3{color:#ffb2b2}.collection-track-list .sort-item{grid-template-columns:42px 52px minmax(0,1fr) auto}.collection-add{display:flex;gap:10px;align-items:end}.collection-add label{flex:1;margin:0}.collection-add button{margin-bottom:0}@media(max-width:780px){.music-edit,.audio-add-grid{grid-template-columns:1fr 1fr}.book-music-row{grid-template-columns:42px minmax(0,1fr)}.book-music-row select{grid-column:1/-1}.collection-card{grid-template-columns:60px minmax(0,1fr)}.collection-card img{width:60px;height:60px}.collection-card .music-track-actions{grid-column:1/-1}.collection-add{align-items:stretch;flex-direction:column}.collection-add button{width:100%}}@media(max-width:520px){.music-edit,.audio-add-grid{grid-template-columns:1fr}.music-track-item{grid-template-columns:42px 42px minmax(0,1fr)}.music-track-item .music-track-actions{grid-column:1/-1;justify-content:flex-end}.music-subnav{justify-content:center}}
.dashboard-groups{display:grid;gap:22px;margin-bottom:22px}.dashboard-group{border:1px solid var(--line);border-radius:18px;padding:18px;background:#0d0d0f}.dashboard-group-head{display:flex;align-items:baseline;justify-content:space-between;gap:14px;margin-bottom:12px}.dashboard-group-head h2{margin:0;font:500 22px Georgia,serif}.dashboard-group-head span{color:var(--muted);font-size:12px}.dashboard-group .cards{margin:0}.announcement-admin-row{align-items:start}.announcement-admin-row .announcement-admin-actions{align-self:end;padding-top:0;display:flex;gap:7px;flex-wrap:wrap;margin-bottom:1px}.announcement-reason-form{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;align-items:end;margin-top:8px}.announcement-reason-form label{margin:0}.announcement-reason-form .mini-btn{margin-bottom:1px}@media(max-width:760px){.announcement-reason-form{grid-template-columns:1fr}.announcement-admin-row .announcement-admin-actions{padding-top:0;grid-column:1/-1}}.blog-admin-list{display:grid;gap:10px}.blog-admin-tools{display:flex;gap:10px;align-items:end;justify-content:space-between;flex-wrap:wrap;margin:14px 0 8px}.blog-admin-tools form{display:flex;gap:8px;align-items:end;flex-wrap:wrap}.blog-admin-tools label{margin:0;min-width:190px}.blog-admin-tools select{margin-top:5px}.blog-admin-counts{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.blog-admin-pager{display:flex;gap:6px;align-items:center;justify-content:center;flex-wrap:wrap;margin:16px 0 2px}.blog-admin-pager .mini-btn.active{border-color:#a8874f;color:#e7c27c;pointer-events:none}.blog-admin-pager .page-note{color:var(--muted);font-size:11px;padding:0 4px}.blog-admin-row{display:grid;grid-template-columns:76px minmax(0,1fr) auto;gap:14px;align-items:center;border-top:1px solid #24221f;padding:12px 0}.blog-admin-row img{width:76px;height:50px;object-fit:cover;border-radius:9px;border:1px solid #2b2925}.blog-admin-copy b{display:block;font:500 17px Georgia,serif}.blog-admin-copy span{display:block;color:var(--muted);font-size:11px;margin-top:4px}.current-image{display:flex;gap:12px;align-items:center;margin:8px 0 14px}.current-image img{width:180px;aspect-ratio:16/9;object-fit:cover;border-radius:10px;border:1px solid var(--line)}.editor-shell{margin-top:7px;border:1px solid #34312c;border-radius:13px;overflow:hidden;background:#0b0b0d}.editor-toolbar{display:flex;gap:6px;flex-wrap:wrap;padding:8px;border-bottom:1px solid #2c2925;background:#101012;position:sticky;top:0;z-index:3}.editor-toolbar button,.editor-toolbar select{min-width:36px;height:34px;border:1px solid #39352f;border-radius:8px;background:#151517;color:#eee9df;cursor:pointer;padding:0 9px}.editor-toolbar select{border:1px solid #39352f;border-radius:8px;background:#151517;color:#eee9df;padding:0 8px;max-width:155px}.editor-toolbar button:hover,.editor-toolbar button:focus{border-color:#806b45;color:var(--gold)}.editor-toolbar .wide{min-width:auto}.rich-editor{min-height:320px;height:clamp(420px,60vh,680px);padding:20px;color:#eee9df;font:18px/1.72 Georgia,serif;outline:none;overflow:auto;resize:vertical;box-sizing:border-box}.blog-editor-form .rich-editor{overflow-y:auto;overscroll-behavior:contain}.blog-editor-form .html-code-editor{display:none;box-sizing:border-box;width:100%;height:clamp(420px,60vh,680px);min-height:280px;padding:18px 20px;border:0;outline:none;resize:vertical;background:#09090b;color:#e8e4dc;font:14px/1.55 Consolas,"Liberation Mono",monospace;tab-size:2;overflow:auto;overscroll-behavior:contain}.blog-editor-form .editor-shell.code-mode .rich-editor{display:none}.blog-editor-form .editor-shell.code-mode .html-code-editor{display:block}.blog-editor-form .editor-toolbar [data-editor-mode].active{border-color:#9a7a42;background:#221d15;color:var(--gold)}.blog-editor-form .editor-shell.code-mode .editor-toolbar button:not([data-editor-mode]),.blog-editor-form .editor-shell.code-mode .editor-toolbar select{opacity:.42;pointer-events:none}.rich-editor p{margin:0 0 1.1em}.rich-editor h2{font-size:30px;line-height:1.2;margin:1.7em 0 .6em}.rich-editor h3{font-size:24px;line-height:1.25;margin:1.5em 0 .55em}.rich-editor blockquote{margin:1.2em 0;padding:2px 0 2px 18px;border-left:3px solid #806b45;color:#d6cec0}.rich-editor a{color:#e1bd77;overflow-wrap:anywhere;word-break:break-word}.rich-editor .mavik-text-gold{color:#d7b46a}.rich-editor .mavik-text-light{color:#d8d8d8}.rich-editor .mavik-text-black{color:#111}.rich-editor .mavik-text-white{color:#fff}.rich-editor .mavik-bg-gold{background:#d7b46a;padding:.04em .16em;border-radius:.15em}.rich-editor .mavik-bg-light{background:#d8d8d8;padding:.04em .16em;border-radius:.15em}.rich-editor ul,.rich-editor ol{padding-left:28px}.rich-editor .mavik-align-left{text-align:left}.rich-editor .mavik-align-center{text-align:center}.rich-editor .mavik-align-right{text-align:right}.editor-note{color:var(--muted);font-size:11px;margin-top:7px}.readonly-slug{opacity:.75}.form-actions{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.form-actions .btn{margin-top:0}@media(max-width:650px){.blog-admin-row{grid-template-columns:64px minmax(0,1fr)}.blog-admin-row img{width:64px;height:44px}.blog-admin-row .mini-btn{grid-column:1/-1}.editor-toolbar{gap:4px}.editor-toolbar button{min-width:34px;padding:0 7px}.rich-editor{min-height:360px;padding:15px;font-size:17px}.blog-editor-form .rich-editor,.blog-editor-form .html-code-editor{height:56vh;min-height:340px}.blog-editor-form .html-code-editor{padding:14px;font-size:13px}}
.book-edit-panel{scroll-margin-top:18px}.announcement-reason-form{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;align-items:end;margin-top:9px}.announcement-reason-form label{margin:0}.announcement-reason-form input{margin-top:5px}.announcement-reason-form .mini-btn{height:38px}@media(max-width:760px){.announcement-reason-form{grid-template-columns:1fr}.announcement-reason-form .mini-btn{width:100%}}.content-admin-actions{display:flex;gap:6px;align-items:center;flex-wrap:wrap;justify-content:flex-end}.content-admin-actions form{margin:0}.status-pill{display:inline-flex;width:max-content;margin-top:5px;border:1px solid #3a352e;border-radius:999px;padding:3px 7px;color:var(--muted);font-size:9px;letter-spacing:.06em;text-transform:uppercase}.status-pill.hidden{color:#e7c27c;border-color:#665337}.book-admin-row{grid-template-columns:58px minmax(0,1fr) auto}.book-admin-row img{width:48px;height:68px;object-fit:cover}.book-edit-current{display:flex;gap:14px;align-items:center;margin-bottom:14px}.book-edit-current img{width:70px;height:100px;object-fit:cover;border-radius:8px;border:1px solid var(--line)}@media(max-width:650px){.content-admin-actions{grid-column:1/-1;justify-content:flex-start}.book-admin-row{grid-template-columns:52px minmax(0,1fr)}.book-admin-row img{width:44px;height:62px}}.media-field{margin-bottom:15px}.field-label{display:block;color:var(--muted);font-size:12px;margin-bottom:8px}.media-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(128px,148px));justify-content:start;gap:10px;align-items:start;max-height:430px;overflow:auto;padding:8px;border:1px solid #24221f;border-radius:13px;background:#09090b}.media-choice{display:block;width:100%;min-width:0;margin:0!important;cursor:pointer;position:relative}.media-choice input{position:absolute;opacity:0;pointer-events:none}.media-card{position:relative;display:flex;flex-direction:column;width:100%;min-width:0;overflow:hidden;border:1px solid #2b2925;border-radius:13px;background:#0c0c0e;padding:7px}.media-card img{display:block;width:100%;height:auto;aspect-ratio:16/10;object-fit:cover;border-radius:8px;margin:0 0 7px}.media-card.cover img{aspect-ratio:3/4.5}.media-card b{display:block;min-width:0;color:var(--text);font-size:10px;line-height:1.25;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.media-upload{margin-top:10px}.media-upload input[type=file]{margin-top:0}.media-choice input:checked+.media-card{border-color:#a58a59;box-shadow:0 0 0 1px rgba(217,189,134,.2);background:#18150f}.media-choice input:checked+.media-card:before{content:'ВИБРАНО';position:absolute;z-index:3;top:13px;right:13px;display:block;margin:0;padding:4px 6px;border:1px solid rgba(217,189,134,.58);border-radius:999px;background:rgba(12,10,7,.9);color:var(--gold);font-size:8px;letter-spacing:.1em;box-shadow:0 2px 10px rgba(0,0,0,.35)}.media-thumb-button{display:block;width:max-content;max-width:100%;padding:0;border:0;border-radius:8px;background:transparent;cursor:zoom-in;line-height:0}.media-thumb-button:focus-visible{outline:2px solid var(--gold);outline-offset:2px}.media-thumb{width:74px!important;height:54px!important;object-fit:cover!important;border-radius:7px}.media-sort-item{grid-template-columns:42px 74px minmax(0,1fr) auto!important}.media-sort-item.cover-row .media-thumb{width:48px!important;height:68px!important}.media-preview-dialog{width:min(920px,calc(100vw - 28px));max-height:calc(100dvh - 28px);padding:14px;border:1px solid #4b4335;border-radius:18px;background:#0d0d0f;color:var(--text);box-shadow:0 24px 90px rgba(0,0,0,.72)}.media-preview-dialog::backdrop{background:rgba(0,0,0,.82)}.media-preview-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:10px}.media-preview-head b{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.media-preview-close{width:38px;height:38px;flex:0 0 38px;border:1px solid #454038;border-radius:999px;background:#171719;color:var(--text);font-size:22px;cursor:pointer}.media-preview-dialog img{display:block;max-width:100%;max-height:calc(100dvh - 120px);width:auto;height:auto;margin:auto;border-radius:12px;object-fit:contain;background:#080809}.media-actions{display:flex;gap:6px;align-items:center;flex-wrap:wrap}.media-link-tools{display:flex;gap:6px;flex-wrap:wrap;margin-top:7px}.media-link-tools .mini-btn{font-size:10px;padding:6px 9px}.media-link-tools .mini-btn.copied{border-color:#4f7d4f;color:var(--ok)}.mini-btn.danger{color:#ffaaaa;border-color:#55302f}.btn.danger{color:#ffb7b7!important;border-color:#653635!important;background:#1b1010!important}.link-picker{width:auto;min-width:180px;height:34px;margin:0;padding:5px 8px;border-radius:8px;font-size:12px}.editor-toolbar .tool-sep{width:1px;height:26px;background:#312e29;margin:4px 2px}@media(max-width:650px){.link-picker{width:100%}.media-grid{grid-template-columns:repeat(2,minmax(0,1fr));justify-content:stretch}.media-card b{font-size:9px}.media-sort-item{grid-template-columns:42px 54px minmax(0,1fr)!important}.media-thumb{width:50px!important;height:42px!important}.media-actions{grid-column:1/-1}}
.reaction-table{width:100%;border-collapse:collapse}.reaction-table th,.reaction-table td{padding:10px 8px;border-top:1px solid #24221f;text-align:left;vertical-align:top}.reaction-table th{color:var(--muted);font-size:11px}.reaction-table td.num,.reaction-table th.num{text-align:right;white-space:nowrap}.reaction-type{display:inline-flex;border:1px solid #34312c;border-radius:999px;padding:3px 7px;color:var(--muted);font-size:10px;text-transform:uppercase}.reaction-live{color:var(--gold);font-weight:700}.reaction-zero{color:#6f6a63}.reaction-title{max-width:430px}.reaction-title a{color:var(--text);text-decoration:none}.reaction-title a:hover{color:var(--gold)}.reaction-recent{font-size:12px}@media(max-width:760px){.reaction-table-wrap{overflow:auto}.reaction-table{min-width:760px}}.workspace-upload{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:14px}.workspace-stats{display:flex;gap:8px;flex-wrap:wrap;margin:0 0 18px}.workspace-stats span{border:1px solid var(--line);border-radius:999px;padding:7px 10px;color:var(--muted);font-size:12px}.workspace-list{display:grid;gap:10px}.workspace-item{border:1px solid #292722;border-radius:14px;background:#0c0c0e;padding:14px}.workspace-head{display:flex;justify-content:space-between;gap:16px;align-items:flex-start}.workspace-name{font-weight:700;overflow-wrap:anywhere}.workspace-meta{color:var(--muted);font-size:12px;margin-top:4px}.workspace-note{color:#c9c2b7;font-size:13px;margin-top:9px}.workspace-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}.workspace-actions form{margin:0}.workspace-filter{max-width:460px;margin-bottom:14px}.build-meta{margin-top:5px;font-size:12px;color:var(--muted);font-variant-numeric:tabular-nums}.book-admin-row.sort-item{grid-template-columns:34px 54px minmax(220px,1fr) auto;align-items:center;min-height:76px;padding:9px 10px}.book-admin-row .sort-cover{width:44px;height:60px;object-fit:cover;border-radius:6px}.book-admin-row .content-admin-actions{display:flex;align-items:center;justify-content:flex-end;gap:6px;flex-wrap:wrap}.book-admin-row .sort-copy{min-width:0}.book-admin-row .sort-copy b{display:block;white-space:normal}.book-admin-row .sort-copy span{display:inline-block;margin-right:6px}.book-admin-row .sort-arrow{width:30px;height:30px}.book-admin-row .sort-pos{min-width:28px;text-align:center}@media(max-width:900px){.book-admin-row.sort-item{grid-template-columns:32px 48px minmax(0,1fr)}.book-admin-row .content-admin-actions{grid-column:2/4;justify-content:flex-start}}@media(max-width:760px){.workspace-upload{grid-template-columns:1fr}.workspace-head{display:block}}

.mail-status{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}.mail-status span{border:1px solid var(--line);border-radius:999px;padding:6px 9px;font-size:11px}.mail-status .ok{color:#b7e6ba;border-color:#355d3b}.mail-status .bad{color:#ffb0b0;border-color:#653838}.mail-layout{display:grid;grid-template-columns:220px minmax(0,1fr);gap:14px}.mail-folders{padding:14px}.mail-folders a{display:block;padding:8px 10px;border-radius:8px;color:var(--muted);text-decoration:none}.mail-folders a.active{background:#17140f;color:var(--gold)}.mail-row{display:grid;grid-template-columns:minmax(120px,.8fr) minmax(0,1.5fr) auto;gap:12px;padding:12px 2px;border-top:1px solid #25231f;color:var(--text);text-decoration:none;align-items:center}.mail-row.unread strong,.mail-row.unread .mail-from{color:#fff;font-weight:700}.mail-row time{color:var(--muted);font-size:11px}.mail-from{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.mail-from small{display:block;color:var(--muted);font-size:10px;font-weight:400;overflow:hidden;text-overflow:ellipsis}.contact-reply-form{margin-top:16px}.mail-to{color:var(--muted);font-size:12px;margin-bottom:16px}.mail-body{background:#fff;color:#171717;border-radius:12px;padding:18px;overflow:auto;min-height:160px}.mail-body pre{white-space:pre-wrap;font:15px/1.55 Arial,sans-serif;margin:0}.mail-body a{color:#174b8b}.mail-attachments{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:14px}.mail-editor-shell{margin:7px 0 15px;border:1px solid #34312c;border-radius:11px;background:#fff;overflow:hidden}.mail-editor-toolbar{display:flex;flex-wrap:wrap;gap:5px;padding:8px;border-bottom:1px solid #ddd;background:#f4f2ee}.mail-editor-toolbar button{border:1px solid #d1ccc2;border-radius:7px;background:#fff;color:#222;padding:6px 9px;cursor:pointer;font:13px Arial,sans-serif!important}.mail-editor-toolbar button:hover{background:#ece7de}.mail-rich-editor{min-height:300px;padding:16px 17px;color:#171717;background:#fff;outline:none;font:16px/1.55 Arial,sans-serif!important}.mail-rich-editor p,.mail-rich-editor div{margin:0 0 .8em}.mail-rich-editor a{color:#174b8b}.mail-compose-actions{display:flex;gap:9px;align-items:center;flex-wrap:wrap}.mail-draft-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:10px;align-items:center;border-top:1px solid #25231f}.mail-draft-row>a{display:grid;grid-template-columns:minmax(120px,.8fr) minmax(0,1.5fr) auto;gap:12px;padding:12px 2px;color:var(--text);text-decoration:none;align-items:center}.mail-draft-row form{margin:0}.mail-draft-row time{color:var(--muted);font-size:11px}
.mail-recipient-box{position:relative;display:flex;align-items:center;flex-wrap:wrap;gap:6px;min-height:42px;width:min(100%,760px);padding:6px 8px;border:1px solid var(--line);border-radius:10px;background:#0c0c0e;cursor:text}.mail-recipient-box:focus-within{border-color:#806b45;box-shadow:0 0 0 2px rgba(128,107,69,.12)}.mail-recipient-box.has-error{border-color:#753d3d}.mail-recipient-chips{display:flex;gap:6px;flex-wrap:wrap}.mail-recipient-chip{display:inline-flex;align-items:center;gap:6px;max-width:100%;padding:5px 8px;border:1px solid #4b4336;border-radius:999px;background:#17140f;color:#ead8b5;font-size:12px}.mail-recipient-chip button{border:0;background:transparent;color:#a9987b;font-size:16px;line-height:1;padding:0;cursor:pointer}.mail-recipient-input{flex:1 1 220px;min-width:170px!important;width:auto!important;height:30px!important;min-height:30px!important;padding:4px 5px!important;border:0!important;box-shadow:none!important;background:transparent!important;color:var(--text)!important}.mail-recipient-suggestions{position:absolute;z-index:30;top:calc(100% + 5px);left:0;width:min(520px,100%);border:1px solid #37322b;border-radius:10px;background:#111113;box-shadow:0 14px 30px rgba(0,0,0,.36);overflow:hidden}.mail-recipient-suggestion{display:block;width:100%;padding:9px 11px;border:0;border-top:1px solid #24221f;background:transparent;color:var(--text);text-align:left;cursor:pointer}.mail-recipient-suggestion:first-child{border-top:0}.mail-recipient-suggestion:hover,.mail-recipient-suggestion.active{background:#1c1812}.mail-recipient-suggestion b,.mail-recipient-suggestion small{display:block}.mail-recipient-suggestion small{color:var(--muted);margin-top:2px}.mail-recipient-meta{display:flex;gap:12px;align-items:center;flex-wrap:wrap;width:min(100%,760px);margin:5px 0 14px;color:var(--muted);font-size:11px}.mail-recipient-meta a{color:var(--gold)}.mail-recipient-error{color:#ffaaaa}.mail-bcc-details{width:min(100%,760px);margin:0 0 14px;padding:8px 10px;border:1px solid #28251f;border-radius:9px;background:#0b0b0d}.mail-bcc-details summary{cursor:pointer;color:var(--muted);font-size:12px}.mail-bcc-details label{margin-top:9px}.mail-batch-result{margin:0 0 16px;padding:14px;border:1px solid #50442f;border-radius:12px;background:#12100d}.mail-result-list{display:grid;gap:6px;margin-top:10px}.mail-result-row{display:grid;grid-template-columns:22px minmax(180px,1fr) minmax(120px,.65fr) minmax(150px,1fr);gap:8px;align-items:center;padding:8px 9px;border:1px solid #292722;border-radius:9px;background:#0c0c0e}.mail-result-row.ok{border-color:#2f4934}.mail-result-row.bad{border-color:#623939}.mail-result-row small{color:var(--muted);overflow-wrap:anywhere}.mail-contact-add{margin-bottom:18px}.mail-contact-list{display:grid;gap:7px}.mail-contact-row{display:grid;grid-template-columns:minmax(150px,.8fr) minmax(220px,1fr) minmax(160px,.7fr) auto auto auto;gap:8px;align-items:center;padding:8px;border:1px solid #292722;border-radius:10px;background:#0c0c0e}.mail-contact-row input{margin:0}.mail-contact-stat{color:var(--muted);font-size:10px;line-height:1.4}.mail-history-list{display:grid;gap:8px}.mail-history-batch{border:1px solid #292722;border-radius:11px;background:#0c0c0e;overflow:hidden}.mail-history-batch summary{display:flex;justify-content:space-between;gap:12px;align-items:center;padding:12px 14px;cursor:pointer}.mail-history-batch summary span:first-child{min-width:0}.mail-history-batch summary b,.mail-history-batch summary small{display:block}.mail-history-batch summary small{margin-top:3px;color:var(--muted)}.mail-history-batch .mail-result-list{padding:0 12px 12px;margin:0}.ok-text{color:#b7e6ba}.bad-text{color:#ffb0b0}
@media(max-width:760px){.mail-layout{grid-template-columns:1fr}.mail-row{grid-template-columns:1fr}.mail-draft-row>a{grid-template-columns:1fr}.mail-draft-row{grid-template-columns:1fr}.mail-rich-editor{min-height:260px}.mail-result-row{grid-template-columns:20px 1fr}.mail-result-row span:nth-child(3),.mail-result-row small{grid-column:2}.mail-contact-row{grid-template-columns:1fr}.mail-contact-stat{margin-bottom:4px}}

/* simplified, calmer Boss UI */
:root{--boss-radius:16px;--boss-shadow:0 16px 44px rgba(0,0,0,.20)}
body,body *,input,textarea,select,button{font-family:Georgia,'Times New Roman',serif!important}
.wrap{width:min(1240px,calc(100% - 36px));padding-top:16px}
.top{position:sticky;top:0;z-index:80;margin:0 -10px 14px;padding:12px 10px;background:rgba(9,9,10,.94);backdrop-filter:blur(14px);border-bottom:1px solid rgba(255,255,255,.06)}
.brand{font-size:30px}.sub,.build-meta{line-height:1.45}
.nav{gap:7px}.nav a,.btn{min-height:40px;padding:9px 13px}
.boss-smartbar{display:flex;flex-wrap:wrap;gap:7px;margin:0 0 18px;padding:0 2px}
.smart-pill{display:inline-flex;align-items:center;min-height:28px;padding:5px 9px;border:1px solid var(--line);border-radius:999px;color:var(--muted);background:#0d0d0f;font-size:11px}
.smart-pill.okpill{color:#b7e6ba;border-color:#355d3b}.smart-pill.warn{color:#ffd39b;border-color:#70502c}
.card,.panel{border-radius:var(--boss-radius);box-shadow:var(--boss-shadow)}
.card{min-height:118px;padding:20px}.card b{font-size:22px}.card span{line-height:1.5}
.dashboard-group{margin-bottom:18px}.dashboard-group-head{margin-bottom:10px}.dashboard-group-head h2{font-size:20px}
.panel{padding:22px}.panel h2{font-size:23px}
input,textarea,select{font-size:15px;border-radius:10px}
.note,.help{line-height:1.55}
.seo-check{margin:0 0 18px;padding:14px 16px;border:1px solid #34312a;border-radius:12px;background:#0c0c0e}.seo-check strong{display:block;margin-bottom:8px}.seo-check-list{display:flex;flex-wrap:wrap;gap:7px}.seo-check-list span{display:inline-flex;align-items:center;min-height:28px;padding:5px 9px;border-radius:999px;border:1px solid #4d3829;font-size:11px;color:#ffd39b}.seo-check-list span.seo-ok{border-color:#355d3b;color:#b7e6ba}.seo-fields{border:1px solid #34312a;border-radius:12px;padding:16px;margin:14px 0;background:#0d0d0f}.seo-fields>strong{display:block;margin-bottom:10px;color:var(--gold)}
@media(max-width:760px){.wrap{width:min(100% - 24px,680px)}.top{position:static;margin:0 0 14px;padding:0 0 12px}.nav{gap:6px}.nav a,.btn{min-height:38px;padding:8px 11px}.boss-smartbar{margin-bottom:14px}.card{min-height:auto}.panel{padding:18px}}
</style><script src="/assets/admin/editor-enhance.js?v=250v20c3"></script></head><body><?php $releaseInfo=mavik_release_info($root);?><main class="wrap"><div class="top"><div><div class="brand">MaVik · Boss</div><div class="sub">Керування сайтом · власник: <?=h((string)($_SESSION['mavik_owner_name']??'MaVik'))?></div><div class="build-meta">Збірка: <b><?=h((string)($releaseInfo['release_label']??$releaseInfo['release']))?></b> · <?=h(mavik_release_time_ua($releaseInfo['generated_at']))?></div></div><nav class="nav"><a class="<?=($tab==='home')?'active':''?>" href="/boss/">Головна</a><a class="<?=$tab==='stats'?'active':''?>" href="?tab=stats">Статистика</a><a class="<?=$isBlogTab?'active':''?>" href="?tab=blog">Блог</a><a class="<?=$isBookTab?'active':''?>" href="?tab=book">Книги</a><a class="<?=$isMusicTab?'active':''?>" href="?tab=music">Музика</a><a id="bossMailNav" class="nav-mail <?=$isMailTab?'active':''?> <?=$contactUnread?'has-mail':''?>" href="?tab=mail"><span>Пошта</span><span id="bossMailBeacon" class="mail-beacon" aria-live="polite" aria-label="<?=$contactUnread?'Нових повідомлень: '.$contactUnread:''?>"><?=$contactUnread?($contactUnread>99?'99+':$contactUnread):''?></span></a><a class="<?=$isSecurityTab?'active':''?>" href="?tab=security">Безпека</a><a href="/account/?logout=1">Вийти</a></nav></div><div class="boss-smartbar"><span class="smart-pill"><?=h((string)($releaseInfo['release_label']??$releaseInfo['release']))?></span><span class="smart-pill <?=$maintenanceActive?'warn':'okpill'?>"><?=$maintenanceActive?'Технічна перерва':'Сайт відкритий'?></span><span class="smart-pill">Редактор: спільний</span></div>
<?php if($isBlogTab):?><nav class="subnav" aria-label="Блог"><a class="<?=$tab==='blog'?'active':''?>" href="?tab=blog">Дописи</a><a class="<?=$tab==='blog_add'?'active':''?>" href="?tab=blog_add">Додати блог</a><a class="<?=$tab==='blog_focus'?'active':''?>" href="?tab=blog_focus">Блог у фокусі</a><a class="<?=$tab==='images_blog'?'active':''?>" href="?tab=images_blog">Фото блогу</a></nav><?php elseif($isBookTab):?><nav class="subnav" aria-label="Книги"><a class="<?=$tab==='book'?'active':''?>" href="?tab=book">Книги</a><a class="<?=$tab==='book_add'?'active':''?>" href="?tab=book_add">Додати книгу</a><a class="<?=$tab==='book_home'?'active':''?>" href="?tab=book_home">Книг на головній</a><a class="<?=$tab==='announcements'?'active':''?>" href="?tab=announcements">Анонси</a><a class="<?=$tab==='focus'?'active':''?>" href="?tab=focus">Книга у фокусі</a><a class="<?=$tab==='images_covers'?'active':''?>" href="?tab=images_covers">Обкладинки</a><a class="<?=$tab==='errors'?'active':''?>" href="?tab=errors">Помилки<?=$readerErrorNew?' · '.$readerErrorNew:''?></a></nav><?php endif;?>
<script>
window.MaVikPointerSorter=function(cfg){
  const list=document.getElementById(cfg.listId),form=document.getElementById(cfg.formId),out=document.getElementById(cfg.outputId);
  if(!list||!form||!out)return;
  const items=()=>[...list.children].filter(el=>el.classList.contains('sort-item'));
  const refresh=()=>{
    items().forEach((el,i)=>{const p=el.querySelector('.sort-pos');if(p)p.textContent=String(i+1)});
    out.value=JSON.stringify(items().map(el=>el.dataset[cfg.key]));
  };
  const moveOne=(item,dir)=>{
    if(!item)return;
    if(dir==='up'&&item.previousElementSibling)list.insertBefore(item,item.previousElementSibling);
    if(dir==='down'&&item.nextElementSibling)list.insertBefore(item.nextElementSibling,item);
    refresh();
  };
  list.addEventListener('click',e=>{
    const b=e.target.closest('[data-move]');
    if(!b||!list.contains(b))return;
    moveOne(b.closest('.sort-item'),b.dataset.move);
  });
  list.addEventListener('keydown',e=>{
    const h=e.target.closest('.drag-handle');
    if(!h)return;
    if(e.key==='ArrowUp'||e.key==='ArrowDown'){e.preventDefault();moveOne(h.closest('.sort-item'),e.key==='ArrowUp'?'up':'down')}
  });

  let active=null,placeholder=null,startY=0,offsetY=0,left=0,width=0,height=0,moved=false,mode='';
  const isInteractive=el=>!!el.closest('a,button,input,select,textarea,label');
  const yOf=e=>e.touches&&e.touches[0]?e.touches[0].clientY:e.clientY;
  const xOf=e=>e.touches&&e.touches[0]?e.touches[0].clientX:e.clientX;
  const start=(item,e,kind)=>{
    if(active||!item)return;
    const r=item.getBoundingClientRect();
    active=item;mode=kind;startY=yOf(e);offsetY=startY-r.top;left=r.left;width=r.width;height=r.height;moved=false;
    placeholder=document.createElement('div');placeholder.className='sort-placeholder';placeholder.style.height=Math.max(54,r.height)+'px';
    item.parentNode.insertBefore(placeholder,item.nextSibling);
    item.classList.add('dragging'); if(kind==='touch')item.classList.add('touch-dragging');
    item.style.left=left+'px';item.style.top=r.top+'px';item.style.width=width+'px';item.style.height=height+'px';
    list.classList.add('sort-active');
    document.body.style.cursor='grabbing';
  };
  const placePlaceholder=y=>{
    const others=items().filter(el=>el!==active);
    let before=null;
    for(const el of others){const r=el.getBoundingClientRect();if(y<r.top+r.height/2){before=el;break;}}
    if(before)list.insertBefore(placeholder,before);else list.appendChild(placeholder);
  };
  const move=e=>{
    if(!active)return;
    const y=yOf(e); if(!Number.isFinite(y))return;
    if(Math.abs(y-startY)>3)moved=true;
    if(mode==='touch')e.preventDefault();
    active.style.top=(y-offsetY)+'px';
    placePlaceholder(y);
    const edge=78,speed=16;
    if(y<edge)window.scrollBy(0,-speed);else if(y>window.innerHeight-edge)window.scrollBy(0,speed);
  };
  const finish=()=>{
    if(!active)return;
    list.insertBefore(active,placeholder);
    active.classList.remove('dragging','touch-dragging');
    active.style.left='';active.style.top='';active.style.width='';active.style.height='';
    placeholder.remove();placeholder=null;active=null;mode='';list.classList.remove('sort-active');document.body.style.cursor='';refresh();
  };

  // Desktop: grab any non-interactive area of the row, including the ⋮⋮ handle.
  list.addEventListener('mousedown',e=>{
    if(e.button!==0)return;
    const item=e.target.closest('.sort-item'); if(!item||!list.contains(item))return;
    if(isInteractive(e.target)&&!e.target.closest('.drag-handle'))return;
    e.preventDefault(); start(item,e,'mouse');
  });
  document.addEventListener('mousemove',move);
  document.addEventListener('mouseup',finish);

  // Touch: start only from ⋮⋮ so normal page scrolling on the row remains available.
  list.addEventListener('touchstart',e=>{
    const h=e.target.closest('.drag-handle');if(!h||!list.contains(h))return;
    const item=h.closest('.sort-item');if(!item)return;
    e.preventDefault();start(item,e,'touch');
  },{passive:false});
  document.addEventListener('touchmove',move,{passive:false});
  document.addEventListener('touchend',finish);
  document.addEventListener('touchcancel',finish);
  window.addEventListener('blur',finish);
  form.addEventListener('submit',()=>{if(active)finish();refresh()});
  refresh();
};
</script>
<?php if($error):?><div class="msg err"><?=h($error)?></div><?php endif;?><?php if($success):?><div class="msg success"><?=h($success)?></div><?php endif;?>
<?php if($tab==='home'):?>
<div class="dashboard-groups">
<section class="dashboard-group"><div class="dashboard-group-head"><h2>Контент</h2><span>Створення й редагування того, що бачить читач</span></div><div class="cards"><a class="card" href="?tab=book"><b>Книги</b><span>Каталог, редагування книг, EPUB та статуси.</span></a><a class="card" href="?tab=blog"><b>Блог</b><span>Дописи, редагування і публікація.</span></a><a class="card" href="?tab=music"><b>Музика</b><span>Музичний каталог і треки.</span></a><a class="card" href="?tab=announcements"><b>Анонси</b><span>Майбутні книги та причини статусу.</span></a></div></section>
<section class="dashboard-group"><div class="dashboard-group-head"><h2>Публікація й читачі</h2><span>Що підсвічуємо і як це знаходять</span></div><div class="cards"><a class="card" href="?tab=focus"><b>Книга у фокусі</b><span>Обрати книгу для головного акценту або лишити місце порожнім.</span></a><a class="card" href="?tab=blog_focus"><b>Блог у фокусі</b><span>Редакторський акцент на одному дописі.</span></a><a class="card" href="?tab=seo"><b>SEO / Роботи</b><span>IndexNow, Bing API, sitemap і робот-аудит.</span></a><a class="card" href="?tab=stats"><b>Статистика</b><span>Читачі, перегляди, що читають і що слухають — без cookies та сторонніх трекерів.</span></a><a class="card" href="?tab=reactions"><b>Реакції</b><span>«Сподобалось», конверсія і останні дії читачів.</span></a></div></section>
<section class="dashboard-group"><div class="dashboard-group-head"><h2>Сайт</h2><span>Швидкі переходи</span></div><div class="cards"><a class="card" href="/copyright/" target="_blank"><b>Права</b><span>Відкрити сторінку авторських прав.</span></a><a class="card" href="<?=h($adminPublicUrl)?>" target="_blank"><b>Український сайт</b><span>Відкрити публічну версію.</span></a></div></section>
<section class="dashboard-group"><div class="dashboard-group-head"><h2>Система й сервіс</h2><span>Оновлення, резервування та зовнішні служби</span></div><div class="cards"><a class="card" href="?tab=deploy"><b>Оновити сайт</b><span>Повна збірка, multipart або overlay-патч із rollback.</span></a><a class="card" href="?tab=maintenance"><b>Технічна перерва</b><span><?= $maintenanceActive ? 'Увімкнена: читачі бачать заглушку, ти — весь сайт.' : 'Вимкнена: сайт відкритий для всіх.' ?></span></a><a class="card" href="?tab=workspace"><b>Файли</b><span>GitHub-сховище робочих файлів.</span></a><a class="card" href="?tab=state"><b>Стан сайту</b><span>Експорт і відновлення глобального стану.</span></a><a class="card" href="?tab=security"><b>Пароль і безпека</b><span>Пароль власника та відновлення доступу.</span></a><a class="card" href="?tab=mail"><b>Пошта</b><span>Вхідні, відповіді, нові листи й вкладення прямо в Boss.</span></a><a class="card" href="https://cp.cityhost.ua/hostingcp_new/?id=21972" target="_blank" rel="noopener"><b>Хостинг</b><span>Панель керування Cityhost.</span></a></div></section>
</div>
<section class="panel"><h2>Стан системи</h2><div class="diag"><?php foreach($diag as $k=>$v):?><span class="<?=$v?'ok':'bad'?>"><?=h($k)?>: <?=$v?'OK':'немає запису'?></span><?php endforeach;?></div><p class="note">Контент зберігається як звичайні HTML, EPUB та файли зображень. Живий стан Boss і робоче сховище зберігаються у захищеному <code>/_site-state/</code>; код і початкові шаблони — у <code>/_site-admin/</code>. MySQL, SQLite або інша база даних не використовуються.</p><form method="post"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="rebuild"><button class="btn primary">Відновити індекси</button></form></section>
<?php elseif($tab==='stats'):$lite=mavik_stats_lite_dashboard($root);?>
<section class="panel"><div class="panel-title-actions"><div><h2>Легка статистика</h2><p class="note">Власний агрегований лічильник. Без cookies, без збереження IP і без Google Analytics. «Читачі» тут — приблизна кількість сесій браузера.</p></div></div>
<div class="stats-lite-cards"><div><b><?=h((string)$lite['today']['sessions'])?></b><span>читачів сьогодні</span><small><?=h((string)$lite['today']['views'])?> переглядів</small></div><div><b><?=h((string)$lite['week']['sessions'])?></b><span>за 7 днів</span><small><?=h((string)$lite['week']['views'])?> переглядів</small></div><div><b><?=h((string)$lite['month']['sessions'])?></b><span>за 30 днів</span><small><?=h((string)$lite['month']['views'])?> переглядів</small></div></div></section>
<section class="panel"><h2>Що читають · 30 днів</h2><?php if(!$lite['top']):?><p class="note">Даних ще немає. Вони з’являться після відвідувань сайту з цією збіркою.</p><?php else:?><div class="stats-lite-list"><?php foreach($lite['top'] as $r):?><div><span><?=h((string)$r['label'])?></span><b><?=h((string)$r['count'])?></b></div><?php endforeach;?></div><?php endif;?></section>
<section class="panel"><h2>Що слухають · 30 днів</h2><?php if(!$lite['tracks']):?><p class="note">Прослуховувань окремих треків ще немає.</p><?php else:?><div class="stats-lite-list"><?php foreach($lite['tracks'] as $r):?><div><span><?=h((string)$r['label'])?></span><b><?=h((string)$r['count'])?></b></div><?php endforeach;?></div><?php endif;?></section>
<section class="panel"><h2>Звідки приходять · 30 днів</h2><?php if(!$lite['refs']):?><p class="note">Джерел переходів ще немає.</p><?php else:?><div class="stats-lite-list"><?php foreach($lite['refs'] as $r):?><div><span><?=h((string)$r['label'])?></span><b><?=h((string)$r['count'])?></b></div><?php endforeach;?></div><?php endif;?></section>
<?php elseif($tab==='book_home'):?>
<section class="panel"><div class="panel-title-actions"><div><h2>Книг на головній</h2><p class="note">Скільки книжок показувати на головній сторінці до кнопки «Усі книги».</p></div><a class="btn" href="?tab=book">До книг</a></div><form method="post" data-boss-validate><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="core_home_limit"><div class="grid"><label>Desktop <span class="help">Від 1 до 40 книг.</span><input type="number" min="1" max="40" name="books_limit_desktop" value="<?=h((string)($coreState['home']['books_limit_desktop']??8))?>" required></label><label>Mobile <span class="help">Можна задати іншу кількість для телефону.</span><input type="number" min="1" max="40" name="books_limit_mobile" value="<?=h((string)($coreState['home']['books_limit_mobile']??8))?>" required></label></div><button class="btn primary">Зберегти</button></form></section>
<?php elseif($tab==='mail'):?>
<?php require $root.'/_site-admin/boss-mail-ui.php'; ?>
<?php elseif($tab==='maintenance'):?>
<section class="panel"><div class="panel-title-actions"><h2>Технічна перерва</h2><a class="btn" href="/" target="_blank" rel="noopener">Відкрити сайт як власник ↗</a></div>
<?php if($maintenanceActive):?>
<p class="note"><b>Зараз увімкнено.</b> Звичайні відвідувачі отримують сторінку «Технічна перерва» з кодом 503. Ви, як авторизований власник у цьому браузері, бачите весь сайт без обмежень — головну, книги, блог, музику та сторінки, які щойно змінили.</p>
<form method="post" onsubmit="return confirm('Відкрити сайт для всіх відвідувачів?');"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="maintenance_toggle"><input type="hidden" name="mode" value="off"><button class="btn primary">Вимкнути перерву · відкрити сайт</button></form>
<?php else:?>
<p class="note"><b>Сайт відкритий для всіх.</b> Увімкніть перерву перед технічними змінами. Після ввімкнення читачі бачитимуть лише службову сторінку, а ваш авторизований браузер продовжить бачити весь сайт — так можна перевірити результат перед відкриттям.</p>
<form method="post" onsubmit="return confirm('Увімкнути технічну перерву для відвідувачів? Ви продовжите бачити весь сайт.');"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="maintenance_toggle"><input type="hidden" name="mode" value="on"><button class="btn primary">Увімкнути технічну перерву</button></form>
<?php endif;?>
<p class="note" style="margin-top:18px">Цей перемикач не входить до резервної копії «Стан сайту» і не змінює книги, блог, музику, порядок або «фокус». Це лише режим доступу для відвідувачів.</p></section>
<?php elseif($tab==='workspace'):?>
<section class="panel"><div class="panel-title-actions"><h2>Файли</h2><div class="workspace-public-link" style="margin:10px 0 14px;">
  <div style="font-size:13px;opacity:.75;margin-bottom:6px;">Постійне робоче посилання</div>
  <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
    <input id="workspaceGithubPublicUrl" type="text" readonly value="https://github.com/mavik-name/sklad_open/tree/main/mavik-sklad/files" style="min-width:320px;flex:1;">
    <a class="btn" href="https://github.com/mavik-name/sklad_open/tree/main/mavik-sklad/files" target="_blank" rel="noopener">Відкрити GitHub ↗</a>
    <button type="button" class="btn" id="copyWorkspaceGithubUrl">Копіювати посилання</button>
  </div>
</div></div>
<?php if(!$workspaceGithubReady):?>
<p class="note">Одноразове підключення GitHub. Після збереження токена це поле більше не потрібне.</p>
<form method="post"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="workspace_github_token"><label>GitHub token<input type="password" name="github_token" required autocomplete="new-password" placeholder="github_pat_…"></label><button class="btn primary">Зберегти token</button></form>
<?php else:?>
<form method="post" enctype="multipart/form-data" style="margin-bottom:20px"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="workspace_upload"><label>Файл<input type="file" name="workspace_file" required></label><button class="btn primary">Завантажити файл</button></form>
<div class="workspace-stats"><span><?=count($workspaceItems)?> файлів</span><span><?=h(mavik_workspace_human_bytes($workspaceBytes))?></span></div>
<?php if($workspaceItems):?><div class="workspace-list"><?php foreach($workspaceItems as $wi):?><article class="workspace-item"><div class="workspace-head"><div><div class="workspace-name"><?=h((string)$wi['name'])?></div><div class="workspace-meta"><?=h(mavik_workspace_human_bytes((int)$wi['size']))?></div></div></div><div class="workspace-actions"><a class="btn primary" href="<?=h((string)($wi['html_url']??''))?>" target="_blank" rel="noopener">Дивитись</a><form method="post" onsubmit="return confirm('Видалити цей файл?');"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="workspace_delete"><input type="hidden" name="workspace_path" value="<?=h((string)$wi['path'])?>"><input type="hidden" name="workspace_sha" value="<?=h((string)$wi['sha'])?>"><button class="btn">Видалити</button></form></div></article><?php endforeach;?></div><?php else:?><p class="note">Файлів поки немає.</p><?php endif;?>
<?php endif;?></section>
<?php elseif($tab==='state'):?>
<section class="panel"><div class="panel-title-actions"><h2>Зберегти стан сайту</h2><span class="diag"><span class="ok">окремо від коду</span></span></div><p class="note">Створює датований файл <code>mavik-state-YYYY-MM-DD_HH-MM-SS.json</code>. У ньому зберігаються: порядок книг, постійний перелік жанрів, книга у фокусі, блог у фокусі, музичний каталог і його порядок/збірки, записи блогу з датами та метаданими, порядок медіатеки, меню та системні налаштування. Пароль власника, пароль пошти, статистика, реакції та файли розділу «Файли» до цього JSON не потрапляють. Для робочих файлів у «Репозитарії» є окрема кнопка «Завантажити все ZIP».</p><form method="post"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="state_export"><button class="btn primary">Зберегти стан на комп’ютер</button></form></section>
<section class="panel"><h2>Відновити стан</h2><p class="note">Використовуйте після оновлення або якщо треба повернути попередню розстановку. Відновлення не відкочує PHP/CSS/JS та іншу структуру сайту. Після імпорту Boss автоматично синхронізує головну, каталог книг, блог і музику. Перед імпортом поточний стан можна окремо зберегти на комп’ютер.</p><form method="post" enctype="multipart/form-data" onsubmit="return confirm('Відновити стан із вибраного файла? Поточні налаштування розстановки та контентний маніфест буде замінено.');"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="state_import"><label>Файл стану<input type="file" name="state_file" accept="application/json,.json" required></label><button class="btn primary">Відновити стан</button></form></section>
<section class="panel"><h2>Постійне сховище</h2><p class="note">Живий стан Boss і робочі файли зберігаються в захищеній папці <code>/_site-state/</code>. У наступних оновленнях цю папку не можна видаляти або перезаписувати. Код збірки бере початкові значення з <code>/_site-admin/state-defaults/</code> лише тоді, коли живого стану ще немає.</p></section>
<?php elseif($tab==='blog_focus'):?>
<section class="panel"><div class="panel-title-actions"><h2>Блог у фокусі</h2><button class="btn primary" type="submit" form="blogFocusForm">Зберегти у фокусі</button></div><p class="note">Оберіть допис, на якому зараз треба акцентувати увагу читача. Він стає великим матеріалом у блоці «Блог» на головній і першим, візуально виділеним матеріалом на сторінці блогу. Хронологія RSS, URL та SEO-адреси не змінюються.</p>
<form method="post" id="blogFocusForm"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="blog_focus">
<div class="focus-grid"><?php foreach($blogFocusPosts as $x):?><label class="focus-choice"><input type="radio" name="focus_slug" value="<?=h((string)$x['slug'])?>" <?=(string)$x['slug']===$focusedBlogSlug?'checked':''?> required><span class="focus-card blog-focus-card"><span class="focus-state">У фокусі</span><?php if(!empty($x['image'])):?><img src="<?=h((string)$x['image'])?>" alt=""><?php endif;?><b><?=h((string)$x['title'])?></b><span class="focus-type"><?=h((string)($x['category']??'Блог'))?> · <?=h(ua_date((string)($x['date']??'')))?></span></span></label><?php endforeach;?></div>
<div class="order-save"><button class="btn primary" type="submit">Зберегти у фокусі</button><?php if($focusedBlog):?><span class="note">Зараз у фокусі: «<?=h((string)$focusedBlog['title'])?>».</span><?php endif;?></div></form></section>
<?php elseif($tab==='security'):?>
<section class="panel"><div class="panel-title-actions"><h2>Пароль і безпека</h2><span class="diag"><span class="ok">email для відновлення: <?=h((string)($config['email']??'viktor@mavik.name'))?></span></span></div>
<?php if(isset($_GET['password_reset'])):?><div class="msg success">Новий пароль збережено. Ви вже увійшли.</div><?php endif;?>
<p class="note">Тут можна змінити пароль власника. Після входу цей браузер залишається авторизованим до явного «Вийти». Довга сесія захищена випадковим HttpOnly-токеном; на сервері зберігається лише його SHA-256. Зміна або скидання пароля анулює старі довгі сесії. Якщо доступ втрачено, «Забули пароль?» надсилає одноразове посилання на 30 хвилин.</p>
<div class="grid"><div><form method="post" style="max-width:620px"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="owner_password_change"><label>Чинний пароль<input type="password" name="current_password" autocomplete="current-password" required></label><label>Новий пароль<input type="password" name="new_password" autocomplete="new-password" minlength="12" required></label><div class="help">Щонайменше 12 символів.</div><label>Повторіть новий пароль<input type="password" name="new_password2" autocomplete="new-password" minlength="12" required></label><button class="btn primary">Змінити пароль</button></form></div><div><div class="panel" style="margin:0"><h2>Довгі сесії</h2><p class="note">Авторизація цього браузера відновлюється автоматично навіть після завершення звичайної PHP-сесії. Токен не містить пароля.</p><form method="post" onsubmit="return confirm('Завершити довгі сесії на інших пристроях?');"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="owner_sessions_revoke_others"><button class="btn">Вийти на інших пристроях</button></form></div></div></div></section>
<?php elseif($tab==='reactions'):?>
<section class="cards"><div class="card"><b><?=number_format($reactionCurrent,0,',',' ')?></b><span>активних «Сподобалось» зараз</span></div><div class="card"><b><?=number_format($reactionActive,0,',',' ')?></b><span>матеріалів із реакціями</span></div><div class="card"><b><?=number_format($reactionAdded,0,',',' ')?></b><span>усіх поставлених реакцій</span></div><div class="card"><b><?=number_format($reactionRemoved,0,',',' ')?></b><span>знятих реакцій</span></div></section>
<section class="panel"><h2>Реальні реакції по матеріалах</h2><p class="note">Тут показані точні числа. Публічно сайт навмисно не показує слабкі сирі цифри: 0–4 — без числа, 5–19 — «Подобається читачам», 20–49 — «20+ читачів», 50–99 — «50+ читачів», від 100 — точне число. Реакція анонімна, без акаунта; один локальний ID браузера може мати одну активну реакцію на матеріал.</p><div class="reaction-table-wrap"><table class="reaction-table"><tr><th>Матеріал</th><th>Тип</th><th class="num">Зараз</th><th class="num">Поставлено</th><th class="num">Знято</th><th>Остання дія</th></tr>
<?php foreach($reactionRows as $x): $url=$x['type']==='book'?'/books/'.$x['slug'].'/':'/blog/'.$x['slug'].'/';?><tr><td class="reaction-title"><a href="<?=h($url)?>" target="_blank"><?=h($x['title'])?> ↗</a></td><td><span class="reaction-type"><?=h($x['type']==='book'?'книга':'блог')?></span></td><td class="num <?=$x['current']?'reaction-live':'reaction-zero'?>"><?=number_format($x['current'],0,',',' ')?></td><td class="num"><?=number_format($x['likes_all_time'],0,',',' ')?></td><td class="num"><?=number_format($x['unlikes_all_time'],0,',',' ')?></td><td><?=h($x['last_action']?:'—')?></td></tr><?php endforeach;?>
</table></div></section>
<section class="panel"><h2>Останні 50 дій</h2><div class="reaction-table-wrap"><table class="reaction-table reaction-recent"><tr><th>Час</th><th>Матеріал</th><th>Дія</th><th>Анонімний ID</th></tr><?php if(!$reactionRecent):?><tr><td colspan="4" class="note">Реакцій ще не було.</td></tr><?php else:foreach($reactionRecent as $x):$key=(string)($x['type']??'').':'.(string)($x['slug']??'');?><tr><td><?=h((string)($x['at']??''))?></td><td><?=h($reactionTitleMap[$key]??$key)?></td><td class="<?=($x['action']??'')==='like'?'reaction-live':'reaction-zero'?>"><?=h(($x['action']??'')==='like'?'поставлено':'знято')?></td><td><?=h((string)($x['voter']??''))?></td></tr><?php endforeach;endif;?></table></div></section>
<?php elseif($tab==='focus'):?>
<section class="panel"><div class="panel-title-actions"><h2>Книга у фокусі</h2><button class="btn primary" type="submit" form="bookFocusForm">Зберегти у фокусі</button></div><p class="note">Оберіть книгу, яка буде показана великою обкладинкою у верхньому блоці головної сторінки. Це не змінює порядок каталогу, URL або SEO-адреси.</p>
<form method="post" id="bookFocusForm"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="book_focus">
<div class="focus-grid"><label class="focus-choice"><input type="radio" name="focus_slug" value="" <?=$focusedSlug===''?'checked':''?> required><span class="focus-card"><span class="focus-state">Без фокусу</span><span class="announcement-empty-cover">ПОРОЖНЄ<br>МІСЦЕ</span><b>Не показувати обкладинку</b><span class="focus-type">Головна збереже порожній простір без заглушки.</span></span></label><?php foreach($orderedPublicCatalog as $x):?><label class="focus-choice"><input type="radio" name="focus_slug" value="<?=h($x['slug'])?>" <?=$x['slug']===$focusedSlug?'checked':''?> required><span class="focus-card"><span class="focus-state">У фокусі</span><?php if($x['cover']):?><img src="<?=h(catalog_cover_admin_url($x['cover']))?>" alt=""><?php endif;?><b><?=h($x['title'])?></b><span class="focus-type"><?=h($x['type'])?></span></span></label><?php endforeach;?></div>
<div class="order-save"><button class="btn primary" type="submit">Зберегти у фокусі</button><?php if($focusedBook):?><span class="note">Зараз у фокусі: «<?=h($focusedBook['title'])?>».</span><?php endif;?></div></form></section>
<?php elseif($tab==='errors'):?>
<section class="panel"><div class="panel-title-actions"><h2>Повідомлення читачів про помилки</h2><span class="diag"><span class="<?=$readerErrorNew?'bad':'ok'?>">Нових: <?=$readerErrorNew?></span><span>Усього: <?=count($readerErrorItems)?></span></span></div><p class="note">У читанці читач може виділити фрагмент або просто описати проблему. Логін не потрібен. IP не зберігається — лише короткий односторонній хеш для антиспаму.</p><?php if(!$readerErrorItems):?><p class="note">Повідомлень поки немає.</p><?php else:?><div class="list"><?php foreach($readerErrorItems as $er):if(!is_array($er))continue;$status=(string)($er['status']??'new');$labels=['new'=>'Нова','in_progress'=>'В роботі','fixed'=>'Виправлено','rejected'=>'Відхилено'];?><article class="panel" style="margin:10px 0;padding:18px"><div class="row" style="border-top:0;padding-top:0"><div><b><?=h((string)($er['title']??$er['book']??''))?></b><div class="help"><?=h((string)($er['created_at']??''))?><?=!empty($er['section'])?' · '.h((string)$er['section']):''?></div></div><a target="_blank" href="<?=h((string)($er['url']??'/books/'.($er['book']??'').'/read/'))?>">відкрити ↗</a></div><?php if(!empty($er['fragment'])):?><blockquote style="margin:12px 0;padding:12px 14px;border-left:2px solid #806b45;background:#0c0c0e;border-radius:8px;white-space:pre-wrap"><?=h((string)$er['fragment'])?></blockquote><?php endif;?><?php if(!empty($er['note'])):?><p><b>Коментар:</b> <?=h((string)$er['note'])?></p><?php endif;?><?php if(!empty($er['contact'])):?><p class="note"><b>Контакт:</b> <?=h((string)$er['contact'])?></p><?php endif;?><form method="post" class="grid" style="grid-template-columns:minmax(180px,280px) auto;align-items:end"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="reader_error_status"><input type="hidden" name="error_id" value="<?=h((string)$er['id'])?>"><label>Статус<select name="status"><?php foreach($labels as $k=>$v):?><option value="<?=$k?>" <?=$status===$k?'selected':''?>><?=$v?></option><?php endforeach;?></select></label><button class="btn">Зберегти статус</button></form></article><?php endforeach;?></div><?php endif;?></section>
<?php elseif($tab==='seo'):?>
<section class="panel">
  <div class="panel-title-actions"><h2>SEO / Роботи</h2><a class="btn" href="https://www.bing.com/webmasters/home" target="_blank" rel="noopener">Bing Webmaster Tools ↗</a></div>
  <p class="note">Цей модуль перевіряє сайт окремо від Google/Bing: проходить внутрішні HTML-сторінки, ловить HTTP-помилки, noindex, дублікати title, canonical, sitemap і контролює всі опубліковані книги.</p>
  <div class="cards">
    <form method="post" class="card" style="display:block"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="seo_scan"><b>Повний робот-аудит</b><span>До 500 URL + Googlebot/Bingbot/OAI-SearchBot/ChatGPT-User, redirects, headers, robots, sitemap, 403/429 і час відповіді.</span><button class="btn primary" type="submit" style="margin-top:10px">Запустити перевірку</button></form>
    <div class="card" style="display:block"><b>Зовнішній crawler allowlist</b><span>robots.txt явно дозволяє OAI-SearchBot. Якщо Cityhost, CDN або WAF фільтрує ботів за IP, дозвольте актуальні офіційні діапазони OpenAI SearchBot з <a href="https://openai.com/searchbot.json" target="_blank" rel="noopener noreferrer">openai.com/searchbot.json ↗</a>. Не копіюйте IP вручну в код сайту: список може змінюватися. Цей self-test перевіряє HTTP-відповідь і User-Agent із сервера, але не може довести зовнішній source-IP allowlist.</span></div>
    <form method="post" class="card" style="display:block"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="seo_indexnow_all"><b>IndexNow</b><span>Надіслати всі URL із sitemap у мережу IndexNow.</span><button class="btn primary" type="submit" style="margin-top:10px">Надіслати sitemap</button></form>
    <form method="post" class="card" style="display:block"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="seo_bing_submit_all"><b>Bing URL Submission</b><span>Додаткове пряме надсилання до Bing.</span><button class="btn" type="submit" style="margin-top:10px">Надіслати в Bing</button></form>
  </div>
</section>
<section class="panel">
  <h2>Bing API key</h2>
  <form method="post"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="seo_bing_key">
    <label>API key <span class="help">Зберігається тільки в /_site-state/seo-tools.json і не входить у реліз.</span>
      <input name="bing_api_key" type="password" autocomplete="off" placeholder="<?=!empty($seoState['bing_api_key'])?'Ключ уже збережено':'Вставте API key Bing Webmaster Tools'?>">
    </label>
    <button class="btn primary">Зберегти ключ</button>
  </form>
</section>
<section class="panel">
  <h2>Останній робот-аудит</h2>
  <?php if(!$seoReport):?><p class="note">Ще не запускався.</p><?php else:?>
  <div class="cards">
    <div class="card"><b><?= (int)($seoSummary['crawled']??0) ?></b><span>HTML URL перевірено</span></div>
    <div class="card"><b><?= (int)($seoSummary['books_ok']??0) ?>/<?= (int)($seoSummary['books_expected']??0) ?></b><span>книг доступні</span></div>
    <div class="card"><b><?= (int)($seoSummary['http_errors']??0) ?></b><span>HTTP-помилок</span></div>
    <div class="card"><b><?= (int)($seoSummary['crawler_blocks']??0) ?></b><span>блокувань crawler</span></div>
    <div class="card"><b><?= (int)($seoSummary['redirect_issues']??0) ?></b><span>проблем redirect-chain</span></div>
    <div class="card"><b><?= (int)($seoSummary['slow_urls']??0) ?></b><span>повільних URL &gt;2,5 с</span></div>
    <div class="card"><b><?= (int)($seoSummary['robots_issues']??0) ?></b><span>проблем robots.txt</span></div>
    <div class="card"><b><?= (int)($seoSummary['sitemap_issues']??0) ?></b><span>проблем sitemap</span></div>
    <div class="card"><b><?= (int)($seoSummary['header_issues']??0) ?></b><span>проблем HTTP headers</span></div>
    <div class="card"><b><?= (int)($seoSummary['noindex']??0) ?></b><span>noindex</span></div>
    <div class="card"><b><?= (int)($seoSummary['duplicate_titles']??0) ?></b><span>дублів title</span></div>
    <div class="card"><b><?= (int)($seoSummary['canonical_mismatch']??0) ?></b><span>canonical-помилок</span></div>
    <div class="card"><b><?= (int)($seoSummary['missing_descriptions']??0) ?></b><span>без description</span></div>
    <div class="card"><b><?= (int)($seoSummary['h1_issues']??0) ?></b><span>сторінок з H1 ≠ 1</span></div>
    <div class="card"><b><?= (int)($seoSummary['redirects']??0) ?></b><span>редиректів</span></div>
    <div class="card"><b><?= (int)($seoSummary['not_in_sitemap']??0) ?></b><span>індексних URL поза sitemap</span></div>
    <div class="card"><b><?= (int)($seoSummary['consistency_issues']??0) ?></b><span>розсинхронізацій state / SEO</span></div>
    <div class="card"><b><?= (int)($seoSummary['static_gate_issues']??0) ?></b><span>локальних structural/garbage дефектів</span></div>
    
    <div class="card"><b><?= !empty($seoSummary['indexnow_ready'])?'OK':'ERR' ?></b><span>IndexNow key</span></div>
    <div class="card"><b><?= !empty($seoSummary['bing_ready'])?'OK':'—' ?></b><span>Bing API key</span></div>
  </div>
  <p class="note">robots.txt: HTTP <?= (int)($seoSummary['robots_status']??0) ?> · sitemap.xml: HTTP <?= (int)($seoSummary['sitemap_status']??0) ?> · URL у sitemap: <?= (int)($seoSummary['sitemap_urls']??0) ?> · <?=h((string)($seoReport['generated_at']??''))?></p>
  <?php if(!empty($seoReport['crawler_matrix'])):?><h3>Crawler matrix</h3><pre><?=h(json_encode((array)$seoReport['crawler_matrix'],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES))?></pre><?php endif;?>
  <?php if(!empty($seoReport['crawler_blocks'])):?><h3>Блокування crawler (401/403/429/5xx)</h3><pre><?=h(json_encode((array)$seoReport['crawler_blocks'],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES))?></pre><?php endif;?>
  <?php if(!empty($seoReport['redirect_issues'])):?><h3>Redirect chain / canonical origin</h3><pre><?=h(json_encode((array)$seoReport['redirect_issues'],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES))?></pre><?php endif;?>
  <?php if(!empty($seoReport['header_issues'])):?><h3>HTTP headers</h3><pre><?=h(json_encode(['issues'=>$seoReport['header_issues'],'headers'=>$seoReport['headers']??[]],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES))?></pre><?php endif;?>
  <?php if(!empty($seoReport['robots_issues'])):?><h3>robots.txt</h3><pre><?=h(implode("\n",(array)$seoReport['robots_issues']))?></pre><?php endif;?>
  <?php if(!empty($seoReport['sitemap_issues'])):?><h3>sitemap.xml</h3><pre><?=h(implode("\n",(array)$seoReport['sitemap_issues']))?></pre><?php endif;?>
  <?php if(!empty($seoReport['slow_urls'])):?><h3>Повільні URL</h3><pre><?=h(json_encode((array)$seoReport['slow_urls'],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES))?></pre><?php endif;?>
  <?php if(!empty($seoReport['http_errors'])):?><h3>HTTP-помилки</h3><pre><?=h(json_encode($seoReport['http_errors'],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES))?></pre><?php endif;?>
  <?php if(!empty($seoReport['redirects'])):?><h3>Редиректи</h3><pre><?=h(json_encode(array_slice((array)$seoReport['redirects'],0,80),JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES))?></pre><?php endif;?>
  <?php if(!empty($seoReport['canonical_mismatch'])):?><h3>Canonical</h3><pre><?=h(json_encode((array)$seoReport['canonical_mismatch'],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES))?></pre><?php endif;?>
  <?php if(!empty($seoReport['missing_titles'])):?><h3>Без title</h3><pre><?=h(implode("\n",(array)$seoReport['missing_titles']))?></pre><?php endif;?>
  <?php if(!empty($seoReport['missing_descriptions'])):?><h3>Без description</h3><pre><?=h(implode("\n",(array)$seoReport['missing_descriptions']))?></pre><?php endif;?>
  <?php if(!empty($seoReport['h1_issues'])):?><h3>H1</h3><pre><?=h(json_encode((array)$seoReport['h1_issues'],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES))?></pre><?php endif;?>
  <?php if(!empty($seoReport['missing_books'])):?><h3>Відсутні книги</h3><pre><?=h(implode("\n",(array)$seoReport['missing_books']))?></pre><?php endif;?>
  <?php if(!empty($seoReport['not_in_sitemap'])):?><h3>Індексні URL не в sitemap</h3><pre><?=h(implode("\n",array_slice((array)$seoReport['not_in_sitemap'],0,80)))?></pre><?php endif;?>
  <?php if(!empty($seoReport['consistency_issues'])):?><h3>State ↔ SEO / файли</h3><pre><?=h(implode("\n",(array)$seoReport['consistency_issues']))?></pre><?php endif;?>
  <?php if(!empty($seoReport['static_gate']['issues'])):?><h3>Локальний static/garbage gate</h3><pre><?=h(json_encode((array)$seoReport['static_gate'],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES))?></pre><?php endif;?>
  <?php endif;?>
</section>
<?php elseif($tab==='deploy'):?>
<section class="panel">
  <div class="panel-title-actions"><h2>Оновити сайт</h2>
    <?php if($deploySupported):?><span class="diag"><span class="ok">ZIP підтримується</span><span>Резервна копія перед розгортанням</span><span>Архів після успіху видаляється</span></span><?php else:?><span class="diag"><span class="bad">ZIP недоступний у PHP</span></span><?php endif;?>
  </div>
  <p class="note">Boss приймає три формати: повну збірку MaVik, одну частину multipart-релізу або малий overlay-патч із <code>.mavik-patch.json</code>. Overlay змінює лише файли, явно перелічені у маніфесті патча, і не видаляє решту сайту. Перед будь-яким застосуванням створюється резервна копія. <code>_site-state</code> та дані реакцій зберігаються.</p>
  <p class="help"><?=h(mavik_deploy_ini_limit())?> · якщо повний реліз не проходить upload-ліміт хостингу, завантажуйте PART-1 і PART-2 по черзі. Після останньої частини Boss автоматично збере й розгорне реліз.</p>
  <?php if($deploySupported):?>
  <form method="post" enctype="multipart/form-data" onsubmit="return confirm('Застосувати цей ZIP на живому сайті? Boss перевірить, чи це реліз, multipart-частина або overlay-патч, і перед змінами створить резервну копію.');">
    <input type="hidden" name="csrf" value="<?=h(csrf())?>">
    <input type="hidden" name="action" value="site_deploy">
    <label>ZIP-збірка, multipart-частина або overlay-патч<input type="file" name="release_zip" accept=".zip,application/zip" required></label>
    <button class="btn primary">Прийняти й розгорнути</button>
  </form>
  <?php else:?><div class="msg err">На цій версії PHP не знайдено ZipArchive або PharData. Розгортання з Boss недоступне.</div><?php endif;?>
</section>

<section class="grid">
  <div class="panel"><div class="panel-title-actions"><h2>Резервні копії LIVE DATA</h2><span class="diag"><span class="ok">Перед deploy — обов’язково</span></span></div>
    <p class="note">Backup зберігає живий state, книги, блоги, EPUB, усі обкладинки та медіа. Якщо safety-backup перед релізом не створився або не пройшов checksum-перевірку, deploy автоматично зупиняється. Каталог backup-ів лежить поза core.</p>
    <div class="form-actions" style="margin:10px 0 14px">
      <form method="post"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="backup_create"><button class="btn">Створити backup</button></form>
      <form method="post"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="backup_create_download"><button class="btn primary">Створити й завантажити</button></form>
      <form method="post"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="backup_create_golden_download"><button class="btn primary">Створити золотий backup і завантажити</button></form>
      <?php if($deployBackups):?><form id="backupBulkDeleteForm" method="post" onsubmit="const picked=[...document.querySelectorAll('.backup-delete-check:checked')];if(!picked.length){alert('Оберіть backup-и для видалення.');return false;}return confirm('Видалити вибрані backup-и?\n\n'+picked.map(x=>x.dataset.label).join('\n'));"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="backup_delete_selected"><button class="btn danger">Видалити вибрані</button></form><?php endif;?>
    </div>
    <div class="list"><?php if(!$deployBackups):?><div class="note">Ще немає резервних копій.</div><?php else:foreach($deployBackups as $bk):?>
      <?php $backupDate=date('Y-m-d H:i',(int)$bk['mtime']);$backupProtected=!empty($bk['protected']);?>
      <div class="row"><?php if(!$backupProtected):?><label title="Позначити для видалення"><input class="backup-delete-check" type="checkbox" name="backups[]" value="<?=h((string)$bk['name'])?>" data-label="<?=h((string)$bk['name'].' · '.$backupDate)?>" form="backupBulkDeleteForm"></label><?php endif;?><span><b><?=h((string)$bk['name'])?></b><?php if($backupProtected):?> <span class="status-pill">Захищено</span><?php elseif(!empty($bk['golden'])):?> <span class="status-pill">Золотий</span><?php endif;?><span class="help"><?=h($backupDate)?> · <?=number_format((int)$bk['size']/1024/1024,1,',',' ')?> МБ · <?=number_format((int)($bk['file_count']??0),0,',',' ')?> файлів · книг <?= (int)($bk['books']??0) ?> · блог <?= (int)($bk['blog']??0) ?> · порядок <?= (int)($bk['book_order']??0) ?> · <?=!empty($bk['verified'])?'checksum ✓':'checksum ?'?></span></span><span class="form-actions">
        <form method="post"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="backup_download"><input type="hidden" name="backup" value="<?=h((string)$bk['name'])?>"><button class="mini-btn">Завантажити</button></form>
        <form method="post" onsubmit="return confirm('Відновити LIVE DATA з цієї копії? Перед restore Boss автоматично створить ще один safety-backup поточного стану.');"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="backup_restore"><input type="hidden" name="backup" value="<?=h((string)$bk['name'])?>"><button class="mini-btn danger">Відновити</button></form>
        <?php if(!$backupProtected):?><form method="post" onsubmit="return confirm('Видалити backup «<?=h(addslashes((string)$bk['name']))?>» від <?=h($backupDate)?>?');"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="backup_delete"><input type="hidden" name="backup" value="<?=h((string)$bk['name'])?>"><button class="mini-btn danger">Видалити</button></form><?php endif;?>
      </span></div>
    <?php endforeach;endif;?></div>
  </div>
  <div class="panel"><h2>Невдалі ZIP</h2>
    <p class="note">Якщо перевірка або розгортання не завершилося, ZIP не видаляється автоматично. Він лежить у захищеній службовій папці, доки ви не видалите його тут.</p>
    <div class="list"><?php if(!$deployFailed):?><div class="note">Немає.</div><?php else:foreach($deployFailed as $fa):?>
      <div class="row"><span><b><?=h((string)$fa['name'])?></b><span class="help"><?=h(date('Y-m-d H:i',(int)$fa['mtime']))?> · <?=number_format((int)$fa['size']/1024/1024,1,',',' ')?> МБ</span></span><form method="post" onsubmit="return confirm('Видалити цей невдалий ZIP?');"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="deploy_failed_delete"><input type="hidden" name="archive" value="<?=h((string)$fa['name'])?>"><button class="btn">Видалити</button></form></div>
    <?php endforeach;endif;?></div>
  </div>
</section>
<?php elseif($tab==='music'):?>
<div class="music-subnav"><a class="<?=$musicView==='tracks'?'active':''?>" href="?tab=music&view=tracks">Треки</a><a class="<?=$musicView==='collections'?'active':''?>" href="?tab=music&view=collections">Збірки</a><a class="<?=$musicView==='books'?'active':''?>" href="?tab=music&view=books">Музика до книг</a><a class="<?=$musicView==='recommendations'?'active':''?>" href="?tab=music&view=recommendations">Зовнішні рекомендації</a><a target="_blank" href="/music/">Відкрити музику ↗</a></div>
<?php if($musicView==='tracks'):?>
<section class="panel"><h2>Додати трек</h2><form method="post" enctype="multipart/form-data" id="musicAddForm"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="music_add_track"><input type="hidden" name="duration" id="musicDetectedDuration" value="0"><div class="audio-add-grid"><label>Назва<input name="title" required></label><label>Виконавець<input name="artist" value="MaVik_AI" required></label><label>Альбом / група<input name="album" value="Окремі треки" required></label></div><div class="grid"><label>Аудіофайл<input id="musicAudioInput" type="file" name="audio" accept="audio/*,.mp3,.m4a,.aac,.wav,.ogg" required><span class="help" id="musicDurationHint">MP3, M4A, AAC, WAV або OGG · до 100 MB.</span></label><label>Обкладинка <span class="help">Необов’язково. Без неї використається загальна обкладинка MaVik_AI.</span><input type="file" name="cover" accept="image/jpeg,image/png"></label></div><div class="music-add-actions"><button class="btn primary">Додати трек</button><button class="btn" type="submit" form="musicOrderForm">Зберегти порядок</button></div></form></section>
<section class="panel"><h2>Порядок треків</h2><p class="note">Перетягуйте треки мишею або пальцем. Прихований трек лишається в Boss і збірках, але не потрапляє у публічний програвач.</p><form method="post" id="musicOrderForm"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="music_track_order"><input type="hidden" name="order" id="musicOrderValue"><div class="sort-list" id="musicSortList">
<?php foreach($musicTracks as $i=>$t):if(!is_array($t))continue;$tHidden=!empty($t['hidden']);$tid=(string)$t['id'];?>
<div class="sort-item music-track-item" data-id="<?=h($tid)?>"><button type="button" class="drag-handle" aria-label="Перетягнути">⋮⋮</button><img class="sort-cover" src="<?=h((string)($t['cover']??'/assets/images/mavik-music.jpg'))?>" alt=""><div class="sort-copy"><b><?=h((string)($t['title']??'Трек'))?></b><div class="music-track-meta"><span><?=h((string)($t['artist']??'MaVik_AI'))?></span><span>·</span><span><?=h((string)($t['album']??''))?></span></div><?php if($tHidden):?><span class="status-pill hidden">Приховано</span><?php endif;?></div><div class="music-track-actions"><button type="button" class="sort-arrow" data-move="up" aria-label="Вище">↑</button><button type="button" class="sort-arrow" data-move="down" aria-label="Нижче">↓</button><a class="mini-btn" href="?tab=music&view=tracks&edit=<?=rawurlencode($tid)?>#edit-track">Редагувати</a><button class="mini-btn" type="submit" form="visibility-<?=h($tid)?>"><?=$tHidden?'Показати':'Приховати'?></button><button class="mini-btn danger music-delete-trigger" type="submit" form="delete-<?=h($tid)?>">Видалити</button><span class="sort-pos"><?=$i+1?></span></div></div>
<?php endforeach;?></div><div class="order-save"><button class="btn primary">Зберегти порядок</button><span class="note"><?=count($musicTracks)?> треків.</span></div></form>
<?php foreach($musicTracks as $t):if(!is_array($t))continue;$tid=(string)$t['id'];?><form id="visibility-<?=h($tid)?>" method="post"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="music_track_visibility"><input type="hidden" name="track_id" value="<?=h($tid)?>"></form><form id="delete-<?=h($tid)?>" method="post" onsubmit="return confirm('Прибрати трек «<?=h(addslashes((string)($t['title']??'')))?>» з музичного каталогу та всіх збірок?');"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="music_track_delete"><input type="hidden" name="track_id" value="<?=h($tid)?>"></form><?php endforeach;?></section>
<?php $editId=(string)($_GET['edit']??'');$editTrack=$musicTrackMap[$editId]??null;if(is_array($editTrack)):?><section class="panel" id="edit-track"><div class="panel-title-actions"><h2>Редагувати трек</h2><a class="btn" href="?tab=music&view=tracks">Закрити</a></div><form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="music_track_update"><input type="hidden" name="track_id" value="<?=h($editId)?>"><div class="music-edit"><label>Назва<input name="title" value="<?=h((string)$editTrack['title'])?>" required></label><label>Виконавець<input name="artist" value="<?=h((string)($editTrack['artist']??'MaVik_AI'))?>"></label><label>Альбом<input name="album" value="<?=h((string)($editTrack['album']??''))?>"></label><label>Секунд<input type="number" min="0" step="0.1" name="duration" value="<?=h((string)($editTrack['duration']??0))?>"></label></div><label>Нова обкладинка <span class="help">Необов’язково.</span><input type="file" name="cover" accept="image/jpeg,image/png"></label><button class="btn primary">Зберегти трек</button></form></section><?php endif;?>
<script>MaVikPointerSorter({listId:'musicSortList',formId:'musicOrderForm',outputId:'musicOrderValue',key:'id'});(()=>{const input=document.getElementById('musicAudioInput'),dur=document.getElementById('musicDetectedDuration'),hint=document.getElementById('musicDurationHint');if(input&&dur){input.addEventListener('change',()=>{const f=input.files?.[0];if(!f)return;const u=URL.createObjectURL(f),a=new Audio();a.preload='metadata';a.onloadedmetadata=()=>{if(Number.isFinite(a.duration)){dur.value=String(a.duration);if(hint)hint.textContent='Тривалість визначено: '+Math.floor(a.duration/60)+':'+String(Math.floor(a.duration%60)).padStart(2,'0')}URL.revokeObjectURL(u)};a.src=u})}})();</script>
<?php elseif($musicView==='collections'):?>
<?php if($musicCollection):$cid=(string)$musicCollection['id'];$ids=array_values((array)($musicCollection['tracks']??[]));?><section class="panel"><div class="panel-title-actions"><h2>Збірка · <?=h((string)$musicCollection['name'])?> <?php if(!empty($musicCollection['hidden'])):?><span class="status-pill hidden">Приховано</span><?php endif;?></h2><form method="post"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="music_collection_visibility"><input type="hidden" name="collection_id" value="<?=h($cid)?>"><button class="mini-btn"><?=!empty($musicCollection['hidden'])?'Показати збірку':'Приховати збірку'?></button></form></div><form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="music_collection_update"><input type="hidden" name="collection_id" value="<?=h($cid)?>"><div class="grid"><label>Назва<input name="name" value="<?=h((string)$musicCollection['name'])?>" required></label><label>Нова обкладинка <span class="help">Необов’язково.</span><input type="file" name="cover" accept="image/jpeg,image/png"></label></div><label>Опис<input name="description" value="<?=h((string)($musicCollection['description']??''))?>"></label><button class="btn primary">Зберегти опис</button></form></section>
<section class="panel"><h2>Треки збірки</h2><form method="post" id="collectionOrderForm"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="music_collection_order"><input type="hidden" name="collection_id" value="<?=h($cid)?>"><input type="hidden" name="order" id="collectionOrderValue"><div class="sort-list collection-track-list" id="collectionSortList"><?php foreach($ids as $i=>$tid):$t=$musicTrackMap[(string)$tid]??null;if(!is_array($t))continue;?><div class="sort-item" data-id="<?=h((string)$tid)?>"><button type="button" class="drag-handle">⋮⋮</button><img class="sort-cover" src="<?=h((string)($t['cover']??'/assets/images/mavik-music.jpg'))?>" alt=""><div class="sort-copy"><b><?=h((string)$t['title'])?></b><span><?=h((string)($t['album']??''))?></span></div><div class="music-track-actions"><button type="button" class="sort-arrow" data-move="up" aria-label="Вище">↑</button><button type="button" class="sort-arrow" data-move="down" aria-label="Нижче">↓</button><button class="mini-btn danger" type="submit" form="remove-<?=h((string)$tid)?>">Прибрати</button><span class="sort-pos"><?=$i+1?></span></div></div><?php endforeach;?></div><div class="order-save"><button class="btn primary">Зберегти порядок</button><span class="note"><?=count($ids)?> треків у збірці.</span></div></form><?php foreach($ids as $tid):?><form id="remove-<?=h((string)$tid)?>" method="post"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="music_collection_remove_track"><input type="hidden" name="collection_id" value="<?=h($cid)?>"><input type="hidden" name="track_id" value="<?=h((string)$tid)?>"></form><?php endforeach;?></section>
<section class="panel"><h2>Додати трек</h2><form method="post" class="collection-add"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="music_collection_add_track"><input type="hidden" name="collection_id" value="<?=h($cid)?>"><label>Трек<select name="track_id" required><option value="">Оберіть…</option><?php foreach($musicTracks as $t):if(!is_array($t)||in_array((string)$t['id'],$ids,true))continue;?><option value="<?=h((string)$t['id'])?>"><?=h((string)$t['title'])?> · <?=h((string)($t['album']??''))?></option><?php endforeach;?></select></label><button class="btn primary">Додати</button></form></section>
<section class="panel music-danger-zone"><h2>Видалити збірку</h2><p class="note">Самі аудіотреки не видаляються. Книги, які використовували цю збірку, повернуться до режиму «Усі треки».</p><form method="post" onsubmit="return confirm('Видалити збірку? Самі треки залишаться.');"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="music_collection_delete"><input type="hidden" name="collection_id" value="<?=h($cid)?>"><button class="mini-btn danger">Видалити збірку</button></form></section>
<script>MaVikPointerSorter({listId:'collectionSortList',formId:'collectionOrderForm',outputId:'collectionOrderValue',key:'id'});</script>
<?php else:?><section class="panel"><h2>Збірки / плейлисти</h2><p class="note">Один трек може входити до кількох збірок. Порядок усередині кожної збірки налаштовується drag & drop.</p><div class="list"><?php if(!$musicCollections):?><div class="note">Поки немає жодної збірки.</div><?php else:foreach($musicCollections as $c):if(!is_array($c))continue;?><div class="collection-card"><img src="<?=h((string)($c['cover']??'/assets/images/mavik-music.jpg'))?>" alt=""><div><h3><?=h((string)$c['name'])?></h3><p><?=count((array)($c['tracks']??[]))?> треків<?php if(!empty($c['description'])):?> · <?=h((string)$c['description'])?><?php endif;?></p></div><div class="music-track-actions"><?php if(!empty($c['hidden'])):?><span class="status-pill hidden">Приховано</span><?php endif;?><a class="mini-btn" href="?tab=music&view=collections&cid=<?=rawurlencode((string)$c['id'])?>">Редагувати</a><form method="post"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="music_collection_visibility"><input type="hidden" name="collection_id" value="<?=h((string)$c['id'])?>"><button class="mini-btn"><?=!empty($c['hidden'])?'Показати':'Приховати'?></button></form><form method="post" onsubmit="return confirm('Видалити збірку «<?=h(addslashes((string)$c['name']))?>»? Самі треки залишаться в музичній бібліотеці.');"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="music_collection_delete"><input type="hidden" name="collection_id" value="<?=h((string)$c['id'])?>"><button class="mini-btn danger">Видалити</button></form></div></div><?php endforeach;endif;?></div></section><section class="panel"><h2>Створити збірку</h2><form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="music_collection_create"><div class="grid"><label>Назва<input name="name" required placeholder="Музика для UNIVERSE"></label><label>Обкладинка <span class="help">Необов’язково.</span><input type="file" name="cover" accept="image/jpeg,image/png"></label></div><label>Короткий опис<input name="description" placeholder="Темна, споглядальна добірка для читання"></label><button class="btn primary">Створити збірку</button></form></section><?php endif;?>
<?php elseif($musicView==='books'):?>
<section class="panel"><h2>Музика до книг</h2><p class="note">Для кожної книги можна вибрати весь каталог, конкретну збірку, окремий трек або «Без музики». Якщо вже прив’язану збірку/трек приховати, прив’язка зберігається, але публічно музика не відтворюється до повторного показу.</p><form method="post"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="music_book_assign"><div class="book-music-grid"><?php foreach($orderedPublicCatalog as $b):$slug=(string)$b['slug'];$selected=(string)($musicLib['book_collections'][$slug]??'all');?><div class="book-music-row"><?php if($b['cover']):?><img src="<?=h(catalog_cover_admin_url($b['cover']))?>" alt=""><?php endif;?><div><b><?=h($b['title'])?></b><div class="note"><?=h($b['type'])?></div></div><select name="book_music[<?=h($slug)?>]"><option value="all" <?=$selected==='all'?'selected':''?>>Усі треки</option><option value="none" <?=$selected==='none'?'selected':''?>>Без музики</option><?php $visibleCollections=array_values(array_filter((array)$musicCollections,fn($c)=>is_array($c)&&empty($c['hidden'])));$selectedVisible=$selected==='all'||$selected==='none';foreach($visibleCollections as $c)if((string)($c['id']??'')===$selected)$selectedVisible=true;$visibleTracks=array_values(array_filter((array)($musicLib['tracks']??[]),fn($t)=>is_array($t)&&empty($t['hidden'])));foreach($visibleTracks as $t)if('track:'.(string)($t['id']??'')===$selected)$selectedVisible=true;if(!$selectedVisible):$hiddenLabel='Прихована/недоступна музика';if(str_starts_with($selected,'track:')){$hid=substr($selected,6);foreach((array)($musicLib['tracks']??[]) as $t)if(is_array($t)&&(string)($t['id']??'')===$hid){$hiddenLabel='Прихований трек: '.(string)($t['title']??'Трек');break;}}else foreach((array)$musicCollections as $c)if(is_array($c)&&(string)($c['id']??'')===$selected){$hiddenLabel='Прихована збірка: '.(string)($c['name']??'Збірка');break;}?><option value="<?=h($selected)?>" selected><?=h($hiddenLabel)?></option><?php endif;?><?php if($visibleCollections):?><optgroup label="Збірки"><?php foreach($visibleCollections as $c):$id=(string)$c['id'];?><option value="<?=h($id)?>" <?=$selected===$id?'selected':''?>><?=h((string)$c['name'])?> · <?=count((array)($c['tracks']??[]))?> треків</option><?php endforeach;?></optgroup><?php endif;?><?php if($visibleTracks):?><optgroup label="Окремі треки"><?php foreach($visibleTracks as $t):$tid=(string)($t['id']??'');if($tid==='')continue;$token='track:'.$tid;?><option value="<?=h($token)?>" <?=$selected===$token?'selected':''?>><?=h((string)($t['title']??'Трек'))?><?=!empty($t['album'])?' · '.h((string)$t['album']):''?></option><?php endforeach;?></optgroup><?php endif;?></select></div><?php endforeach;?></div><div class="order-save"><button class="btn primary">Зберегти музику до книг</button></div></form></section>
<?php elseif($musicView==='recommendations'):?>
<section class="panel"><h2>Зовнішні рекомендації</h2><p class="note">Додавайте лише легальні посилання на офіційні сторінки треків, альбомів або плейлистів. Чужі аудіофайли сайт не копіює і не проксіює. У читанці рекомендація з’явиться тільки для вибраної книги; сторонній плеєр, якщо він підтримується, завантажується лише після явної дії читача.</p>
<form method="post"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="music_external_add">
<div class="grid"><label>Книга<select name="book_slug" required><option value="">Оберіть книгу…</option><?php foreach($orderedPublicCatalog as $b):?><option value="<?=h((string)$b['slug'])?>"><?=h((string)$b['title'])?></option><?php endforeach;?></select></label><label>Назва<input name="title" required maxlength="180" placeholder="Наприклад: Ambient Reading"></label></div>
<div class="grid"><label>Автор / джерело<input name="source" maxlength="180" placeholder="Виконавець, канал або сервіс"></label><label>HTTPS-посилання<input type="url" name="url" required maxlength="1600" placeholder="https://…"></label></div>
<label>Примітка <span class="help">Необов’язково. Коротко: чому саме ця музика пасує до читання.</span><input name="note" maxlength="300" placeholder="Спокійний фон для цієї книги"></label>
<div class="form-actions"><button class="btn primary">Додати рекомендацію</button></div></form></section>
<section class="panel"><h2>Додані рекомендації</h2><?php $hasExt=false;foreach($orderedPublicCatalog as $b):$slug=(string)$b['slug'];$items=(array)($musicLib['external_recommendations'][$slug]??[]);if(!$items)continue;$hasExt=true;?><div class="collection-card" style="grid-template-columns:48px minmax(0,1fr)"><?php if($b['cover']):?><img style="width:42px;height:58px" src="<?=h(catalog_cover_admin_url($b['cover']))?>" alt=""><?php endif;?><div><h3><?=h((string)$b['title'])?></h3><p><?=count($items)?> рекомендац.</p></div></div><?php foreach($items as $r):if(!is_array($r))continue;?><div class="sort-item" style="grid-template-columns:minmax(0,1fr) auto"><div class="sort-copy"><b><?=h((string)($r['title']??'Музика'))?></b><span><?=h((string)($r['source']??''))?><?php if(!empty($r['note'])):?> · <?=h((string)$r['note'])?><?php endif;?></span><a class="mini-btn" style="width:max-content;margin-top:7px" href="<?=h((string)($r['url']??'#'))?>" target="_blank" rel="noopener noreferrer">Перевірити джерело ↗</a></div><form method="post" onsubmit="return confirm('Прибрати цю рекомендацію?');"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="music_external_delete"><input type="hidden" name="book_slug" value="<?=h($slug)?>"><input type="hidden" name="recommendation_id" value="<?=h((string)($r['id']??''))?>"><button class="mini-btn danger">Видалити</button></form></div><?php endforeach;?><?php endforeach;?><?php if(!$hasExt):?><p class="note">Поки немає жодної зовнішньої рекомендації. Додайте першу вище — після збереження вона стане доступною читачеві в меню ☰ відповідної книги.</p><?php endif;?></section>
<?php endif;?>
<?php elseif($tab==='images_blog'||$tab==='images_covers'):$mediaType=$tab==='images_blog'?'blog':'covers';$mediaItems=$mediaType==='blog'?$blogMedia:$coverMedia;$mediaTitle=$mediaType==='blog'?'Фото блогу':'Обкладинки книг';?>
<section class="panel"><div class="panel-title-actions"><h2><?=$mediaTitle?></h2><span class="note">Папка: /images/<?=$mediaType?>/ · <?=count($mediaItems)?> файлів</span></div><form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="media_add"><input type="hidden" name="media_type" value="<?=h($mediaType)?>"><div class="grid"><label>Назва / підпис для файла<input name="label" placeholder="<?= $mediaType==='blog'?'nazva-statti':'nazva-knyhy' ?>"></label><label>Нове зображення<input type="file" name="media" accept="image/jpeg,image/png" required></label></div><button class="btn primary">Додати до медіатеки</button></form></section>
<?php if($mediaType!=='covers'&&$mediaReplace!==''): $replaceFound=null;foreach($mediaItems as $mi)if(($mi['file']??'')===$mediaReplace){$replaceFound=$mi;break;}if($replaceFound):?>
<section class="panel" id="replace-media"><div class="panel-title-actions"><h2>Замінити <?=h($mediaReplace)?></h2><a class="btn" href="?tab=<?=h($tab)?>">Скасувати</a></div><div class="current-image"><img src="<?=h((string)$replaceFound['url'])?>" alt=""><span class="note">Адреса не зміниться. Новий файл має бути того самого формату.</span></div><form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="media_replace"><input type="hidden" name="media_type" value="<?=h($mediaType)?>"><input type="hidden" name="file" value="<?=h($mediaReplace)?>"><label>Новий файл<input type="file" name="media" accept="image/jpeg,image/png" required></label><button class="btn primary">Замінити файл</button></form></section>
<?php endif;endif;?>
<section class="panel"><h2>Порядок</h2><p class="note">Перетягуйте мишею/пальцем або користуйтеся стрілками. Порядок потрібен для зручного вибору в Boss і не змінює порядок статей чи книг.</p><form method="post" id="mediaOrderForm"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="media_order"><input type="hidden" name="media_type" value="<?=h($mediaType)?>"><input type="hidden" name="order" id="mediaOrderValue"><div class="sort-list" id="mediaSortList"><?php foreach($mediaItems as $i=>$mi):?><div class="sort-item media-sort-item <?=$mediaType==='covers'?'cover-row':''?>" data-file="<?=h((string)$mi['file'])?>"><button type="button" class="drag-handle" aria-label="Перетягнути">⋮⋮</button><button type="button" class="media-thumb-button" data-media-preview="<?=h((string)$mi['url'])?>" data-media-name="<?=h((string)$mi['file'])?>" aria-label="Збільшити <?=h((string)$mi['file'])?>"><img class="media-thumb" src="<?=h((string)$mi['url'])?>" alt=""></button><?php $mediaAbs=media_public_url($mediaType,(string)$mi['file']);$mediaAlt=pathinfo((string)$mi['file'],PATHINFO_FILENAME);$mediaMd='!['.$mediaAlt.']('.$mediaAbs.')';$mediaHtml='<img src="'.$mediaAbs.'" alt="'.$mediaAlt.'">';?><div class="sort-copy"><b><?=h((string)$mi['file'])?></b><span><?= (int)$mi['width']?>×<?= (int)$mi['height']?> · <?=number_format(((int)$mi['bytes'])/1024,0,',',' ')?> KB</span><div class="media-link-tools"><button class="mini-btn" type="button" data-copy-media="<?=h($mediaAbs)?>">URL</button><button class="mini-btn" type="button" data-copy-media="<?=h($mediaMd)?>">Markdown</button><button class="mini-btn" type="button" data-copy-media="<?=h($mediaHtml)?>">HTML</button><a class="mini-btn" href="<?=h($mediaAbs)?>" target="_blank" rel="noopener">Відкрити ↗</a></div></div><div class="media-actions"><button type="button" class="sort-arrow" data-move="up">↑</button><button type="button" class="sort-arrow" data-move="down">↓</button><?php if($mediaType!=='covers'):?><a class="mini-btn" href="?tab=<?=h($tab)?>&amp;replace=<?=rawurlencode((string)$mi['file'])?>#replace-media">Замінити</a><?php endif;?><button class="mini-btn danger" type="submit" form="media-delete-<?=md5($mediaType.'|'.(string)$mi['file'])?>">Видалити</button><span class="sort-pos"><?=$i+1?></span></div></div><?php endforeach;?></div><div class="order-save"><button class="btn primary">Зберегти порядок</button></div></form><?php foreach($mediaItems as $mi):?><form id="media-delete-<?=md5($mediaType.'|'.(string)$mi['file'])?>" method="post" onsubmit="return confirm('Видалити <?=h(addslashes((string)$mi['file']))?>? Якщо файл використовується, Boss не дозволить це зробити.');"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="media_delete"><input type="hidden" name="media_type" value="<?=h($mediaType)?>"><input type="hidden" name="file" value="<?=h((string)$mi['file'])?>"></form><?php endforeach;?></section>
<dialog class="media-preview-dialog" id="mediaPreviewDialog"><div class="media-preview-head"><b id="mediaPreviewName">Зображення</b><button type="button" class="media-preview-close" id="mediaPreviewClose" aria-label="Закрити">×</button></div><img id="mediaPreviewImage" src="" alt=""></dialog>
<script>MaVikPointerSorter({listId:'mediaSortList',formId:'mediaOrderForm',outputId:'mediaOrderValue',key:'file'});</script><script>(()=>{const copy=async text=>{if(navigator.clipboard&&window.isSecureContext){await navigator.clipboard.writeText(text);return;}const ta=document.createElement('textarea');ta.value=text;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();document.execCommand('copy');ta.remove();};document.addEventListener('click',async e=>{const b=e.target.closest('[data-copy-media]');if(!b)return;const original=b.textContent;try{await copy(b.dataset.copyMedia||'');b.textContent='Скопійовано ✓';b.classList.add('copied');setTimeout(()=>{b.textContent=original;b.classList.remove('copied')},1300)}catch(err){alert('Не вдалося скопіювати. Виділіть адресу вручну.')}})})();</script>
<?php elseif($tab==='announcements'):?>
<?php $announcementCombined=announcement_combined_items($manifest,$announcementState);?>
<section class="panel"><div class="panel-title-actions"><div><h2>Анонси · порядок</h2><p class="note">Усі анонси в одному списку. «Код легенди» та книги зі статусом «Анонс» перетягуються так само, як окремі анонси.</p></div><form method="post"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="announcements_toggle"><button class="btn"><?=!empty($announcementState['visible'])?'Приховати весь блок':'Показати весь блок'?></button></form></div>
<form method="post" id="announcementOrderForm"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="announcement_order"><input type="hidden" name="order" id="announcementOrderValue"><div class="sort-list" id="announcementSortList">
<?php $annCount=0;foreach($announcementCombined as $i=>$row):$annCount++;$aid=(string)$row['id'];if(($row['kind']??'')==='book'):$b=(array)$row['book'];?>
<div class="sort-item announcement-admin-row" data-id="<?=h($aid)?>"><button type="button" class="drag-handle" aria-label="Перетягнути">⋮⋮</button><?php if(!empty($b['cover_catalog'])):?><img class="sort-cover" src="<?=h((string)$b['cover_catalog'])?>" alt=""><?php else:?><span class="announcement-empty-cover">БЕЗ<br>ОБКЛ.</span><?php endif;?><div class="sort-copy"><b><?=h((string)$b['title'])?></b><span><?=h((string)($b['genre']??'Книга'))?> · книга-анонс</span><span><?=h(book_announcement_reason($b))?></span></div><div class="announcement-admin-actions"><button type="button" class="sort-arrow" data-move="up">↑</button><button type="button" class="sort-arrow" data-move="down">↓</button><a class="mini-btn" href="?tab=book&amp;edit=<?=rawurlencode($aid)?>#edit-book">Редагувати</a><button class="mini-btn" type="submit" form="book-back-<?=h($aid)?>">Повернути в книги</button><button class="mini-btn danger" type="submit" form="book-del-ann-<?=h($aid)?>">Видалити</button><span class="sort-pos"><?=$i+1?></span></div></div>
<?php else:$a=(array)$row['item'];$ah=!empty($a['hidden']);?>
<div class="sort-item announcement-admin-row" data-id="<?=h($aid)?>"><button type="button" class="drag-handle" aria-label="Перетягнути">⋮⋮</button><?php if(!empty($a['cover'])):?><img class="sort-cover" src="<?=h((string)$a['cover'])?>" alt=""><?php else:?><span class="announcement-empty-cover">БЕЗ<br>ОБКЛ.</span><?php endif;?><div class="sort-copy"><b><?=h((string)$a['title'])?></b><span><?=h((string)($a['kicker']??'Анонс'))?></span><?php if($ah):?><span class="status-pill hidden">Приховано</span><?php endif;?></div><div class="announcement-admin-actions"><button type="button" class="sort-arrow" data-move="up">↑</button><button type="button" class="sort-arrow" data-move="down">↓</button><button class="mini-btn" type="submit" form="ann-vis-<?=h($aid)?>"><?=$ah?'Показати':'Приховати'?></button><button class="mini-btn danger" type="submit" form="ann-del-<?=h($aid)?>">Видалити</button><span class="sort-pos"><?=$i+1?></span></div></div>
<?php endif;endforeach;if(!$annCount):?><p class="note">Поки немає жодного анонсу.</p><?php endif;?></div><div class="order-save"><?php if($annCount):?><button class="btn primary">Зберегти порядок</button><?php endif;?><a class="btn" href="/announcements/" target="_blank">Відкрити анонси ↗</a></div></form>
<?php foreach($announcementCombined as $row):$aid=(string)$row['id'];if(($row['kind']??'')==='book'):$ab=(array)$row['book'];?><form id="book-back-<?=h($aid)?>" method="post"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="book_placement"><input type="hidden" name="slug" value="<?=h($aid)?>"><input type="hidden" name="placement" value="books"></form><form id="book-del-ann-<?=h($aid)?>" method="post" onsubmit="return confirm('Видалити анонс-книгу «<?=h(addslashes((string)($ab['title']??$aid)))?>»?');"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="book_delete"><input type="hidden" name="slug" value="<?=h($aid)?>"></form><?php else:$a=(array)$row['item'];?><form id="ann-vis-<?=h($aid)?>" method="post"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="announcement_visibility"><input type="hidden" name="id" value="<?=h($aid)?>"></form><form id="ann-del-<?=h($aid)?>" method="post" onsubmit="return confirm('Видалити анонс «<?=h(addslashes((string)$a['title']))?>»?');"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="announcement_delete"><input type="hidden" name="id" value="<?=h($aid)?>"></form><?php endif;endforeach;?></section>
<script>MaVikPointerSorter({listId:'announcementSortList',formId:'announcementOrderForm',outputId:'announcementOrderValue',key:'id'});</script>
<section class="panel" id="announcement-form"><h2>Додавання анонсів</h2><p class="note">Нові анонси створюються тільки з книг. У розділі «Книги» натисніть «Додати в анонси» або під час додавання книги виберіть розміщення «Анонси». Існуючі старі окремі анонси вище залишаються доступними для керування.</p><a class="btn primary" href="?tab=book">До книг →</a></section>

<?php elseif($tab==='blog'):?>
<?php if(!$blogEdit):?>
<?php if($orphanLiveBlogs):?>
<section class="panel" id="orphan-live-blogs"><div class="panel-title-actions"><div><h2>Є на сайті, але немає в Boss</h2><p class="note">Ці дописи фізично існують у /blog/, але випали з реєстру Boss. Відновлення додає запис у state і не перезаписує публічний текст чи зображення.</p></div><span class="status-pill hidden"><?=count($orphanLiveBlogs)?> до відновлення</span></div>
<form method="post" data-recovery-form onsubmit="const n=this.querySelectorAll('input[type=checkbox]:checked').length;if(!n){alert('Оберіть дописи.');return false;}return confirm('Відновити вибрані live-дописи в Boss: '+n+'? Публічні сторінки не буде перезаписано.');"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="blog_adopt_live_selected"><div class="form-actions" style="margin:10px 0 14px"><button class="mini-btn" type="button" data-recovery-all>Вибрати всі</button><button class="mini-btn" type="button" data-recovery-none>Зняти всі</button><span class="note">Вибрано: <b data-recovery-count><?=count($orphanLiveBlogs)?></b></span><button class="btn primary" type="submit">Відновити вибрані</button></div><div class="blog-admin-list"><?php foreach($orphanLiveBlogs as $orphanSlug=>$orphan):?><label class="blog-admin-row"><input type="checkbox" name="slugs[]" value="<?=h((string)$orphanSlug)?>" checked><?php if(!empty($orphan['image'])):?><img src="<?=h((string)$orphan['image'])?>" alt=""><?php endif;?><span class="blog-admin-copy"><b><?=h((string)$orphan['title'])?></b><span><?=h(ua_date((string)($orphan['date']??'')))?> · /blog/<?=h((string)$orphanSlug)?>/</span></span></label><?php endforeach;?></div></form></section>
<?php endif;?>
<?php
$bossBlog=array_values(array_filter(blog_sorted((array)($manifest['blog']??[])),static fn($p)=>is_array($p)&&empty($p['deleted'])));
$bossBlogTotal=count($bossBlog);
$blogMonthRaw=trim((string)($_GET['blog_month']??''));
$blogMonth=preg_match('/^\d{4}-\d{2}$/',$blogMonthRaw)?$blogMonthRaw:'';
$blogMonthNames=[1=>'Січень',2=>'Лютий',3=>'Березень',4=>'Квітень',5=>'Травень',6=>'Червень',7=>'Липень',8=>'Серпень',9=>'Вересень',10=>'Жовтень',11=>'Листопад',12=>'Грудень'];
$blogMonthCounts=[];
foreach($bossBlog as $bp){$bd=trim((string)($bp['date']??''));if(preg_match('/^(\d{4})-(\d{2})-/',$bd,$bm)){$key=$bm[1].'-'.$bm[2];$blogMonthCounts[$key]=($blogMonthCounts[$key]??0)+1;}}
krsort($blogMonthCounts,SORT_STRING);
$bossBlogFiltered=$blogMonth===''?$bossBlog:array_values(array_filter($bossBlog,static fn($p)=>str_starts_with((string)($p['date']??''),$blogMonth.'-')));
$blogPerPage=10;
$blogPages=max(1,(int)ceil(count($bossBlogFiltered)/$blogPerPage));
$blogPage=max(1,(int)($_GET['blog_page']??1));if($blogPage>$blogPages)$blogPage=$blogPages;
$blogOffset=($blogPage-1)*$blogPerPage;
$bossBlogPage=array_slice($bossBlogFiltered,$blogOffset,$blogPerPage);
$blogFilterCount=count($bossBlogFiltered);
$blogPageUrl=static function(int $page)use($blogMonth):string{$q=['tab'=>'blog'];if($blogMonth!=='')$q['blog_month']=$blogMonth;if($page>1)$q['blog_page']=$page;return '?'.http_build_query($q);};
?>
<section class="panel"><div class="panel-title-actions"><div><h2>Записи блогу</h2><span class="help">Відсутні в реєстрі live-дописи не підхоплюються автоматично. Boss показує їх окремо й відновлює лише після натискання «Відновити в Boss». Публічні файли допису при цьому не переписуються.</span></div><form method="post"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="blog_seo_rebuild"><button class="btn" type="submit">Перебудувати SEO всіх дописів</button></form></div>
<div class="blog-admin-tools"><div class="blog-admin-counts"><span class="status-pill">Усього: <?=$bossBlogTotal?> дописів</span><?php if($blogMonth!==''):?><span class="status-pill">За вибрану дату: <?=$blogFilterCount?></span><?php endif;?></div><form method="get"><input type="hidden" name="tab" value="blog"><label>Дата публікації<select name="blog_month" onchange="this.form.submit()"><option value="">Усі дати</option><?php foreach($blogMonthCounts as $monthKey=>$monthCount):$parts=explode('-',$monthKey);$mi=(int)($parts[1]??0);?><option value="<?=h($monthKey)?>" <?=$blogMonth===$monthKey?'selected':''?>><?=h(($blogMonthNames[$mi]??$monthKey).' '.($parts[0]??''))?> · <?=$monthCount?></option><?php endforeach;?></select></label><?php if($blogMonth!==''):?><a class="mini-btn" href="?tab=blog">Скинути</a><?php endif;?></form></div>
<div class="blog-admin-list">
<?php foreach($bossBlogPage as $p):$pSlug=(string)$p['slug'];$pHidden=!empty($p['hidden']);?>
<div class="blog-admin-row"><img src="<?=h((string)($p['image']??''))?>" alt=""><div class="blog-admin-copy"><b><?=h((string)$p['title'])?></b><span><?=h(ua_date_time((string)$p['date'],(string)($p['published_at']??'')))?> · <?=h((string)$p['category'])?> · <?=max(1,(int)($p['reading_minutes']??1))?> хв</span><?php if($pHidden):?><span class="status-pill hidden">Приховано</span><?php endif;?></div><div class="content-admin-actions"><a class="mini-btn" href="?tab=blog&amp;edit=<?=rawurlencode($pSlug)?>">Редагувати</a><form method="post"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="blog_visibility"><input type="hidden" name="slug" value="<?=h($pSlug)?>"><button class="mini-btn" type="submit"><?=$pHidden?'Показати':'Приховати'?></button></form><form method="post" onsubmit="return confirm('Видалити допис «<?=h(addslashes((string)$p['title']))?>»? Цю дію не можна скасувати.');"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="blog_delete"><input type="hidden" name="slug" value="<?=h($pSlug)?>"><button class="mini-btn danger" type="submit">Видалити</button></form></div></div>
<?php endforeach;if(!$bossBlogPage):?><p class="note"><?=$blogMonth!==''?'За цю дату дописів немає.':'Поки немає дописів.'?></p><?php endif;?></div>
<?php if($blogPages>1):?><nav class="blog-admin-pager" aria-label="Сторінки списку блогів"><?php if($blogPage>1):?><a class="mini-btn" href="<?=h($blogPageUrl($blogPage-1))?>">←</a><?php endif;?><?php for($bp=max(1,$blogPage-2);$bp<=min($blogPages,$blogPage+2);$bp++):?><a class="mini-btn <?=$bp===$blogPage?'active':''?>" href="<?=h($blogPageUrl($bp))?>"><?=$bp?></a><?php endfor;?><?php if($blogPage<$blogPages):?><a class="mini-btn" href="<?=h($blogPageUrl($blogPage+1))?>">→</a><?php endif;?><span class="page-note"><?=$blogPage?> / <?=$blogPages?></span></nav><?php endif;?>
</section>
<?php endif;?>
<?php if($blogEdit):?>
<section class="panel"><div class="panel-title-actions"><h2>Редагувати допис</h2><div style="display:flex;gap:8px;flex-wrap:wrap"><a class="btn" href="?tab=blog">← До списку</a><a class="btn" href="/blog/<?=h((string)$blogEdit['slug'])?>/" target="_blank">Відкрити ↗</a></div></div><?=blog_seo_status_html($root,(array)$blogEdit)?><form method="post" enctype="multipart/form-data" class="blog-editor-form" data-preserve-form="blog-edit" data-boss-validate><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="blog_edit"><input type="hidden" name="slug" value="<?=h((string)$blogEdit['slug'])?>"><label>Заголовок<input name="title" required maxlength="180" value="<?=h((string)$blogEdit['title'])?>"></label><div class="grid"><label>Категорія<input name="category" required value="<?=h((string)$blogEdit['category'])?>"></label><label>Дата<input type="date" name="date" value="<?=h((string)$blogEdit['date'])?>" required></label><label>Час<input type="time" name="published_time" value="<?=h(blog_publication_time_value((array)$blogEdit))?>" required></label></div><label>Slug <span class="help">Адресу не змінюємо, щоб не ламати зовнішні посилання й SEO.</span><input class="readonly-slug" value="<?=h((string)$blogEdit['slug'])?>" readonly></label><label>Короткий опис<input name="excerpt" required maxlength="400" value="<?=h((string)$blogEdit['excerpt'])?>"></label><div class="seo-fields"><strong>SEO-профіль публікації</strong><label>Основний пошуковий запит <span class="help">Один намір на одну статтю.</span><input name="primary_query" required maxlength="180" value="<?=h((string)($blogEdit['primary_query']??$blogEdit['title']))?>"></label><label>SEO title <span class="help">Бажано близько до основного запиту; це &lt;title&gt; сторінки.</span><input name="seo_title" required maxlength="180" value="<?=h((string)($blogEdit['seo_title']??blog_default_seo_title((string)$blogEdit['title'])))?>"></label><label>Meta description<textarea name="meta_description" required maxlength="400" rows="3"><?=h((string)($blogEdit['meta_description']??$blogEdit['excerpt']))?></textarea></label><div class="grid"><label>SEO-кластер<select name="seo_cluster"><?php foreach(blog_cluster_catalog() as $ck=>$cv):?><option value="<?=h($ck)?>" <?=blog_cluster_value((string)($blogEdit['seo_cluster']??'auto'))===$ck?'selected':''?>><?=h((string)$cv['label'])?></option><?php endforeach;?></select></label><label>ALT головної ілюстрації<input name="image_alt" required maxlength="240" value="<?=h((string)($blogEdit['image_alt']??$blogEdit['title']))?>"></label></div></div><label>Теги <span class="help">Щонайменше один тег. Розділяйте комами.</span><input name="tags" required value="<?=h(implode(', ',(array)($blogEdit['tags']??[])))?>"></label><label>Текст</label><input type="hidden" name="body_html" class="blog-body-html" id="blogBodyHtml1"><div class="editor-shell" data-mavik-editor data-editor-output="#blogBodyHtml1" data-required-editor="40"><div class="editor-toolbar" role="toolbar" aria-label="Форматування тексту"><?=mavik_editor_toolbar_html()?></div><div class="rich-editor" contenteditable="true" spellcheck="true"><?=(string)($blogEdit['body_html']??'')?></div><textarea class="html-code-editor" spellcheck="false" aria-label="HTML-код допису"></textarea></div><div class="editor-note">Редактор має власну прокрутку. Режими «Візуальний» і «HTML» можна перемикати без втрати тексту. Під час збереження Boss очищає небезпечну або випадкову розмітку.</div><div class="media-field"><span class="field-label">Ілюстрація <span class="help">Формат блогу — 3:2, рекомендовано 1200×800 px. Нове завантажене зображення Boss автоматично кадрує по центру до 3:2; великі файли оптимізуються до 1200×800. Оригінал на вашому пристрої не змінюється.</span></span><?php if(!empty($blogEdit['image'])):?><div class="current-image"><img src="<?=h((string)$blogEdit['image'])?>" alt="Поточна ілюстрація"><span class="note">Поточне фото цього допису. Якщо нічого не змінювати нижче, воно залишиться.</span></div><?php endif;?><div class="media-grid"><?php foreach($blogMedia as $mi):$checked=media_file_from_url('blog',(string)$blogEdit['image'])===(string)$mi['file'];?><label class="media-choice"><input type="radio" name="image_library" value="<?=h((string)$mi['file'])?>" <?=$checked?'checked':''?>><span class="media-card"><img src="<?=h((string)$mi['url'])?>" alt=""><b><?=h((string)$mi['file'])?></b></span></label><?php endforeach;?></div><div class="media-upload"><input type="file" name="image" accept="image/jpeg,image/png" aria-label="Завантажити нову ілюстрацію"></div><span class="help">Якщо вибрати файл тут, він матиме пріоритет над вибраним з медіатеки. Ім’я файла буде автоматично приведене до безпечної латиниці.</span></div><div class="form-actions" style="margin-top:18px"><button class="btn primary">Зберегти зміни</button><a class="btn" href="?tab=blog">Скасувати</a></div></form></section>
<?php endif;?>
<?php elseif($tab==='blog_add'):?>
<section class="panel"><h2>Новий допис у блог</h2><form method="post" enctype="multipart/form-data" class="blog-editor-form" data-preserve-form="blog-add" data-boss-validate><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="blog"><label>Заголовок<input name="title" required maxlength="180"></label><div class="grid"><label>Категорія<input name="category" required placeholder="Література"></label><label>Дата<input type="date" name="date" value="<?=date('Y-m-d')?>" required></label><label>Час<input type="time" name="published_time" value="<?=date('H:i')?>" required></label></div><label>Slug <span class="help">Можна не заповнювати — створиться автоматично.</span><input name="slug" placeholder="nazva-statti"></label><label>Короткий опис<input name="excerpt" required maxlength="400"></label><div class="seo-fields"><strong>SEO-профіль публікації</strong><label>Основний пошуковий запит <span class="help">Один головний пошуковий намір на статтю.</span><input name="primary_query" required maxlength="180" placeholder="що почитати українською"></label><label>SEO title <span class="help">Близьке формулювання головного запиту; стане &lt;title&gt; сторінки.</span><input name="seo_title" required maxlength="180" placeholder="Що почитати українською — ... | MaVik"></label><label>Meta description<textarea name="meta_description" required maxlength="400" rows="3" placeholder="Коротка відповідь на пошуковий намір і причина відкрити матеріал."></textarea></label><div class="grid"><label>SEO-кластер<select name="seo_cluster"><?php foreach(blog_cluster_catalog() as $ck=>$cv):?><option value="<?=h($ck)?>" <?=$ck==='auto'?'selected':''?>><?=h((string)$cv['label'])?></option><?php endforeach;?></select></label><label>ALT головної ілюстрації<input name="image_alt" required maxlength="240" placeholder="Опис зображення у контексті теми статті"></label></div></div><label>Теги <span class="help">Щонайменше один тег. Розділяйте комами.</span><input name="tags" required placeholder="література, книги, читання"></label><label>Текст</label><input type="hidden" name="body_html" class="blog-body-html" id="blogBodyHtml2"><div class="editor-shell" data-mavik-editor data-editor-output="#blogBodyHtml2" data-required-editor="40"><div class="editor-toolbar" role="toolbar" aria-label="Форматування тексту"><?=mavik_editor_toolbar_html()?></div><div class="rich-editor" contenteditable="true" spellcheck="true"><p><br></p></div><textarea class="html-code-editor" spellcheck="false" aria-label="HTML-код допису"></textarea></div><div class="editor-note">Редактор має власну прокрутку. Режими «Візуальний» і «HTML» можна перемикати без втрати тексту.</div><div class="media-field" data-required-media="image"><span class="field-label">Ілюстрація <span class="help">Останній блок форми. Формат блогу — 3:2, рекомендовано 1200×800 px. Нове зображення Boss автоматично кадрує по центру до 3:2.</span></span><div class="media-grid"><?php foreach($blogMedia as $mi):?><label class="media-choice"><input type="radio" name="image_library" value="<?=h((string)$mi['file'])?>"><span class="media-card"><img src="<?=h((string)$mi['url'])?>" alt=""><b><?=h((string)$mi['file'])?></b></span></label><?php endforeach;?></div><div class="media-upload"><input type="file" name="image" accept="image/jpeg,image/png" aria-label="Завантажити нову ілюстрацію JPG або PNG"></div><span class="help">Оберіть готове фото або завантажте нове. Ім’я нового файла буде автоматично приведене до безпечної латиниці.</span></div><button class="btn primary" style="margin-top:18px">Опублікувати</button></form></section>

<?php elseif($tab==='book'):?>
<?php if($orphanLiveBooks):?>
<section class="panel" id="orphan-live-books"><div class="panel-title-actions"><div><h2>Є на сайті, але немає в Boss</h2><p class="note">Ці книги фізично існують на сервері, але випали з реєстру. Відновлення додає лише запис у state: сторінка, читанка, EPUB та обкладинка не видаляються і не завантажуються заново.</p></div><span class="status-pill hidden"><?=count($orphanLiveBooks)?> до відновлення</span></div>
<form method="post" data-recovery-form onsubmit="const n=this.querySelectorAll('input[type=checkbox]:checked').length;if(!n){alert('Оберіть книги.');return false;}return confirm('Відновити вибрані live-книги в Boss: '+n+'? Існуючі файли не буде видалено.');"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="book_adopt_live_selected"><div class="form-actions" style="margin:10px 0 14px"><button class="mini-btn" type="button" data-recovery-all>Вибрати всі</button><button class="mini-btn" type="button" data-recovery-none>Зняти всі</button><span class="note">Вибрано: <b data-recovery-count><?=count($orphanLiveBooks)?></b></span><button class="btn primary" type="submit">Відновити вибрані</button></div><?php foreach($orphanLiveBooks as $orphanSlug=>$orphan):?><label class="sort-item book-admin-row"><input type="checkbox" name="slugs[]" value="<?=h((string)$orphanSlug)?>" checked><?php if(!empty($orphan['cover_catalog'])):?><img class="sort-cover" src="<?=h(catalog_cover_admin_url((string)$orphan['cover_catalog']))?>" alt=""><?php endif;?><span class="sort-copy"><b><?=h((string)$orphan['title'])?></b><span>/books/<?=h((string)$orphanSlug)?>/ · <?=h((string)($orphan['genre']??'книга'))?></span><span>Live-файли знайдено<?=is_file($root.'/books/'.$orphanSlug.'/read/index.html')?' · читанка є':''?><?=is_file($root.'/downloads/'.$orphanSlug.'.epub')?' · EPUB є':''?></span></span></label><?php endforeach;?></form>
</section>
<?php endif;?>
<section class="panel"><div class="panel-title-actions"><div><h2>Книги</h2><p class="note"><b>Порядок книг:</b> перетягніть прямо цей перелік. Другого списку сортування немає.</p></div><button class="btn primary" type="submit" form="bookOrderForm">Зберегти порядок</button></div>
<form method="post" id="bookOrderForm"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="book_order"><input type="hidden" name="order" id="bookOrderValue" value="[]"><div class="sort-list blog-admin-list" id="bookSortList"><?php foreach($orderedCatalog as $i=>$x):$slug=(string)$x['slug'];$mb=null;foreach((array)($manifest['books']??[]) as $candidate)if(is_array($candidate)&&($candidate['slug']??'')===$slug){$mb=$candidate;break;}if(!$mb)continue;$bHidden=!empty($mb['hidden']);$isAnnouncement=(string)($mb['placement']??'books')==='announcements';$isDirect=(string)($mb['placement']??'books')==='direct';?><div class="sort-item book-admin-row" data-slug="<?=h($slug)?>"><button class="drag-handle" type="button" aria-label="Перетягнути">⋮⋮</button><?php if($x['cover']):?><img class="sort-cover" src="<?=h(catalog_cover_admin_url($x['cover']))?>" alt=""><?php endif;?><div class="sort-copy"><b><?=h((string)$x['title'])?></b><span><?=h((string)$x['type'])?></span><?php if($isDirect):?><span class="status-pill hidden">Прихована в каталозі · пряме посилання · <?=h((string)($mb['language']??'uk-UA'))?></span><?php else:?><?php if($bHidden):?><span class="status-pill hidden">Приховано</span><?php endif;?><?php if($isAnnouncement):?><span class="status-pill">Анонс<?=!empty($mb['without_text'])?' · без тексту':''?></span><?php else:?><?php $isFinal=(string)($mb['publication_mode']??'final')==='final';$epubOk=is_file($root.'/downloads/'.$slug.'.epub');?><span class="status-pill <?=($isFinal&&!$epubOk)?'hidden':''?>"><?=$isFinal?($epubOk?'Завершена · EPUB OK':'Завершена · EPUB бракує'):'Бета · без EPUB'?></span><?php endif;?><?php endif;?></div><div class="content-admin-actions"><button type="button" class="sort-arrow" data-move="up">↑</button><button type="button" class="sort-arrow" data-move="down">↓</button><a class="mini-btn" href="?tab=book&amp;edit=<?=rawurlencode($slug)?>#edit-book">Редагувати</a><?php if(!$isDirect):?><button class="mini-btn" type="submit" form="book-place-<?=h($slug)?>"><?=$isAnnouncement?'До бібліотеки':'Додати в анонси'?></button><button class="mini-btn" type="submit" form="book-vis-<?=h($slug)?>"><?=$bHidden?'Показати':'Приховати'?></button><?php endif;?><button class="mini-btn danger" type="submit" form="book-del-<?=h($slug)?>">Видалити</button><span class="sort-pos"><?=$i+1?></span></div></div><?php endforeach;?></div><div class="order-save"><button class="btn primary">Зберегти порядок</button><span class="note"><?=count($orderedCatalog)?> записів у Boss: бібліотека, анонси та книги за прямим посиланням.</span></div></form><?php foreach($orderedCatalog as $x):$slug=(string)$x['slug'];$mb=null;foreach((array)($manifest['books']??[]) as $candidate)if(is_array($candidate)&&($candidate['slug']??'')===$slug){$mb=$candidate;break;}$isAnnouncement=$mb&&(string)($mb['placement']??'books')==='announcements';$isDirect=$mb&&(string)($mb['placement']??'books')==='direct';?><?php if(!$isDirect):?><form id="book-place-<?=h($slug)?>" method="post"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="book_placement"><input type="hidden" name="slug" value="<?=h($slug)?>"><input type="hidden" name="placement" value="<?=$isAnnouncement?'books':'announcements'?>"></form><form id="book-vis-<?=h($slug)?>" method="post"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="book_visibility"><input type="hidden" name="slug" value="<?=h($slug)?>"></form><?php endif;?><form id="book-del-<?=h($slug)?>" method="post" onsubmit="return confirm('Видалити книгу «<?=h(addslashes((string)$x['title']))?>»?\n\nБуде видалено сторінку книги, читанку та EPUB. Обкладинка в медіатеці залишиться.');"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="book_delete"><input type="hidden" name="slug" value="<?=h($slug)?>"></form><?php endforeach;?></section><script>MaVikPointerSorter({listId:'bookSortList',formId:'bookOrderForm',outputId:'bookOrderValue',key:'slug'});</script>
<?php if($bookEdit):$editCover=media_file_from_url('covers',(string)($bookEdit['cover_catalog']??''));?>
<section class="panel book-edit-panel" id="edit-book"><div class="panel-title-actions"><h2>Редагувати книгу</h2><div style="display:flex;gap:8px;flex-wrap:wrap"><a class="btn" href="?tab=book">Закрити</a><a class="btn" href="/books/<?=h((string)$bookEdit['slug'])?>/" target="_blank">Відкрити ↗</a><button class="btn danger" type="submit" form="book-edit-delete">Видалити книгу</button></div></div><form id="book-edit-delete" method="post" onsubmit="return confirm('Видалити книгу «<?=h(addslashes((string)$bookEdit['title']))?>»?\n\nБуде видалено сторінку книги, читанку та EPUB. Обкладинка в медіатеці залишиться.');"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="book_delete"><input type="hidden" name="slug" value="<?=h((string)$bookEdit['slug'])?>"></form><div class="book-edit-current"><?php if(!empty($bookEdit['cover_catalog'])):?><img src="<?=h((string)$bookEdit['cover_catalog'])?>" alt=""><?php endif;?><div><b><?=h((string)$bookEdit['title'])?></b><div class="help">Slug: <?=h((string)$bookEdit['slug'])?> · адресу не змінюємо.</div></div></div><form method="post" enctype="multipart/form-data" data-preserve-form="book-edit" data-boss-validate><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="book_edit"><input type="hidden" name="slug" value="<?=h((string)$bookEdit['slug'])?>"><label>Назва<input name="title" required value="<?=h((string)$bookEdit['title'])?>"></label><div class="grid"><label>Жанр / підзаголовок<input name="genre" required value="<?=h((string)($bookEdit['genre']??''))?>"></label><label>Дата<input type="date" name="date" value="<?=h((string)($bookEdit['date']??date('Y-m-d')))?>" required></label></div><div class="grid"><label>Статус книги<div class="genres"><label><input type="radio" name="publication_mode" value="final" <?=($bookEdit['publication_mode']??'final')==='final'?'checked':''?>><span>Завершена · створити EPUB</span></label><label><input type="radio" name="publication_mode" value="beta" <?=($bookEdit['publication_mode']??'final')==='beta'?'checked':''?>><span>Бета · без EPUB</span></label><label><input type="checkbox" name="without_text" value="1" <?=!empty($bookEdit['without_text'])?'checked':''?>><span>Без тексту · тільки анонс</span></label></div><span class="help">«Без тексту» працює лише для розміщення «Анонси».</span></label><label>Slug<input class="readonly-slug" value="<?=h((string)$bookEdit['slug'])?>" readonly></label></div><label>Розміщення<div class="genres"><label><input type="radio" name="placement" value="books" <?=($bookEdit['placement']??'books')==='books'?'checked':''?>><span>Бібліотека</span></label><label><input type="radio" name="placement" value="announcements" <?=($bookEdit['placement']??'books')==='announcements'?'checked':''?>><span>Анонси</span></label><label><input type="radio" name="placement" value="direct" <?=($bookEdit['placement']??'books')==='direct'?'checked':''?>><span>За прямим посиланням · індексується</span></label></div></label><label>Мова книги <span class="help">Сайт український. pl-PL використовується лише для окремої польської книги за прямим посиланням.</span><input name="language" list="bookLanguageCodes" value="<?=h((string)($bookEdit['language']??'uk-UA'))?>" placeholder="uk-UA"></label><div class="genres"><label><input type="checkbox" name="is_new" value="1" <?=!empty($bookEdit['is_new'])?'checked':''?>><span>Рубрика «Новинки»</span></label><label><input type="checkbox" name="show_continuation" value="1" <?=!empty($bookEdit['show_continuation'])?'checked':''?>><span>«Далі буде…»</span></label></div><label>Короткий опис<input name="description" required maxlength="500" value="<?=h((string)($bookEdit['description']??''))?>"></label><label>Опис для анонсу<input name="announcement_reason" maxlength="500" value="<?=h(book_announcement_reason((array)$bookEdit))?>"><span class="help">Використовується, коли книга в «Анонсах». Якщо порожньо — береться короткий опис.</span></label><label>Текст анонсу <span class="help">Необов’язково. Тут можна нормально розповісти про майбутню книгу; текст показується на сторінці анонсу під обкладинкою та коротким описом.</span></label><input type="hidden" name="announcement_body_html" id="bookAnnouncementBodyEdit"><div class="editor-shell" data-mavik-editor data-editor-output="#bookAnnouncementBodyEdit"><div class="editor-toolbar" role="toolbar" aria-label="Форматування тексту анонсу"><?=mavik_editor_toolbar_html()?></div><div class="rich-editor book-rich-editor announcement-rich-editor" contenteditable="true" spellcheck="true"><?=(string)($bookEdit['announcement_body_html']??'')?></div><textarea class="html-code-editor announcement-code-editor" spellcheck="false" aria-label="HTML-код анонсу"></textarea></div><div class="editor-note">Це текст саме анонсу. Він не створює читанку книги.</div><label>Новий жанр <span class="help">Необов’язково. Після збереження він автоматично залишиться у постійному переліку.</span><input name="new_genre" maxlength="80" placeholder="Наприклад: соціальна проза"></label><label>Жанрові фільтри <span class="help">Необов’язково. Якщо нічого не вибрати, Boss автоматично створить фільтр із поля «Жанр / підзаголовок».</span><div class="genres"><?php foreach($genres as $k=>$v):?><label><input type="checkbox" name="genre_keys[]" value="<?=h($k)?>" <?=in_array($k,(array)($bookEdit['genre_keys']??[]),true)?'checked':''?>><span><?=h($v)?></span></label><?php endforeach;?></div></label><div class="platform-link-editor" data-platform-editor><div class="panel-title-actions" style="margin:0"><div><b>Посилання на платформи</b><span class="help">Зберігаються разом із книгою та не залежать від косметичних релізів.</span></div><button class="mini-btn" type="button" data-platform-add>+ Додати платформу</button></div><div data-platform-rows><?=book_platform_rows_html((array)($bookEdit['platform_links']??[]))?></div></div><label>Текст книги <span class="help">Той самий редактор, що в блозі й пошті. Якщо нижче завантажити DOCX/TXT, файл має пріоритет і повністю замінить текст із редактора.</span></label><input type="hidden" name="book_body_html" id="bookBodyHtml"><div class="editor-shell" data-mavik-editor data-editor-output="#bookBodyHtml"><div class="editor-toolbar" role="toolbar" aria-label="Форматування тексту"><?=mavik_editor_toolbar_html()?></div><div class="rich-editor book-rich-editor" contenteditable="true" spellcheck="true"><?=$bookEditReaderBody?></div><textarea class="html-code-editor" spellcheck="false" aria-label="HTML-код книги"></textarea></div><div class="editor-note">Поле можна розтягувати по висоті. Після збереження Boss оновить читанку, текстову версію та EPUB завершеної книги.</div><label>Новий рукопис DOCX або TXT <span class="help">Необов’язково. Якщо не завантажувати — текст книги лишиться без змін.</span><input type="file" name="manuscript" accept=".docx,.txt,text/plain,application/vnd.openxmlformats-officedocument.wordprocessingml.document"></label><div class="media-field"><span class="field-label">Обкладинка <span class="help">Поточна вже збережена. Вибирайте іншу лише якщо хочете замінити.</span></span><div class="media-grid"><?php foreach($coverMedia as $mi):$checked=$editCover===(string)$mi['file'];?><label class="media-choice"><input type="radio" name="cover_library" value="<?=h((string)$mi['file'])?>" <?=$checked?'checked':''?>><span class="media-card cover"><img src="<?=h((string)$mi['url'])?>" alt=""><b><?=h((string)$mi['file'])?></b></span></label><?php endforeach;?></div><div class="media-upload"><input type="file" name="cover" accept="image/jpeg,image/png"></div></div><button class="btn primary">Зберегти книгу</button></form></section>
<?php endif;?>
<?php elseif($tab==='book_add'):?>
<section class="panel"><h2>Додати нову книгу</h2><form method="post" class="grid" style="grid-template-columns:minmax(0,1fr) auto;align-items:end;margin-bottom:18px"><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="genre_add"><label style="margin:0">Додати жанр до постійного переліку<input name="genre_label" maxlength="80" required placeholder="Наприклад: соціальна проза"><span class="help">Після додавання жанр одразу з’явиться серед фільтрів нижче й збережеться для наступних книг.</span></label><button class="btn" type="submit">+ Додати жанр</button></form><form method="post" enctype="multipart/form-data" data-preserve-form="book-add" data-boss-validate><input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="action" value="book"><label>Назва<input name="title" required></label><div class="grid"><label>Жанр / підзаголовок<input name="genre" required placeholder="психологічний трилер"></label><label>Дата<input type="date" name="date" value="<?=date('Y-m-d')?>" required></label></div><div class="grid"><label>Статус книги<div class="genres"><label><input type="radio" name="publication_mode" value="final" checked><span>Завершена · створити EPUB</span></label><label><input type="radio" name="publication_mode" value="beta"><span>Бета · без EPUB</span></label><label><input type="checkbox" name="without_text" value="1"><span>Без тексту · тільки анонс</span></label></div></label><label style="align-self:end"><span class="help">Завершена книга одразу отримує EPUB. Бета-книга лишається без EPUB до зміни статусу.</span></label></div><label>Розміщення<div class="genres"><label><input type="radio" name="placement" value="books" checked><span>Бібліотека</span></label><label><input type="radio" name="placement" value="announcements"><span>Анонси</span></label><label><input type="radio" name="placement" value="direct"><span>За прямим посиланням · індексується</span></label></div></label><p class="help" style="margin-top:-8px">«Без тексту» працює лише з розміщенням «Анонси»: Boss створить сторінку анонсу без читанки та EPUB.</p><label>Мова книги <span class="help">Сайт український. pl-PL — лише для окремої книги за прямим посиланням.</span><input name="language" list="bookLanguageCodes" value="uk-UA" placeholder="uk-UA"></label><div class="genres"><label><input type="checkbox" name="is_new" value="1"><span>Додати до рубрики «Новинки»</span></label><label><input type="checkbox" name="show_continuation" value="1"><span>Показати в кінці «Далі буде…»</span></label></div><label>Slug <span class="help">Можна не заповнювати.</span><input name="slug" placeholder="nazva-knyhy"></label><label>Короткий опис<input name="description" required maxlength="500"></label><label>Опис для анонсу <span class="help">Необов’язково. Якщо порожньо — використаємо короткий опис.</span><input name="announcement_reason" maxlength="500"></label><label>Текст анонсу <span class="help">Необов’язково. Напишіть тут те, що читач має побачити після відкриття анонсу.</span></label><input type="hidden" name="announcement_body_html" id="bookAnnouncementBodyNew"><div class="editor-shell" data-mavik-editor data-editor-output="#bookAnnouncementBodyNew"><div class="editor-toolbar" role="toolbar" aria-label="Форматування тексту анонсу"><?=mavik_editor_toolbar_html()?></div><div class="rich-editor book-rich-editor announcement-rich-editor" contenteditable="true" spellcheck="true"><p><br></p></div><textarea class="html-code-editor announcement-code-editor" spellcheck="false" aria-label="HTML-код анонсу"></textarea></div><div class="editor-note">Цей текст буде на landing-сторінці анонсу; це не повний текст книги.</div><label>Новий жанр <span class="help">Необов’язково. Після збереження він автоматично залишиться у постійному переліку.</span><input name="new_genre" maxlength="80" placeholder="Наприклад: соціальна проза"></label><label>Жанрові фільтри <span class="help">Необов’язково. Якщо нічого не вибрати, Boss автоматично створить фільтр із поля «Жанр / підзаголовок».</span><div class="genres"><?php foreach($genres as $k=>$v):?><label><input type="checkbox" name="genre_keys[]" value="<?=h($k)?>"><span><?=h($v)?></span></label><?php endforeach;?></div></label><div class="platform-link-editor" data-platform-editor><div class="panel-title-actions" style="margin:0"><div><b>Посилання на платформи</b><span class="help">Необов’язково. Додавайте Аркуш, NovelKlo чи будь-яку іншу сторінку твору.</span></div><button class="mini-btn" type="button" data-platform-add>+ Додати платформу</button></div><div data-platform-rows><?=book_platform_rows_html([])?></div></div><label>Текст книги <span class="help">Можна написати або вставити текст тут. DOCX/TXT нижче має пріоритет, якщо його вибрано.</span></label><input type="hidden" name="book_body_html" id="bookNewBodyHtml"><div class="editor-shell" data-mavik-editor data-editor-output="#bookNewBodyHtml"><div class="editor-toolbar" role="toolbar" aria-label="Форматування тексту"><?=mavik_editor_toolbar_html()?></div><div class="rich-editor book-rich-editor" contenteditable="true" spellcheck="true"><p><br></p></div><textarea class="html-code-editor" spellcheck="false" aria-label="HTML-код книги"></textarea></div><div class="editor-note">Поле можна розтягувати по висоті.</div><label>Рукопис DOCX або TXT <span class="help">Необов’язково, якщо текст уже є в редакторі.</span><input type="file" name="manuscript" accept=".docx,.txt,text/plain,application/vnd.openxmlformats-officedocument.wordprocessingml.document"></label><p class="note">Для звичайної книги Boss створить читанку, режим озвучення та EPUB завершеної книги. Якщо вибрано «Анонси» + «Без тексту», створюється тільки відкрита landing-сторінка анонсу.</p><div class="media-field" data-required-media="cover"><span class="field-label">Обкладинка <span class="help">Оберіть готову з /images/covers/ або завантажте нову.</span></span><div class="media-grid"><?php foreach($coverMedia as $mi):?><label class="media-choice"><input type="radio" name="cover_library" value="<?=h((string)$mi['file'])?>"><span class="media-card cover"><img src="<?=h((string)$mi['url'])?>" alt=""><b><?=h((string)$mi['file'])?></b></span></label><?php endforeach;?></div><div class="media-upload"><input type="file" name="cover" accept="image/jpeg,image/png" aria-label="Завантажити нову обкладинку JPG або PNG без прозорості"></div><span class="help">Новий файл автоматично буде додано до медіатеки обкладинок і отримає безпечне ім’я латиницею.</span></div><button class="btn primary">Опублікувати книгу</button></form></section>
<?php endif;?><datalist id="bookLanguageCodes"><option value="uk-UA"><option value="pl-PL"></datalist></main><script>
(function(){
  const link=document.getElementById('bossMailNav'),badge=document.getElementById('bossMailBeacon');
  if(!link||!badge)return;
  async function refreshBossMailBeacon(){try{const r=await fetch('/boss/?mail_unread=1',{credentials:'same-origin',cache:'no-store',headers:{'Accept':'application/json'}});if(!r.ok)return;const j=await r.json();if(!j||!j.ok)return;const n=Math.max(0,Number(j.count)||0);if(n>0){badge.textContent=n>99?'99+':String(n);badge.setAttribute('aria-label','Непрочитаних повідомлень: '+n);link.classList.add('has-mail');link.title='Пошта · нових: '+n;}else{badge.textContent='';badge.setAttribute('aria-label','');link.classList.remove('has-mail');link.title='Пошта';}}catch(e){}}
  window.refreshBossMailBeacon=refreshBossMailBeacon;refreshBossMailBeacon();const timer=setInterval(()=>{if(!document.hidden)refreshBossMailBeacon()},60000);document.addEventListener('visibilitychange',()=>{if(!document.hidden)refreshBossMailBeacon()});window.addEventListener('pagehide',()=>clearInterval(timer),{once:true});
})();
</script><script>(()=>{document.querySelectorAll('[data-recovery-form]').forEach(form=>{const boxes=[...form.querySelectorAll('input[name="slugs[]"]')],count=form.querySelector('[data-recovery-count]'),update=()=>{if(count)count.textContent=String(boxes.filter(x=>x.checked).length)};form.querySelector('[data-recovery-all]')?.addEventListener('click',()=>{boxes.forEach(x=>x.checked=true);update()});form.querySelector('[data-recovery-none]')?.addEventListener('click',()=>{boxes.forEach(x=>x.checked=false);update()});boxes.forEach(x=>x.addEventListener('change',update));update()})})();</script><script>(()=>{const d=document.getElementById('mediaPreviewDialog'),img=document.getElementById('mediaPreviewImage'),name=document.getElementById('mediaPreviewName'),close=document.getElementById('mediaPreviewClose');if(!d||!img)return;document.querySelectorAll('[data-media-preview]').forEach(b=>b.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();img.src=b.dataset.mediaPreview||'';img.alt=b.dataset.mediaName||'';if(name)name.textContent=b.dataset.mediaName||'Зображення';if(typeof d.showModal==='function')d.showModal();else d.setAttribute('open','')}));const shut=()=>{if(typeof d.close==='function'&&d.open)d.close();else d.removeAttribute('open');img.src=''};close?.addEventListener('click',shut);d.addEventListener('click',e=>{if(e.target===d)shut()});d.addEventListener('cancel',()=>{img.src=''})})();</script><script>(()=>{document.querySelectorAll('[data-platform-editor]').forEach(ed=>{const rows=ed.querySelector('[data-platform-rows]'),add=ed.querySelector('[data-platform-add]');if(!rows||!add)return;const row=()=>{const d=document.createElement('div');d.className='platform-link-row';d.innerHTML='<label>Платформа<input name="platform_label[]" maxlength="80" placeholder="Наприклад: Аркуш"></label><label>Посилання<input type="url" name="platform_url[]" placeholder="https://..."></label><button class="mini-btn danger platform-remove" type="button" aria-label="Видалити посилання">×</button>';return d};add.addEventListener('click',()=>rows.appendChild(row()));rows.addEventListener('click',e=>{const b=e.target.closest('.platform-remove');if(!b)return;const r=b.closest('.platform-link-row');if(r)r.remove()})})})();</script>
<script>
(()=>{
  const plain=html=>{const d=document.createElement('div');d.innerHTML=html||'';return (d.textContent||'').replace(/\s+/g,' ').trim()};
  const clear=form=>{form.querySelectorAll('.field-invalid').forEach(x=>x.classList.remove('field-invalid'));form.querySelectorAll('.field-error,.form-error-summary').forEach(x=>x.remove())};
  const mark=(el,msg)=>{const box=el.closest('label,.media-field,.editor-shell')||el;box.classList.add('field-invalid');if(!box.querySelector(':scope > .field-error')){const e=document.createElement('span');e.className='field-error';e.textContent=msg;box.appendChild(e)}return box};
  const validate=form=>{clear(form);form.querySelectorAll('[data-mavik-editor]').forEach(x=>x._mavikSync?.());let first=null;for(const el of form.querySelectorAll('input,textarea,select')){if(el.disabled||el.type==='hidden'||el.type==='file')continue;if(!el.checkValidity()){first=first||mark(el,el.validationMessage||'Перевірте це поле.')}}for(const shell of form.querySelectorAll('[data-required-editor]')){const outSel=shell.dataset.editorOutput,out=outSel?document.querySelector(outSel):null,min=Math.max(1,Number(shell.dataset.requiredEditor)||1);if(plain(out?.value||shell.querySelector('.rich-editor')?.innerHTML||'').length<min)first=first||mark(shell,'Додайте текст. Мінімум '+min+' символів.')}for(const media of form.querySelectorAll('[data-required-media]')){const name=media.dataset.requiredMedia;const chosen=form.querySelector('input[name="'+name+'_library"]:checked');const file=form.querySelector('input[type="file"][name="'+name+'"]');if(!chosen&&!(file&&file.files&&file.files.length))first=first||mark(media,name==='cover'?'Оберіть або завантажте обкладинку.':'Оберіть або завантажте ілюстрацію.')}if(first){const sum=document.createElement('div');sum.className='form-error-summary';sum.textContent='Не все заповнено. Перевірте позначене поле.';form.prepend(sum);first.scrollIntoView({behavior:'smooth',block:'center'});const focus=first.querySelector('input,textarea,select,[contenteditable="true"]');focus?.focus();return false}return true};
  const key=form=>'mavik-boss-form:'+location.pathname+location.search+':'+(form.dataset.preserveForm||'form');
  const snapshot=form=>{const data={};form.querySelectorAll('input[name],textarea[name],select[name]').forEach(el=>{if(['file','password','hidden','submit','button'].includes(el.type))return;if((el.type==='checkbox'||el.type==='radio')){(data[el.name]??=[]).push([el.value,el.checked])}else if(el.multiple)data[el.name]=[...el.selectedOptions].map(o=>o.value);else data[el.name]=el.value});form.querySelectorAll('[data-mavik-editor]').forEach((shell,i)=>{shell._mavikSync?.();data['__editor_'+i]=shell.querySelector('.rich-editor')?.innerHTML||''});try{sessionStorage.setItem(key(form),JSON.stringify(data))}catch(_){}};
  const restore=form=>{let data=null;try{data=JSON.parse(sessionStorage.getItem(key(form))||'null')}catch(_){}if(!data)return;form.querySelectorAll('input[name],textarea[name],select[name]').forEach(el=>{if(!(el.name in data)||['file','password','hidden','submit','button'].includes(el.type))return;const v=data[el.name];if(el.type==='checkbox'||el.type==='radio'){const pair=Array.isArray(v)?v.find(x=>Array.isArray(x)&&x[0]===el.value):null;if(pair)el.checked=!!pair[1]}else if(el.multiple&&Array.isArray(v))[...el.options].forEach(o=>o.selected=v.includes(o.value));else el.value=String(v??'')});form.querySelectorAll('[data-mavik-editor]').forEach((shell,i)=>{const html=data['__editor_'+i];const ed=shell.querySelector('.rich-editor');if(ed&&typeof html==='string'){ed.innerHTML=html;shell._mavikSync?.()}})};
  document.querySelectorAll('form[data-boss-validate]').forEach(form=>{const noText=form.querySelector('input[name="without_text"]');const placements=[...form.querySelectorAll('input[name="placement"]')];if(!noText||!placements.length)return;noText.addEventListener('change',()=>{if(noText.checked){const ann=placements.find(x=>x.value==='announcements');if(ann)ann.checked=true;}});placements.forEach(x=>x.addEventListener('change',()=>{if(x.checked&&x.value!=='announcements')noText.checked=false;}));});
  const preserved=[...document.querySelectorAll('form[data-preserve-form]')],savedSuccessfully=!!document.querySelector('.msg.success');
  preserved.forEach(form=>{if(savedSuccessfully){try{sessionStorage.removeItem(key(form))}catch(_){}}else restore(form);form.addEventListener('input',()=>snapshot(form));form.addEventListener('change',()=>snapshot(form));form.addEventListener('submit',e=>{snapshot(form);if(form.hasAttribute('data-boss-validate')&&!validate(form)){e.preventDefault();e.stopImmediatePropagation()}},true)});
})();
</script></body></html>

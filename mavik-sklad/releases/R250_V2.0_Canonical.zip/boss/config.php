<?php
return [
  'password_hash' => '$2y$12$.yzcFa699gHReb9GxHNlYOmgpq84.xuqK20LLdC1hePA5HQFlDXfG',
  'emergency_password_id' => 'r187-v1-2026-08-15-security-reset-01',
  'emergency_password_hash' => '$2y$12$.yzcFa699gHReb9GxHNlYOmgpq84.xuqK20LLdC1hePA5HQFlDXfG',
  'site_root' => dirname(__DIR__),
  'manifest' => dirname(__DIR__) . '/_site-state/boss-content.json',
  'manifest_seed' => dirname(__DIR__) . '/_site-admin/state-defaults/boss-content.json',
  'templates' => dirname(__DIR__) . '/_site-admin/boss-templates',
  'email' => 'viktor@mavik.name',
];

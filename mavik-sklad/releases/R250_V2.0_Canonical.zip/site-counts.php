<?php
declare(strict_types=1);
require_once __DIR__.'/_site-admin/state.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Robots-Tag: noindex, nofollow, noarchive');
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') { http_response_code(405); echo '{"books":0,"blog":0,"tracks":0}'; exit; }
$root=__DIR__;
$readJson=static function(string $file): array { $raw=is_file($file)?@file_get_contents($file):false; $j=$raw!==false?json_decode($raw,true):null; return is_array($j)?$j:[]; };
$manifest=$readJson(mavik_state_seed($root,'boss-content.json'));
$books=0;foreach((array)($manifest['books']??[]) as $b){if(!is_array($b)||!empty($b['deleted'])||!empty($b['hidden']))continue;if((string)($b['placement']??'books')!=='books')continue;$books++;}
$blog=0;foreach((array)($manifest['blog']??[]) as $p){if(!is_array($p)||!empty($p['deleted'])||!empty($p['hidden']))continue;$blog++;}
$lib=$readJson(mavik_state_seed($root,'music-library.json'));
$tracks=0;foreach((array)($lib['tracks']??[]) as $t){if(is_array($t)&&empty($t['hidden'])&&trim((string)($t['src']??''))!=='')$tracks++;}
echo json_encode(['books'=>$books,'blog'=>$blog,'tracks'=>$tracks],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);

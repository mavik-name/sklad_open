(()=>{
  const input=document.getElementById('blogSearch');
  const posts=document.getElementById('posts');
  const status=document.getElementById('searchStatus');
  const empty=document.getElementById('emptyState');
  const pager=document.getElementById('blogPagination');
  if(!input||!posts||!status||!empty||!pager)return;

  const staticCards=[...posts.querySelectorAll('.post-card')].map(node=>node.cloneNode(true));
  const staticStatus=status.textContent;
  const staticPager=pager.innerHTML;
  const staticPagerHidden=pager.hidden;
  const basePath=location.pathname;
  const perPage=7;
  let indexPromise=null;
  let searchPage=1;
  let currentQuery='';

  const norm=value=>(value||'').toLocaleLowerCase('uk-UA').replace(/\s+/g,' ').trim();
  const plural=count=>{const d=count%10,m=count%100;return count+' '+(d===1&&m!==11?'публікація':d>=2&&d<=4&&(m<12||m>14)?'публікації':'публікацій')};
  const params=()=>new URLSearchParams(location.search);
  const loadIndex=()=>indexPromise||(indexPromise=fetch('/blog/search-index.json',{credentials:'same-origin',cache:'no-cache'}).then(r=>{if(!r.ok)throw new Error('index');return r.json()}).then(data=>Array.isArray(data.items)?data.items:[]));

  function setUrl(query,page){const p=new URLSearchParams();if(query)p.set('q',query);if(query&&page>1)p.set('page',String(page));history.replaceState(null,'',basePath+(p.toString()?'?'+p.toString():'')+location.hash)}
  function clearCards(){posts.querySelectorAll('.post-card').forEach(n=>n.remove())}
  function restoreStatic(){clearCards();staticCards.forEach(card=>posts.insertBefore(card.cloneNode(true),empty));status.textContent=staticStatus;empty.classList.remove('show');pager.innerHTML=staticPager;pager.hidden=staticPagerHidden;currentQuery='';searchPage=1;setUrl('',1)}
  function makeCard(row){
    const article=document.createElement('article');article.className='post-card'+(row.focused?' post-card-focused':'');
    const media=document.createElement('a');media.className='post-img';media.href='/blog/'+encodeURIComponent(row.slug)+'/';
    const img=document.createElement('img');img.src=row.image||'';img.alt=row.image_alt||row.title||'';img.loading='lazy';img.decoding='async';media.appendChild(img);article.appendChild(media);
    const copy=document.createElement('div');copy.className='post-copy';
    if(row.focused){const badge=document.createElement('div');badge.className='post-focus-badge';badge.textContent='У фокусі';copy.appendChild(badge)}
    const meta=document.createElement('div');meta.className='post-meta';const date=document.createElement('span');date.textContent=row.date||'';const cat=document.createElement('b');cat.textContent=row.category||'';meta.append(date,cat);copy.appendChild(meta);
    const h2=document.createElement('h2');h2.className='post-title';const title=document.createElement('a');title.href='/blog/'+encodeURIComponent(row.slug)+'/';title.textContent=row.title||'';h2.appendChild(title);copy.appendChild(h2);
    const excerpt=document.createElement('p');excerpt.className='post-excerpt';excerpt.textContent=row.excerpt||'';copy.appendChild(excerpt);
    const more=document.createElement('a');more.className='readmore';more.href='/blog/'+encodeURIComponent(row.slug)+'/';more.textContent='Читати далі →';copy.appendChild(more);article.appendChild(copy);return article;
  }
  function drawSearchPager(total){
    pager.innerHTML='';const pages=Math.max(1,Math.ceil(total/perPage));if(pages<=1){pager.hidden=true;return}pager.hidden=false;
    const add=(label,target,disabled=false,current=false)=>{const b=document.createElement('button');b.type='button';b.className='page-btn'+(current?' active':'');b.textContent=label;b.disabled=disabled;if(current)b.setAttribute('aria-current','page');b.addEventListener('click',()=>{searchPage=target;runSearch(currentQuery,true);posts.scrollIntoView({behavior:'smooth',block:'start'})});pager.appendChild(b)};
    add('←',Math.max(1,searchPage-1),searchPage===1);
    for(let n=1;n<=pages;n++){if(pages>9&&Math.abs(n-searchPage)>2&&n!==1&&n!==pages){if(n===2||n===pages-1){const gap=document.createElement('span');gap.className='page-gap';gap.textContent='…';pager.appendChild(gap)}continue}add(String(n),n,false,n===searchPage)}
    add('→',Math.min(pages,searchPage+1),searchPage===pages);
  }
  async function runSearch(raw,updateUrl=true){
    const query=norm(raw);currentQuery=query;
    if(!query){restoreStatic();return}
    status.textContent='Шукаю…';pager.hidden=true;
    try{
      const items=await loadIndex();if(query!==currentQuery)return;
      const matches=items.filter(row=>norm(row.search).includes(query));const pages=Math.max(1,Math.ceil(matches.length/perPage));searchPage=Math.min(Math.max(1,searchPage),pages);
      clearCards();matches.slice((searchPage-1)*perPage,searchPage*perPage).forEach(row=>posts.insertBefore(makeCard(row),empty));empty.classList.toggle('show',matches.length===0);status.textContent=plural(matches.length)+' · запит: «'+query+'»';drawSearchPager(matches.length);if(updateUrl)setUrl(query,searchPage);
    }catch(_){if(query!==currentQuery)return;restoreStatic();input.value='';status.textContent='Пошук тимчасово недоступний. Показую цю сторінку блогу.'}
  }

  input.addEventListener('input',()=>{searchPage=1;runSearch(input.value)});
  document.querySelectorAll('[data-tag]').forEach(button=>button.addEventListener('click',()=>{input.value=button.dataset.tag||'';searchPage=1;runSearch(input.value);input.focus()}));
  document.addEventListener('keydown',event=>{if(event.key==='/'&&document.activeElement!==input&&!/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName||'')){event.preventDefault();input.focus()}else if(event.key==='Escape'&&document.activeElement===input){input.value='';restoreStatic();input.blur()}});
  window.addEventListener('popstate',()=>{const p=params(),q=p.get('q')||'';input.value=q;searchPage=Math.max(1,parseInt(p.get('page')||'1',10)||1);q?runSearch(q,false):restoreStatic()});
  const p=params(),q=p.get('q')||'';if(q){input.value=q;searchPage=Math.max(1,parseInt(p.get('page')||'1',10)||1);runSearch(q,false)}
})();

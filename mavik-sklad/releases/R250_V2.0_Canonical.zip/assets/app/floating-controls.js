(() => {
  const GAP = 10;
  const READER_COFFEE_SELECTOR = '.reader-floating-ding';
  const LEGACY_SITE_COFFEE_SELECTOR = '.floating-ding';
  const DESKTOP_HEADER_COFFEE_SELECTOR = '.mavik-site-ding, .ding-small';
  const FALLBACK_ID = 'mavikGlobalDing';

  const isVisible = el => {
    if (!el) return false;
    const style = getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden') return false;
    return !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
  };

  const visible = selector => [...document.querySelectorAll(selector)].find(isVisible) || null;

  const removeFallbacks = () => {
    document.querySelectorAll('.mavik-global-ding').forEach(el => el.remove());
  };

  const desktopHeaderCoffee = () =>
    window.innerWidth > 780 ? visible(DESKTOP_HEADER_COFFEE_SELECTOR) : null;

  const isReader = () => !!(document.body && (document.body.classList.contains('reader-body') || document.body.hasAttribute('data-reader-build') || document.querySelector('#reader,.reader-wrap,.reader-floating-ding')));

  // Old reader HTML did not always carry reader-body. Normalize it before any control logic.
  if (document.body && isReader()) document.body.classList.add('reader-body');

  const removeLegacySiteControls = () => {
    // Non-reader mobile pages use one canonical coffee control only.
    // Removing stale page-local controls prevents the old mobile "ghost cup".
    if (window.innerWidth <= 780 && !isReader()) {
      document.querySelectorAll(LEGACY_SITE_COFFEE_SELECTOR).forEach(el => el.remove());
    }
    document.querySelectorAll('.back-to-top').forEach(el => el.remove());
  };

  const ensureBottomCoffee = () => {
    removeLegacySiteControls();

    if (isReader()) {
      removeFallbacks();

      const readerCups = [...document.querySelectorAll(READER_COFFEE_SELECTOR)];
      const legacyCups = [...document.querySelectorAll(LEGACY_SITE_COFFEE_SELECTOR)];

      // Prefer the canonical reader control. Old generated readers may still
      // contain a legacy .floating-ding; keeping both caused the desktop
      // double-cup bug. If only the legacy control exists, promote it instead
      // of deleting the author's only coffee shortcut.
      let coffee = readerCups[0] || legacyCups[0] || null;

      if (!readerCups[0] && coffee) {
        coffee.classList.remove('floating-ding');
        coffee.classList.add('reader-floating-ding');
      }

      readerCups.slice(1).forEach(el => el.remove());
      legacyCups.forEach(el => {
        if (el !== coffee) el.remove();
      });

      return coffee;
    }

    // Every non-reader mobile page uses the same single fallback control.
    if (window.innerWidth <= 780) {
      let fallback = document.getElementById(FALLBACK_ID);
      if (!fallback) {
        removeFallbacks();
        fallback = document.createElement('a');
        fallback.id = FALLBACK_ID;
        fallback.className = 'mavik-global-ding';
        fallback.href = '/#support';
        fallback.setAttribute('aria-label','Пригостити автора кавою');
        fallback.setAttribute('title','Пригостити автора кавою');
        fallback.innerHTML =
          '<img aria-hidden="true" alt="" class="mavik-coffee-icon" src="/assets/icons/coffee.svg?v=250v20c3"/>';
        document.body.appendChild(fallback);
      }
      return fallback;
    }

    // Desktop uses only the compact coffee icon in the header.
    // Do not add a second floating coffee shortcut there.
    if (desktopHeaderCoffee()) {
      removeFallbacks();
      return null;
    }

    const nativeBottom = visible(LEGACY_SITE_COFFEE_SELECTOR);
    if (nativeBottom) {
      removeFallbacks();
      return nativeBottom;
    }

    let fallback = document.getElementById(FALLBACK_ID);
    if (!fallback) {
      removeFallbacks();
      fallback = document.createElement('a');
      fallback.id = FALLBACK_ID;
      fallback.className = 'mavik-global-ding';
      fallback.href = '/#support';
      fallback.setAttribute('aria-label','Пригостити автора кавою');
      fallback.setAttribute('title','Пригостити автора кавою');
      fallback.innerHTML =
        '<img aria-hidden="true" alt="" class="mavik-coffee-icon" src="/assets/icons/coffee.svg?v=250v20c3"/>';
      document.body.appendChild(fallback);
    }
    return fallback;
  };

  // Remove old blog-only arrow and stale global arrow duplicates.
  const oldTops = [...document.querySelectorAll('.mavik-global-top')];
  oldTops.slice(1).forEach(el => el.remove());

  let top = oldTops[0] || null;
  if (!top) {
    top = document.createElement('button');
    top.className = 'mavik-global-top';
    top.type = 'button';
    top.setAttribute('aria-label','Повернутися догори');
    top.setAttribute('title','Догори');
    top.innerHTML =
      '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5.5 14.5 12 8l6.5 6.5"/></svg>';
    document.body.appendChild(top);
  }

  const hideResumeAfterManualScroll = () => {
    const resume = document.getElementById('resumeBtn');
    if (!resume) return;
    if (window.scrollY > 180) resume.style.display = 'none';
  };

  const position = () => {
    const coffee = ensureBottomCoffee();
    const tr = top.getBoundingClientRect();

    if (!coffee) {
      // Desktop site pages: coffee is in the header, so the chevron stands alone.
      top.style.bottom = '18px';
      top.style.right = '18px';
      top.style.left = 'auto';
      return;
    }

    const dr = coffee.getBoundingClientRect();
    const bottom = Math.max(0, window.innerHeight - dr.top + GAP);
    let left = dr.left + (dr.width - tr.width) / 2;
    left = Math.max(4, Math.min(left, window.innerWidth - tr.width - 4));

    top.style.bottom = `${bottom}px`;
    top.style.left = `${left}px`;
    top.style.right = 'auto';
  };

  const homeMobileReveal = () => {
    if (window.innerWidth > 780) return null;
    const recommend = document.getElementById('shareSiteBtn');
    if (!recommend) return null;
    const header = document.querySelector('.nav, .mavik-site-header');
    const headerBottom = header ? header.getBoundingClientRect().bottom : 0;
    return recommend.getBoundingClientRect().bottom <= headerBottom;
  };

  const setMobileControlVisible = (el, show) => {
    if (!el) return;
    el.classList.toggle('is-visible', show);
    // JS enforces the pair state too, so a stale mobile CSS cache
    // cannot leave the coffee control permanently visible.
    el.style.setProperty('opacity', show ? '1' : '0', 'important');
    el.style.setProperty('visibility', show ? 'visible' : 'hidden', 'important');
    el.style.setProperty('pointer-events', show ? 'auto' : 'none', 'important');
  };

  const clearMobileVisibilityOverrides = el => {
    if (!el) return;
    ['opacity','visibility','pointer-events'].forEach(prop => el.style.removeProperty(prop));
  };

  const visibility = () => {
    const homeReveal = homeMobileReveal();
    const show = homeReveal === null ? window.scrollY > 420 : homeReveal;

    if (window.innerWidth <= 780) {
      const coffee = ensureBottomCoffee();
      setMobileControlVisible(top, show);
      setMobileControlVisible(coffee, show);
      return;
    }

    clearMobileVisibilityOverrides(top);
    top.classList.toggle('is-visible', show);
    const coffee = document.querySelector(READER_COFFEE_SELECTOR) || document.querySelector(LEGACY_SITE_COFFEE_SELECTOR) || document.getElementById(FALLBACK_ID);
    if (coffee) {
      clearMobileVisibilityOverrides(coffee);
      coffee.classList.remove('is-visible');
    }
  };

  top.addEventListener('click', () =>
    window.scrollTo({top:0, behavior:'smooth'})
  );

  const sync = () => {
    hideResumeAfterManualScroll();
    position();
    visibility();
  };

  window.addEventListener('scroll', sync, {passive:true});
  window.addEventListener('resize', sync, {passive:true});
  window.addEventListener('orientationchange', () => setTimeout(sync, 80));

  window.addEventListener('load', () => {
    sync();
    setTimeout(sync, 120);
    setTimeout(sync, 500);
  });

  sync();
})();


/* R250_V2.0 CANON — lightweight first-party statistics. No cookies, no IP collection. */
(()=>{
  'use strict';
  if(navigator.doNotTrack==='1'||navigator.globalPrivacyControl===true)return;
  const endpoint='/stats-lite.php';
  const sid=()=>{try{let v=sessionStorage.getItem('mavik-stats-session-v1');if(!v){v=(crypto.randomUUID?crypto.randomUUID():(Date.now().toString(36)+Math.random().toString(36).slice(2)+Math.random().toString(36).slice(2)));sessionStorage.setItem('mavik-stats-session-v1',v)}return v}catch(_){return Date.now().toString(36)+Math.random().toString(36).slice(2)}};
  const send=data=>{try{const body=new URLSearchParams({...data,sid:sid()}).toString();if(navigator.sendBeacon){const blob=new Blob([body],{type:'application/x-www-form-urlencoded;charset=UTF-8'});if(navigator.sendBeacon(endpoint,blob))return}fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},body,credentials:'same-origin',keepalive:true,cache:'no-store'}).catch(()=>{})}catch(_){}};
  const page=()=>send({event:'page',path:location.pathname,ref:document.referrer||''});
  const later=()=>('requestIdleCallback'in window?requestIdleCallback(page,{timeout:1800}):setTimeout(page,700));
  document.readyState==='complete'?later():addEventListener('load',later,{once:true});
  window.MaVikStats={track:(id)=>{id=String(id||'').trim();if(id)send({event:'track',path:location.pathname,item:id})}};
})();

(() => {
  'use strict';
  const state={menu:null};
  const current=()=>location.pathname.replace(/\/+$/,'')||'/';
  const active=href=>{try{return (new URL(href,location.origin).pathname.replace(/\/+$/,'')||'/')===current()}catch(_){return false}};
  const itemData=x=>({label:String(x?.label||''),href:String(x?.href||'')});

  const mountBackAssets=()=>{
    if(!document.querySelector('link[data-mavik-back-nav]')){const l=document.createElement('link');l.rel='stylesheet';l.href='/assets/app/back-nav.css?v=250v20c3';l.dataset.mavikBackNav='1';document.head.appendChild(l)}
    if(!document.querySelector('script[data-mavik-back-nav]')){const s=document.createElement('script');s.src='/assets/app/back-nav.js?v=250v20c3';s.defer=true;s.dataset.mavikBackNav='1';document.head.appendChild(s)}
  };
  mountBackAssets();

  const renderMenu=data=>{
    if(!data||!Array.isArray(data.items))return;
    state.menu=data;
    const items=data.items.map(itemData).filter(x=>x.label&&x.href);
    document.querySelectorAll('.mavik-site-desktop-nav,nav.menu').forEach(host=>{
      [...host.querySelectorAll(':scope > a')].forEach(a=>{if(!a.matches('.mavik-site-ding,.ding-small,.js-ding,.mavik-owner-access,.mavik-menu-back,.mavik-install-app'))a.remove()});
      const before=host.querySelector('.mavik-site-ding,.ding-small,.js-ding,.mavik-owner-access');
      items.forEach(x=>{const a=document.createElement('a');a.href=x.href;a.textContent=x.label;if(active(x.href))a.setAttribute('aria-current','page');before?host.insertBefore(a,before):host.appendChild(a)});
    });
    document.querySelectorAll('.mavik-site-mobile-inner,.mobile-menu-inner').forEach(host=>{
      [...host.querySelectorAll(':scope > a')].forEach(a=>{if(!a.matches('.mavik-owner-access,.mavik-menu-back,.mavik-install-app'))a.remove()});
      const before=host.querySelector('.mavik-owner-access');
      items.forEach(x=>{const a=document.createElement('a');a.href=x.href;a.textContent=x.label;if(active(x.href))a.setAttribute('aria-current','page');before?host.insertBefore(a,before):host.appendChild(a)});
    });
    document.dispatchEvent(new CustomEvent('mavik:menu-ready',{detail:{data}}));
  };

  const initMobile=()=>document.querySelectorAll('.mavik-site-mobile-toggle').forEach(btn=>{
    if(btn.dataset.mavikBound==='1')return;btn.dataset.mavikBound='1';
    const id=btn.getAttribute('aria-controls'),menu=id?document.getElementById(id):null;if(!menu)return;
    const close=()=>{menu.classList.remove('open');btn.classList.remove('open');btn.setAttribute('aria-expanded','false');btn.setAttribute('aria-label','Відкрити меню');menu.setAttribute('aria-hidden','true');document.body.classList.remove('mavik-menu-open')};
    const open=()=>{menu.classList.add('open');btn.classList.add('open');btn.setAttribute('aria-expanded','true');btn.setAttribute('aria-label','Закрити меню');menu.setAttribute('aria-hidden','false');document.body.classList.add('mavik-menu-open')};
    btn.addEventListener('click',()=>menu.classList.contains('open')?close():open());menu.addEventListener('click',e=>{if(e.target.closest('a'))close()});document.addEventListener('keydown',e=>{if(e.key==='Escape')close()});window.addEventListener('resize',()=>{if(innerWidth>780)close()});
  });
  document.readyState==='loading'?document.addEventListener('DOMContentLoaded',initMobile,{once:true}):initMobile();

  document.addEventListener('click',e=>{if(e.target.closest('.mavik-site-ding,.ding-small,.js-ding')){try{sessionStorage.setItem('mavik-open-ding','1')}catch(_){}}});

  const mountOwner=authenticated=>{
    document.querySelectorAll('.mavik-site-desktop-nav,nav.menu,.mavik-site-mobile-inner,.mobile-menu-inner').forEach(host=>{
      if(host.querySelector('.mavik-owner-access'))return;
      const a=document.createElement('a');a.className='mavik-owner-access';const next=encodeURIComponent(location.pathname+location.search+location.hash);a.href=authenticated?'/boss/':'/account/?next='+next;a.textContent=authenticated?'Адмінка':'Вхід';
      const before=host.querySelector('.mavik-site-ding,.ding-small,.js-ding');before?host.insertBefore(a,before):host.appendChild(a);
    });
  };

  fetch('/assets/app/site-menu.json?v=250v20c3',{cache:'no-store',credentials:'same-origin'}).then(r=>r.ok?r.json():Promise.reject()).then(renderMenu).catch(()=>{});
  fetch('/account/status.php',{credentials:'same-origin',cache:'no-store'}).then(r=>r.ok?r.json():Promise.reject()).then(s=>mountOwner(!!s.authenticated)).catch(()=>{});
})();


/* MAVIK_MOBILE_INSTALL_V223 */
(() => {
  'use strict';
  const isStandalone=()=>window.matchMedia?.('(display-mode: standalone)')?.matches||navigator.standalone===true;
  const isIOS=()=>/iP(?:hone|ad|od)/i.test(navigator.userAgent)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1);
  const isAndroid=()=>/Android/i.test(navigator.userAgent);
  let deferredPrompt=null;

  const ensureHead=()=>{
    if(!document.querySelector('link[rel="manifest"]')){const l=document.createElement('link');l.rel='manifest';l.href='/manifest.webmanifest?v=250v20c3';document.head.appendChild(l)}
    if(!document.querySelector('link[data-mavik-install-css]')){const l=document.createElement('link');l.rel='stylesheet';l.href='/assets/app/install-app.css?v=250v20c3';l.dataset.mavikInstallCss='1';document.head.appendChild(l)}
  };
  ensureHead();

  if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js',{scope:'/'}).catch(()=>{}),{once:true})}

  const removeInstallLinks=()=>document.querySelectorAll('.mavik-install-app').forEach(a=>a.remove());
  const getModal=()=>{
    let modal=document.getElementById('mavikInstallModal');
    if(modal)return modal;
    modal=document.createElement('div');modal.id='mavikInstallModal';modal.className='mavik-install-modal';modal.setAttribute('aria-hidden','true');
    modal.innerHTML='<div class="mavik-install-card" role="dialog" aria-modal="true" aria-labelledby="mavikInstallTitle"><button class="mavik-install-close" type="button" aria-label="Закрити">×</button><div class="mavik-install-copy"></div></div>';
    const close=()=>{modal.classList.remove('open');modal.setAttribute('aria-hidden','true')};
    modal.querySelector('.mavik-install-close').addEventListener('click',close);
    modal.addEventListener('click',e=>{if(e.target===modal)close()});
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&modal.classList.contains('open'))close()});
    document.body.appendChild(modal);return modal;
  };
  const showInstructions=()=>{
    const modal=getModal(),copy=modal.querySelector('.mavik-install-copy');
    if(isIOS()){
      copy.innerHTML='<h2 id="mavikInstallTitle">Встановити MaVik</h2><p>На iPhone або iPad сайт можна додати як окрему вебпрограму.</p><ol><li>Натисніть <strong>«Поширити»</strong> у браузері.</li><li>Оберіть <strong>«На Початковий екран»</strong>.</li><li>Залиште увімкненим <strong>«Відкрити як вебпрограму»</strong>.</li><li>Натисніть <strong>«Додати»</strong>.</li></ol><p class="mavik-install-note">Якщо пункт «На Початковий екран» у вашому браузері не показується, відкрийте mavik.name у Safari й повторіть ці кроки.</p>';
    }else if(isAndroid()){
      copy.innerHTML='<h2 id="mavikInstallTitle">Встановити MaVik</h2><p>Браузер поки не показав системне вікно встановлення.</p><ol><li>Відкрийте меню браузера <strong>⋮</strong>.</li><li>Оберіть <strong>«Встановити застосунок»</strong> або <strong>«Додати на головний екран»</strong>.</li></ol>';
    }else{
      copy.innerHTML='<h2 id="mavikInstallTitle">Встановити MaVik</h2><p>Відкрийте меню браузера й оберіть додавання сайту на головний екран або встановлення вебзастосунку.</p>';
    }
    modal.classList.add('open');modal.setAttribute('aria-hidden','false');modal.querySelector('.mavik-install-close').focus();
  };
  const install=async e=>{
    e?.preventDefault();
    if(isStandalone()){removeInstallLinks();return}
    if(deferredPrompt){
      const p=deferredPrompt;deferredPrompt=null;
      try{await p.prompt();const choice=await p.userChoice;if(choice?.outcome==='accepted')removeInstallLinks()}catch(_){showInstructions()}
      return;
    }
    showInstructions();
  };
  const mount=()=>{
    if(isStandalone()){removeInstallLinks();return}
    document.querySelectorAll('.mavik-site-mobile-inner,.mobile-menu-inner').forEach(host=>{
      if(host.querySelector('.mavik-install-app'))return;
      const a=document.createElement('a');a.href='#';a.className='mavik-install-app';a.textContent='Встановити MaVik';a.setAttribute('role','button');a.addEventListener('click',install);
      const before=host.querySelector('.mavik-owner-access');before?host.insertBefore(a,before):host.appendChild(a);
    });
  };
  window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredPrompt=e;mount()});
  window.addEventListener('appinstalled',()=>{deferredPrompt=null;removeInstallLinks()});
  document.addEventListener('mavik:menu-ready',mount);
  document.readyState==='loading'?document.addEventListener('DOMContentLoaded',mount,{once:true}):mount();
})();

/* External links never replace mavik.name in the current tab. */
(()=>{const apply=()=>document.querySelectorAll('main a[href],article a[href]').forEach(a=>{try{const u=new URL(a.getAttribute('href'),location.origin);if(/^https?:$/.test(u.protocol)&&!['mavik.name','www.mavik.name'].includes(u.hostname.toLowerCase())){a.target='_blank';a.rel='noopener noreferrer'}else if(u.hostname===location.hostname||['mavik.name','www.mavik.name'].includes(u.hostname.toLowerCase())){a.removeAttribute('target');a.removeAttribute('rel')}}catch(_){}});document.readyState==='loading'?document.addEventListener('DOMContentLoaded',apply,{once:true}):apply()})();



/* R250_V2.0 CANON: live counters + legacy blog tag compatibility. */
(()=>{
  'use strict';
  const word=(n,one,few,many)=>{n=Math.abs(Number(n)||0);const d=n%10,m=n%100;return d===1&&m!==11?one:(d>=2&&d<=4&&(m<12||m>14)?few:many)};
  const updateHeroCounts=counts=>{
    const host=document.querySelector('.hero-note');if(!host||!counts)return;
    const rows=[...host.children];
    const set=(label,value,forms)=>{const row=rows.find(x=>x.querySelector('b')?.textContent.trim()===label);if(!row)return;const b=row.querySelector('b');b.textContent=String(value)+' '+word(value,...forms)};
    set('Книги',counts.books,['книга','книги','книг']);
    set('Музика',counts.tracks,['трек','треки','треків']);
    set('Блог',counts.blog,['допис','дописи','дописів']);
  };
  const fixBlogTags=()=>{
    if(!location.pathname.startsWith('/blog/'))return;
    document.querySelectorAll('.article-side .relatedbox').forEach(box=>{
      const h=box.querySelector('h3');if(!h||h.textContent.trim()!=='Теги')return;
      let tags=box.querySelector('.tags');if(!tags){tags=document.createElement('div');tags.className='tags';box.appendChild(tags)}
      [...tags.querySelectorAll('a.tag')].forEach(a=>{try{const u=new URL(a.getAttribute('href')||'',location.href);let q=u.searchParams.get('q');if(!q&&u.hash.startsWith('#q='))q=decodeURIComponent(u.hash.slice(3));if(q)a.href='/blog/?q='+encodeURIComponent(q)}catch(_){}});
      if(tags.querySelector('a.tag'))return;
      const category=document.querySelector('.article-hero .eyebrow')?.textContent.trim()||'';
      if(category&&category.toLocaleLowerCase('uk-UA')!=='блог'){
        const a=document.createElement('a');a.className='tag';a.href='/blog/?q='+encodeURIComponent(category);a.textContent=category;tags.appendChild(a);
      }else box.hidden=true;
    });
    document.querySelectorAll('.article-hero .crumbs').forEach(x=>x.hidden=true);
  };
  const init=()=>{fixBlogTags();if(document.querySelector('.hero-note'))fetch('/site-counts.php',{cache:'no-store',credentials:'same-origin'}).then(r=>r.ok?r.json():Promise.reject()).then(updateHeroCounts).catch(()=>{})};
  document.readyState==='loading'?document.addEventListener('DOMContentLoaded',init,{once:true}):init();
})();

/* R250_V2.0 blog owner tools: visible only to authenticated owner. */
(()=>{
  'use strict';
  if(!location.pathname.startsWith('/blog/'))return;

  const style=document.createElement('style');
  style.textContent=`
    .mavik-blog-owner-tools{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:14px}
    .mavik-blog-owner-btn{appearance:none;border:1px solid rgba(217,189,134,.45);background:rgba(12,12,13,.72);color:#dfc58f;border-radius:999px;padding:7px 11px;font:700 11px/1 Arial,sans-serif;text-decoration:none;cursor:pointer}
    .mavik-blog-owner-btn:hover{border-color:#d9bd86;color:#f1d9a6}
    .mavik-blog-owner-btn.danger{border-color:rgba(209,120,112,.45);color:#e3aaa4}
    .mavik-blog-owner-btn[disabled]{opacity:.55;cursor:default}
    .mavik-blog-owner-state{font-size:11px;color:#9f998f}
    .article-hero .mavik-blog-owner-tools{justify-content:flex-start}
    @media(max-width:780px){.mavik-blog-owner-tools{justify-content:center}.article-hero .mavik-blog-owner-tools{justify-content:center}}
  `;
  document.head.appendChild(style);

  const fmt=iso=>{
    if(!iso||!iso.includes('T'))return '';
    const d=new Date(iso);if(Number.isNaN(d.getTime()))return '';
    return new Intl.DateTimeFormat('uk-UA',{day:'numeric',month:'long',year:'numeric',hour:'2-digit',minute:'2-digit',hour12:false,timeZone:'Europe/Kyiv'}).format(d).replace(' о ', ' · ');
  };
  const slugFromHref=href=>{
    try{const p=new URL(href,location.origin).pathname.split('/').filter(Boolean);return p[0]==='blog'&&p[1]&&p[1]!=='page'?p[1]:''}catch(_){return ''}
  };
  const articleSlug=()=>{
    const p=location.pathname.split('/').filter(Boolean);
    return p[0]==='blog'&&p[1]&&p[1]!=='page'?p[1]:'';
  };
  const metaBySlug=new Map();
  let owner=null;

  const updateTime=(host,row)=>{
    if(!row)return;
    const label=fmt(row.published_at);
    if(!label)return;
    if(host.matches('.post-card')){
      const date=host.querySelector('.post-meta span');
      if(date)date.textContent=label;
    }else{
      const info=document.querySelector('.article-info');
      if(info){
        const parts=info.textContent.split('· Макарчук');
        info.textContent=label+' · Макарчук'+(parts[1]||' Віктор / MaVik');
      }
    }
  };

  const hidePost=async(slug,button,row)=>{
    if(!owner?.authenticated||!owner.csrf)return;
    const willHide=!row.hidden;
    if(!confirm(willHide?'Приховати цей допис із публічного блогу?':'Знову показати цей допис у публічному блозі?'))return;
    button.disabled=true;const old=button.textContent;button.textContent='Зберігаю…';
    const body=new FormData();body.set('csrf',owner.csrf);body.set('action','blog_visibility');body.set('slug',slug);
    try{
      const r=await fetch('/boss/',{method:'POST',body,credentials:'same-origin',cache:'no-store'});
      const text=await r.text();
      const ok=r.ok&&(text.includes('Допис приховано з публічного сайту.')||text.includes('Допис знову опубліковано.'));
      if(!ok)throw new Error('Boss');
      row.hidden=willHide;
      if(location.pathname.startsWith('/blog/'+slug+'/')){
        if(willHide){button.textContent='Приховано';setTimeout(()=>location.href='/blog/',350)}
        else{button.textContent='Приховати';button.disabled=false}
      }else{
        location.reload();
      }
    }catch(_){
      button.textContent=old;button.disabled=false;alert('Не вдалося змінити видимість. Відкрийте допис у Boss.');
    }
  };

  const ownerTools=(slug,row)=>{
    if(!owner?.authenticated||!slug||!row)return null;
    const box=document.createElement('div');box.className='mavik-blog-owner-tools';box.dataset.blogOwner=slug;
    const edit=document.createElement('a');edit.className='mavik-blog-owner-btn';edit.href='/boss/?tab=blog&edit='+encodeURIComponent(slug);edit.textContent='Редагувати';
    const visibility=document.createElement('button');visibility.type='button';visibility.className='mavik-blog-owner-btn danger';visibility.textContent=row.hidden?'Показати':'Приховати';
    visibility.addEventListener('click',()=>hidePost(slug,visibility,row));
    box.append(edit,visibility);return box;
  };

  const decorateCard=card=>{
    if(card.dataset.mavikOwnerDecorated==='1')return;
    const slug=slugFromHref(card.querySelector('.post-title a,.post-img')?.getAttribute('href')||'');
    const row=metaBySlug.get(slug);if(!row)return;
    card.dataset.mavikOwnerDecorated='1';updateTime(card,row);
    const tools=ownerTools(slug,row);if(tools)(card.querySelector('.post-copy')||card).appendChild(tools);
  };

  const decorateArticle=()=>{
    const slug=articleSlug(),row=metaBySlug.get(slug);if(!slug||!row)return;
    updateTime(document.body,row);
    if(owner?.authenticated&&!document.querySelector('[data-blog-owner="'+CSS.escape(slug)+'"]')){
      const tools=ownerTools(slug,row);
      const info=document.querySelector('.article-info');if(tools&&info)info.insertAdjacentElement('afterend',tools);
    }
  };

  const decorate=()=>{
    document.querySelectorAll('.post-card').forEach(decorateCard);
    decorateArticle();
  };

  fetch('/blog-meta.php',{credentials:'same-origin',cache:'no-store'})
    .then(r=>r.ok?r.json():Promise.reject())
    .then(data=>{
      owner=data?.owner||null;
      (Array.isArray(data?.items)?data.items:[]).forEach(row=>metaBySlug.set(String(row.slug||''),row));
      decorate();
      const posts=document.getElementById('posts');
      if(posts)new MutationObserver(decorate).observe(posts,{childList:true,subtree:true});
    }).catch(()=>{});
})();


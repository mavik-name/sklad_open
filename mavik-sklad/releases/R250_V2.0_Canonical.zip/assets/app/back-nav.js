(() => {
  'use strict';
  if(window.__mavikBackNavInit)return;window.__mavikBackNavInit=true;
  const norm=p=>('/'+String(p||'').replace(/^\/+|\/+$/g,'')+'/').replace(/\/+/g,'/');
  const path=norm(location.pathname);
  const fallback=()=>{
    let m=path.match(/^\/books\/([^/]+)\/read\/$/);if(m)return `/books/${m[1]}/`;
    m=path.match(/^\/books\/([^/]+)\/read\/text\/$/);if(m)return `/books/${m[1]}/read/`;
    if(/^\/books\/[^/]+\//.test(path))return document.body?.dataset?.bookPlacement==='announcements'?'/announcements/':'/books/';
    if(path==='/books/')return '/';
    if(/^\/announcements\/[^/]+\//.test(path))return '/announcements/';
    if(path==='/announcements/')return '/';
    if(/^\/blog\/[^/]+\//.test(path))return '/blog/';
    if(path==='/blog/')return '/';
    if(/^\/music\/[^/]+\//.test(path))return '/music/';
    if(path==='/music/')return '/';
    return '/';
  };
  const sameOriginReferrer=()=>{try{return !!document.referrer&&new URL(document.referrer,location.href).origin===location.origin}catch(_){return false}};
  const make=()=>{const a=document.createElement('a');a.className='mavik-menu-back';a.href=fallback();a.setAttribute('aria-label','Назад');a.innerHTML='<span aria-hidden="true">←</span><span>Назад</span>';a.addEventListener('click',e=>{if(sameOriginReferrer()&&history.length>1){e.preventDefault();history.back()}});return a};
  const mount=()=>{document.querySelectorAll('.mavik-backbar').forEach(x=>x.remove());if(path==='/'){document.querySelectorAll('.mavik-menu-back').forEach(x=>x.remove());return}document.querySelectorAll('.mavik-site-desktop-nav,nav.menu,.mavik-site-mobile-inner,.mobile-menu-inner').forEach(host=>{host.querySelectorAll(':scope > .mavik-menu-back').forEach(x=>x.remove());host.prepend(make())})};
  document.addEventListener('mavik:menu-ready',mount);document.readyState==='loading'?document.addEventListener('DOMContentLoaded',mount,{once:true}):mount();setTimeout(mount,300);
})();

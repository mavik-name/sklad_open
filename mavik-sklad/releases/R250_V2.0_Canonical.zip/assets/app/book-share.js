(()=>{
  'use strict';
  const icon='<svg aria-hidden="true" viewBox="0 0 24 24"><circle cx="18" cy="5" r="2.5"></circle><circle cx="6" cy="12" r="2.5"></circle><circle cx="18" cy="19" r="2.5"></circle><path d="m8.2 10.9 7.6-4.6M8.2 13.1l7.6 4.6"></path></svg>';
  const makeShare=(className,label)=>{const b=document.createElement('button');b.type='button';b.className=className;b.title=label;b.setAttribute('aria-label',label);b.innerHTML=icon;return b;};
  const bindShare=(button,{title,text,url,promptText})=>{button.onclick=async()=>{try{if(navigator.share){await navigator.share({title,text,url});return;}if(navigator.clipboard&&window.isSecureContext){await navigator.clipboard.writeText(url);button.classList.add('is-done');setTimeout(()=>button.classList.remove('is-done'),1300);return;}window.prompt(promptText,url);}catch(e){}};};

  const announcement=document.querySelector('.announcement-detail-page .announcement-detail-hero');
  if(announcement){
    const slot=document.querySelector('.announcement-share-slot');if(!slot||slot.querySelector('.book-share-btn'))return;
    const share=makeShare('book-share-btn','Поділитися анонсом');slot.appendChild(share);
    const url=location.origin+location.pathname.replace(/\/?$/,'/');const title=(announcement.querySelector('h1')?.textContent||document.title||'Анонс').trim();
    bindShare(share,{title,text:`«${title}» — анонс MaVik`,url,promptText:'Скопіюйте посилання на анонс:'});return;
  }

  const bookMatch=location.pathname.match(/^\/books\/([^/]+)\/?$/);if(!bookMatch)return;
  const slug=bookMatch[1],book=document.querySelector('.book');if(!book)return;
  const info=book.children[1]||book,actions=info.querySelector('.actions'),heading=info.querySelector('h1');if(!actions||!heading)return;
  const url=location.origin+'/books/'+slug+'/';const title=(heading.textContent||document.title||'Книга').trim();
  const shareData={title,text:`«${title}» — Макарчук Віктор (MaVik)`,url,promptText:'Скопіюйте посилання на книгу:'};

  if(!info.querySelector('.book-title-row')){
    const row=document.createElement('div');row.className='book-title-row';heading.parentNode.insertBefore(row,heading);row.appendChild(heading);
    const desktopShare=makeShare('book-share-btn book-share-title','Поділитися книгою');row.appendChild(desktopShare);bindShare(desktopShare,shareData);
  }
  if(!info.querySelector('.book-share-center')){
    const wrap=document.createElement('div');wrap.className='book-share-center';const mobileShare=makeShare('book-share-btn','Поділитися книгою');wrap.appendChild(mobileShare);bindShare(mobileShare,shareData);
    const reaction=info.querySelector('.mavik-reaction');if(reaction)reaction.insertAdjacentElement('beforebegin',wrap);else actions.insertAdjacentElement('afterend',wrap);
  }
})();

(() => {
  const buttons = [...document.querySelectorAll('.reader-share-btn')];
  if (!buttons.length) return;

  const parts = location.pathname.split('/').filter(Boolean);
  const bookSlug = parts[0] === 'books' && parts[1] ? parts[1] : '';
  const shareUrl = bookSlug
    ? `${location.origin}/books/${encodeURIComponent(bookSlug)}/`
    : location.origin + location.pathname.replace(/\/read\/?$/, '/');

  const title = (document.querySelector('.book-hero h1')?.textContent || document.title || 'Твір MaVik').trim();
  const shareText = `«${title}» — Макарчук Віктор (MaVik)`;

  const feedback = (button, text) => {
    const old = button.getAttribute('aria-label') || 'Поділитися твором';
    button.dataset.oldShareLabel = old;
    button.setAttribute('aria-label', text);
    button.setAttribute('title', text);
    button.classList.add('share-done');
    setTimeout(() => {
      button.setAttribute('aria-label', button.dataset.oldShareLabel || 'Поділитися твором');
      button.setAttribute('title', 'Поділитися твором');
      button.classList.remove('share-done');
    }, 1500);
  };

  const track = method => {
    try {
    } catch(e) {}
  };

  buttons.forEach(button => {
    button.addEventListener('click', async () => {
      if (navigator.share) {
        try {
          await navigator.share({title, text: shareText, url: shareUrl});
          track('native');
          feedback(button, 'Надіслано');
          return;
        } catch (e) {
          if (e && e.name === 'AbortError') return;
        }
      }

      try {
        await navigator.clipboard.writeText(shareUrl);
        track('clipboard');
        feedback(button, 'Посилання скопійовано');
        return;
      } catch(e) {}

      const ta = document.createElement('textarea');
      ta.value = shareUrl;
      ta.setAttribute('readonly','');
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      try {
        document.execCommand('copy');
        track('clipboard-legacy');
        feedback(button, 'Посилання скопійовано');
      } catch(e) {
        window.prompt('Скопіюйте посилання на твір:', shareUrl);
        track('prompt');
      } finally {
        ta.remove();
      }
    });
  });
})();
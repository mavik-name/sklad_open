(()=>{
  'use strict';
  if(window.__mavikReaderListen)return;window.__mavikReaderListen=true;
  const reader=document.getElementById('reader');if(!reader)return;
  const mobileView=window.matchMedia('(max-width:780px)');if(!mobileView.matches)return;
  const m=location.pathname.match(/^\/books\/([^/]+)\/read\/?$/);if(!m)return;
  if(new URLSearchParams(location.search).get('listen')!=='1')return;
  const slug=m[1], synth=window.speechSynthesis;
  const normalize=t=>(t||'').replace(/\s+/g,' ').trim();
  const targetLang=String(document.documentElement.lang||'uk-UA').replace('_','-');
  const targetPrimary=targetLang.split('-')[0].toLowerCase();

  const nodes=[...reader.querySelectorAll('h1,h2,h3,p,blockquote,li')].filter(el=>{
    if(el.closest('nav,aside,.settings,.drawer,.actions,.reader-error-modal'))return false;
    return normalize(el.innerText).length>1;
  });

  const chunks=[];
  const split=(raw,el)=>{
    const text=normalize(raw);if(!text)return;
    const sentences=text.match(/[^.!?…]+[.!?…]+|[^.!?…]+$/g)||[text];
    let cursor=0;
    sentences.forEach(sentence=>{
      const st=sentence.trim();if(!st)return;
      let start=text.indexOf(st,cursor);if(start<0)start=cursor;
      let rest=st,localStart=start;
      while(rest.length>620){
        let cut=rest.lastIndexOf(' ',620);if(cut<260)cut=620;
        const part=rest.slice(0,cut).trim();
        if(part)chunks.push({text:part,el,start:localStart,end:localStart+part.length});
        rest=rest.slice(cut).trim();
        localStart=start+(st.length-rest.length);
      }
      if(rest)chunks.push({text:rest,el,start:localStart,end:localStart+rest.length});
      cursor=start+st.length;
    });
  };
  nodes.forEach(el=>split(el.innerText,el));if(!chunks.length)return;

  const key='mavik-listen-v3:'+slug;
  let index=0,active=false,paused=false,utter=null,listenMode=false,wakeLock=null,wakeRetry=0;
  let voicePromise=null,speakToken=0,noVoiceWarned=false;
  try{
    const saved=JSON.parse(localStorage.getItem(key)||'null');
    if(saved&&Number.isInteger(saved.index)&&saved.index<chunks.length)index=Math.max(0,saved.index);
  }catch(_){}

  const btn=document.createElement('button');
  btn.type='button';
  btn.className='reader-listen-primary reader-listen-single';
  btn.setAttribute('aria-label','Слухати вголос');
  document.body.appendChild(btn);

  const save=()=>{try{localStorage.setItem(key,JSON.stringify({index,at:Date.now()}))}catch(_){}};
  const voiceLang=v=>String(v?.lang||'').replace('_','-').toLowerCase();
  const targetVoice=()=>{
    const all=synth?.getVoices?.()||[], exact=targetLang.toLowerCase();
    return all.find(v=>voiceLang(v)===exact)
      ||all.find(v=>voiceLang(v).startsWith(targetPrimary+'-'))
      ||all.find(v=>voiceLang(v)===targetPrimary)
      ||null;
  };
  const waitForTargetVoice=()=>{
    const ready=targetVoice();if(ready)return Promise.resolve(ready);
    if(!synth)return Promise.resolve(null);
    if(voicePromise)return voicePromise;
    voicePromise=new Promise(resolve=>{
      let timer=0,done=false;
      const finish=v=>{
        if(done)return;done=true;
        clearTimeout(timer);
        try{synth.removeEventListener?.('voiceschanged',onVoicesChanged)}catch(_){}
        voicePromise=null;resolve(v||null);
      };
      const onVoicesChanged=()=>{const v=targetVoice();if(v)finish(v)};
      try{synth.addEventListener?.('voiceschanged',onVoicesChanged)}catch(_){}
      try{synth.getVoices()}catch(_){}
      timer=setTimeout(()=>finish(targetVoice()),1400);
    });
    return voicePromise;
  };

  const mark=()=>{
    document.querySelectorAll('.reader-listen-reading').forEach(x=>x.classList.remove('reader-listen-reading'));
    const c=chunks[index];if(c?.el)c.el.classList.add('reader-listen-reading');
  };

  const sync=()=>{
    btn.innerHTML=active&&!paused
      ? '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 5h4v14H6zm8 0h4v14h-4z"/></svg><span>Пауза</span>'
      : '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5v14l11-7z"/></svg><span>Слухати</span>';
    btn.setAttribute('aria-label',active&&!paused?'Пауза':'Слухати вголос');
    mark();save();
  };

  const requestWake=async()=>{
    if(!listenMode||document.visibilityState!=='visible'||wakeLock)return;
    if(!('wakeLock' in navigator))return;
    try{
      wakeLock=await navigator.wakeLock.request('screen');wakeRetry=0;
      wakeLock.addEventListener('release',()=>{
        wakeLock=null;
        if(listenMode&&document.visibilityState==='visible'){
          clearTimeout(wakeRetry);wakeRetry=setTimeout(requestWake,180);
        }
      },{once:true});
    }catch(_){
      wakeLock=null;
      if(listenMode&&document.visibilityState==='visible'){
        clearTimeout(wakeRetry);wakeRetry=setTimeout(requestWake,1200);
      }
    }
  };

  const releaseWake=async()=>{
    clearTimeout(wakeRetry);wakeRetry=0;
    const lock=wakeLock;wakeLock=null;
    if(lock){try{await lock.release()}catch(_){}}
  };

  const setListenMode=on=>{
    listenMode=!!on;
    if(listenMode)requestWake();else releaseWake();
  };

  const showTargetVoiceHelp=()=>{
    const ua=String(navigator.userAgent||'');
    const platform=String(navigator.platform||'');
    const isAppleMobile=/iPhone|iPad|iPod/i.test(ua)||(platform==='MacIntel'&&navigator.maxTouchPoints>1);
    const isAndroid=/Android/i.test(ua);
    const isUkrainian=targetPrimary==='uk';
    const voiceName=isUkrainian?'український':targetLang;
    const steps=isAppleMobile
      ? '<ol><li>Відкрийте <b>Параметри</b>.</li><li>Перейдіть: <b>Доступність → Читання і мовлення → Голоси</b>.</li><li>Встановіть системний голос для <b>'+voiceName+'</b>.</li><li>Поверніться на MaVik і натисніть <b>Слухати</b> ще раз.</li></ol>'
      : isAndroid
        ? '<ol><li>Відкрийте <b>Налаштування</b>.</li><li>Знайдіть <b>Синтез мовлення / Text-to-speech</b>.</li><li>Установіть голос для <b>'+voiceName+'</b>.</li><li>Поверніться на MaVik і натисніть <b>Слухати</b> ще раз.</li></ol>'
        : '<p>Встановіть у системних налаштуваннях синтезу мовлення голос для <b>'+voiceName+'</b>, потім поверніться на MaVik і повторіть.</p>';
    const modal=document.createElement('div');
    modal.className='reader-listen-voice-modal';
    const title=isUkrainian?'Потрібен український голос':'Потрібен голос '+targetLang;
    const intro=isUkrainian?'На цьому пристрої українського системного голосу не знайдено. MaVik не підмінятиме його російським, білоруським чи іншим голосом.':'На цьому пристрої не знайдено системного голосу для мови цієї книги ('+targetLang+'). MaVik не підмінятиме його голосом іншої мови.';
    modal.innerHTML='<div class="reader-listen-voice-card" role="dialog" aria-modal="true" aria-labelledby="readerListenVoiceTitle"><div class="reader-listen-voice-head"><strong id="readerListenVoiceTitle">'+title+'</strong><button type="button" class="reader-listen-voice-x" aria-label="Закрити">×</button></div><p>'+intro+'</p>'+steps+'<button type="button" class="reader-listen-voice-close">Зрозуміло</button></div>';
    const close=()=>modal.remove();
    modal.querySelector('.reader-listen-voice-x')?.addEventListener('click',close);
    modal.querySelector('.reader-listen-voice-close')?.addEventListener('click',close);
    modal.addEventListener('click',e=>{if(e.target===modal)close()});
    document.body.appendChild(modal);
    modal.querySelector('.reader-listen-voice-x')?.focus();
  };
  const failNoTargetVoice=()=>{
    active=false;paused=false;utter=null;setListenMode(false);sync();
    const all=(synth?.getVoices?.()||[]).map(v=>`${v.name||'?'} [${v.lang||'?'}]`);
    console.warn('[MaVik TTS] Voice unavailable for',targetLang,'Device voices:',all);
    if(noVoiceWarned)return;
    noVoiceWarned=true;
    showTargetVoiceHelp();
  };

  const speak=async()=>{
    const token=++speakToken;
    setListenMode(true);
    if(!synth){active=false;paused=false;sync();return;}
    try{synth.cancel()}catch(_){}
    const v=await waitForTargetVoice();
    if(token!==speakToken||!listenMode)return;
    if(!v){failNoTargetVoice();return;}

    const c=chunks[index];if(!c){active=false;paused=false;sync();return;}
    utter=new SpeechSynthesisUtterance(c.text);
    utter.lang=targetLang;
    utter.voice=v;
    utter.rate=1;utter.pitch=1;
    console.info('[MaVik TTS] voice:',v.name,'lang:',v.lang,'requested:',targetLang);

    utter.onend=()=>{
      if(!active||paused)return;
      if(index<chunks.length-1){index++;sync();setTimeout(()=>speak(),35)}
      else{active=false;paused=false;setListenMode(false);sync();}
    };
    utter.onerror=e=>{
      if(e.error==='canceled'||e.error==='interrupted')return;
      active=false;paused=false;setListenMode(false);sync();
    };

    active=true;paused=false;sync();
    c.el?.scrollIntoView({behavior:'smooth',block:'center'});
    synth.speak(utter);
  };

  const startAtViewport=()=>{
    let best=0,dist=Infinity;
    chunks.forEach((c,i)=>{
      const r=c.el?.getBoundingClientRect();if(!r)return;
      const d=Math.abs(r.top-Math.min(innerHeight*.3,180));
      if(r.bottom>0&&d<dist){dist=d;best=i}
    });
    index=best;
  };

  const caretOffsetIn=(el,x,y)=>{
    let node=null,offset=0;
    try{
      if(document.caretPositionFromPoint){
        const p=document.caretPositionFromPoint(x,y);if(p){node=p.offsetNode;offset=p.offset}
      }else if(document.caretRangeFromPoint){
        const r=document.caretRangeFromPoint(x,y);if(r){node=r.startContainer;offset=r.startOffset}
      }
      if(!node||!el.contains(node))return 0;
      const range=document.createRange();range.selectNodeContents(el);range.setEnd(node,offset);
      return normalize(range.toString()).length;
    }catch(_){return 0}
  };

  const chunkAtPoint=(el,x,y)=>{
    const candidates=[];
    chunks.forEach((c,i)=>{if(c.el===el)candidates.push([i,c])});
    if(!candidates.length)return -1;
    const pos=caretOffsetIn(el,x,y);
    for(const [i,c] of candidates)if(pos>=c.start&&pos<=c.end+1)return i;
    return candidates.reduce((best,item)=>Math.abs(item[1].start-pos)<Math.abs(best[1].start-pos)?item:best,candidates[0])[0];
  };

  btn.onclick=()=>{
    setListenMode(true);
    if(active&&!paused){
      try{synth?.pause()}catch(_){}
      paused=true;sync();
    }else if(active&&paused){
      try{synth?.resume()}catch(_){}
      paused=false;sync();
    }else{
      startAtViewport();speak();
    }
  };

  reader.addEventListener('click',e=>{
    if(e.target.closest('a,button,input,select,textarea,label'))return;
    const el=e.target.closest('h1,h2,h3,p,blockquote,li');
    if(!el||!reader.contains(el))return;
    const next=chunkAtPoint(el,e.clientX,e.clientY);if(next<0)return;
    index=next;
    setListenMode(true);
    speakToken++;
    if(synth)try{synth.cancel()}catch(_){}
    active=false;paused=false;
    speak();
  });

  document.addEventListener('visibilitychange',()=>{
    save();
    if(document.visibilityState==='visible'&&listenMode)requestWake();
  });
  window.addEventListener('pagehide',()=>{save();speakToken++;setListenMode(false)});
  window.addEventListener('beforeunload',()=>{speakToken++;setListenMode(false)});

  if(synth){
    try{synth.getVoices()}catch(_){}
    try{synth.addEventListener?.('voiceschanged',()=>synth.getVoices())}catch(_){}
  }
  if(new URLSearchParams(location.search).get('listen')==='1'){
    setListenMode(true);startAtViewport();
  }
  sync();
})();

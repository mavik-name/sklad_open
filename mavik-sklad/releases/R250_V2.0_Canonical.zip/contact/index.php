<?php
declare(strict_types=1);
$root=dirname(__DIR__);
require_once $root.'/_site-admin/contact-page.php';
mavik_contact_render($root,'uk');

<?php
declare(strict_types=1);
require_once __DIR__.'/state.php';
require_once __DIR__.'/core.php';
require_once __DIR__.'/mail-client.php';
require_once __DIR__.'/contact-inbox.php';

function mavik_contact_h(string $s): string {return htmlspecialchars($s,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');}
class MavikContactUserError extends RuntimeException {}
function mavik_contact_rate_file(string $root): string {
  $ip=(string)($_SERVER['REMOTE_ADDR']??'unknown');
  return mavik_state_dir($root).'/contact-rate/'.hash('sha256',$ip).'.json';
}
function mavik_contact_rate_check(string $root,bool $consume=false): void {
  $f=mavik_contact_rate_file($root);$now=time();$window=15*60;$max=5;$raw=is_file($f)?@file_get_contents($f):false;$j=$raw?json_decode($raw,true):null;$hits=[];
  foreach((array)($j['hits']??[]) as $t){$t=(int)$t;if($t>$now-$window&&$t<=$now)$hits[]=$t;}
  if(count($hits)>=$max)throw new MavikContactUserError('Забагато повідомлень за короткий час. Спробуйте трохи пізніше.');
  if($consume){$hits[]=$now;$dir=dirname($f);if(!is_dir($dir))@mkdir($dir,0700,true);@file_put_contents($f,json_encode(['hits'=>$hits]),LOCK_EX);@chmod($f,0600);}
}
function mavik_contact_handle(string $root): array {
  if(session_status()!==PHP_SESSION_ACTIVE){session_name('mavik_contact');session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off'),'httponly'=>true,'samesite'=>'Lax']);session_start();}
  if(empty($_SESSION['contact_csrf']))$_SESSION['contact_csrf']=bin2hex(random_bytes(24));
  if(empty($_SESSION['contact_form_time']))$_SESSION['contact_form_time']=time();
  $out=['ok'=>false,'error'=>'','values'=>['name'=>'','email'=>'','subject'=>'','message'=>'']];
  if(($_SERVER['REQUEST_METHOD']??'GET')!=='POST')return $out;
  $out['values']=['name'=>trim((string)($_POST['name']??'')),'email'=>trim((string)($_POST['email']??'')),'subject'=>trim((string)($_POST['subject']??'')),'message'=>trim((string)($_POST['message']??''))];
  try{
    if(!hash_equals((string)$_SESSION['contact_csrf'],(string)($_POST['csrf']??'')))throw new MavikContactUserError('Сесія форми застаріла. Оновіть сторінку й спробуйте ще раз.');
    if(trim((string)($_POST['website']??''))!=='')throw new MavikContactUserError('Spam rejected.');
    $ft=(int)($_POST['form_time']??0);if($ft<=0||time()-$ft<2||time()-$ft>7200)throw new MavikContactUserError('Оновіть сторінку й спробуйте ще раз.');
    $name=preg_replace('/[\r\n]+/u',' ',$out['values']['name'])??$out['values']['name'];$email=$out['values']['email'];$subject=preg_replace('/[\r\n]+/u',' ',$out['values']['subject'])??$out['values']['subject'];$message=$out['values']['message'];
    if($name===''||strlen($name)>120)throw new MavikContactUserError('Вкажіть, будь ласка, ім’я.');
    if(!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($email)>190)throw new MavikContactUserError('Вкажіть коректну адресу електронної пошти.');
    if($subject==='')$subject='Повідомлення з mavik.name';if(strlen($subject)>180)$subject=substr($subject,0,180);
    if(strlen($message)<3||strlen($message)>12000)throw new MavikContactUserError('Повідомлення має містити від 3 до 12 000 символів.');
    mavik_contact_rate_check($root,false);$to='site@mavik.name';
    // Primary delivery is the protected Boss inbox. E-mail is a best-effort backup copy.
    $stored=mavik_contact_inbox_store($root,['name'=>$name,'email'=>$email,'subject'=>$subject,'message'=>$message,'lang'=>'uk']);
    $body="Повідомлення з контактної форми mavik.name

Ім’я: $name
Email: $email
Тема: $subject

".$message;
    try{mavik_mail_send($root,['to'=>$to,'subject'=>'[mavik.name] '.$subject,'body'=>$body,'reply_to'=>$email,'reply_name'=>$name]);mavik_contact_inbox_patch($root,(string)$stored['id'],['mail_backup_sent'=>true]);}
    catch(Throwable $mailError){$log=mavik_state_dir($root).'/contact-errors.log';@file_put_contents($log,date(DATE_ATOM).' '.str_replace(["\r","\n"],' ', $mailError->getMessage())."\n",FILE_APPEND|LOCK_EX);@chmod($log,0600);}
    mavik_contact_rate_check($root,true);$out['ok']=true;$out['values']=['name'=>'','email'=>'','subject'=>'','message'=>''];$_SESSION['contact_csrf']=bin2hex(random_bytes(24));$_SESSION['contact_form_time']=time();
  }catch(Throwable $e){$out['error']=$e->getMessage();}
  return $out;
}
function mavik_contact_render(string $root,string $lang='uk'): void {
  $state=mavik_contact_handle($root);$canonical='https://mavik.name/contact/';$home='/';
  $title='Контакт · MaVik';$desc='Написати Макарчуку Віктору / MaVik. Відгуки читачів, запитання та зауваження.';$heading='Контакт';
  $intro='<p><strong>Дякую, що захотіли написати.</strong> Для мене це справді важливо. Сайт існує не лише як місце, де лежать книжки й тексти, а й як можливість чути тих, хто їх читає.</p><p>Відгук, запитання, зауваження, кілька слів після прочитаного — усе це допомагає розуміти, що по той бік екрана є жива людина. Іноді навіть одне коротке повідомлення має значно більше значення, ніж може здаватися.</p><p>Тож пишіть. Прочитаю обов’язково.</p>';
  $v=$state['values'];$csrf=(string)($_SESSION['contact_csrf']??'');$formTime=(int)($_SESSION['contact_form_time']??time());$menuHtml=mavik_core_menu_links_html($root,mavik_core_load($root),'/contact/');
  header('Content-Type: text/html; charset=UTF-8');
?><!doctype html><html lang="uk-UA"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="robots" content="index,follow,max-image-preview:large"><title><?=mavik_contact_h($title)?></title><meta name="description" content="<?=mavik_contact_h($desc)?>"><link rel="canonical" href="<?=$canonical?>"><link rel="icon" href="/favicon.ico"><link rel="stylesheet" href="/assets/app/site-shell.css?v=250v20c3"><link rel="stylesheet" href="/assets/app/footer-clean.css?v=250v20c3"><link rel="stylesheet" href="/assets/app/discovery.css?v=250v20c3"><link rel="stylesheet" href="/assets/app/static-pages.css?v=250v20c3"><link rel="stylesheet" href="/assets/app/global-system.css?v=250v20c3"><link rel="stylesheet" href="/assets/app/contact.css?v=250v20c3"><script type="application/ld+json">{"@context":"https://schema.org","@type":"ContactPage","name":"Контакт","url":"https://mavik.name/contact/","isPartOf":{"@id":"https://mavik.name/#website"},"about":{"@id":"https://mavik.name/#person"}}</script></head><body><header class="mavik-site-header"><div class="mavik-site-head-inner"><a class="mavik-site-brand" href="/" aria-label="MaVik"><img src="/assets/brand/mavik-mvv-gold.svg" alt="MVV" width="1876" height="1876"><span class="mavik-site-brand-copy"><strong>MaVik</strong><span>МАКАРЧУК ВІКТОР</span></span></a><nav class="mavik-site-desktop-nav" aria-label="Головне меню"><?=$menuHtml?></nav><button class="mavik-site-mobile-toggle" type="button" aria-expanded="false" aria-controls="mavikMobileMenu" aria-label="Відкрити меню"><i></i><i></i><i></i></button></div><nav class="mavik-site-mobile-menu" id="mavikMobileMenu" aria-hidden="true"><div class="mavik-site-mobile-inner"><?=$menuHtml?></div></nav></header><main class="mavik-global-page wrap contact-page"><section class="contact-intro"><div class="eyebrow">MaVik</div><h1><?=mavik_contact_h($heading)?></h1><div class="contact-copy"><?=$intro?></div></section><section class="contact-form-card" aria-labelledby="contact-form-title"><h2 id="contact-form-title">Написати повідомлення</h2><?php if($state['ok']):?><div class="contact-notice success" role="status">Дякую. Повідомлення надіслано.</div><?php elseif($state['error']!==''):?><div class="contact-notice error" role="alert"><?=mavik_contact_h($state['error'])?></div><?php endif;?><form method="post" action="" class="contact-form"><input type="hidden" name="csrf" value="<?=mavik_contact_h($csrf)?>"><input type="hidden" name="form_time" value="<?=$formTime?>"><div class="contact-hp" aria-hidden="true"><label>Сайт<input type="text" name="website" tabindex="-1" autocomplete="off"></label></div><label>Ваше ім’я<input name="name" maxlength="120" autocomplete="name" required value="<?=mavik_contact_h((string)$v['name'])?>"></label><label>Електронна пошта<input type="email" name="email" maxlength="190" autocomplete="email" required value="<?=mavik_contact_h((string)$v['email'])?>"></label><label>Тема<input name="subject" maxlength="180" value="<?=mavik_contact_h((string)$v['subject'])?>" placeholder="Необов’язково"></label><label>Повідомлення<textarea name="message" minlength="3" maxlength="12000" rows="9" required><?=mavik_contact_h((string)$v['message'])?></textarea></label><div class="contact-form-foot"><button class="contact-submit" type="submit">Надіслати повідомлення</button><p>Ваша електронна адреса використовується лише для відповіді на це повідомлення.</p></div></form></section></main><footer><span class="footer-copy-row">© 2026 · Макарчук Віктор — MaVik®<br>Всі права застережено.</span><span class="footer-legal-row"><a class="footer-legal-link" href="/copyright/">Правова охорона творчого доробку</a> · <a class="footer-legal-link" href="/privacy/">Приватність</a></span></footer><script defer src="/assets/app/site-shell.js?v=250v20c3"></script></body></html><?php
}

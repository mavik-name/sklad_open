<?php
declare(strict_types=1);
require_once __DIR__.'/utf8.php';

function mavik_mail_state_file(string $root): string { return mavik_state_path($root,'mail-client.json'); }
function mavik_mail_key_file(string $root): string { return mavik_state_path($root,'mail-client.key'); }
function mavik_mail_key(string $root): string {
  $f=mavik_mail_key_file($root);
  if(is_file($f)){$k=@file_get_contents($f);if(is_string($k)&&strlen($k)===32)return $k;}
  $k=random_bytes(32);if(@file_put_contents($f,$k,LOCK_EX)===false)throw new RuntimeException('Не вдалося створити ключ для поштових налаштувань.');@chmod($f,0600);return $k;
}
function mavik_mail_encrypt(string $root,string $plain): string {
  if($plain==='')return '';$key=mavik_mail_key($root);
  if(function_exists('sodium_crypto_secretbox')){$nonce=random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);return 'sodium:'.base64_encode($nonce.sodium_crypto_secretbox($plain,$nonce,$key));}
  if(function_exists('openssl_encrypt')){$iv=random_bytes(12);$tag='';$ct=openssl_encrypt($plain,'aes-256-gcm',$key,OPENSSL_RAW_DATA,$iv,$tag);if($ct===false)throw new RuntimeException('Не вдалося зашифрувати пароль пошти.');return 'gcm:'.base64_encode($iv.$tag.$ct);}
  throw new RuntimeException('На сервері немає Sodium або OpenSSL для безпечного збереження пароля пошти.');
}
function mavik_mail_decrypt(string $root,string $sealed): string {
  if($sealed==='')return '';$key=mavik_mail_key($root);
  if(str_starts_with($sealed,'sodium:')){$raw=base64_decode(substr($sealed,7),true);if($raw===false||strlen($raw)<=SODIUM_CRYPTO_SECRETBOX_NONCEBYTES)return '';$nonce=substr($raw,0,SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);$pt=sodium_crypto_secretbox_open(substr($raw,SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),$nonce,$key);return $pt===false?'':$pt;}
  if(str_starts_with($sealed,'gcm:')){$raw=base64_decode(substr($sealed,4),true);if($raw===false||strlen($raw)<29)return '';$iv=substr($raw,0,12);$tag=substr($raw,12,16);$pt=openssl_decrypt(substr($raw,28),'aes-256-gcm',$key,OPENSSL_RAW_DATA,$iv,$tag);return $pt===false?'':$pt;}
  return '';
}
function mavik_mail_config_load(string $root,bool $withPassword=true): array {
  $defaults=['email'=>'site@mavik.name','sender_name'=>'MaVik','imap_host'=>'mx1.cityhost.com.ua','imap_port'=>993,'imap_security'=>'ssl','smtp_host'=>'mx1.cityhost.com.ua','smtp_port'=>587,'smtp_security'=>'starttls','username'=>'','password_sealed'=>'','webmail_url'=>'https://mx1.cityhost.com.ua/mail/'];
  $f=mavik_mail_state_file($root);$raw=is_file($f)?@file_get_contents($f):false;$j=$raw?json_decode($raw,true):null;if(is_array($j))$defaults=array_replace($defaults,$j);
  $defaults['password']=$withPassword?mavik_mail_decrypt($root,(string)($defaults['password_sealed']??'')):'';unset($defaults['password_sealed']);return $defaults;
}
function mavik_mail_config_save(string $root,array $in): void {
  $email=trim((string)($in['email']??''));if($email!==''&&!filter_var($email,FILTER_VALIDATE_EMAIL))throw new RuntimeException('Некоректна адреса поштової скриньки.');
  $username=trim((string)($in['username']??''));if($username==='')$username=$email;
  $imapSec=in_array(($in['imap_security']??''),['ssl','starttls','none'],true)?(string)$in['imap_security']:'ssl';$smtpSec=in_array(($in['smtp_security']??''),['ssl','starttls','none'],true)?(string)$in['smtp_security']:'starttls';
  $old=mavik_mail_config_load($root,true);$password=(string)($in['password']??'');if($password==='')$password=(string)($old['password']??'');
  $data=['version'=>1,'email'=>$email,'sender_name'=>trim((string)($in['sender_name']??'MaVik'))?:'MaVik','imap_host'=>trim((string)($in['imap_host']??'mx1.cityhost.com.ua')),'imap_port'=>max(1,min(65535,(int)($in['imap_port']??993))),'imap_security'=>$imapSec,'smtp_host'=>trim((string)($in['smtp_host']??'mx1.cityhost.com.ua')),'smtp_port'=>max(1,min(65535,(int)($in['smtp_port']??587))),'smtp_security'=>$smtpSec,'username'=>$username,'password_sealed'=>mavik_mail_encrypt($root,$password),'webmail_url'=>trim((string)($in['webmail_url']??'https://mx1.cityhost.com.ua/mail/')),'updated_at'=>date(DATE_ATOM)];
  $f=mavik_mail_state_file($root);if(@file_put_contents($f,json_encode($data,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES),LOCK_EX)===false)throw new RuntimeException('Не вдалося зберегти налаштування пошти.');@chmod($f,0640);
}
function mavik_mail_imap_mailbox(array $cfg,string $folder='INBOX'): string {
  $host=(string)$cfg['imap_host'];$port=(int)$cfg['imap_port'];$sec=(string)$cfg['imap_security'];$flags='/imap';if($sec==='ssl')$flags.='/ssl';elseif($sec==='starttls')$flags.='/tls';else $flags.='/notls';return '{'.$host.':'.$port.$flags.'}'.$folder;
}
function mavik_mail_php_imap_available(): bool { return function_exists('imap_open'); }
function mavik_mail_raw_imap_available(): bool { return function_exists('stream_socket_client')&&function_exists('stream_socket_enable_crypto'); }
function mavik_mail_imap_available(): bool { return mavik_mail_php_imap_available()||mavik_mail_raw_imap_available(); }
function mavik_mail_imap_backend(): string { return mavik_mail_php_imap_available()?'PHP IMAP':(mavik_mail_raw_imap_available()?'вбудований TLS IMAP':'недоступний'); }
function mavik_mail_unread_count(string $root): int {
  $c=mavik_mail_config_load($root,true);if(($c['email']??'')===''||($c['password']??'')==='')return 0;
  if(mavik_mail_php_imap_available()){
    $mb=mavik_mail_open($root,'INBOX');try{$ids=@imap_search($mb,'UNSEEN',SE_UID);return is_array($ids)?count($ids):0;}finally{@imap_close($mb);}
  }
  $cn=mavik_mail_raw_connect($root,'INBOX');try{$r=mavik_mail_raw_command($cn,'UID SEARCH UNSEEN');if(!preg_match('/^\\* SEARCH(?:\\s+(.*))?$/mi',$r,$m))return 0;$line=trim((string)($m[1]??''));if($line==='')return 0;$ids=preg_split('/\\s+/', $line, -1, PREG_SPLIT_NO_EMPTY)?:[];return count(array_filter($ids,static fn($v)=>ctype_digit((string)$v)));}finally{mavik_mail_raw_close($cn);}
}
function mavik_mail_open(string $root,string $folder='INBOX') {
  if(!mavik_mail_php_imap_available())throw new RuntimeException('PHP IMAP не активований; буде використано вбудований TLS IMAP там, де він підтримується.');
  $c=mavik_mail_config_load($root,true);if(($c['email']??'')===''||($c['password']??'')==='')throw new RuntimeException('Спочатку збережи адресу скриньки та пароль у налаштуваннях пошти.');$mb=@imap_open(mavik_mail_imap_mailbox($c,$folder),(string)$c['username'],(string)$c['password'],0,1,['DISABLE_AUTHENTICATOR'=>'GSSAPI']);if(!$mb)throw new RuntimeException('IMAP: '.(imap_last_error()?:'не вдалося підключитися.'));return $mb;
}
function mavik_mail_decode_header(string $s): string {
  if($s==='')return '';
  if(function_exists('imap_mime_header_decode')){$out='';foreach(imap_mime_header_decode($s)?:[] as $x)$out.=(string)($x->text??'');return $out;}
  if(function_exists('iconv_mime_decode')){$v=@iconv_mime_decode($s,ICONV_MIME_DECODE_CONTINUE_ON_ERROR,'UTF-8');if(is_string($v)&&$v!=='')return $v;}
  return preg_replace_callback('/=\?([^?]+)\?([bqBQ])\?([^?]*)\?=/',static function($m){$x=strtoupper($m[2])==='B'?(base64_decode($m[3],true)?:''):quoted_printable_decode(str_replace('_',' ',$m[3]));if(function_exists('iconv')&&strcasecmp($m[1],'UTF-8')!==0){$y=@iconv($m[1],'UTF-8//IGNORE',$x);if(is_string($y))$x=$y;}return $x;},$s)??$s;
}
function mavik_mail_address_string($a): string { if(!$a)return '';if(is_array($a)){$out=[];foreach($a as $x){$mail=((string)($x->mailbox??'')).'@'.((string)($x->host??''));$name=mavik_mail_decode_header((string)($x->personal??''));$out[]=$name!==''?$name.' <'.$mail.'>':$mail;}return implode(', ',$out);}return ''; }
function mavik_mail_raw_quote(string $s): string { return '"'.str_replace(['\\','"'],['\\\\','\\"'],$s).'"'; }
function mavik_mail_raw_read_exact($fp,int $n): string {$out='';while(strlen($out)<$n&&!feof($fp)){$x=fread($fp,$n-strlen($out));if($x===false||$x==='')break;$out.=$x;}return $out;}
function mavik_mail_raw_response(array &$cn,string $tag): string {
  $fp=$cn['fp'];$all='';while(!feof($fp)){$line=fgets($fp,16384);if($line===false)break;$all.=$line;if(preg_match('/\{(\d+)\}\r?\n$/',$line,$m)){$all.=mavik_mail_raw_read_exact($fp,(int)$m[1]);continue;}if(str_starts_with($line,$tag.' '))return $all;}throw new RuntimeException('IMAP: сервер закрив з’єднання без відповіді.');
}
function mavik_mail_raw_command(array &$cn,string $cmd,array $ok=['OK']): string {
  $tag='A'.str_pad((string)$cn['seq']++,4,'0',STR_PAD_LEFT);if(@fwrite($cn['fp'],$tag.' '.$cmd."\r\n")===false)throw new RuntimeException('IMAP: не вдалося надіслати команду.');$r=mavik_mail_raw_response($cn,$tag);$status='';if(preg_match('/^'.preg_quote($tag,'/').'\s+([A-Z]+)/mi',$r,$m))$status=strtoupper($m[1]);if(!in_array($status,$ok,true)){$msg=preg_replace('/\s+/',' ',trim($r))??trim($r);throw new RuntimeException('IMAP '.$status.': '.substr($msg,0,500));}return $r;
}
function mavik_mail_raw_connect(string $root,?string $folder='INBOX'): array {
  if(!mavik_mail_raw_imap_available())throw new RuntimeException('На сервері недоступні PHP IMAP і TLS sockets.');$c=mavik_mail_config_load($root,true);if(($c['email']??'')===''||($c['password']??'')==='')throw new RuntimeException('Спочатку збережи адресу скриньки та пароль у налаштуваннях пошти.');$host=(string)$c['imap_host'];$port=(int)$c['imap_port'];$sec=(string)$c['imap_security'];$remote=($sec==='ssl'?'ssl://':'tcp://').$host.':'.$port;$ctx=stream_context_create(['ssl'=>['verify_peer'=>true,'verify_peer_name'=>true,'SNI_enabled'=>true,'peer_name'=>$host]]);$fp=@stream_socket_client($remote,$eno,$estr,15,STREAM_CLIENT_CONNECT,$ctx);if(!$fp)throw new RuntimeException('IMAP: '.$estr.' ('.$eno.')');stream_set_timeout($fp,20);$g=fgets($fp,16384);if($g===false||!preg_match('/^\*\s+(OK|PREAUTH)/i',$g)){@fclose($fp);throw new RuntimeException('IMAP: некоректне привітання сервера.');}$cn=['fp'=>$fp,'seq'=>1];try{if($sec==='starttls'){mavik_mail_raw_command($cn,'STARTTLS');if(!@stream_socket_enable_crypto($fp,true,STREAM_CRYPTO_METHOD_TLS_CLIENT))throw new RuntimeException('IMAP: не вдалося увімкнути STARTTLS.');}mavik_mail_raw_command($cn,'LOGIN '.mavik_mail_raw_quote((string)$c['username']).' '.mavik_mail_raw_quote((string)$c['password']));if($folder!==null)mavik_mail_raw_command($cn,'SELECT '.mavik_mail_raw_quote($folder));return $cn;}catch(Throwable $e){@fclose($fp);throw $e;}
}
function mavik_mail_raw_close(array &$cn): void {if(isset($cn['fp'])&&is_resource($cn['fp'])){try{mavik_mail_raw_command($cn,'LOGOUT',['OK','BYE']);}catch(Throwable $e){}@fclose($cn['fp']);}$cn=[];}
function mavik_mail_raw_first_literal(string $r): string {if(!preg_match('/\{(\d+)\}\r?\n/',$r,$m,PREG_OFFSET_CAPTURE))return '';$n=(int)$m[1][0];$start=$m[0][1]+strlen($m[0][0]);return substr($r,$start,$n);}
function mavik_mail_raw_headers(string $raw): array {$raw=str_replace("\r\n","\n",$raw);$raw=preg_replace("/\n[ \t]+/",' ',$raw)??$raw;$out=[];foreach(explode("\n",$raw) as $line){$p=strpos($line,':');if($p===false)continue;$k=strtolower(trim(substr($line,0,$p)));$v=trim(substr($line,$p+1));if($k==='')continue;$out[$k]=isset($out[$k])?$out[$k].', '.$v:$v;}return $out;}
function mavik_mail_raw_unquote(string $s): string {$s=trim($s);if(strlen($s)>=2&&$s[0]==='"'&&$s[strlen($s)-1]==='"')$s=substr($s,1,-1);return str_replace(['\\"','\\\\'],['"','\\'],$s);}
function mavik_mail_list_folders(string $root): array {
  if(mavik_mail_php_imap_available()){$mb=mavik_mail_open($root,'INBOX');$c=mavik_mail_config_load($root,false);$base='{'.$c['imap_host'].':'.$c['imap_port'].'/imap'.($c['imap_security']==='ssl'?'/ssl':($c['imap_security']==='starttls'?'/tls':'/notls')).'}';$boxes=@imap_getmailboxes($mb,$base,'*')?:[];$out=[];foreach($boxes as $b){$name=(string)$b->name;$short=str_starts_with($name,$base)?substr($name,strlen($base)):$name;$decoded=mavik_mail_decode_header($short);$out[]=['id'=>$short,'label'=>mavik_mail_folder_label_uk($short,$decoded)];}@imap_close($mb);return $out?:[['id'=>'INBOX','label'=>'Вхідні']];}
  $cn=mavik_mail_raw_connect($root,null);try{$r=mavik_mail_raw_command($cn,'LIST "" "*"');$out=[];foreach(preg_split('/\r?\n/',$r)?:[] as $line){if(!preg_match('/^\*\s+LIST\s+\([^)]*\)\s+(?:"[^"]*"|NIL)\s+(".*"|[^\s]+)$/i',$line,$m))continue;$name=mavik_mail_raw_unquote(trim($m[1]));if($name==='')continue;$decoded=mavik_mail_decode_header($name);$out[]=['id'=>$name,'label'=>mavik_mail_folder_label_uk($name,$decoded)];}return $out?:[['id'=>'INBOX','label'=>'Вхідні']];}finally{mavik_mail_raw_close($cn);}
}
function mavik_mail_list(string $root,string $folder='INBOX',int $limit=40): array {
  if(mavik_mail_php_imap_available()){$mb=mavik_mail_open($root,$folder);$uids=@imap_sort($mb,SORTDATE,1,SE_UID)?:[];$uids=array_slice($uids,0,max(1,min(100,$limit)));$out=[];if($uids){$ovs=@imap_fetch_overview($mb,implode(',',$uids),FT_UID)?:[];foreach($ovs as $o){$out[]=['uid'=>(int)($o->uid??0),'subject'=>mavik_mail_decode_header((string)($o->subject??'(без теми)')),'from'=>mavik_mail_decode_header((string)($o->from??'')),'date'=>(string)($o->date??''),'seen'=>!empty($o->seen),'answered'=>!empty($o->answered),'size'=>(int)($o->size??0)];}}@imap_close($mb);return $out;}
  $cn=mavik_mail_raw_connect($root,$folder);try{$r=mavik_mail_raw_command($cn,'UID SEARCH ALL');$uids=[];if(preg_match('/^\* SEARCH(.*)$/mi',$r,$m))foreach(preg_split('/\s+/',trim($m[1]))?:[] as $u)if(ctype_digit($u))$uids[]=(int)$u;$uids=array_slice(array_reverse($uids),0,max(1,min(100,$limit)));$out=[];foreach($uids as $uid){$fr=mavik_mail_raw_command($cn,'UID FETCH '.$uid.' (FLAGS RFC822.SIZE BODY.PEEK[HEADER.FIELDS (SUBJECT FROM DATE MESSAGE-ID)])');$hdr=mavik_mail_raw_headers(mavik_mail_raw_first_literal($fr));preg_match('/FLAGS\s+\(([^)]*)\)/i',$fr,$fm);preg_match('/RFC822\.SIZE\s+(\d+)/i',$fr,$sm);$flags=$fm[1]??'';$out[]=['uid'=>$uid,'subject'=>mavik_mail_decode_header((string)($hdr['subject']??'(без теми)')),'from'=>mavik_mail_decode_header((string)($hdr['from']??'')),'date'=>(string)($hdr['date']??''),'seen'=>stripos($flags,'\\Seen')!==false,'answered'=>stripos($flags,'\\Answered')!==false,'size'=>(int)($sm[1]??0)];}return $out;}finally{mavik_mail_raw_close($cn);}
}
function mavik_mail_decode_body(string $body,int $enc): string {return match($enc){3=>(base64_decode($body,true)?:''),4=>quoted_printable_decode($body),default=>$body};}
function mavik_mail_find_body($mb,int $uid,$st, string $prefix=''): array {$plain='';$html='';$attachments=[];$parts=isset($st->parts)&&is_array($st->parts)?$st->parts:[];if(!$parts){$raw=(string)@imap_fetchbody($mb,(string)$uid,'1',FT_UID|FT_PEEK);$text=mavik_mail_decode_body($raw,(int)($st->encoding??0));if((int)($st->subtype??0)===0)$plain=$text;else $plain=$text;return [$plain,$html,$attachments];}
  foreach($parts as $i=>$p){$sec=$prefix===''?(string)($i+1):$prefix.'.'.($i+1);$disp=strtolower((string)($p->disposition??''));$filename='';foreach(array_merge((array)($p->dparameters??[]),(array)($p->parameters??[])) as $par){$attr=strtolower((string)($par->attribute??''));if($attr==='filename'||$attr==='name')$filename=mavik_mail_decode_header((string)($par->value??''));}
    if(isset($p->parts)&&is_array($p->parts)){[$pl,$ht,$at]=mavik_mail_find_body($mb,$uid,$p,$sec);if($plain===''&&$pl!=='')$plain=$pl;if($html===''&&$ht!=='')$html=$ht;$attachments=array_merge($attachments,$at);continue;}
    $raw=(string)@imap_fetchbody($mb,(string)$uid,$sec,FT_UID|FT_PEEK);$decoded=mavik_mail_decode_body($raw,(int)($p->encoding??0));$type=(int)($p->type??0);$sub=strtoupper((string)($p->subtype??''));if($filename!==''||$disp==='attachment'){$attachments[]=['section'=>$sec,'name'=>$filename!==''?$filename:'attachment-'.$sec,'bytes'=>strlen($decoded),'mime'=>($type===0?'text':($type===2?'message':'application')).'/'.strtolower($sub)];continue;}if($type===0&&$sub==='PLAIN'&&$plain==='')$plain=$decoded;elseif($type===0&&$sub==='HTML'&&$html==='')$html=$decoded;
  }return [$plain,$html,$attachments];}
function mavik_mail_sanitize_message_html(string $html): string {$html=preg_replace('#<(script|style|iframe|object|embed|form|input|button)[^>]*>.*?</\\1>#si','',$html)??$html;$html=preg_replace("#\\son[a-z]+\\s*=\\s*([\\\"']).*?\\1#si",'',$html)??$html;$html=preg_replace("#\\s(src|href)\\s*=\\s*([\\\"'])\\s*javascript:.*?\\2#si",'',$html)??$html;return $html;}
function mavik_mail_raw_split_entity(string $raw): array {$p=preg_split('/\r?\n\r?\n/',$raw,2);return [$p[0]??'',$p[1]??''];}
function mavik_mail_raw_header_params(string $v): array {$parts=preg_split('/;\s*/',$v)?:[];$main=strtolower(trim((string)array_shift($parts)));$params=[];foreach($parts as $x){$p=strpos($x,'=');if($p===false)continue;$k=strtolower(trim(substr($x,0,$p)));$val=mavik_mail_raw_unquote(trim(substr($x,$p+1)));if(str_ends_with($k,'*')){$k=rtrim($k,'*');if(preg_match("/^([^']*)'[^']*'(.*)$/",$val,$m))$val=rawurldecode($m[2]);}$params[$k]=mavik_mail_decode_header($val);}return [$main,$params];}
function mavik_mail_raw_decode_transfer(string $body,string $cte): string {$cte=strtolower(trim($cte));if($cte==='base64')return base64_decode(preg_replace('/\s+/','',$body)??$body,true)?:'';if($cte==='quoted-printable')return quoted_printable_decode($body);return $body;}
function mavik_mail_raw_to_utf8(string $s,string $charset): string {$charset=trim($charset," \t\r\n\"'");if($charset===''||strcasecmp($charset,'UTF-8')===0)return $s;if(function_exists('mb_convert_encoding')){try{return mb_convert_encoding($s,'UTF-8',$charset);}catch(Throwable $e){}}if(function_exists('iconv')){$x=@iconv($charset,'UTF-8//IGNORE',$s);if(is_string($x))return $x;}return $s;}
function mavik_mail_raw_parse_entity(string $raw,string $path,array &$acc): void {[$head,$body]=mavik_mail_raw_split_entity($raw);$h=mavik_mail_raw_headers($head);[$ctype,$cp]=mavik_mail_raw_header_params((string)($h['content-type']??'text/plain; charset=UTF-8'));[$disp,$dp]=mavik_mail_raw_header_params((string)($h['content-disposition']??''));$filename=(string)($dp['filename']??$cp['name']??'');if(str_starts_with($ctype,'multipart/')&&isset($cp['boundary'])&&$cp['boundary']!==''){$chunks=explode('--'.$cp['boundary'],$body);$n=0;foreach($chunks as $chunk){$chunk=ltrim($chunk,"\r\n");if($chunk===''||str_starts_with($chunk,'--'))continue;$chunk=preg_replace('/\r?\n$/','',$chunk)??$chunk;$n++;mavik_mail_raw_parse_entity($chunk,$path.'.'.$n,$acc);}return;}$data=mavik_mail_raw_decode_transfer($body,(string)($h['content-transfer-encoding']??''));$charset=(string)($cp['charset']??'UTF-8');if(str_starts_with($ctype,'text/'))$data=mavik_mail_raw_to_utf8($data,$charset);$isAttachment=$filename!==''||$disp==='attachment';if($isAttachment){$name=$filename!==''?$filename:'attachment-'.str_replace('.','-',$path);$acc['attachments'][]=['section'=>'raw-'.$path,'name'=>$name,'bytes'=>strlen($data),'mime'=>$ctype!==''?$ctype:'application/octet-stream','_data'=>$data];return;}if($ctype==='text/plain'&&$acc['plain']==='')$acc['plain']=$data;elseif($ctype==='text/html'&&$acc['html']==='')$acc['html']=$data;}
function mavik_mail_raw_parse_message(string $raw): array {[$head,$body]=mavik_mail_raw_split_entity($raw);$h=mavik_mail_raw_headers($head);$acc=['plain'=>'','html'=>'','attachments'=>[]];mavik_mail_raw_parse_entity($raw,'1',$acc);return [$h,$acc];}
function mavik_mail_read(string $root,string $folder,int $uid): array {
  if(mavik_mail_php_imap_available()){$mb=mavik_mail_open($root,$folder);$h=@imap_headerinfo($mb,(int)@imap_msgno($mb,$uid));$st=@imap_fetchstructure($mb,$uid,FT_UID);if(!$h||!$st){@imap_close($mb);throw new RuntimeException('Лист не знайдено.');}[$plain,$html,$attachments]=mavik_mail_find_body($mb,$uid,$st);@imap_setflag_full($mb,(string)$uid,'\\Seen',ST_UID);$msg=['uid'=>$uid,'subject'=>mavik_mail_decode_header((string)($h->subject??'(без теми)')),'from'=>mavik_mail_address_string($h->from??[]),'to'=>mavik_mail_address_string($h->to??[]),'date'=>(string)($h->date??''),'message_id'=>(string)($h->message_id??''),'in_reply_to'=>(string)($h->in_reply_to??''),'plain'=>$plain,'html'=>$html!==''?mavik_mail_sanitize_message_html($html):'','attachments'=>$attachments];@imap_close($mb);return $msg;}
  $cn=mavik_mail_raw_connect($root,$folder);try{$fr=mavik_mail_raw_command($cn,'UID FETCH '.$uid.' (BODY.PEEK[])');$raw=mavik_mail_raw_first_literal($fr);if($raw==='')throw new RuntimeException('Лист не знайдено.');[$h,$acc]=mavik_mail_raw_parse_message($raw);try{mavik_mail_raw_command($cn,'UID STORE '.$uid.' +FLAGS.SILENT (\\Seen)');}catch(Throwable $e){}$ats=[];foreach($acc['attachments'] as $a){unset($a['_data']);$ats[]=$a;}return ['uid'=>$uid,'subject'=>mavik_mail_decode_header((string)($h['subject']??'(без теми)')),'from'=>mavik_mail_decode_header((string)($h['from']??'')),'to'=>mavik_mail_decode_header((string)($h['to']??'')),'date'=>(string)($h['date']??''),'message_id'=>(string)($h['message-id']??''),'in_reply_to'=>(string)($h['in-reply-to']??''),'plain'=>$acc['plain'],'html'=>$acc['html']!==''?mavik_mail_sanitize_message_html($acc['html']):'','attachments'=>$ats];}finally{mavik_mail_raw_close($cn);}
}
function mavik_mail_attachment(string $root,string $folder,int $uid,string $section): array {
  if(mavik_mail_php_imap_available()){$mb=mavik_mail_open($root,$folder);$st=@imap_fetchstructure($mb,$uid,FT_UID);if(!$st){@imap_close($mb);throw new RuntimeException('Лист не знайдено.');}[$pl,$ht,$ats]=mavik_mail_find_body($mb,$uid,$st);$target=null;foreach($ats as $a)if(($a['section']??'')===$section){$target=$a;break;}if(!$target){@imap_close($mb);throw new RuntimeException('Вкладення не знайдено.');}$raw=(string)@imap_fetchbody($mb,(string)$uid,$section,FT_UID|FT_PEEK);$parts=explode('.',$section);$p=$st;foreach($parts as $idx){$n=(int)$idx-1;if(!isset($p->parts[$n]))break;$p=$p->parts[$n];}$data=mavik_mail_decode_body($raw,(int)($p->encoding??0));@imap_close($mb);return ['name'=>(string)$target['name'],'mime'=>(string)$target['mime'],'data'=>$data];}
  $cn=mavik_mail_raw_connect($root,$folder);try{$fr=mavik_mail_raw_command($cn,'UID FETCH '.$uid.' (BODY.PEEK[])');$raw=mavik_mail_raw_first_literal($fr);if($raw==='')throw new RuntimeException('Лист не знайдено.');[, $acc]=mavik_mail_raw_parse_message($raw);foreach($acc['attachments'] as $a)if(($a['section']??'')===$section)return ['name'=>(string)$a['name'],'mime'=>(string)$a['mime'],'data'=>(string)($a['_data']??'')];throw new RuntimeException('Вкладення не знайдено.');}finally{mavik_mail_raw_close($cn);}
}

function mavik_mail_delete(string $root,string $folder,int $uid): void {
  if($uid<1)throw new RuntimeException('Некоректний UID листа.');
  if(str_contains($folder,"\0"))throw new RuntimeException('Некоректна папка пошти.');
  if(mavik_mail_php_imap_available()){
    $mb=mavik_mail_open($root,$folder);
    try{
      if(!@imap_delete($mb,(string)$uid,FT_UID))throw new RuntimeException('IMAP: не вдалося позначити лист для видалення.');
      if(!@imap_expunge($mb))throw new RuntimeException('IMAP: не вдалося завершити видалення листа.');
    }finally{@imap_close($mb);}
    return;
  }
  $cn=mavik_mail_raw_connect($root,$folder);
  try{
    mavik_mail_raw_command($cn,'UID STORE '.$uid.' +FLAGS.SILENT (\\Deleted)');
    mavik_mail_raw_command($cn,'EXPUNGE');
  }finally{mavik_mail_raw_close($cn);}
}
function mavik_mail_smtp_read($fp): string {
  $all='';
  while(($line=fgets($fp,8192))!==false){$all.=$line;if(strlen($line)<4||$line[3]!=='-')break;}
  return $all;
}
function mavik_mail_smtp_cmd($fp,string $cmd,array $ok): string {
  if($cmd!==''&&@fwrite($fp,$cmd."\r\n")===false)throw new RuntimeException('SMTP: не вдалося передати команду.');
  $r=mavik_mail_smtp_read($fp);$code=(int)substr($r,0,3);
  if(!in_array($code,$ok,true))throw new RuntimeException('SMTP '.$code.': '.trim($r));
  return $r;
}
function mavik_mail_header_encode(string $s): string {return '=?UTF-8?B?'.base64_encode($s).'?=';}
function mavik_mail_parse_addresses(string $raw): array {
  $parts=preg_split('/[\s,;]+/u',trim($raw),-1,PREG_SPLIT_NO_EMPTY)?:[];$out=[];$seen=[];
  foreach($parts as $part){
    $email=trim((string)$part," \t\n\r\0\x0B<>\"");
    if($email===''||!filter_var($email,FILTER_VALIDATE_EMAIL))throw new RuntimeException('Некоректна адреса: '.$part);
    $key=strtolower($email);if(isset($seen[$key]))continue;$seen[$key]=1;$out[]=$email;
  }
  return $out;
}
function mavik_mail_cut(string $s,int $max): string {return mavik_utf8_substr($s,0,$max);}
function mavik_mail_extract_email(string $raw): string {
  if(preg_match('/<([^<>\s]+@[^<>\s]+)>/u',$raw,$m)&&filter_var($m[1],FILTER_VALIDATE_EMAIL))return strtolower($m[1]);
  if(preg_match('/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/iu',$raw,$m)&&filter_var($m[0],FILTER_VALIDATE_EMAIL))return strtolower($m[0]);
  return '';
}
function mavik_mail_extract_name(string $raw,string $email): string {
  $name=trim(str_replace(['<'.$email.'>',$email], '', $raw)," \t\n\r\0\x0B\"'");
  $name=preg_replace('/\s+/u',' ',$name)??$name;
  return mavik_mail_cut($name,160);
}
function mavik_mail_folder_label_uk(string $id,string $label=''): string {
  $src=trim($label!==''?$label:$id);
  if(strcasecmp($src,'INBOX')===0||preg_match('/(^|[.\/ _-])inbox$/iu',$src))return 'Вхідні';
  if(preg_match('/sent|sent items|sent messages|надіслан|відправлен|отправлен/iu',$src))return 'Надіслані';
  if(preg_match('/draft|чернет/iu',$src))return 'Чернетки';
  if(preg_match('/junk|spam|спам/iu',$src))return 'Спам';
  if(preg_match('/trash|deleted|bin|кошик|видален/iu',$src))return 'Кошик';
  if(preg_match('/archive|архів/iu',$src))return 'Архів';
  return $label!==''?$label:$id;
}
function mavik_mail_find_sent_folder(string $root): string {
  try{$folders=mavik_mail_list_folders($root);}catch(Throwable $e){return '';}
  foreach($folders as $f){$id=(string)($f['id']??'');$label=(string)($f['label']??'');$src=$id.' '.$label;if(preg_match('/(^|[.\/ _-])(sent|sent items|sent messages)([.\/ _-]|$)|надіслан|відправлен|отправлен/iu',$src))return $id;}
  return '';
}
function mavik_mail_raw_append_message(string $root,string $folder,string $message): void {
  $cn=mavik_mail_raw_connect($root,null);$fp=$cn['fp'];$tag='A'.str_pad((string)$cn['seq']++,4,'0',STR_PAD_LEFT);$cmd=$tag.' APPEND '.mavik_mail_raw_quote($folder).' (\\Seen) {'.strlen($message)."}\r\n";
  try{
    if(@fwrite($fp,$cmd)===false)throw new RuntimeException('IMAP: не вдалося почати збереження у «Надіслані».');
    $line=fgets($fp,16384);if($line===false)throw new RuntimeException('IMAP: немає відповіді на APPEND.');
    if(!str_starts_with($line,'+')){if(str_starts_with($line,$tag.' '))throw new RuntimeException('IMAP: '.trim($line));throw new RuntimeException('IMAP: сервер не прийняв APPEND.');}
    if(@fwrite($fp,$message."\r\n")===false)throw new RuntimeException('IMAP: не вдалося передати копію листа.');
    $r=mavik_mail_raw_response($cn,$tag);if(!preg_match('/^'.preg_quote($tag,'/').'\s+OK\b/mi',$r))throw new RuntimeException('IMAP: копію листа не збережено.');
  }finally{mavik_mail_raw_close($cn);}
}
function mavik_mail_append_sent(string $root,string $message): bool {
  $folder=mavik_mail_find_sent_folder($root);if($folder==='')return false;
  try{
    if(mavik_mail_php_imap_available()){$c=mavik_mail_config_load($root,true);$mb=mavik_mail_open($root,'INBOX');try{return (bool)@imap_append($mb,mavik_mail_imap_mailbox($c,$folder),$message,"\\Seen");}finally{@imap_close($mb);}}
    mavik_mail_raw_append_message($root,$folder,$message);return true;
  }catch(Throwable $e){return false;}
}

function mavik_mail_html_sanitize(string $html): string {
  $html=trim($html);if($html==='')return '';$html=preg_replace('#<(script|style|iframe|object|embed|form|input|button)[^>]*>.*?</\\1>#si','',$html)??$html;$html=strip_tags($html,'<p><div><h2><h3><br><strong><b><em><i><u><ul><ol><li><blockquote><a><span>');
  $html=preg_replace_callback('#<([a-z0-9]+)\\b([^>]*)>#i',static function($m){$tag=strtolower((string)$m[1]);$attrs=(string)$m[2];if($tag==='a'){$href='';if(preg_match('/\\bhref\\s*=\\s*(["\\\'])(.*?)\\1/i',$attrs,$hm))$href=trim((string)$hm[2]);if($href!==''&&(preg_match('#^https?://#i',$href)||preg_match('#^mailto:#i',$href)))return '<a href="'.htmlspecialchars($href,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8').'" target="_blank" rel="noopener noreferrer">';return '<a>';}if($tag==='span'){$class='';if(preg_match('/\\bclass\\s*=\\s*(["\\\'])(.*?)\\1/i',$attrs,$cm))$class=(string)$cm[2];$styles=[];foreach(preg_split('/\\s+/',trim($class))?:[] as $c){if($c==='mavik-text-gold')$styles[]='color:#b38738';elseif($c==='mavik-text-light')$styles[]='color:#d0d0d0';elseif($c==='mavik-text-black')$styles[]='color:#111111';elseif($c==='mavik-text-white')$styles[]='color:#ffffff';elseif($c==='mavik-bg-gold')$styles[]='background-color:#d7b46a';elseif($c==='mavik-bg-light')$styles[]='background-color:#d8d8d8';}return '<span'.($styles?' style="'.implode(';',$styles).'"':'').'>';}return '<'.$tag.'>';},$html)??$html;
  $html=preg_replace('/<(p|div)>\\s*<\\/\\1>/i','',$html)??$html;return trim($html);
}
function mavik_mail_html_to_text(string $html): string {$html=mavik_mail_html_sanitize($html);if($html==='')return '';$html=preg_replace('#<br\\s*/?>#i',"\n",$html)??$html;$html=preg_replace('#</(p|div|li|blockquote)>#i',"\n",$html)??$html;$html=preg_replace('#<li>#i','• ',$html)??$html;$text=html_entity_decode(strip_tags($html),ENT_QUOTES|ENT_HTML5,'UTF-8');$text=preg_replace("/[ \\t]+\\n/u","\n",$text)??$text;$text=preg_replace("/\\n{3,}/u","\n\n",$text)??$text;return trim($text);}

/* Persistent address book in protected /_site-state/. */
function mavik_mail_contacts_file(string $root): string {return mavik_state_path($root,'mail-address-book.json');}
function mavik_mail_contacts_load(string $root): array {
  $f=mavik_mail_contacts_file($root);$raw=is_file($f)?@file_get_contents($f):false;$j=$raw?json_decode($raw,true):null;
  if(!is_array($j)||!is_array($j['items']??null))$j=['version'=>1,'items'=>[]];
  return $j;
}
function mavik_mail_contacts_write(string $root,array $data): void {
  $data['version']=1;$data['updated_at']=date(DATE_ATOM);mavik_core_atomic_write(mavik_mail_contacts_file($root),json_encode($data,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
}
function mavik_mail_contacts_list(string $root): array {
  $j=mavik_mail_contacts_load($root);$items=array_values(array_filter((array)$j['items'],'is_array'));
  usort($items,static function($a,$b){$x=strcmp((string)($b['last_used']??$b['updated_at']??''),(string)($a['last_used']??$a['updated_at']??''));if($x!==0)return $x;return strcasecmp((string)($a['name']??$a['email']??''),(string)($b['name']??$b['email']??''));});
  return $items;
}
function mavik_mail_contact_touch(string $root,string $email,string $name='',bool $sent=false,string $source='manual'): void {
  $email=strtolower(trim($email));if(!filter_var($email,FILTER_VALIDATE_EMAIL))return;$name=trim($name);$now=date(DATE_ATOM);$j=mavik_mail_contacts_load($root);$found=false;
  foreach($j['items'] as &$item){if(!is_array($item)||strtolower((string)($item['email']??''))!==$email)continue;$item['email']=$email;if($name!==''&&trim((string)($item['name']??''))==='')$item['name']=$name;$item['updated_at']=$now;$item['last_used']=$now;$item['last_source']=$source;$item['attempt_count']=(int)($item['attempt_count']??0)+($source==='send'?1:0);if($sent)$item['send_count']=(int)($item['send_count']??0)+1;$found=true;break;}unset($item);
  if(!$found)$j['items'][]=['id'=>'contact-'.substr(hash('sha256',$email),0,16),'email'=>$email,'name'=>$name,'created_at'=>$now,'updated_at'=>$now,'last_used'=>$now,'last_source'=>$source,'attempt_count'=>$source==='send'?1:0,'send_count'=>$sent?1:0];
  if(count($j['items'])>3000)$j['items']=array_slice($j['items'],-3000);mavik_mail_contacts_write($root,$j);
}
function mavik_mail_contact_save(string $root,string $email,string $name='',string $oldEmail=''): void {
  $email=strtolower(trim($email));$oldEmail=strtolower(trim($oldEmail));if(!filter_var($email,FILTER_VALIDATE_EMAIL))throw new RuntimeException('Некоректна адреса контакту.');$name=trim($name);$j=mavik_mail_contacts_load($root);$now=date(DATE_ATOM);$preserve=[];
  if($oldEmail!==''&&$oldEmail!==$email){foreach($j['items'] as $x)if(is_array($x)&&strtolower((string)($x['email']??''))===$oldEmail){$preserve=$x;break;}$j['items']=array_values(array_filter($j['items'],static fn($x)=>!is_array($x)||strtolower((string)($x['email']??''))!==$oldEmail));}
  $found=false;foreach($j['items'] as &$x){if(!is_array($x)||strtolower((string)($x['email']??''))!==$email)continue;$x=array_replace($preserve,$x,['email'=>$email,'name'=>$name,'updated_at'=>$now,'last_used'=>$now]);$found=true;break;}unset($x);
  if(!$found)$j['items'][]=array_replace(['id'=>'contact-'.substr(hash('sha256',$email),0,16),'created_at'=>$now,'attempt_count'=>0,'send_count'=>0],$preserve,['email'=>$email,'name'=>$name,'updated_at'=>$now,'last_used'=>$now]);
  mavik_mail_contacts_write($root,$j);
}
function mavik_mail_contact_delete(string $root,string $email): void {$email=strtolower(trim($email));if($email==='')return;$j=mavik_mail_contacts_load($root);$j['items']=array_values(array_filter($j['items'],static fn($x)=>!is_array($x)||strtolower((string)($x['email']??''))!==$email));mavik_mail_contacts_write($root,$j);}
function mavik_mail_contact_learn_from_string(string $root,string $raw): void {$email=mavik_mail_extract_email($raw);if($email==='')return;$name=mavik_mail_extract_name($raw,$email);mavik_mail_contact_touch($root,$email,$name,false,'incoming');}

/* Persistent send audit; body/attachments are deliberately not logged. */
function mavik_mail_send_log_file(string $root): string {return mavik_state_path($root,'mail-send-log.json');}
function mavik_mail_send_log_load(string $root): array {$f=mavik_mail_send_log_file($root);$raw=is_file($f)?@file_get_contents($f):false;$j=$raw?json_decode($raw,true):null;if(!is_array($j)||!is_array($j['batches']??null))$j=['version'=>1,'batches'=>[]];return $j;}
function mavik_mail_send_log_write(string $root,array $j): void {$j['version']=1;$j['updated_at']=date(DATE_ATOM);mavik_core_atomic_write(mavik_mail_send_log_file($root),json_encode($j,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));}
function mavik_mail_send_log_append(string $root,array $batch): void {$j=mavik_mail_send_log_load($root);$j['batches'][]=$batch;if(count($j['batches'])>200)$j['batches']=array_slice($j['batches'],-200);mavik_mail_send_log_write($root,$j);}
function mavik_mail_send_history(string $root): array {$j=mavik_mail_send_log_load($root);$x=array_values(array_filter((array)$j['batches'],'is_array'));usort($x,static fn($a,$b)=>strcmp((string)($b['created_at']??''),(string)($a['created_at']??'')));return $x;}

function mavik_mail_drafts_file(string $root): string {return mavik_state_path($root,'mail-drafts.json');}
function mavik_mail_drafts_load(string $root): array {$f=mavik_mail_drafts_file($root);$raw=is_file($f)?@file_get_contents($f):false;$j=$raw?json_decode($raw,true):null;if(!is_array($j)||!is_array($j['items']??null))$j=['version'=>1,'items'=>[]];return $j;}
function mavik_mail_drafts_write(string $root,array $data): void {$data['version']=1;$data['updated_at']=date(DATE_ATOM);mavik_core_atomic_write(mavik_mail_drafts_file($root),json_encode($data,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));}
function mavik_mail_drafts_list(string $root): array {$j=mavik_mail_drafts_load($root);$items=array_values(array_filter((array)$j['items'],'is_array'));usort($items,static fn($a,$b)=>strcmp((string)($b['updated_at']??''),(string)($a['updated_at']??'')));return $items;}
function mavik_mail_draft_get(string $root,string $id): ?array {$id=preg_replace('/[^A-Za-z0-9_-]/','',$id)??'';if($id==='')return null;foreach(mavik_mail_drafts_list($root) as $d)if((string)($d['id']??'')===$id)return $d;return null;}
function mavik_mail_draft_save(string $root,array $msg,string $id=''): string {foreach([(string)($msg['to']??''),(string)($msg['bcc']??'')] as $raw){if(preg_match_all('/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/iu',$raw,$mm))foreach((array)$mm[0] as $email)mavik_mail_contact_touch($root,(string)$email,'',false,'draft');}$id=preg_replace('/[^A-Za-z0-9_-]/','',$id)??'';$j=mavik_mail_drafts_load($root);$now=date(DATE_ATOM);$html=mavik_mail_html_sanitize((string)($msg['html']??''));$body=trim((string)($msg['body']??''));if($body===''&&$html!=='')$body=mavik_mail_html_to_text($html);$draft=['id'=>$id!==''?$id:'draft-'.date('Ymd-His').'-'.substr(bin2hex(random_bytes(4)),0,8),'to'=>trim((string)($msg['to']??'')),'bcc'=>trim((string)($msg['bcc']??'')),'subject'=>trim((string)($msg['subject']??'')),'body'=>$body,'html'=>$html,'in_reply_to'=>trim((string)($msg['in_reply_to']??'')),'created_at'=>$now,'updated_at'=>$now];$found=false;foreach((array)$j['items'] as $i=>$old)if(is_array($old)&&(string)($old['id']??'')===$draft['id']){$draft['created_at']=(string)($old['created_at']??$now);$j['items'][$i]=$draft;$found=true;break;}if(!$found)$j['items'][]=$draft;if(count($j['items'])>100)$j['items']=array_slice($j['items'],-100);mavik_mail_drafts_write($root,$j);foreach(array_merge(preg_split('/[\s,;]+/u',(string)$draft['to'],-1,PREG_SPLIT_NO_EMPTY)?:[],preg_split('/[\s,;]+/u',(string)$draft['bcc'],-1,PREG_SPLIT_NO_EMPTY)?:[]) as $addr){$addr=trim((string)$addr," \t\n\r\0\x0B<>\"");if(filter_var($addr,FILTER_VALIDATE_EMAIL))mavik_mail_contact_touch($root,$addr,'',false,'draft');}return (string)$draft['id'];}
function mavik_mail_draft_delete(string $root,string $id): void {$id=preg_replace('/[^A-Za-z0-9_-]/','',$id)??'';if($id==='')return;$j=mavik_mail_drafts_load($root);$j['items']=array_values(array_filter((array)$j['items'],static fn($d)=>!is_array($d)||(string)($d['id']??'')!==$id));mavik_mail_drafts_write($root,$j);}

function mavik_mail_prepare_attachment(array $upload): ?array {
  if(empty($upload['tmp_name'])||!is_uploaded_file((string)$upload['tmp_name']))return null;
  $bytes=@file_get_contents((string)$upload['tmp_name']);if($bytes===false)throw new RuntimeException('Не вдалося прочитати вкладення.');if(strlen($bytes)>12*1024*1024)throw new RuntimeException('Вкладення завелике (максимум 12 MB).');
  $name=preg_replace('/[^\p{L}\p{N}._ -]/u','_',basename((string)($upload['name']??'attachment')))?:'attachment';$mime=trim((string)($upload['type']??'application/octet-stream'))?:'application/octet-stream';
  return ['name'=>$name,'mime'=>$mime,'bytes'=>$bytes];
}
function mavik_mail_build_raw(array $c,string $recipient,string $subject,string $body,string $html,array $msg,?array $attachment=null,bool $hiddenRecipient=false): array {
  $mix='=_mavik_mix_'.bin2hex(random_bytes(10));$alt='=_mavik_alt_'.bin2hex(random_bytes(10));$messageId='<'.bin2hex(random_bytes(12)).'.'.time().'@mavik.name>';
  $toHeader=$hiddenRecipient?'undisclosed-recipients:;':'<'.$recipient.'>';
  $headers=['Date: '.date(DATE_RFC2822),'Message-ID: '.$messageId,'From: '.mavik_mail_header_encode((string)$c['sender_name']).' <'.$c['email'].'>','To: '.$toHeader,'Subject: '.mavik_mail_header_encode($subject!==''?$subject:'(без теми)'),'MIME-Version: 1.0'];
  $replyTo=trim((string)($msg['reply_to']??''));if($replyTo!==''&&filter_var($replyTo,FILTER_VALIDATE_EMAIL)){$replyName=trim((string)($msg['reply_name']??''));$headers[]='Reply-To: '.($replyName!==''?mavik_mail_header_encode($replyName).' ':'').'<'.$replyTo.'>';}$replyId=trim((string)($msg['in_reply_to']??''));if($replyId!==''){$headers[]='In-Reply-To: '.$replyId;$headers[]='References: '.$replyId;}
  $textPart="Content-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: quoted-printable\r\n\r\n".quoted_printable_encode($body)."\r\n";
  if($html!==''){$content="--$alt\r\n".$textPart."--$alt\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: quoted-printable\r\n\r\n".quoted_printable_encode($html)."\r\n--$alt--\r\n";$contentType='Content-Type: multipart/alternative; boundary="'.$alt.'"';}else{$content=quoted_printable_encode($body)."\r\n";$contentType="Content-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: quoted-printable";}
  if($attachment!==null){$headers[]='Content-Type: multipart/mixed; boundary="'.$mix.'"';$innerHeader=$html!==''?'Content-Type: multipart/alternative; boundary="'.$alt.'"':$contentType;$raw=implode("\r\n",$headers)."\r\n\r\n--$mix\r\n".$innerHeader."\r\n\r\n".$content;$raw.="--$mix\r\nContent-Type: ".$attachment['mime'].'; name="'.addcslashes((string)$attachment['name'],'"\\')."\"\r\nContent-Disposition: attachment; filename=\"".addcslashes((string)$attachment['name'],'"\\')."\"\r\nContent-Transfer-Encoding: base64\r\n\r\n".chunk_split(base64_encode((string)$attachment['bytes']))."\r\n--$mix--\r\n";}else{$headers[]=$contentType;$raw=implode("\r\n",$headers)."\r\n\r\n".$content;}
  return ['raw'=>$raw,'message_id'=>$messageId];
}
function mavik_mail_smtp_open_session(array $c) {
  $host=(string)$c['smtp_host'];$port=(int)$c['smtp_port'];$sec=(string)$c['smtp_security'];$remote=($sec==='ssl'?'ssl://':'').$host.':'.$port;$ctx=stream_context_create(['ssl'=>['verify_peer'=>true,'verify_peer_name'=>true,'SNI_enabled'=>true,'peer_name'=>$host]]);$fp=@stream_socket_client($remote,$eno,$estr,15,STREAM_CLIENT_CONNECT,$ctx);if(!$fp)throw new RuntimeException('SMTP: '.$estr.' ('.$eno.')');stream_set_timeout($fp,20);
  try{mavik_mail_smtp_cmd($fp,'',[220]);mavik_mail_smtp_cmd($fp,'EHLO mavik.name',[250]);if($sec==='starttls'){mavik_mail_smtp_cmd($fp,'STARTTLS',[220]);if(!stream_socket_enable_crypto($fp,true,STREAM_CRYPTO_METHOD_TLS_CLIENT))throw new RuntimeException('SMTP: не вдалося увімкнути TLS.');mavik_mail_smtp_cmd($fp,'EHLO mavik.name',[250]);}mavik_mail_smtp_cmd($fp,'AUTH LOGIN',[334]);mavik_mail_smtp_cmd($fp,base64_encode((string)$c['username']),[334]);mavik_mail_smtp_cmd($fp,base64_encode((string)$c['password']),[235]);return $fp;}catch(Throwable $e){@fclose($fp);throw $e;}
}
function mavik_mail_smtp_send_transaction($fp,array $c,string $recipient,string $raw): string {
  mavik_mail_smtp_cmd($fp,'MAIL FROM:<'.$c['email'].'>',[250]);mavik_mail_smtp_cmd($fp,'RCPT TO:<'.$recipient.'>',[250,251]);mavik_mail_smtp_cmd($fp,'DATA',[354]);$wire=preg_replace('/(?m)^\./','..',$raw)??$raw;if(@fwrite($fp,$wire."\r\n.\r\n")===false)throw new RuntimeException('SMTP: не вдалося передати лист.');$r=mavik_mail_smtp_read($fp);$code=(int)substr($r,0,3);if($code!==250)throw new RuntimeException('SMTP '.$code.': '.trim($r));return trim(preg_replace('/\s+/',' ',$r)??$r);
}
class MavikMailRecipientException extends RuntimeException {public string $messageId;public function __construct(string $message,string $messageId=''){parent::__construct($message);$this->messageId=$messageId;}}
function mavik_mail_batch_execute(array $recipients,callable $sender): array {
  $results=[];foreach($recipients as $entry){$email=(string)($entry['email']??'');$role=(string)($entry['role']??'to');try{$x=$sender($email,$role);$results[]=array_merge(['email'=>$email,'role'=>$role,'status'=>'accepted'],is_array($x)?$x:[]);}catch(Throwable $e){$mid=$e instanceof MavikMailRecipientException?$e->messageId:'';$results[]=['email'=>$email,'role'=>$role,'status'=>'failed','message_id'=>$mid,'smtp_result'=>mavik_mail_cut($e->getMessage(),500),'sent_saved'=>false,'timestamp'=>date(DATE_ATOM)];}}return $results;
}
function mavik_mail_send(string $root,array $msg,array $upload=[]): array {
  @set_time_limit(0);@ignore_user_abort(true);
  $c=mavik_mail_config_load($root,true);if(($c['email']??'')===''||($c['password']??'')==='')throw new RuntimeException('Спочатку налаштуй поштову скриньку.');
  $to=mavik_mail_parse_addresses((string)($msg['to']??''));if(!$to)throw new RuntimeException('Вкажіть хоча б одну адресу одержувача.');$bcc=mavik_mail_parse_addresses((string)($msg['bcc']??''));$allSeen=[];$targets=[];foreach($to as $email){$key=strtolower($email);if(isset($allSeen[$key]))continue;$allSeen[$key]=1;$targets[]=['email'=>$email,'role'=>'to'];}foreach($bcc as $email){$key=strtolower($email);if(isset($allSeen[$key]))continue;$allSeen[$key]=1;$targets[]=['email'=>$email,'role'=>'bcc'];}
  $subject=trim((string)($msg['subject']??''));$html=mavik_mail_html_sanitize((string)($msg['html']??''));$body=trim((string)($msg['body']??''));if($body===''&&$html!=='')$body=mavik_mail_html_to_text($html);if($body===''&&$html==='')throw new RuntimeException('Напишіть текст листа.');$attachment=mavik_mail_prepare_attachment($upload);$batchId='mail-'.date('Ymd-His').'-'.substr(bin2hex(random_bytes(5)),0,10);$fp=null;
  $results=mavik_mail_batch_execute($targets,function(string $recipient,string $role)use($root,$c,$subject,$body,$html,$msg,$attachment,&$fp){
    $built=mavik_mail_build_raw($c,$recipient,$subject,$body,$html,$msg,$attachment,$role==='bcc');
    try{if(!is_resource($fp)||feof($fp))$fp=mavik_mail_smtp_open_session($c);$smtp=mavik_mail_smtp_send_transaction($fp,$c,$recipient,(string)$built['raw']);}
    catch(Throwable $e){if(is_resource($fp)){@fwrite($fp,"RSET\r\n");@fclose($fp);}$fp=null;throw new MavikMailRecipientException($e->getMessage(),(string)$built['message_id']);}
    $saved=mavik_mail_append_sent($root,(string)$built['raw']);
    return ['message_id'=>(string)$built['message_id'],'smtp_result'=>$smtp,'sent_saved'=>$saved,'timestamp'=>date(DATE_ATOM)];
  });
  if(is_resource($fp)){@fwrite($fp,"QUIT\r\n");@fclose($fp);}
  foreach($results as $rr)if(is_array($rr))mavik_mail_contact_touch($root,(string)($rr['email']??''),'',($rr['status']??'')==='accepted','send');
  $accepted=count(array_filter($results,static fn($x)=>($x['status']??'')==='accepted'));$failed=count($results)-$accepted;$sentSaved=count(array_filter($results,static fn($x)=>!empty($x['sent_saved'])));$batch=['batch_id'=>$batchId,'created_at'=>date(DATE_ATOM),'subject'=>$subject!==''?$subject:'(без теми)','total'=>count($results),'accepted'=>$accepted,'failed'=>$failed,'sent_saved'=>$sentSaved,'results'=>$results];mavik_mail_send_log_append($root,$batch);
  $failedRecipients=array_values(array_map(static fn($x)=>(string)($x['email']??''),array_filter($results,static fn($x)=>($x['status']??'')==='failed')));return ['ok'=>$accepted>0,'batch_id'=>$batchId,'total'=>count($results),'accepted'=>$accepted,'failed'=>$failed,'failed_recipients'=>$failedRecipients,'sent_saved'=>$sentSaved,'recipients'=>count($to),'bcc'=>count($bcc),'results'=>$results];
}
function mavik_mail_test(string $root): array {$c=mavik_mail_config_load($root,true);$out=['imap'=>false,'smtp'=>false,'imap_message'=>'','smtp_message'=>''];try{if(mavik_mail_php_imap_available()){$mb=mavik_mail_open($root,'INBOX');@imap_close($mb);}else{$cn=mavik_mail_raw_connect($root,'INBOX');mavik_mail_raw_close($cn);}$out['imap']=true;$out['imap_message']='IMAP підключено · '.mavik_mail_imap_backend();}catch(Throwable $e){$out['imap_message']=$e->getMessage();}try{$fp=mavik_mail_smtp_open_session($c);$out['smtp']=true;$out['smtp_message']='SMTP підключено';@fwrite($fp,"QUIT\r\n");@fclose($fp);}catch(Throwable $e){$out['smtp_message']='SMTP: '.$e->getMessage();}return $out;}

<?php
declare(strict_types=1);
require_once __DIR__.'/utf8.php';

/*
 * MAVIK SEO / ROBOT AUDIT
 * Secrets are stored only in /_site-state/ and never in release ZIP.
 */

function mavik_seo_state_file(string $root): string { return $root.'/_site-state/seo-tools.json'; }
function mavik_seo_expected_release(string $root): string {$f=$root.'/.mavik-release.json';$raw=is_file($f)?@file_get_contents($f):false;$j=$raw?json_decode($raw,true):null;$label=is_array($j)?trim((string)($j['release_label']??'')):'';return $label!==''?strtoupper($label):'';}
function mavik_seo_utf8_clip(string $s,int $n): string {return mavik_seo_strlen($s)<=$n?$s:mavik_utf8_substr($s,0,$n).'…';}
function mavik_seo_heading_looks_like_prose(string $text): bool {$text=trim(preg_replace('/\s+/u',' ',html_entity_decode(strip_tags($text),ENT_QUOTES|ENT_HTML5,'UTF-8'))??$text);$len=mavik_seo_strlen($text);$sent=preg_match_all('/[.!?…](?:\s|$)/u',$text,$m)?:0;return ($len>120&&$sent>=3)||$len>220;}

function mavik_seo_load(string $root): array {
  $f=mavik_seo_state_file($root);
  $raw=is_file($f)?file_get_contents($f):false;
  $j=$raw?json_decode($raw,true):null;
  if(!is_array($j))$j=[];
  return [
    'bing_api_key'=>(string)($j['bing_api_key']??''),
    'last_scan'=>is_array($j['last_scan']??null)?$j['last_scan']:null,
    'last_indexnow'=>is_array($j['last_indexnow']??null)?$j['last_indexnow']:null,
  ];
}
function mavik_seo_save(string $root,array $j): void {
  $dir=$root.'/_site-state';
  if(!is_dir($dir)&&!mkdir($dir,0755,true)&&!is_dir($dir))throw new RuntimeException('Не вдалося створити _site-state.');
  $f=mavik_seo_state_file($root);
  $tmp=$f.'.tmp-'.bin2hex(random_bytes(4));
  if(file_put_contents($tmp,json_encode($j,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES),LOCK_EX)===false)throw new RuntimeException('Не вдалося записати SEO state.');
  @chmod($tmp,0600);
  if(!rename($tmp,$f)){@unlink($tmp);throw new RuntimeException('Не вдалося зберегти SEO state.');}
}
function mavik_seo_save_bing_key(string $root,string $key): void {
  $key=trim($key);
  if($key!==''&&!preg_match('/^[A-Za-z0-9_-]{16,256}$/',$key))throw new RuntimeException('Bing API key має неочікуваний формат.');
  $s=mavik_seo_load($root);$s['bing_api_key']=$key;mavik_seo_save($root,$s);
}
function mavik_seo_http(string $url,string $method='GET',?string $body=null,array $headers=[],int $timeout=12,string $userAgent='MaVikSiteAudit/2.0 (+https://mavik.name/)'): array {
  $result=['status'=>0,'body'=>'','content_type'=>'','final_url'=>$url,'error'=>'','headers'=>[],'time_ms'=>0,'redirect_count'=>0,'primary_ip'=>''];$started=microtime(true);
  if(function_exists('curl_init')){
    $respHeaders=[];$ch=curl_init($url);
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_MAXREDIRS=>5,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>$timeout,CURLOPT_USERAGENT=>$userAgent,CURLOPT_ENCODING=>'',CURLOPT_HEADERFUNCTION=>static function($ch,string $line)use(&$respHeaders): int {$len=strlen($line);$line=trim($line);if($line===''||str_starts_with(strtoupper($line),'HTTP/'))return $len;$pos=strpos($line,':');if($pos!==false){$k=strtolower(trim(substr($line,0,$pos)));$v=trim(substr($line,$pos+1));if(isset($respHeaders[$k]))$respHeaders[$k].=', '.$v;else$respHeaders[$k]=$v;}return $len;}]);
    if($method!=='GET'){curl_setopt($ch,CURLOPT_CUSTOMREQUEST,$method);if($body!==null)curl_setopt($ch,CURLOPT_POSTFIELDS,$body);}
    if($headers)curl_setopt($ch,CURLOPT_HTTPHEADER,$headers);
    $raw=curl_exec($ch);$result['error']=curl_error($ch);$result['status']=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);$result['content_type']=(string)curl_getinfo($ch,CURLINFO_CONTENT_TYPE);$result['final_url']=(string)curl_getinfo($ch,CURLINFO_EFFECTIVE_URL);$result['redirect_count']=(int)curl_getinfo($ch,CURLINFO_REDIRECT_COUNT);$result['primary_ip']=(string)curl_getinfo($ch,CURLINFO_PRIMARY_IP);$result['body']=is_string($raw)?$raw:'';$result['headers']=$respHeaders;$result['time_ms']=(int)round((float)curl_getinfo($ch,CURLINFO_TOTAL_TIME)*1000);curl_close($ch);return $result;
  }
  $headerLines=$headers;$headerLines[]='User-Agent: '.$userAgent;$ctx=stream_context_create(['http'=>['method'=>$method,'timeout'=>$timeout,'ignore_errors'=>true,'follow_location'=>1,'max_redirects'=>5,'header'=>implode("\r\n",$headerLines)."\r\n",'content'=>$body??'']]);$raw=@file_get_contents($url,false,$ctx);$result['body']=is_string($raw)?$raw:'';$resp=[];foreach((array)($http_response_header??[]) as $h){if(preg_match('#^HTTP/\S+\s+(\d+)#i',$h,$m))$result['status']=(int)$m[1];elseif(($pos=strpos($h,':'))!==false){$k=strtolower(trim(substr($h,0,$pos)));$v=trim(substr($h,$pos+1));$resp[$k]=isset($resp[$k])?$resp[$k].', '.$v:$v;}}$result['headers']=$resp;$result['content_type']=(string)($resp['content-type']??'');$result['time_ms']=(int)round((microtime(true)-$started)*1000);return $result;
}
function mavik_seo_abs_url(string $href,string $base): string {
  $href=trim(html_entity_decode($href,ENT_QUOTES|ENT_HTML5,'UTF-8'));
  if($href===''||str_starts_with($href,'#')||preg_match('#^(mailto:|tel:|javascript:|data:)#i',$href))return '';
  if(preg_match('#^https?://#i',$href))return $href;
  $b=parse_url($base);if(!$b||empty($b['host']))return '';
  $scheme=$b['scheme']??'https';$host=$b['host'];$port=isset($b['port'])?':'.$b['port']:'';
  if(str_starts_with($href,'//'))return $scheme.':'.$href;
  if(str_starts_with($href,'/'))$path=$href;
  else{$dir=preg_replace('#/[^/]*$#','/',(string)($b['path']??'/'))??'/';$path=$dir.$href;}
  $parts=[];foreach(explode('/',$path) as $seg){if($seg===''||$seg==='.')continue;if($seg==='..'){array_pop($parts);continue;}$parts[]=$seg;}
  $path='/'.implode('/',$parts);if(str_ends_with(parse_url($href,PHP_URL_PATH)??'','/'))$path.='/';
  $q=parse_url($href,PHP_URL_QUERY);return $scheme.'://'.$host.$port.$path.($q!==null?'?'.$q:'');
}
function mavik_seo_canonicalize(string $url): string {
  $p=parse_url($url);if(!$p||empty($p['host']))return '';
  $scheme=strtolower((string)($p['scheme']??'https'));$host=strtolower((string)$p['host']);
  $path=(string)($p['path']??'/');if($path==='')$path='/';
  return $scheme.'://'.$host.$path.(isset($p['query'])?'?'.$p['query']:'');
}
function mavik_seo_tag_attrs(string $tag): array {
  $out=[];if(preg_match_all('/([:\w-]+)\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s>]+))/u',$tag,$m,PREG_SET_ORDER)){foreach($m as $a){$k=strtolower((string)($a[1]??''));$v=(string)($a[2]??'');if($v==='')$v=(string)($a[3]??'');if($v==='')$v=(string)($a[4]??'');if($k!=='')$out[$k]=html_entity_decode($v,ENT_QUOTES|ENT_HTML5,'UTF-8');}}return $out;
}
function mavik_seo_parse_html(string $html,string $url): array {
  $out=['title'=>'','description'=>'','h1'=>0,'canonical'=>'','noindex'=>false,'links'=>[]];
  if(class_exists('DOMDocument')){
    $dom=new DOMDocument();libxml_use_internal_errors(true);@$dom->loadHTML($html,LIBXML_NOWARNING|LIBXML_NOERROR);libxml_clear_errors();
    $ts=$dom->getElementsByTagName('title');if($ts->length)$out['title']=trim((string)$ts->item(0)->textContent);
    $out['h1']=$dom->getElementsByTagName('h1')->length;
    foreach($dom->getElementsByTagName('meta') as $m){$name=strtolower((string)$m->getAttribute('name'));if($name==='robots'&&str_contains(strtolower((string)$m->getAttribute('content')),'noindex'))$out['noindex']=true;if($name==='description')$out['description']=trim((string)$m->getAttribute('content'));}
    foreach($dom->getElementsByTagName('link') as $l){if(strtolower((string)$l->getAttribute('rel'))==='canonical')$out['canonical']=mavik_seo_abs_url((string)$l->getAttribute('href'),$url);}
    foreach($dom->getElementsByTagName('a') as $a){$u=mavik_seo_abs_url((string)$a->getAttribute('href'),$url);if($u!=='')$out['links'][]=$u;}
  } else {
    if(preg_match('#<title[^>]*>(.*?)</title>#is',$html,$m))$out['title']=trim(html_entity_decode(strip_tags($m[1]),ENT_QUOTES|ENT_HTML5,'UTF-8'));
    preg_match_all('#<h1\b#i',$html,$m);$out['h1']=count($m[0]);
    preg_match_all('#<meta\b[^>]*>#i',$html,$mm);foreach($mm[0]??[] as $tag){$a=mavik_seo_tag_attrs((string)$tag);$name=strtolower(trim((string)($a['name']??'')));if($name==='robots'&&str_contains(strtolower((string)($a['content']??'')),'noindex'))$out['noindex']=true;if($name==='description')$out['description']=trim((string)($a['content']??''));}
    preg_match_all('#<link\b[^>]*>#i',$html,$lm);foreach($lm[0]??[] as $tag){$a=mavik_seo_tag_attrs((string)$tag);if(strtolower(trim((string)($a['rel']??'')))==='canonical'&&!empty($a['href'])){$out['canonical']=mavik_seo_abs_url((string)$a['href'],$url);break;}}
    preg_match_all('#<a\b[^>]*>#i',$html,$am);foreach($am[0]??[] as $tag){$a=mavik_seo_tag_attrs((string)$tag);if(empty($a['href']))continue;$u=mavik_seo_abs_url((string)$a['href'],$url);if($u!=='')$out['links'][]=$u;}
  }
  $out['links']=array_values(array_unique($out['links']));return $out;
}
function mavik_seo_local_itemlist_count(string $file): ?int {
  if(!is_file($file))return null;$html=@file_get_contents($file);if(!is_string($html))return null;preg_match_all('#<script\b[^>]*type=["\']application/ld\+json["\'][^>]*>(.*?)</script>#si',$html,$m);$best=null;
  $walk=function($node)use(&$walk,&$best){if(!is_array($node))return;if(($node['@type']??'')==='ItemList'){$n=isset($node['numberOfItems'])?(int)$node['numberOfItems']:count((array)($node['itemListElement']??[]));$best=$best===null?$n:max($best,$n);}foreach($node as $v)if(is_array($v))$walk($v);};
  foreach($m[1]??[] as $raw){$j=json_decode(trim((string)$raw),true);if(is_array($j))$walk($j);}return $best;
}
function mavik_seo_local_consistency(string $root,array $manifest): array {
  $books=[];$final=[];$new=[];$missingCovers=[];$issues=[];foreach((array)($manifest['books']??[]) as $b){if(!is_array($b)||!empty($b['deleted'])||!empty($b['hidden'])||(string)($b['placement']??'books')!=='books')continue;$books[]=$b;if((string)($b['publication_mode']??'final')==='final')$final[]=$b;if(!empty($b['is_new']))$new[]=$b;$cover=trim((string)($b['cover_catalog']??''));if($cover===''||!is_file($root.'/'.ltrim((string)(parse_url($cover,PHP_URL_PATH)??$cover),'/'))) $missingCovers[]=(string)($b['slug']??$b['title']??'книга');}
  $booksSchema=mavik_seo_local_itemlist_count($root.'/books/index.html');$newSchema=mavik_seo_local_itemlist_count($root.'/books/new/index.html');$freeSchema=mavik_seo_local_itemlist_count($root.'/books/free/index.html');
  if($booksSchema!==null&&$booksSchema!==count($books))$issues[]='Каталог: state '.count($books).' ≠ JSON-LD '.$booksSchema;
  if($newSchema!==null&&$newSchema!==count($new))$issues[]='Новинки: state '.count($new).' ≠ JSON-LD '.$newSchema;
  if($freeSchema!==null&&$freeSchema!==count($final))$issues[]='Завершені: state '.count($final).' ≠ /books/free JSON-LD '.$freeSchema;
  if($missingCovers)$issues[]='Відсутні файли обкладинок: '.implode(', ',array_slice($missingCovers,0,8)).(count($missingCovers)>8?'…':'');
  $sitemap=@file_get_contents($root.'/sitemap.xml');if(is_string($sitemap)){foreach((array)($manifest['books']??[]) as $b){if(!is_array($b)||!empty($b['deleted'])||!empty($b['hidden'])||($slug=(string)($b['slug']??''))==='')continue;$landing='https://mavik.name/books/'.$slug.'/';if(!str_contains($sitemap,'<loc>'.$landing.'</loc>'))$issues[]='Немає в sitemap: '.$landing;if((string)($b['placement']??'books')==='books'){$reader='https://mavik.name/books/'.$slug.'/read/';$isFinal=(string)($b['publication_mode']??'final')==='final';$hasReader=is_file($root.'/books/'.$slug.'/read/index.html');$hasReaderInMap=str_contains($sitemap,'<loc>'.$reader.'</loc>');if($isFinal&&$hasReader&&!$hasReaderInMap)$issues[]='Завершена читанка не в sitemap: '.$reader;if(!$isFinal&&$hasReaderInMap)$issues[]='Бета-читанка помилково в sitemap: '.$reader;$rf=$root.'/books/'.$slug.'/read/index.html';if($hasReader){$html=(string)@file_get_contents($rf);$noindex=(bool)preg_match('#<meta\b[^>]*name=["\']robots["\'][^>]*content=["\'][^"\']*noindex#i',$html);if($isFinal&&$noindex)$issues[]='Завершена читанка має noindex: '.$reader;if(!$isFinal&&!$noindex)$issues[]='Бета-читанка має index: '.$reader;if(!preg_match('#<link\b[^>]*rel=["\']canonical["\'][^>]*href=["\']'.preg_quote($reader,'#').'["\']#i',$html))$issues[]='Canonical читанки не збігається: '.$reader;}$epub=$root.'/downloads/'.$slug.'.epub';if($isFinal&&!is_file($epub))$issues[]='Немає EPUB завершеної книги: '.$slug;if(!$isFinal&&is_file($epub))$issues[]='Бета-книга має EPUB: '.$slug;}}}
  $indexNow=mavik_indexnow_key($root)!=='';if(!$indexNow)$issues[]='IndexNow key file не знайдено або не збігається';$state=mavik_seo_load($root);$bing=trim((string)($state['bing_api_key']??''))!=='';if(!$bing)$issues[]='Bing API key не налаштований';
  return ['issues'=>array_values(array_unique($issues)),'books_state'=>count($books),'final_books_state'=>count($final),'books_jsonld'=>$booksSchema,'free_books_jsonld'=>$freeSchema,'new_state'=>count($new),'new_jsonld'=>$newSchema,'missing_covers'=>$missingCovers,'indexnow_ready'=>$indexNow,'bing_ready'=>$bing];
}

function mavik_seo_strlen(string $s): int {if(function_exists('mb_strlen'))return mb_strlen($s,'UTF-8');$m=[];return preg_match_all('/./us',$s,$m)?:strlen($s);}
function mavik_seo_static_url_from_file(string $root,string $file): string {
  $root=rtrim(str_replace('\\','/',$root),'/').'/';$file=str_replace('\\','/',$file);if(!str_starts_with($file,$root))return '';$rel=substr($file,strlen($root));
  if($rel==='index.html')return 'https://mavik.name/';if(str_ends_with($rel,'/index.html'))return 'https://mavik.name/'.substr($rel,0,-10);return 'https://mavik.name/'.$rel;
}
function mavik_seo_static_gate(string $root): array {
  $root=rtrim($root,'/');$issues=[];$counts=['html'=>0,'indexable'=>0,'jsonld'=>0,'images'=>0,'assets'=>0,'covers'=>0,'garbage'=>0];$menuRaw=@file_get_contents($root.'/assets/app/site-menu.json');$menuJson=is_string($menuRaw)?json_decode($menuRaw,true):null;$menuHrefs=[];foreach((array)($menuJson['items']??[]) as $mi)if(is_array($mi)&&!empty($mi['href']))$menuHrefs[]=(string)$mi['href'];
  $skip=['/_site-admin/','/boss/','/account/','/reactions/','/repository/','/templates/'];
  $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS));
  foreach($it as $f){if(!$f->isFile())continue;$path=str_replace('\\','/',$f->getPathname());$rel='/'.ltrim(substr($path,strlen($root)),'/');
    $base=basename($path);if(preg_match('/(?:^|\/)(?:\.git|node_modules|__pycache__|tmp|temp|backup|backups|cache|logs?|wip)(?:\/|$)/i',$rel)||preg_match('/(?:\.bak|\.old|\.orig|\.rej|\.tmp|\.swp|~)$/i',$base)||preg_match('/(?:R21[0-9]|R22[0-1]).*\.(?:zip|txt)$/i',$base)){$issues[]=['type'=>'garbage','path'=>$rel,'detail'=>'Заборонений release/dev/runtime артефакт'];$counts['garbage']++;}
    if(preg_match('#^/images/covers/#',$rel)&&preg_match('/\.(png|webp|avif|gif)$/i',$rel)){$issues[]=['type'=>'cover_format','path'=>$rel,'detail'=>'Обкладинка має бути JPG/JPEG'];}
    if(preg_match('#^/en(?:/|$)#',$rel)){$issues[]=['type'=>'retired_runtime','path'=>$rel,'detail'=>'Залишок вимкненої міжнародної гілки /en/'];}
    if(strtolower($f->getExtension())!=='html')continue;$private=false;foreach($skip as $needle)if(str_contains($rel,$needle)){$private=true;break;}if($private)continue;
    $html=@file_get_contents($path);if(!is_string($html)||$html==='')continue;if(str_contains($html,'{{'))continue;$counts['html']++;$url=mavik_seo_static_url_from_file($root,$path);$parsed=mavik_seo_parse_html($html,$url);
    if(preg_match('#<html\b[^>]*\blang=["\']([^"\']+)["\']#i',$html,$m)){$expectedLang=str_starts_with($rel,'/books/ewakuacja-albo-w-drodze-do-punktu-stabilizacyjnego/')?'pl-pl':'uk-ua';if(strtolower(trim($m[1]))!==$expectedLang)$issues[]=['type'=>'lang','path'=>$rel,'detail'=>'html lang має бути '.($expectedLang==='pl-pl'?'pl-PL':'uk-UA')];}else $issues[]=['type'=>'lang','path'=>$rel,'detail'=>'Немає html lang'];
    if(!$parsed['noindex']){$counts['indexable']++;if((int)$parsed['h1']!==1)$issues[]=['type'=>'h1','path'=>$rel,'detail'=>'H1 = '.(int)$parsed['h1'].' (потрібно рівно 1)'];if(trim((string)$parsed['title'])==='')$issues[]=['type'=>'title','path'=>$rel,'detail'=>'Немає title'];elseif(mavik_seo_strlen((string)$parsed['title'])>120)$issues[]=['type'=>'title','path'=>$rel,'detail'=>'Підозріло довгий title (>120 символів)'];if(trim((string)$parsed['description'])==='')$issues[]=['type'=>'description','path'=>$rel,'detail'=>'Немає meta description'];elseif(mavik_seo_strlen((string)$parsed['description'])>320)$issues[]=['type'=>'description','path'=>$rel,'detail'=>'Підозріло довгий meta description (>320 символів)'];if(trim((string)$parsed['canonical'])==='')$issues[]=['type'=>'canonical','path'=>$rel,'detail'=>'Немає canonical'];elseif(mavik_seo_canonicalize((string)$parsed['canonical'])!==mavik_seo_canonicalize($url))$issues[]=['type'=>'canonical','path'=>$rel,'detail'=>'Canonical не збігається з URL'];}
    preg_match_all('#<script\b[^>]*type=["\']application/ld\+json["\'][^>]*>(.*?)</script>#si',$html,$jm);foreach($jm[1]??[] as $raw){$counts['jsonld']++;json_decode(trim((string)$raw),true);if(json_last_error()!==JSON_ERROR_NONE)$issues[]=['type'=>'jsonld','path'=>$rel,'detail'=>'Невалідний JSON-LD: '.json_last_error_msg()];}
    if(preg_match('/\bhreflang\s*=/i',$html)||preg_match('#/assets/(?:app/)?language[-_.]#i',$html))$issues[]=['type'=>'retired_runtime','path'=>$rel,'detail'=>'HTML містить залишок вимкненої міжнародної/мовної навігації'];
    if(preg_match('#^/books/[^/]+/read/index\.html$#',$rel)){preg_match_all('#<h[1-3]\b[^>]*>(.*?)</h[1-3]>#siu',$html,$hm);foreach($hm[1]??[] as $headingRaw){$heading=trim(preg_replace('/\s+/u',' ',strip_tags((string)$headingRaw))??'');if($heading!==''&&mavik_seo_heading_looks_like_prose($heading))$issues[]=['type'=>'reader_heading','path'=>$rel,'detail'=>'Підозрілий прозовий заголовок: '.mavik_seo_utf8_clip($heading,140)];}}
    if($menuHrefs&&str_contains($html,'mavik-site-desktop-nav')&&preg_match('#<nav\b[^>]*class=["\'][^"\']*\bmavik-site-desktop-nav\b[^"\']*["\'][^>]*>(.*?)</nav>#siu',$html,$nm)){foreach($menuHrefs as $mh)if(!preg_match('#<a\b[^>]*href=["\']'.preg_quote($mh,'#').'["\']#iu',(string)$nm[1]))$issues[]=['type'=>'ssr_menu','path'=>$rel,'detail'=>'У server-rendered меню немає '.$mh];}
    if(class_exists('DOMDocument')){$dom=new DOMDocument();libxml_use_internal_errors(true);@$dom->loadHTML($html,LIBXML_NOWARNING|LIBXML_NOERROR);libxml_clear_errors();foreach($dom->getElementsByTagName('img') as $img){$counts['images']++;$src=trim((string)$img->getAttribute('src'));if(!$img->hasAttribute('alt'))$issues[]=['type'=>'image','path'=>$rel,'detail'=>'IMG без alt: '.$src];if(!$img->hasAttribute('width')||!$img->hasAttribute('height'))$issues[]=['type'=>'image','path'=>$rel,'detail'=>'IMG без width/height: '.$src];if($src!==''&&str_starts_with($src,'/')){$asset=(string)(parse_url($src,PHP_URL_PATH)??'');if($asset!==''&&!is_file($root.'/'.ltrim(rawurldecode($asset),'/')))$issues[]=['type'=>'asset','path'=>$rel,'detail'=>'Немає локального image asset: '.$asset];}}
      foreach($dom->getElementsByTagName('link') as $el){if(strtolower((string)$el->getAttribute('rel'))!=='stylesheet')continue;$href=trim((string)$el->getAttribute('href'));if(!str_starts_with($href,'/'))continue;$counts['assets']++;$ap=(string)(parse_url($href,PHP_URL_PATH)??'');parse_str((string)(parse_url($href,PHP_URL_QUERY)??''),$q);if(trim((string)($q['v']??''))==='')$issues[]=['type'=>'asset_version','path'=>$rel,'detail'=>'CSS без cache-buster ?v=: '.$href];if($ap!==''&&!is_file($root.'/'.ltrim($ap,'/')))$issues[]=['type'=>'asset','path'=>$rel,'detail'=>'Немає CSS asset: '.$ap];}
      foreach($dom->getElementsByTagName('script') as $el){$src=trim((string)$el->getAttribute('src'));if(!str_starts_with($src,'/'))continue;$counts['assets']++;$ap=(string)(parse_url($src,PHP_URL_PATH)??'');parse_str((string)(parse_url($src,PHP_URL_QUERY)??''),$q);if(trim((string)($q['v']??''))==='')$issues[]=['type'=>'asset_version','path'=>$rel,'detail'=>'JS без cache-buster ?v=: '.$src];if($ap!==''&&!is_file($root.'/'.ltrim($ap,'/')))$issues[]=['type'=>'asset','path'=>$rel,'detail'=>'Немає JS asset: '.$ap];}
    } else {
      preg_match_all('#<img\b[^>]*>#i',$html,$im);foreach($im[0]??[] as $tag){$a=mavik_seo_tag_attrs((string)$tag);$counts['images']++;$src=trim((string)($a['src']??''));if(!array_key_exists('alt',$a))$issues[]=['type'=>'image','path'=>$rel,'detail'=>'IMG без alt: '.$src];if(!isset($a['width'])||!isset($a['height']))$issues[]=['type'=>'image','path'=>$rel,'detail'=>'IMG без width/height: '.$src];if($src!==''&&str_starts_with($src,'/')){$asset=(string)(parse_url($src,PHP_URL_PATH)??'');if($asset!==''&&!is_file($root.'/'.ltrim(rawurldecode($asset),'/')))$issues[]=['type'=>'asset','path'=>$rel,'detail'=>'Немає локального image asset: '.$asset];}}
      preg_match_all('#<link\b[^>]*>#i',$html,$lm);foreach($lm[0]??[] as $tag){$a=mavik_seo_tag_attrs((string)$tag);if(strtolower((string)($a['rel']??''))!=='stylesheet')continue;$href=trim((string)($a['href']??''));if(!str_starts_with($href,'/'))continue;$counts['assets']++;$ap=(string)(parse_url($href,PHP_URL_PATH)??'');parse_str((string)(parse_url($href,PHP_URL_QUERY)??''),$q);if(trim((string)($q['v']??''))==='')$issues[]=['type'=>'asset_version','path'=>$rel,'detail'=>'CSS без cache-buster ?v=: '.$href];if($ap!==''&&!is_file($root.'/'.ltrim($ap,'/')))$issues[]=['type'=>'asset','path'=>$rel,'detail'=>'Немає CSS asset: '.$ap];}
      preg_match_all('#<script\b[^>]*>#i',$html,$sm);foreach($sm[0]??[] as $tag){$a=mavik_seo_tag_attrs((string)$tag);$src=trim((string)($a['src']??''));if(!str_starts_with($src,'/'))continue;$counts['assets']++;$ap=(string)(parse_url($src,PHP_URL_PATH)??'');parse_str((string)(parse_url($src,PHP_URL_QUERY)??''),$q);if(trim((string)($q['v']??''))==='')$issues[]=['type'=>'asset_version','path'=>$rel,'detail'=>'JS без cache-buster ?v=: '.$src];if($ap!==''&&!is_file($root.'/'.ltrim($ap,'/')))$issues[]=['type'=>'asset','path'=>$rel,'detail'=>'Немає JS asset: '.$ap];}
    }
  }
  $coverFiles=glob($root.'/images/covers/*')?:[];foreach($coverFiles as $cf)if(is_file($cf)&&preg_match('/\.jpe?g$/i',$cf))$counts['covers']++;
  $feed=@file_get_contents($root.'/blog/feed.xml');if(!is_string($feed)||!str_contains($feed,'<rss')||!str_contains($feed,'<channel>')||!str_contains($feed,'<item>'))$issues[]=['type'=>'feed','path'=>'/blog/feed.xml','detail'=>'RSS feed відсутній або порожній'];else{$counts['feed_items']=preg_match_all('#<item>\s*#i',$feed,$fm)?:0;}if(!is_file($root.'/llms.txt'))$issues[]=['type'=>'llms','path'=>'/llms.txt','detail'=>'llms.txt відсутній'];
  $robots=@file_get_contents($root.'/robots.txt');if(!is_string($robots)||!str_contains($robots,'User-agent: OAI-SearchBot')||!str_contains($robots,'User-agent: ChatGPT-User')||!str_contains($robots,'Sitemap: https://mavik.name/sitemap.xml'))$issues[]=['type'=>'robots','path'=>'/robots.txt','detail'=>'Неповна crawler/sitemap policy'];
  $sitemap=@file_get_contents($root.'/sitemap.xml');if(!is_string($sitemap))$issues[]=['type'=>'sitemap','path'=>'/sitemap.xml','detail'=>'Файл відсутній/нечитабельний'];else{$urls=mavik_seo_sitemap_urls($sitemap);if(count($urls)!==count(array_unique($urls)))$issues[]=['type'=>'sitemap','path'=>'/sitemap.xml','detail'=>'Дублікати URL'];$counts['sitemap_urls']=count($urls);foreach($urls as $u)if(str_contains($u,'https://mavik.name/en/'))$issues[]=['type'=>'retired_runtime','path'=>'/sitemap.xml','detail'=>'Sitemap містить URL вимкненої міжнародної гілки /en/'];}
  return ['ok'=>count($issues)===0,'issue_count'=>count($issues),'counts'=>$counts,'issues'=>$issues,'generated_at'=>date(DATE_ATOM)];
}

function mavik_seo_sitemap_urls(string $xml): array {
  $urls=[];
  if(class_exists('DOMDocument')){$dom=new DOMDocument();libxml_use_internal_errors(true);if(@$dom->loadXML($xml,LIBXML_NONET)){$xp=new DOMXPath($dom);$xp->registerNamespace('s','http://www.sitemaps.org/schemas/sitemap/0.9');foreach($xp->query('/s:urlset/s:url/s:loc')?:[] as $n){$u=trim((string)$n->textContent);if($u!=='')$urls[]=$u;}}libxml_clear_errors();}
  if(!$urls){preg_match_all('#<url\b[^>]*>.*?<loc>\s*(.*?)\s*</loc>.*?</url>#is',$xml,$m);foreach($m[1]??[] as $u)$urls[]=html_entity_decode(trim(strip_tags((string)$u)),ENT_QUOTES|ENT_XML1,'UTF-8');}
  return array_values(array_unique($urls));
}
function mavik_seo_crawler_matrix(string $base,string $sampleReader=''): array {
  $agents=['Browser'=>'Mozilla/5.0 (compatible; MaVikAudit/3.0; +https://mavik.name/)','Googlebot'=>'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','Bingbot'=>'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)','OAI-SearchBot'=>'OAI-SearchBot/1.0; +https://openai.com/searchbot','ChatGPT-User'=>'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; ChatGPT-User/1.0; +https://openai.com/bot'];
  $paths=['/','/books/','/blog/','/music/','/robots.txt','/sitemap.xml'];if($sampleReader!=='')$paths[]=$sampleReader;$paths=array_values(array_unique($paths));$out=[];
  foreach($agents as $name=>$ua)foreach($paths as $path){$r=mavik_seo_http(rtrim($base,'/').$path,'GET',null,[],12,$ua);$out[]=['agent'=>$name,'path'=>$path,'status'=>(int)$r['status'],'time_ms'=>(int)$r['time_ms'],'final_url'=>(string)$r['final_url'],'content_type'=>(string)$r['content_type'],'x_robots_tag'=>(string)($r['headers']['x-robots-tag']??''),'blocked'=>in_array((int)$r['status'],[401,403,429],true)||(int)$r['status']>=500,'error'=>(string)$r['error']];}
  return $out;
}

function mavik_seo_redirect_matrix(): array {
  $tests=[
    'http://mavik.name/'=>'https://mavik.name/',
    'http://www.mavik.name/'=>'https://mavik.name/',
    'https://www.mavik.name/'=>'https://mavik.name/',
    'https://mavik.name/books/index.html'=>'https://mavik.name/books/',
    'https://mavik.name/preview/books/'=>'https://mavik.name/books/',
    'https://mavik.name/blog/?q=audit'=>'https://mavik.name/blog/',
    'https://mavik.name/books/?genre=audit'=>'https://mavik.name/books/',
    'https://mavik.name/announcements/kod-lehendy/'=>'https://mavik.name/books/kod-lehendy/'
  ];
  $out=[];foreach($tests as $u=>$expected){$r=mavik_seo_http($u);$final=mavik_seo_canonicalize((string)$r['final_url']);$out[]=['url'=>$u,'expected'=>$expected,'status'=>(int)$r['status'],'final_url'=>(string)$r['final_url'],'redirect_count'=>(int)$r['redirect_count'],'time_ms'=>(int)$r['time_ms'],'ok'=>$final===mavik_seo_canonicalize($expected)&&(int)$r['redirect_count']<=1];}return $out;
}

function mavik_seo_header_snapshot(string $url): array {
  $r=mavik_seo_http($url);$h=(array)$r['headers'];return [
    'status'=>(int)$r['status'],'time_ms'=>(int)$r['time_ms'],'content_type'=>(string)$r['content_type'],
    'cache_control'=>(string)($h['cache-control']??''),'etag'=>(string)($h['etag']??''),'last_modified'=>(string)($h['last-modified']??''),
    'hsts'=>(string)($h['strict-transport-security']??''),'csp'=>(string)($h['content-security-policy']??''),
    'referrer_policy'=>(string)($h['referrer-policy']??''),'permissions_policy'=>(string)($h['permissions-policy']??''),
    'x_content_type_options'=>(string)($h['x-content-type-options']??''),'x_frame_options'=>(string)($h['x-frame-options']??''),
    'release'=>(string)($h['x-mavik-release']??''),'server'=>(string)($h['server']??'')
  ];
}

function mavik_seo_run_scan(string $root,array $manifest,int $limit=500): array {
  $base='https://mavik.name/';$host='mavik.name';$queue=[$base];$seen=[];$rows=[];$broken=[];$titles=[];$noindex=[];$redirects=[];$missingTitles=[];$missingDescriptions=[];$h1Issues=[];$canonicalMismatch=[];$xRobotsIssues=[];$slow=[];$started=microtime(true);
  while($queue&&count($seen)<$limit){
    $url=mavik_seo_canonicalize((string)array_shift($queue));if($url===''||isset($seen[$url]))continue;$p=parse_url($url);if(strtolower((string)($p['host']??''))!==$host)continue;$path=(string)($p['path']??'/');if(preg_match('#\.(?:jpg|jpeg|png|gif|webp|svg|ico|css|js|mp3|m4a|wav|epub|pdf|zip|txt|xml|json|webmanifest)$#i',$path))continue;
    $seen[$url]=true;$r=mavik_seo_http($url);$status=(int)$r['status'];$ct=strtolower((string)$r['content_type']);$xrobots=strtolower((string)($r['headers']['x-robots-tag']??''));$row=['url'=>$url,'status'=>$status,'title'=>'','description'=>'','h1'=>0,'canonical'=>'','noindex'=>false,'final_url'=>(string)$r['final_url'],'time_ms'=>(int)$r['time_ms'],'x_robots_tag'=>$xrobots];
    if($status>=400||$status===0)$broken[]=['url'=>$url,'status'=>$status,'error'=>(string)$r['error']];if((int)$r['time_ms']>2500)$slow[]=['url'=>$url,'time_ms'=>(int)$r['time_ms'],'status'=>$status];$final=mavik_seo_canonicalize((string)$r['final_url']);if($final!==''&&$final!==$url)$redirects[]=['url'=>$url,'final_url'=>$final,'status'=>$status,'redirect_count'=>(int)$r['redirect_count']];
    if($status===200&&(str_contains($ct,'text/html')||str_contains(ltrim((string)$r['body']),'<!DOCTYPE')||str_contains(ltrim((string)$r['body']),'<html'))){$x=mavik_seo_parse_html((string)$r['body'],$url);$row=array_merge($row,$x);if(str_contains($xrobots,'noindex')&&!$row['noindex']){$row['noindex']=true;$xRobotsIssues[]=['url'=>$url,'x_robots_tag'=>$xrobots];}
      if(!$row['noindex']){if($row['title']!=='')$titles[$row['title']][]=$url;else$missingTitles[]=$url;if(trim((string)$row['description'])==='')$missingDescriptions[]=$url;if((int)$row['h1']!==1)$h1Issues[]=['url'=>$url,'h1'=>(int)$row['h1']];if($row['canonical']==='')$canonicalMismatch[]=['url'=>$url,'canonical'=>''];elseif(mavik_seo_canonicalize((string)$row['canonical'])!==$url)$canonicalMismatch[]=['url'=>$url,'canonical'=>(string)$row['canonical']];}
      if($row['noindex'])$noindex[]=$url;foreach($row['links'] as $link){$lp=parse_url($link);$clean=mavik_seo_canonicalize($link);if(strtolower((string)($lp['host']??''))===$host&&$clean!==''&&!isset($seen[$clean])&&count($queue)<$limit*3)$queue[]=$link;}unset($row['links']);}
    $rows[]=$row;
  }
  $dupeTitles=[];foreach($titles as $title=>$urls)if(count($urls)>1)$dupeTitles[]=['title'=>$title,'urls'=>$urls];$missingBooks=[];$bookCount=0;foreach((array)($manifest['books']??[]) as $b){if(!is_array($b)||!empty($b['deleted'])||!empty($b['hidden'])||(string)($b['placement']??'books')!=='books')continue;$bookCount++;$u=$base.'books/'.(string)$b['slug'].'/';$ok=false;foreach($rows as $rr)if($rr['url']===$u&&(int)$rr['status']===200){$ok=true;break;}if(!$ok)$missingBooks[]=$u;}
  $robots=mavik_seo_http($base.'robots.txt');$sitemap=mavik_seo_http($base.'sitemap.xml');$sitemapUrls=(int)$sitemap['status']===200?mavik_seo_sitemap_urls((string)$sitemap['body']):[];$robotsBody=(string)$robots['body'];$robotsIssues=[];if((int)$robots['status']!==200)$robotsIssues[]='robots.txt HTTP '.(int)$robots['status'];if(!str_contains($robotsBody,'User-agent: OAI-SearchBot'))$robotsIssues[]='Немає explicit OAI-SearchBot policy';if(!str_contains($robotsBody,'User-agent: ChatGPT-User'))$robotsIssues[]='Немає explicit ChatGPT-User policy';if(!str_contains($robotsBody,'Sitemap: https://mavik.name/sitemap.xml'))$robotsIssues[]='Немає canonical Sitemap directive';
  $sitemapIssues=[];if((int)$sitemap['status']!==200)$sitemapIssues[]='sitemap.xml HTTP '.(int)$sitemap['status'];if(count($sitemapUrls)!==count(array_unique($sitemapUrls)))$sitemapIssues[]='Дублікати URL у sitemap';foreach($sitemapUrls as $u)if(!str_starts_with($u,'https://mavik.name/')){$sitemapIssues[]='Неканонічний sitemap URL: '.$u;break;}
  $notInSitemap=[];foreach($rows as $rr){$u=(string)($rr['url']??'');$path=parse_url($u,PHP_URL_PATH)?:'/';if($u===''||!empty($rr['noindex'])||(int)($rr['status']??0)!==200||preg_match('#/(account|boss|reactions|_site-admin)(/|$)#',$path))continue;if(!in_array($u,$sitemapUrls,true))$notInSitemap[]=$u;}
  $sampleReader='';foreach($sitemapUrls as $su){$pp=(string)(parse_url($su,PHP_URL_PATH)??'');if(preg_match('#^/books/[^/]+/read/$#',$pp)){$sampleReader=$pp;break;}}$crawlerMatrix=mavik_seo_crawler_matrix($base,$sampleReader);$crawlerBlocks=array_values(array_filter($crawlerMatrix,fn($x)=>!empty($x['blocked'])||!in_array((int)$x['status'],[200,301,302],true)));$redirectMatrix=mavik_seo_redirect_matrix();$redirectIssues=array_values(array_filter($redirectMatrix,fn($x)=>empty($x['ok'])));$headers=mavik_seo_header_snapshot($base);$headerIssues=[];if((int)$headers['status']!==200)$headerIssues[]='Homepage HTTP '.(int)$headers['status'];if(trim((string)$headers['hsts'])==='')$headerIssues[]='Немає HSTS';if(strtolower((string)$headers['x_content_type_options'])!=='nosniff')$headerIssues[]='Немає X-Content-Type-Options: nosniff';if(trim((string)$headers['cache_control'])==='')$headerIssues[]='Немає Cache-Control';if(trim((string)$headers['csp'])==='')$headerIssues[]='Немає Content-Security-Policy';if(trim((string)$headers['referrer_policy'])==='')$headerIssues[]='Немає Referrer-Policy';if(trim((string)$headers['permissions_policy'])==='')$headerIssues[]='Немає Permissions-Policy';$expectedRelease=mavik_seo_expected_release($root);if($expectedRelease!==''&&strtoupper((string)$headers['release'])!==$expectedRelease)$headerIssues[]='X-MaVik-Release не '.$expectedRelease;$retiredEn=mavik_seo_http($base.'en/about/');if((int)$retiredEn['status']!==410)$headerIssues[]='Legacy /en/* не повертає 410 Gone (HTTP '.(int)$retiredEn['status'].')';
  $consistency=mavik_seo_local_consistency($root,$manifest);$staticGate=mavik_seo_static_gate($root);$report=['generated_at'=>date(DATE_ATOM),'duration_ms'=>(int)round((microtime(true)-$started)*1000),'summary'=>['crawled'=>count($rows),'http_errors'=>count($broken),'crawler_blocks'=>count($crawlerBlocks),'redirects'=>count($redirects),'redirect_issues'=>count($redirectIssues),'slow_urls'=>count($slow),'noindex'=>count($noindex),'duplicate_titles'=>count($dupeTitles),'missing_titles'=>count($missingTitles),'missing_descriptions'=>count($missingDescriptions),'h1_issues'=>count($h1Issues),'canonical_mismatch'=>count($canonicalMismatch),'x_robots_issues'=>count($xRobotsIssues),'books_expected'=>$bookCount,'books_ok'=>$bookCount-count($missingBooks),'books_missing'=>count($missingBooks),'robots_status'=>(int)$robots['status'],'robots_issues'=>count($robotsIssues),'sitemap_status'=>(int)$sitemap['status'],'sitemap_urls'=>count($sitemapUrls),'sitemap_issues'=>count($sitemapIssues),'not_in_sitemap'=>count($notInSitemap),'header_issues'=>count($headerIssues),'retired_en_status'=>(int)$retiredEn['status'],'consistency_issues'=>count((array)$consistency['issues']),'static_gate_issues'=>(int)($staticGate['issue_count']??0),'books_jsonld'=>$consistency['books_jsonld'],'new_books_expected'=>$consistency['new_state'],'new_books_jsonld'=>$consistency['new_jsonld'],'missing_covers'=>count((array)$consistency['missing_covers']),'indexnow_ready'=>!empty($consistency['indexnow_ready']),'bing_ready'=>!empty($consistency['bing_ready'])],'http_errors'=>$broken,'crawler_matrix'=>$crawlerMatrix,'crawler_blocks'=>$crawlerBlocks,'redirects'=>$redirects,'redirect_matrix'=>$redirectMatrix,'redirect_issues'=>$redirectIssues,'slow_urls'=>$slow,'headers'=>$headers,'header_issues'=>$headerIssues,'robots_issues'=>$robotsIssues,'sitemap_issues'=>$sitemapIssues,'noindex_urls'=>$noindex,'x_robots_issues'=>$xRobotsIssues,'duplicate_titles'=>$dupeTitles,'missing_titles'=>$missingTitles,'missing_descriptions'=>$missingDescriptions,'h1_issues'=>$h1Issues,'canonical_mismatch'=>$canonicalMismatch,'missing_books'=>$missingBooks,'not_in_sitemap'=>$notInSitemap,'consistency_issues'=>$consistency['issues'],'static_gate'=>$staticGate,'consistency'=>$consistency,'rows'=>$rows];$s=mavik_seo_load($root);$s['last_scan']=$report;mavik_seo_save($root,$s);return $report;
}

function mavik_seo_sync_free_books(string $root,array $manifest): void {
  if(function_exists('mavik_live_sync_free_books')){mavik_live_sync_free_books($root,$manifest);return;}
  $file=$root.'/books/free/index.html';if(!is_file($file))return;$html=file_get_contents($file);if($html===false)return;
  $books=[];foreach((array)($manifest['books']??[]) as $b){if(!is_array($b)||!empty($b['deleted'])||!empty($b['hidden'])||(string)($b['placement']??'books')!=='books'||(string)($b['publication_mode']??'final')!=='final')continue;$books[]=$b;}
  $cards='';$items=[];$pos=0;foreach($books as $b){$pos++;$slug=(string)$b['slug'];$title=(string)$b['title'];$genre=(string)($b['genre']??'');$desc=(string)($b['description']??'');$cover=(string)($b['cover_catalog']??'');
    $coverPath=$root.'/'.ltrim((string)(parse_url($cover,PHP_URL_PATH)??$cover),'/');$dim=is_file($coverPath)?@getimagesize($coverPath):false;$wh=is_array($dim)&&!empty($dim[0])&&!empty($dim[1])?' width="'.(int)$dim[0].'" height="'.(int)$dim[1].'"':'';$cards.='<a class="book-card" href="/books/'.h($slug).'/"><img alt="Обкладинка — '.h($title).'" loading="lazy" decoding="async"'.$wh.' src="'.h($cover).'"/><div class="book-copy"><div class="book-type">'.h($genre).'</div><h3 class="book-title">'.h($title).'</h3><p class="book-desc">'.h($desc).'</p><span class="book-free">Читати онлайн безкоштовно →</span></div></a>';
    $items[]=['@type'=>'ListItem','position'=>$pos,'item'=>['@type'=>'Book','name'=>$title,'url'=>'https://mavik.name/books/'.$slug.'/','image'=>'https://mavik.name'.$cover,'author'=>['@id'=>'https://mavik.name/#person'],'inLanguage'=>'uk-UA','isAccessibleForFree'=>true]];
  }
  $html=preg_replace('#(<section class="section">.*?<div class="grid">).*?(</div><div class="actions">)#su','$1'.$cards.'$2',$html,1)??$html;
  if(preg_match('#<script type="application/ld\+json">(.*?)</script>#s',$html,$m)){ $j=json_decode($m[1],true);if(is_array($j)&&is_array($j['@graph']??null)){foreach($j['@graph'] as &$node){if(is_array($node)&&($node['@type']??'')==='WebPage'&&is_array($node['mainEntity']??null)&&($node['mainEntity']['@type']??'')==='ItemList'){$node['mainEntity']['numberOfItems']=count($items);$node['mainEntity']['itemListElement']=$items;}}unset($node);$new=json_encode($j,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);$html=str_replace($m[0],'<script type="application/ld+json">'.$new.'</script>',$html);}
  }
  atomic_write($file,$html);
}

function mavik_indexnow_key(string $root): string {
  $files=glob($root.'/*.txt')?:[];foreach($files as $f){$name=basename($f,'.txt');if(preg_match('/^[A-Fa-f0-9]{32,64}$/',$name)){ $raw=trim((string)@file_get_contents($f));if(hash_equals($name,$raw))return $name; }}
  return '';
}
function mavik_indexnow_submit(string $root,array $paths): array {
  $key=mavik_indexnow_key($root);if($key==='')return ['status'=>0,'message'=>'IndexNow key file не знайдено.'];
  $urls=[];foreach($paths as $p){$p=(string)$p;if($p==='')continue;if(preg_match('#^https://mavik\.name/#',$p))$u=$p;else $u='https://mavik.name'.($p==='/'?'/':('/'.trim($p,'/').'/'));$urls[$u]=true;}
  $urls=array_keys($urls);if(!$urls)return ['status'=>0,'message'=>'Немає URL для IndexNow.'];
  $payload=json_encode(['host'=>'mavik.name','key'=>$key,'keyLocation'=>'https://mavik.name/'.$key.'.txt','urlList'=>$urls],JSON_UNESCAPED_SLASHES);
  $r=mavik_seo_http('https://api.indexnow.org/indexnow','POST',$payload,['Content-Type: application/json; charset=utf-8'],12);
  $out=['status'=>(int)$r['status'],'count'=>count($urls),'at'=>date(DATE_ATOM),'message'=>(int)$r['status']>=200&&(int)$r['status']<300?'Прийнято IndexNow':'IndexNow HTTP '.(int)$r['status']];
  $s=mavik_seo_load($root);$s['last_indexnow']=$out;mavik_seo_save($root,$s);return $out;
}
function mavik_bing_submit_urls(string $root,array $paths): array {
  $s=mavik_seo_load($root);$key=trim((string)($s['bing_api_key']??''));if($key==='')return ['status'=>0,'message'=>'Bing API key не збережено.'];
  $urls=[];foreach($paths as $p){$p=(string)$p;if($p==='')continue;$urls[]=preg_match('#^https://#',$p)?$p:'https://mavik.name'.($p==='/'?'/':('/'.trim($p,'/').'/'));}
  $urls=array_values(array_unique($urls));if(!$urls)return ['status'=>0,'message'=>'Немає URL.'];
  $payload=json_encode(['siteUrl'=>'https://mavik.name/','urlList'=>array_slice($urls,0,500)],JSON_UNESCAPED_SLASHES);
  $r=mavik_seo_http('https://ssl.bing.com/webmaster/api.svc/json/SubmitUrlbatch?apikey='.rawurlencode($key),'POST',$payload,['Content-Type: application/json; charset=utf-8'],12);
  return ['status'=>(int)$r['status'],'count'=>count($urls),'message'=>(int)$r['status']>=200&&(int)$r['status']<300?'Bing URL Submission прийняв пакет':'Bing API HTTP '.(int)$r['status']];
}

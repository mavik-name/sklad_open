<?php
declare(strict_types=1);


function mavik_reader_text_publish(string $root,string $slug,string $title,string $bodyHtml,string $statusLabel='',bool $continuation=false): void {
  if(!preg_match('/^[a-z0-9-]+$/',$slug))throw new RuntimeException('Некоректний slug текстової версії.');
  $dir=rtrim($root,'/').'/books/'.$slug.'/read/text';
  if(!is_dir($dir)&&!mkdir($dir,0755,true)&&!is_dir($dir))throw new RuntimeException('Не вдалося створити текстову версію.');
  foreach(glob($dir.'/*.txt')?:[] as $old)@unlink($old);
  $safe=htmlspecialchars($title,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');
  $base='https://mavik.name/books/'.$slug.'/';
  $statusHtml=$statusLabel!==''?'<p class="meta">Статус: '.htmlspecialchars($statusLabel,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8').'</p>':'';
  $body=preg_replace('#<(script|style|iframe|object|embed|form)\\b[^>]*>.*?</\\1>#is','',$bodyHtml)??$bodyHtml;
  $body=preg_replace('/\\s(?:class|style|data-[A-Za-z0-9_-]+)=("[^"]*"|\'[^\']*\')/u','',$body)??$body;
  if($continuation)$body.='<p><strong>ДАЛІ БУДЕ…</strong></p>';
  $index='<!doctype html><html lang="uk-UA"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,follow"><title>'.$safe.' — чистий текст | MaVik</title><meta name="description" content="Чиста текстова версія твору «'.$safe.'» без меню, плеєра та JavaScript — для озвучення браузером і слабких з’єднань."><link rel="canonical" href="'.$base.'read/"><style>html{color-scheme:dark}body{max-width:820px;margin:0 auto;padding:34px 20px 80px;background:#0f0f10;color:#eee;font:19px/1.68 Georgia,serif}header{margin-bottom:32px;padding-bottom:20px;border-bottom:1px solid #333}nav{font:14px/1.5 Arial,sans-serif}a{color:#d9bd86}h1{font-size:2rem;line-height:1.15}h2{font-size:1.45rem;margin-top:2.2em}p{margin:0 0 1.05em}.meta{color:#aaa;font:14px/1.5 Arial,sans-serif}</style></head><body><header><nav><a href="../">← Веб-читанка</a> · <a href="../../">Картка книги</a></nav><h1>'.$safe.'</h1><p class="meta">Макарчук Віктор · MaVik</p>'.$statusHtml.'</header><main><article>'.$body.'</article></main></body></html>';
  file_put_contents($dir.'/index.html',$index,LOCK_EX);
  $ht="Options -Indexes\nDirectoryIndex index.html\nAddDefaultCharset UTF-8\n<IfModule mod_headers.c>\n  Header always set X-Robots-Tag \"noindex, follow\"\n  Header always set X-Content-Type-Options \"nosniff\"\n</IfModule>\n";
  file_put_contents($dir.'/.htaccess',$ht,LOCK_EX);
}

function mavik_reader_rebuild_llms(string $root): void {
  $root=rtrim($root,'/');
  $lines=['# MaVik — авторський сайт Макарчука Віктора','', '> Українські книги, веб-читанки, блог і музика. Публічний контент доступний без авторизації.','', 'Canonical origin: https://mavik.name/','Sitemap: https://mavik.name/sitemap.xml','Robots: https://mavik.name/robots.txt','Language: uk-UA','Preferred book sources: canonical book landing + canonical /read/ page. /read/text/ is a lightweight full-text HTML mirror and is intentionally noindex to avoid duplicate search documents.','', '## Основні сторінки','- https://mavik.name/','- https://mavik.name/books/','- https://mavik.name/blog/','- https://mavik.name/music/','- https://mavik.name/about/','- https://mavik.name/mavik/','', '## Книги та чисті текстові версії'];
  $files=glob($root.'/books/*/read/index.html')?:[];sort($files,SORT_NATURAL|SORT_FLAG_CASE);
  foreach($files as $reader){$slug=basename(dirname(dirname($reader)));$clean=$root.'/books/'.$slug.'/read/text/index.html';if(!is_file($clean))continue;$raw=file_get_contents($reader)?:'';$title=$slug;if(preg_match('~<title>(.*?)</title>~isu',$raw,$m)){$title=trim(html_entity_decode(preg_replace('~\\s+[—|].*$~u','',$m[1])??$m[1],ENT_QUOTES|ENT_HTML5,'UTF-8'));}$base='https://mavik.name/books/'.$slug.'/';$lines[]='- '.$title;$lines[]='  - Картка: '.$base;$lines[]='  - Веб-читанка: '.$base.'read/';$lines[]='  - Чиста текстова HTML-версія: '.$base.'read/text/';}
  $lines[]='';file_put_contents($root.'/llms.txt',implode("\n",$lines),LOCK_EX);
}


<?php
declare(strict_types=1);
require_once __DIR__.'/state.php';

function mavik_stats_lite_file(string $root): string { return mavik_state_path($root,'stats-lite.json'); }
function mavik_stats_lite_empty(): array { return ['schema'=>1,'days'=>[]]; }
function mavik_stats_lite_load(string $root): array {
  $f=mavik_stats_lite_file($root);$raw=is_file($f)?@file_get_contents($f):false;$j=$raw!==false?json_decode($raw,true):null;
  if(!is_array($j)||!is_array($j['days']??null))$j=mavik_stats_lite_empty();return $j;
}
function mavik_stats_lite_day_key(?int $ts=null): string { return date('Y-m-d',$ts??time()); }
function mavik_stats_lite_ref_host(string $ref): string {
  $ref=trim($ref);if($ref==='')return 'Прямий вхід';$host=strtolower((string)(parse_url($ref,PHP_URL_HOST)??''));
  if($host===''||in_array($host,['mavik.name','www.mavik.name'],true))return 'Внутрішній перехід';
  $host=preg_replace('/^www\./','',$host)??$host;return substr($host,0,120);
}
function mavik_stats_lite_path(string $path): string {
  $path=(string)(parse_url($path,PHP_URL_PATH)??'/');$path='/'.ltrim($path,'/');$path=preg_replace('#/+#','/',$path)??'/';
  if(strlen($path)>300)$path=substr($path,0,300);return $path===''?'/':$path;
}
function mavik_stats_lite_record(string $root,array $in,string $ref=''): void {
  $event=(string)($in['event']??'page');if(!in_array($event,['page','track'],true))return;
  $sid=trim((string)($in['sid']??''));if(!preg_match('/^[A-Za-z0-9._:-]{12,160}$/',$sid))return;$sh=hash('sha256',$sid);
  $path=mavik_stats_lite_path((string)($in['path']??'/'));$item=trim((string)($in['item']??''));if(strlen($item)>180)$item=substr($item,0,180);
  $stateDir=mavik_state_dir($root);$lock=$stateDir.'/stats-lite.lock';$lh=@fopen($lock,'c+');if(!$lh)return;
  try{if(!flock($lh,LOCK_EX))return;$data=mavik_stats_lite_load($root);$today=mavik_stats_lite_day_key();$cut=date('Y-m-d',strtotime('-35 days'));
    foreach(array_keys((array)$data['days']) as $d)if($d<$cut)unset($data['days'][$d]);
    if(!isset($data['days'][$today])||!is_array($data['days'][$today]))$data['days'][$today]=['views'=>0,'sessions'=>[],'paths'=>[],'refs'=>[],'tracks'=>[]];
    $day=&$data['days'][$today];foreach(['sessions','paths','refs','tracks'] as $k)if(!is_array($day[$k]??null))$day[$k]=[];
    if(count($day['sessions'])<6000||isset($day['sessions'][$sh]))$day['sessions'][$sh]=1;
    if($event==='page'){$day['views']=(int)($day['views']??0)+1;$day['paths'][$path]=(int)($day['paths'][$path]??0)+1;$rh=mavik_stats_lite_ref_host((string)($in['ref']??$ref));$day['refs'][$rh]=(int)($day['refs'][$rh]??0)+1;}
    elseif($event==='track'&&$item!=='')$day['tracks'][$item]=(int)($day['tracks'][$item]??0)+1;
    $json=json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);if(!is_string($json))return;$f=mavik_stats_lite_file($root);$tmp=$f.'.tmp-'.bin2hex(random_bytes(3));
    if(@file_put_contents($tmp,$json."\n",LOCK_EX)!==false){@chmod($tmp,0640);@rename($tmp,$f);}else @unlink($tmp);
  }finally{flock($lh,LOCK_UN);fclose($lh);}
}
function mavik_stats_lite_sum(string $root,int $days): array {
  $data=mavik_stats_lite_load($root);$from=date('Y-m-d',strtotime('-'.max(0,$days-1).' days'));$sessions=[];$views=0;$paths=[];$refs=[];$tracks=[];
  foreach((array)$data['days'] as $date=>$d){if($date<$from||!is_array($d))continue;$views+=(int)($d['views']??0);foreach((array)($d['sessions']??[]) as $k=>$v)$sessions[(string)$k]=1;foreach((array)($d['paths']??[]) as $k=>$v)$paths[$k]=($paths[$k]??0)+(int)$v;foreach((array)($d['refs']??[]) as $k=>$v)$refs[$k]=($refs[$k]??0)+(int)$v;foreach((array)($d['tracks']??[]) as $k=>$v)$tracks[$k]=($tracks[$k]??0)+(int)$v;}
  arsort($paths,SORT_NUMERIC);arsort($refs,SORT_NUMERIC);arsort($tracks,SORT_NUMERIC);return ['sessions'=>count($sessions),'views'=>$views,'paths'=>$paths,'refs'=>$refs,'tracks'=>$tracks];
}
function mavik_stats_lite_label_maps(string $root): array {
  $books=[];$blogs=[];$tracks=[];$mf=mavik_state_seed($root,'boss-content.json');$raw=is_file($mf)?@file_get_contents($mf):false;$j=$raw!==false?json_decode($raw,true):null;
  if(is_array($j)){foreach((array)($j['books']??[]) as $b)if(is_array($b)&&empty($b['deleted'])&&($slug=trim((string)($b['slug']??'')))!=='')$books[$slug]=(string)($b['title']??$slug);foreach((array)($j['blog']??[]) as $b)if(is_array($b)&&empty($b['deleted'])&&($slug=trim((string)($b['slug']??'')))!=='')$blogs[$slug]=(string)($b['title']??$slug);}
  $lf=mavik_state_seed($root,'music-library.json');$raw=is_file($lf)?@file_get_contents($lf):false;$j=$raw!==false?json_decode($raw,true):null;if(is_array($j))foreach((array)($j['tracks']??[]) as $t)if(is_array($t)&&($id=trim((string)($t['id']??'')))!=='')$tracks[$id]=(string)($t['title']??$id);
  return ['books'=>$books,'blogs'=>$blogs,'tracks'=>$tracks];
}
function mavik_stats_lite_path_label(string $path,array $maps): string {
  if(preg_match('#^/books/([a-z0-9-]+)/read/?$#i',$path,$m))return 'Читають: '.($maps['books'][strtolower($m[1])]??$m[1]);
  if(preg_match('#^/books/([a-z0-9-]+)/?$#i',$path,$m))return 'Книга: '.($maps['books'][strtolower($m[1])]??$m[1]);
  if(preg_match('#^/blog/([a-z0-9-]+)/?$#i',$path,$m))return 'Блог: '.($maps['blogs'][strtolower($m[1])]??$m[1]);
  $fixed=['/'=>'Головна','/books/'=>'Книги','/blog/'=>'Блог','/music/'=>'Музика','/about/'=>'Автор','/announcements/'=>'Анонси','/contact/'=>'Контакт'];return $fixed[$path]??$path;
}
function mavik_stats_lite_dashboard(string $root): array {
  $maps=mavik_stats_lite_label_maps($root);$today=mavik_stats_lite_sum($root,1);$w=mavik_stats_lite_sum($root,7);$m=mavik_stats_lite_sum($root,30);
  $top=[];foreach(array_slice($m['paths'],0,15,true) as $p=>$n)$top[]=['label'=>mavik_stats_lite_path_label((string)$p,$maps),'path'=>(string)$p,'count'=>(int)$n];
  $tr=[];foreach(array_slice($m['tracks'],0,12,true) as $id=>$n)$tr[]=['label'=>$maps['tracks'][$id]??$id,'id'=>$id,'count'=>(int)$n];
  $refs=[];foreach(array_slice($m['refs'],0,12,true) as $r=>$n)$refs[]=['label'=>$r,'count'=>(int)$n];return ['today'=>$today,'week'=>$w,'month'=>$m,'top'=>$top,'tracks'=>$tr,'refs'=>$refs];
}

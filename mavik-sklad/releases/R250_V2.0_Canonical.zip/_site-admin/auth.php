<?php
declare(strict_types=1);
require_once __DIR__.'/state.php';
require_once __DIR__.'/utf8.php';
require_once __DIR__.'/maintenance.php';

function mavik_owner_session_start(): void {
  if (session_status() === PHP_SESSION_ACTIVE) return;
  session_name('mavik_owner');
  session_set_cookie_params([
    'lifetime'=>0,
    'path'=>'/',
    'secure'=>(!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
    'httponly'=>true,
    'samesite'=>'Strict'
  ]);
  session_start();
  if(empty($_SESSION['mavik_owner_auth'])){
    $root=dirname(__DIR__);
    if(is_dir($root)) mavik_owner_restore_persistent($root);
  }
  if(!empty($_SESSION['mavik_owner_auth'])) mavik_maintenance_preview_cookie(true);
}
function mavik_owner_config(): array {
  $f=dirname(__DIR__).'/boss/config.php';
  $c=is_file($f)?require $f:[];
  return is_array($c)?$c:[];
}
function mavik_owner_file(string $root): string { return mavik_state_seed($root,'owner.json'); }
function mavik_owner_load(string $root): ?array {
  $f=mavik_owner_file($root); if(!is_file($f)) return null;
  $raw=file_get_contents($f); if($raw===false) return null;
  $j=json_decode($raw,true); return is_array($j)?$j:null;
}
function mavik_owner_exists(string $root): bool { $x=mavik_owner_load($root); return is_array($x)&&!empty($x['password_hash'])&&!empty($x['email']); }
function mavik_owner_authed(): bool { return !empty($_SESSION['mavik_owner_auth']); }
function mavik_owner_csrf(): string {
  if(empty($_SESSION['mavik_owner_csrf'])) $_SESSION['mavik_owner_csrf']=bin2hex(random_bytes(24));
  return (string)$_SESSION['mavik_owner_csrf'];
}
function mavik_owner_csrf_ok(string $v): bool { return isset($_SESSION['mavik_owner_csrf'])&&hash_equals((string)$_SESSION['mavik_owner_csrf'],$v); }
function mavik_owner_atomic_write(string $file,string $data): void {
  $dir=dirname($file); if(!is_dir($dir)&&!mkdir($dir,0755,true)&&!is_dir($dir)) throw new RuntimeException('Не вдалося створити каталог власника.');
  $tmp=$file.'.tmp-'.bin2hex(random_bytes(4));
  if(file_put_contents($tmp,$data,LOCK_EX)===false) throw new RuntimeException('Не вдалося записати обліковий запис.');
  @chmod($tmp,0600);
  if(!rename($tmp,$file)){@unlink($tmp);throw new RuntimeException('Не вдалося зберегти обліковий запис.');}
  @chmod($file,0600);
}
function mavik_owner_password_ok(string $password): void {
  if(mavik_utf8_strlen($password)<12) throw new RuntimeException('Пароль має містити щонайменше 12 символів.');
}
function mavik_owner_persistent_file(string $root): string { return mavik_state_seed($root,'owner-sessions.json'); }
function mavik_owner_persistent_load(string $root): array {
  $f=mavik_owner_persistent_file($root);$raw=is_file($f)?file_get_contents($f):false;$j=$raw?json_decode($raw,true):null;
  if(!is_array($j))$j=['version'=>1,'tokens'=>[]];if(!isset($j['tokens'])||!is_array($j['tokens']))$j['tokens']=[];return $j;
}
function mavik_owner_persistent_save(string $root,array $j): void {
  $j['version']=1;$j['updated_at']=date(DATE_ATOM);mavik_owner_atomic_write(mavik_owner_persistent_file($root),json_encode($j,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
}
function mavik_owner_persistent_cookie(string $value,int $expires): void {
  setcookie('mavik_owner_remember',$value,['expires'=>$expires,'path'=>'/','secure'=>(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off'),'httponly'=>true,'samesite'=>'Strict']);
}
function mavik_owner_persistent_issue(string $root): void {
  $o=mavik_owner_load($root);if(!$o)return;$id=bin2hex(random_bytes(10));$secret=bin2hex(random_bytes(32));$now=time();$expires=$now+315360000;
  $j=mavik_owner_persistent_load($root);$tokens=[];foreach((array)$j['tokens'] as $t){if(!is_array($t)||(int)($t['expires_at']??0)<$now)continue;$tokens[]=$t;}
  $tokens[]=['id'=>$id,'secret_hash'=>hash('sha256',$secret),'email'=>mavik_utf8_lower((string)($o['email']??'')),'created_at'=>date(DATE_ATOM),'last_seen_at'=>date(DATE_ATOM),'expires_at'=>$expires,'ua_hash'=>hash('sha256',(string)($_SERVER['HTTP_USER_AGENT']??''))];
  if(count($tokens)>8)$tokens=array_slice($tokens,-8);$j['tokens']=$tokens;mavik_owner_persistent_save($root,$j);mavik_owner_persistent_cookie($id.'.'.$secret,$expires);
}
function mavik_owner_persistent_revoke_current(string $root): void {
  $raw=(string)($_COOKIE['mavik_owner_remember']??'');$id='';if(preg_match('/^([a-f0-9]{20})\.[a-f0-9]{64}$/',$raw,$m))$id=$m[1];
  if($id!==''){$j=mavik_owner_persistent_load($root);$j['tokens']=array_values(array_filter((array)$j['tokens'],fn($t)=>!is_array($t)||(string)($t['id']??'')!==$id));mavik_owner_persistent_save($root,$j);}mavik_owner_persistent_cookie('',time()-3600);unset($_COOKIE['mavik_owner_remember']);
}
function mavik_owner_persistent_revoke_all(string $root): void {mavik_owner_persistent_save($root,['version'=>1,'tokens'=>[]]);mavik_owner_persistent_cookie('',time()-3600);unset($_COOKIE['mavik_owner_remember']);}
function mavik_owner_restore_persistent(string $root): bool {
  $raw=(string)($_COOKIE['mavik_owner_remember']??'');if(!preg_match('/^([a-f0-9]{20})\.([a-f0-9]{64})$/',$raw,$m))return false;[$all,$id,$secret]=$m;$now=time();$j=mavik_owner_persistent_load($root);$hit=-1;$token=null;
  foreach((array)$j['tokens'] as $i=>$t){if(!is_array($t)||(string)($t['id']??'')!==$id)continue;$hit=(int)$i;$token=$t;break;}if(!$token||(int)($token['expires_at']??0)<$now||!hash_equals((string)($token['secret_hash']??''),hash('sha256',$secret))){mavik_owner_persistent_cookie('',time()-3600);return false;}
  $o=mavik_owner_load($root);if(!$o||!hash_equals(mavik_utf8_lower((string)($o['email']??'')),mavik_utf8_lower((string)($token['email']??'')))){mavik_owner_persistent_revoke_current($root);return false;}
  session_regenerate_id(true);$_SESSION['mavik_owner_auth']=1;$_SESSION['mavik_owner_email']=mavik_utf8_lower((string)$o['email']);$_SESSION['mavik_owner_name']=(string)($o['name']??'Власник MaVik');$_SESSION['mavik_boss_auth']=1;
  $j['tokens'][$hit]['last_seen_at']=date(DATE_ATOM);mavik_owner_persistent_save($root,$j);mavik_maintenance_preview_cookie(true);return true;
}
function mavik_owner_register(string $root,string $name,string $email,string $password): void {
  if(mavik_owner_exists($root)) throw new RuntimeException('Власник сайту вже зареєстрований.');
  $email=mavik_utf8_lower(trim($email));
  if(!filter_var($email,FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Вкажіть коректну email-адресу.');
  mavik_owner_password_ok($password);
  $data=['version'=>1,'role'=>'owner','name'=>trim($name)?:'Власник MaVik','email'=>$email,'password_hash'=>password_hash($password,PASSWORD_DEFAULT),'created_at'=>date(DATE_ATOM),'updated_at'=>date(DATE_ATOM)];
  mavik_owner_atomic_write(mavik_owner_file($root),json_encode($data,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
}
function mavik_owner_emergency_state_file(string $root): string { return mavik_state_path($root,'owner-emergency-password.json'); }
function mavik_owner_emergency_available(string $root): bool {
  $cfg=mavik_owner_config(); $id=(string)($cfg['emergency_password_id']??''); $hash=(string)($cfg['emergency_password_hash']??'');
  if($id===''||$hash==='') return false;
  $f=mavik_owner_emergency_state_file($root); if(!is_file($f)) return true;
  $j=json_decode((string)file_get_contents($f),true); return !is_array($j)||(string)($j['consumed_id']??'')!==$id;
}
function mavik_owner_consume_emergency(string $root,string $id): void {
  mavik_owner_atomic_write(mavik_owner_emergency_state_file($root),json_encode(['version'=>1,'consumed_id'=>$id,'consumed_at'=>date(DATE_ATOM)],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
}
function mavik_owner_set_password(string $root,string $password): void {
  mavik_owner_password_ok($password); $o=mavik_owner_load($root); if(!$o) throw new RuntimeException('Акаунт власника не знайдено.');
  $o['password_hash']=password_hash($password,PASSWORD_DEFAULT);$o['updated_at']=date(DATE_ATOM);$o['password_changed_at']=date(DATE_ATOM);
  mavik_owner_atomic_write(mavik_owner_file($root),json_encode($o,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
  mavik_owner_persistent_revoke_all($root);
}
function mavik_owner_verify_password(string $root,string $password,bool $allowEmergency=true): bool {
  $o=mavik_owner_load($root); if(!$o) return false;
  if(password_verify($password,(string)($o['password_hash']??''))) return true;
  if(!$allowEmergency||!mavik_owner_emergency_available($root)) return false;
  $cfg=mavik_owner_config();$hash=(string)($cfg['emergency_password_hash']??'');
  return $hash!==''&&password_verify($password,$hash);
}
function mavik_owner_login(string $root,string $email,string $password): bool {
  $o=mavik_owner_load($root); if(!$o) return false;
  $email=mavik_utf8_lower(trim($email));
  if(!hash_equals(mavik_utf8_lower((string)($o['email']??'')),$email)) return false;
  $normal=password_verify($password,(string)($o['password_hash']??''));$emergency=false;
  if(!$normal&&mavik_owner_emergency_available($root)){$cfg=mavik_owner_config();$hash=(string)($cfg['emergency_password_hash']??'');$emergency=$hash!==''&&password_verify($password,$hash);}
  if(!$normal&&!$emergency) return false;
  if($emergency){
    // Make the emergency password the current password until the owner changes it in Boss.
    $o['password_hash']=password_hash($password,PASSWORD_DEFAULT);$o['updated_at']=date(DATE_ATOM);$o['emergency_migrated_at']=date(DATE_ATOM);
    mavik_owner_atomic_write(mavik_owner_file($root),json_encode($o,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
    $cfg=mavik_owner_config();mavik_owner_consume_emergency($root,(string)($cfg['emergency_password_id']??''));
  }
  session_regenerate_id(true); $_SESSION['mavik_owner_auth']=1; $_SESSION['mavik_owner_email']=$email; $_SESSION['mavik_owner_name']=(string)($o['name']??'Власник MaVik');
  $_SESSION['mavik_boss_auth']=1;
  mavik_maintenance_preview_cookie(true);
  mavik_owner_persistent_issue($root);
  return true;
}
function mavik_owner_change_password(string $root,string $current,string $new): void {
  if(!mavik_owner_verify_password($root,$current,true)) throw new RuntimeException('Чинний пароль невірний.');
  mavik_owner_set_password($root,$new);
  mavik_owner_persistent_issue($root);
}
function mavik_owner_reset_file(string $root): string { return mavik_state_path($root,'owner-password-reset.json'); }
function mavik_owner_reset_rate_file(string $root): string { return mavik_state_path($root,'owner-password-reset-rate.json'); }
function mavik_owner_reset_request(string $root,string $email): bool {
  $o=mavik_owner_load($root);$email=mavik_utf8_lower(trim($email));
  if(!$o||!filter_var($email,FILTER_VALIDATE_EMAIL)||!hash_equals(mavik_utf8_lower((string)($o['email']??'')),$email)) return true; // generic response
  $now=time();$rf=mavik_owner_reset_rate_file($root);$rate=is_file($rf)?json_decode((string)file_get_contents($rf),true):[];if(!is_array($rate))$rate=[];
  $times=array_values(array_filter(array_map('intval',(array)($rate['times']??[])),fn($t)=>$t>$now-3600));$last=$times?max($times):0;
  if(count($times)>=4||($last>0&&$now-$last<60)) return true;
  $times[]=$now;mavik_owner_atomic_write($rf,json_encode(['version'=>1,'times'=>$times,'updated_at'=>date(DATE_ATOM)],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
  $token=bin2hex(random_bytes(32));$payload=['version'=>1,'token_hash'=>hash('sha256',$token),'email'=>$email,'expires_at'=>$now+1800,'created_at'=>date(DATE_ATOM)];
  mavik_owner_atomic_write(mavik_owner_reset_file($root),json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
  $cfg=mavik_owner_config();$from=(string)($cfg['email']??'viktor@mavik.name');$link='https://mavik.name/account/?reset='.rawurlencode($token);
  $subject='MaVik — скидання пароля';$body="Запитано скидання пароля власника mavik.name.\n\nПосилання діє 30 хвилин і лише один раз:\n".$link."\n\nЯкщо це були не ви — просто проігноруйте лист.\n";
  $headers=['From: MaVik <'.$from.'>','Reply-To: '.$from,'Content-Type: text/plain; charset=UTF-8','X-Mailer: PHP/'.PHP_VERSION];
  @mail($email,'=?UTF-8?B?'.base64_encode($subject).'?=',$body,implode("\r\n",$headers));
  return true;
}
function mavik_owner_reset_validate(string $root,string $token): ?array {
  if(!preg_match('/^[a-f0-9]{64}$/',$token)) return null;$f=mavik_owner_reset_file($root);if(!is_file($f))return null;$j=json_decode((string)file_get_contents($f),true);if(!is_array($j)||!empty($j['used_at'])||(int)($j['expires_at']??0)<time())return null;
  if(!hash_equals((string)($j['token_hash']??''),hash('sha256',$token)))return null;return $j;
}
function mavik_owner_reset_consume(string $root,string $token,string $password): string {
  $j=mavik_owner_reset_validate($root,$token);if(!$j)throw new RuntimeException('Посилання недійсне або вже прострочене.');
  mavik_owner_set_password($root,$password);$j['used_at']=date(DATE_ATOM);mavik_owner_atomic_write(mavik_owner_reset_file($root),json_encode($j,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));return (string)$j['email'];
}
function mavik_owner_logout(): void {
  $root=dirname(__DIR__);if(is_dir($root))mavik_owner_persistent_revoke_current($root);
  mavik_maintenance_preview_cookie(false);
  $_SESSION=[];
  if(ini_get('session.use_cookies')){$p=session_get_cookie_params();setcookie(session_name(),'',time()-42000,$p['path'],$p['domain']??'',(bool)$p['secure'],(bool)$p['httponly']);}
  session_destroy();
}
function mavik_safe_next(string $v,string $fallback='/'): string {
  $v=trim($v); if($v===''||$v[0]!=='/'||str_starts_with($v,'//')||str_contains($v,"\r")||str_contains($v,"\n")) return $fallback;
  return $v;
}

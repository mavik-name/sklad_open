<?php
declare(strict_types=1);
require_once __DIR__ . '/live-sync.php';

/*
 * MaVik release deployer.
 * Accepts full MaVik release ZIPs or multipart release ZIPs, stages them under protected _site-state,
 * creates a pre-deploy backup, preserves runtime data, and removes the uploaded
 * release archive only after a successful deployment.
 */

function mavik_deploy_supported(): bool {
  return class_exists('ZipArchive') || class_exists('PharData');
}

function mavik_deploy_state_dir(string $root): string {
  $dir=rtrim($root,'/').'/_site-state/deploy';
  if(!is_dir($dir)&&!mkdir($dir,0700,true)&&!is_dir($dir))throw new RuntimeException('Не вдалося створити захищений каталог оновлень.');
  @chmod($dir,0700);
  $guard=dirname($dir).'/.htaccess';
  if(!is_file($guard)){
    @file_put_contents($guard,"Options -Indexes\n<IfModule mod_authz_core.c>\n  Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n  Deny from all\n</IfModule>\n",LOCK_EX);
  }
  return $dir;
}

function mavik_deploy_backup_dir(string $root): string {
  $dir=rtrim($root,'/').'/_site-state/backups';
  if(!is_dir($dir)&&!mkdir($dir,0700,true)&&!is_dir($dir))throw new RuntimeException('Не вдалося створити каталог резервних копій.');
  @chmod($dir,0700);
  return $dir;
}

function mavik_deploy_acquire_lock(string $root,string $operation) {
  $file=mavik_deploy_state_dir($root).'/operation.lock';
  $h=@fopen($file,'c+');
  if(!$h)throw new RuntimeException('Не вдалося відкрити lock-файл операцій.');
  if(!@flock($h,LOCK_EX|LOCK_NB)){@fclose($h);throw new RuntimeException('Інша операція deploy/restore уже виконується. Дочекайтеся її завершення.');}
  @ftruncate($h,0);@rewind($h);@fwrite($h,json_encode(['operation'=>$operation,'at'=>date(DATE_ATOM)],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
  @fflush($h);
  return $h;
}
function mavik_deploy_release_lock($h): void {
  if(is_resource($h)){@flock($h,LOCK_UN);@fclose($h);}
}

function mavik_deploy_norm(string $path): string {
  if($path===''||str_contains($path,"\0")||str_contains($path,'\\')||str_starts_with($path,'/')||preg_match('/^[A-Za-z]:/',$path))throw new RuntimeException('Архів містить небезпечний шлях.');
  $path=rtrim($path,'/');
  if($path==='')return '';
  $parts=explode('/',$path);
  foreach($parts as $p)if($p===''||$p==='.'||$p==='..')throw new RuntimeException('Архів містить небезпечний шлях.');
  if(strlen($path)>700)throw new RuntimeException('Архів містить надто довгий шлях.');
  return implode('/',$parts);
}

function mavik_deploy_protected(string $rel): bool {
  $rel=ltrim($rel,'/');
  return $rel==='_site-state'||str_starts_with($rel,'_site-state/')
    ||$rel==='reactions/data'||str_starts_with($rel,'reactions/data/')
    ||$rel==='assets/music/user'||str_starts_with($rel,'assets/music/user/')
    ||$rel==='assets/music/user-covers'||str_starts_with($rel,'assets/music/user-covers/')
    ||$rel==='assets/blog/user'||str_starts_with($rel,'assets/blog/user/')
    ||$rel==='books'||str_starts_with($rel,'books/')
    ||$rel==='blog'||str_starts_with($rel,'blog/')
    ||$rel==='downloads'||str_starts_with($rel,'downloads/')
    ||$rel==='images/covers'||str_starts_with($rel,'images/covers/')
    ||$rel==='images/blog'||str_starts_with($rel,'images/blog/');
}

/**
 * Root files that are part of the site's external verification/SEO identity.
 * They may be refreshed by a full release, but ordinary cleanup/overlay patches
 * must never delete or replace them accidentally.
 */
function mavik_deploy_guarded_root_file(string $rel): bool {
  $rel=ltrim($rel,'/');
  return $rel==='651fd21ecd39f1571c9d4ab6a9a7574c.txt';
}

function mavik_deploy_entries(string $zipPath): array {
  $out=[];
  if(class_exists('ZipArchive')){
    $z=new ZipArchive();
    if($z->open($zipPath)!==true)throw new RuntimeException('Не вдалося відкрити ZIP.');
    try{
      for($i=0;$i<$z->numFiles;$i++){
        $name=(string)$z->getNameIndex($i);
        $isDir=str_ends_with($name,'/');
        $rel=mavik_deploy_norm($name);
        if($rel==='')continue;
        if(method_exists($z,'getExternalAttributesIndex')){
          $opsys=0;$attr=0;
          if($z->getExternalAttributesIndex($i,$opsys,$attr)){
            $mode=($attr>>16)&0170000;
            if($mode===0120000)throw new RuntimeException('Символічні посилання в ZIP не дозволені.');
          }
        }
        $stat=$z->statIndex($i);
        $out[]=['path'=>$rel,'dir'=>$isDir,'size'=>(int)($stat['size']??0)];
      }
    }finally{$z->close();}
    return $out;
  }
  if(!class_exists('PharData'))throw new RuntimeException('На сервері немає підтримки ZIP.');
  try{
    $p=new PharData($zipPath);
    $prefix='phar://'.str_replace('\\','/',$zipPath).'/';
    $it=new RecursiveIteratorIterator($p,RecursiveIteratorIterator::SELF_FIRST);
    foreach($it as $file){
      $full=str_replace('\\','/',$file->getPathName());
      $name=str_starts_with($full,$prefix)?substr($full,strlen($prefix)):basename($full);
      $rel=mavik_deploy_norm($name);
      if($rel==='')continue;
      if(method_exists($file,'isLink')&&$file->isLink())throw new RuntimeException('Символічні посилання в ZIP не дозволені.');
      $out[]=['path'=>$rel,'dir'=>$file->isDir(),'size'=>$file->isFile()?(int)$file->getSize():0];
    }
  }catch(Throwable $e){throw new RuntimeException('Не вдалося прочитати ZIP: '.$e->getMessage());}
  return $out;
}

function mavik_deploy_extract(string $zipPath,string $stage): void {
  if(is_dir($stage))mavik_deploy_rm_tree($stage);
  if(!mkdir($stage,0700,true)&&!is_dir($stage))throw new RuntimeException('Не вдалося створити тимчасову папку.');
  if(class_exists('ZipArchive')){
    $z=new ZipArchive();
    if($z->open($zipPath)!==true)throw new RuntimeException('Не вдалося відкрити ZIP.');
    try{if(!$z->extractTo($stage))throw new RuntimeException('Не вдалося розпакувати ZIP.');}
    finally{$z->close();}
    return;
  }
  try{$p=new PharData($zipPath);$p->extractTo($stage,null,true);}
  catch(Throwable $e){throw new RuntimeException('Не вдалося розпакувати ZIP: '.$e->getMessage());}
}

function mavik_deploy_rm_tree(string $path): void {
  if(!file_exists($path)&&!is_link($path))return;
  if(is_file($path)||is_link($path)){@unlink($path);return;}
  $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);
  foreach($it as $f){$p=$f->getPathname();if($f->isDir()&&!$f->isLink())@rmdir($p);else @unlink($p);}
  @rmdir($path);
}

function mavik_deploy_manifest(string $base): array {
  $f=rtrim($base,'/').'/.mavik-release.json';
  if(!is_file($f))throw new RuntimeException('Це не повна збірка MaVik: немає .mavik-release.json.');
  $raw=file_get_contents($f);$j=$raw!==false?json_decode($raw,true):null;
  if(!is_array($j)||($j['schema']??null)!==1||empty($j['release'])||!is_array($j['managed_files']??null))throw new RuntimeException('Некоректний маніфест збірки.');
  $managed=[];
  foreach($j['managed_files'] as $rel){
    if(!is_string($rel)||$rel==='')continue;
    $n=mavik_deploy_norm($rel);
    if($n!==''&&!mavik_deploy_protected($n)){
      if(!is_file(rtrim($base,'/').'/'.$n))throw new RuntimeException('Маніфест посилається на відсутній файл: '.$n);
      $managed[$n]=1;
    }
  }
  $j['managed_files']=array_keys($managed);
  return $j;
}

function mavik_deploy_validate(string $zipPath): array {
  if(!mavik_deploy_supported())throw new RuntimeException('На сервері немає PHP-підтримки ZIP/Phar.');
  $entries=mavik_deploy_entries($zipPath);
  if(!$entries)throw new RuntimeException('ZIP порожній.');
  if(count($entries)>12000)throw new RuntimeException('У ZIP забагато файлів.');
  $total=0;$seen=[];
  foreach($entries as $e){
    $rel=(string)$e['path'];
    if(isset($seen[$rel]))throw new RuntimeException('У ZIP дублюється шлях: '.$rel);
    $seen[$rel]=1;
    $total+=(int)$e['size'];
    if($total>2*1024*1024*1024)throw new RuntimeException('Розпакований ZIP завеликий.');
  }
  foreach(['index.html','boss/index.php','_site-admin/state.php','robots.txt','sitemap.xml','.mavik-release.json'] as $required)
    if(!isset($seen[$required]))throw new RuntimeException('У збірці бракує обов’язкового файла: '.$required);
  return ['entries'=>$entries,'unpacked_bytes'=>$total];
}


function mavik_deploy_read_entry(string $zipPath,string $entry): string {
  $entry=mavik_deploy_norm($entry);
  if(class_exists('ZipArchive')){
    $z=new ZipArchive();if($z->open($zipPath)!==true)throw new RuntimeException('Не вдалося відкрити ZIP.');
    try{$raw=$z->getFromName($entry);if($raw===false)throw new RuntimeException('У ZIP бракує '.$entry.'.');return (string)$raw;}finally{$z->close();}
  }
  try{$p=new PharData($zipPath);if(!isset($p[$entry]))throw new RuntimeException('У ZIP бракує '.$entry.'.');return (string)$p[$entry]->getContent();}
  catch(Throwable $e){if($e instanceof RuntimeException)throw $e;throw new RuntimeException('Не вдалося прочитати '.$entry.': '.$e->getMessage());}
}

function mavik_deploy_part_meta(string $zipPath): ?array {
  $entries=mavik_deploy_entries($zipPath);$has=false;foreach($entries as $e)if((string)$e['path']==='.mavik-release-part.json'){$has=true;break;}if(!$has)return null;
  $raw=mavik_deploy_read_entry($zipPath,'.mavik-release-part.json');$j=json_decode($raw,true);
  if(!is_array($j)||($j['schema']??null)!==1||($j['kind']??'')!=='mavik-release-part')throw new RuntimeException('Некоректний multipart-маніфест.');
  $release=(int)($j['release']??0);$part=(int)($j['part']??0);$total=(int)($j['total_parts']??0);$set=preg_replace('/[^A-Za-z0-9._-]/','',(string)($j['set_id']??''))??'';$mh=strtolower((string)($j['full_manifest_sha256']??''));
  if($release<1||$part<1||$total<2||$total>8||$part>$total||$set===''||!preg_match('/^[a-f0-9]{64}$/',$mh))throw new RuntimeException('Multipart-маніфест має некоректні поля.');
  return ['release'=>$release,'base_release'=>(int)($j['base_release']??0),'part'=>$part,'total_parts'=>$total,'set_id'=>$set,'full_manifest_sha256'=>$mh];
}

function mavik_deploy_validate_part(string $zipPath,array $meta): array {
  $entries=mavik_deploy_entries($zipPath);if(!$entries)throw new RuntimeException('ZIP-частина порожня.');if(count($entries)>12000)throw new RuntimeException('У ZIP-частині забагато файлів.');
  $seen=[];$total=0;foreach($entries as $e){$rel=(string)$e['path'];if(isset($seen[$rel]))throw new RuntimeException('У ZIP-частині дублюється шлях: '.$rel);$seen[$rel]=1;$total+=(int)$e['size'];if($total>2*1024*1024*1024)throw new RuntimeException('ZIP-частина завелика після розпакування.');}
  foreach(['.mavik-release-part.json','.mavik-release.json'] as $required)if(!isset($seen[$required]))throw new RuntimeException('У ZIP-частині бракує '.$required.'.');
  $manifestRaw=mavik_deploy_read_entry($zipPath,'.mavik-release.json');if(hash('sha256',$manifestRaw)!==$meta['full_manifest_sha256'])throw new RuntimeException('Multipart-частина належить іншому маніфесту релізу.');
  $m=json_decode($manifestRaw,true);if(!is_array($m)||(int)($m['release']??0)!==(int)$meta['release'])throw new RuntimeException('Номер релізу в multipart-частині не збігається.');if((int)($m['base_release']??0)!==(int)$meta['base_release'])throw new RuntimeException('Базовий реліз у multipart-частині не збігається.');
  return ['entries'=>$entries,'unpacked_bytes'=>$total];
}

function mavik_deploy_extract_into(string $zipPath,string $stage): void {
  if(!is_dir($stage)&&!mkdir($stage,0700,true)&&!is_dir($stage))throw new RuntimeException('Не вдалося створити папку складання релізу.');
  if(class_exists('ZipArchive')){$z=new ZipArchive();if($z->open($zipPath)!==true)throw new RuntimeException('Не вдалося відкрити ZIP-частину.');try{if(!$z->extractTo($stage))throw new RuntimeException('Не вдалося розпакувати ZIP-частину.');}finally{$z->close();}return;}
  try{$p=new PharData($zipPath);$p->extractTo($stage,null,true);}catch(Throwable $e){throw new RuntimeException('Не вдалося розпакувати ZIP-частину: '.$e->getMessage());}
}

function mavik_deploy_zip_tree(string $source,string $dest): void {
  @unlink($dest);$base=rtrim($source,DIRECTORY_SEPARATOR);
  try{
    if(class_exists('ZipArchive')){$z=new ZipArchive();if($z->open($dest,ZipArchive::CREATE|ZipArchive::OVERWRITE)!==true)throw new RuntimeException('Не вдалося створити зібраний ZIP.');$zip=$z;}
    else{$zip=new PharData($dest,0,null,Phar::ZIP);}
    $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($base,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::LEAVES_ONLY);
    foreach($it as $f){if(!$f->isFile()||$f->isLink())continue;$abs=$f->getPathname();$rel=str_replace('\\','/',substr($abs,strlen($base)+1));mavik_deploy_add_to_zip($zip,$abs,$rel);}
    if($zip instanceof ZipArchive)$zip->close();else unset($zip);
  }catch(Throwable $e){@unlink($dest);throw $e;}
  if(!is_file($dest)||filesize($dest)<1000)throw new RuntimeException('Зібраний ZIP не створився.');
}

function mavik_deploy_apply_tree(string $root,string $stage,string $originalName='release tree',int $unpackedBytes=0): array {
  @set_time_limit(0);@ignore_user_abort(true);$readerSnapshot=mavik_deploy_reader_content_snapshot($root);$blogSnapshot=mavik_deploy_blog_content_snapshot($root);$staticPageSnapshot=mavik_deploy_static_page_content_snapshot($root);$backup='';$tx='';$newManaged=[];$release='?';$releaseLabel='?';
  try{
    $manifest=mavik_deploy_manifest($stage);$release=(string)$manifest['release'];$releaseLabel=trim((string)($manifest['release_label']??''));if($releaseLabel==='')$releaseLabel='R'.$release;$newManaged=array_fill_keys($manifest['managed_files'],1);
    foreach(['index.html','boss/index.php','_site-admin/deploy.php'] as $required)
      if(!isset($newManaged[$required])||!is_file($stage.'/'.$required))throw new RuntimeException('Маніфест не охоплює обов’язковий файл: '.$required);
    if($unpackedBytes<1){foreach($manifest['managed_files'] as $rel){$f=$stage.'/'.$rel;if(is_file($f))$unpackedBytes+=(int)filesize($f);}}
    $oldManaged=[];$currentManifest=$root.'/.mavik-release.json';
    if(is_file($currentManifest)){
      $raw=file_get_contents($currentManifest);$old=$raw!==false?json_decode($raw,true):null;
      if(is_array($old)&&is_array($old['managed_files']??null))foreach($old['managed_files'] as $r){try{$n=mavik_deploy_norm((string)$r);if($n!==''&&!mavik_deploy_protected($n))$oldManaged[]=$n;}catch(Throwable $e){}}
    }
    $backup=mavik_deploy_backup($root,$releaseLabel);$affected=$newManaged;foreach($oldManaged as $rel)$affected[$rel]=1;$tx=mavik_deploy_transaction_snapshot($root,$affected);$removed=mavik_deploy_remove_obsolete($root,$oldManaged,$newManaged);$copied=mavik_deploy_copy_tree($stage,$root,$newManaged);$restoredReaders=mavik_deploy_reader_content_restore($root,$readerSnapshot);$restoredBlog=mavik_deploy_blog_content_restore($root,$blogSnapshot);$restoredStaticPages=mavik_deploy_static_page_content_restore($root,$staticPageSnapshot);
    $sync=mavik_live_sync_after_deploy($root);
    foreach(['index.html','boss/index.php','robots.txt','sitemap.xml','.mavik-release.json'] as $f)if(!is_file($root.'/'.$f)||filesize($root.'/'.$f)<1)throw new RuntimeException('Контроль після розгортання не пройдено: '.$f);
    mavik_deploy_log($root,['at'=>date(DATE_ATOM),'status'=>'success','release'=>$release,'release_label'=>$releaseLabel,'archive'=>$originalName,'copied'=>$copied,'removed'=>$removed,'backup'=>basename($backup)]);
    mavik_deploy_rm_tree($stage);if($tx!=='')mavik_deploy_rm_tree($tx);mavik_deploy_prune_backups($root,7);
    return ['release'=>$release,'release_label'=>$releaseLabel,'copied'=>$copied,'removed'=>$removed,'backup'=>basename($backup),'unpacked_bytes'=>$unpackedBytes];
  }catch(Throwable $e){
    $rollback='';try{if($tx!==''&&is_dir($tx))mavik_deploy_transaction_restore($root,$tx);if($backup!==''&&is_file($backup))mavik_deploy_restore_database_backup($root,$backup);$rollback=' Попередню версію автоматично відновлено.';}catch(Throwable $r){$rollback=' Автовідновлення не вдалося: '.$r->getMessage();}if($tx!=='')mavik_deploy_rm_tree($tx);
    mavik_deploy_rm_tree($stage);mavik_deploy_log($root,['at'=>date(DATE_ATOM),'status'=>'failed','release'=>$release,'release_label'=>$releaseLabel,'archive'=>$originalName,'error'=>$e->getMessage(),'backup'=>$backup?basename($backup):null]);
    throw new RuntimeException($e->getMessage().$rollback);
  }
}

function mavik_deploy_pending_part_path(string $root,array $meta,int $part): string {
  return mavik_deploy_state_dir($root).'/pending-'.$meta['set_id'].'-part-'.$part.'.zip';
}

function mavik_deploy_multipart_receive(string $root,string $uploaded,string $originalName,array $meta): array {
  mavik_deploy_validate_part($uploaded,$meta);$dest=mavik_deploy_pending_part_path($root,$meta,(int)$meta['part']);@unlink($dest);if(!rename($uploaded,$dest)){if(!copy($uploaded,$dest))throw new RuntimeException('Не вдалося зберегти multipart-частину.');@unlink($uploaded);}
  $paths=[];for($i=1;$i<=(int)$meta['total_parts'];$i++){$q=mavik_deploy_pending_part_path($root,$meta,$i);if(!is_file($q))return ['waiting'=>true,'release'=>$meta['release'],'part'=>$meta['part'],'total_parts'=>$meta['total_parts']];$pm=mavik_deploy_part_meta($q);if(!$pm||$pm['set_id']!==$meta['set_id']||(int)$pm['release']!==(int)$meta['release']||(int)$pm['total_parts']!==(int)$meta['total_parts']||$pm['full_manifest_sha256']!==$meta['full_manifest_sha256'])throw new RuntimeException('Збережені multipart-частини не належать одному релізу.');$paths[]=$q;}
  $state=mavik_deploy_state_dir($root);$merge=$state.'/merge-'.$meta['set_id'].'-'.bin2hex(random_bytes(3));$assembled=$state.'/assembled-'.$meta['set_id'].'.zip';
  try{
    if(!mkdir($merge,0700,true)&&!is_dir($merge))throw new RuntimeException('Не вдалося створити серверну папку складання.');
    foreach($paths as $q)mavik_deploy_extract_into($q,$merge);@unlink($merge.'/.mavik-release-part.json');
    $mf=$merge.'/.mavik-release.json';if(!is_file($mf)||hash_file('sha256',$mf)!==$meta['full_manifest_sha256'])throw new RuntimeException('Після складання контрольний маніфест не збігається.');
    $manifest=mavik_deploy_manifest($merge);if((int)$manifest['release']!==(int)$meta['release'])throw new RuntimeException('Після складання отримано інший номер релізу.');if((int)($manifest['base_release']??0)!==(int)$meta['base_release'])throw new RuntimeException('Після складання отримано інший базовий реліз.');
    $newManaged=array_fill_keys($manifest['managed_files'],1);$bytes=0;foreach($manifest['managed_files'] as $rel){$f=$merge.'/'.$rel;if(!is_file($f))throw new RuntimeException('Після складання бракує файла з маніфесту: '.$rel);$bytes+=(int)filesize($f);}
    $r=mavik_deploy_apply_tree($root,$merge,'multipart R'.$meta['release'].' ('.$meta['total_parts'].' parts)',$bytes);
    foreach($paths as $q)@unlink($q);@unlink($assembled);$r['multipart']=true;$r['parts']=(int)$meta['total_parts'];return $r;
  }catch(Throwable $e){@unlink($assembled);mavik_deploy_rm_tree($merge);throw new RuntimeException($e->getMessage().' Multipart-частини залишено у захищеній папці Boss для повторної спроби.');}
}

function mavik_deploy_copy_file(string $src,string $dest): void {
  $dir=dirname($dest);
  if(!is_dir($dir)&&!mkdir($dir,0755,true)&&!is_dir($dir))throw new RuntimeException('Не вдалося створити '.$dir);
  $tmp=$dest.'.deploy-'.bin2hex(random_bytes(4));
  if(!copy($src,$tmp)){@unlink($tmp);throw new RuntimeException('Не вдалося записати '.basename($dest));}
  @chmod($tmp,fileperms($src)&0777 ?: 0644);
  if(!rename($tmp,$dest)){@unlink($tmp);throw new RuntimeException('Не вдалося замінити '.basename($dest));}
  if(function_exists('opcache_invalidate')&&str_ends_with(strtolower($dest),'.php'))@opcache_invalidate($dest,true);
}

function mavik_deploy_copy_tree(string $from,string $root,array $managedOnly=[]): int {
  $count=0;$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($from,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::SELF_FIRST);
  foreach($it as $f){
    $abs=$f->getPathname();$rel=str_replace('\\','/',substr($abs,strlen(rtrim($from,DIRECTORY_SEPARATOR))+1));
    $rel=mavik_deploy_norm($rel);if($rel===''||mavik_deploy_protected($rel))continue;
    if($f->isDir()){if(!is_dir($root.'/'.$rel))@mkdir($root.'/'.$rel,0755,true);continue;}
    if($managedOnly&&!isset($managedOnly[$rel]))continue;
    mavik_deploy_copy_file($abs,$root.'/'.$rel);$count++;
  }
  return $count;
}

function mavik_deploy_remove_obsolete(string $root,array $oldManaged,array $newManaged): int {
  $removed=0;$candidateDirs=[];$root=rtrim($root,'/');
  $rememberParents=static function(string $rel)use(&$candidateDirs): void {
    $dir=str_replace('\\','/',dirname($rel));
    while($dir!=='.'&&$dir!==''&&$dir!=='/'){
      if(mavik_deploy_protected($dir))break;
      $candidateDirs[$dir]=substr_count($dir,'/');
      $next=str_replace('\\','/',dirname($dir));
      if($next===$dir)break;
      $dir=$next;
    }
  };
  foreach($oldManaged as $rel){
    if(isset($newManaged[$rel])||mavik_deploy_protected($rel)||mavik_deploy_guarded_root_file($rel))continue;
    $p=$root.'/'.$rel;
    if(is_file($p)||is_link($p)){
      if(@unlink($p)){$removed++;$rememberParents($rel);}
    }
  }
  /* One obsolete helper existed before release manifests were introduced. */
  $legacyRel='_site-admin/local-files.php';$legacy=$root.'/'.$legacyRel;
  if(is_file($legacy)&&!isset($newManaged[$legacyRel])){if(@unlink($legacy)){$removed++;$rememberParents($legacyRel);}}

  /* Full releases must not leave empty legacy trees from older site architectures. */
  arsort($candidateDirs,SORT_NUMERIC);
  foreach(array_keys($candidateDirs) as $relDir){
    if($relDir===''||$relDir==='.'||mavik_deploy_protected($relDir))continue;
    $abs=$root.'/'.$relDir;
    if(is_dir($abs)&&!is_link($abs))@rmdir($abs); /* rmdir succeeds only when the directory is truly empty. */
  }
  return $removed;
}

function mavik_deploy_add_to_zip($zip,string $file,string $rel): void {
  if($zip instanceof ZipArchive){
    if(!$zip->addFile($file,$rel))throw new RuntimeException('Не вдалося додати файл у резервну копію.');
  }else{
    $zip->addFile($file,$rel);
  }
}


function mavik_deploy_live_backup_files(string $root): array {
  $root=rtrim($root,'/');
  $out=[];
  $addFile=static function(string $abs,string $rel)use(&$out): void {
    if(!is_file($abs)||is_link($abs))return;
    $rel=str_replace('\\','/',ltrim($rel,'/'));
    if($rel===''||str_starts_with($rel,'_site-state/backups/')||str_starts_with($rel,'_site-state/deploy/')||$rel==='_site-state/operation.lock')return;
    $out[$rel]=$abs;
  };
  $addTree=static function(string $base,string $relBase)use(&$out,$addFile): void {
    if(!is_dir($base))return;
    $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($base,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::LEAVES_ONLY);
    foreach($it as $f){
      if(!$f->isFile()||$f->isLink())continue;
      $rel=str_replace('\\','/',substr($f->getPathname(),strlen(rtrim($base,'/'))+1));
      $addFile($f->getPathname(),trim($relBase,'/').'/'.$rel);
    }
  };
  $addTree($root.'/_site-state','_site-state');
  foreach([
    ['assets/music/user','assets/music/user'],
    ['assets/music/user-covers','assets/music/user-covers'],
    ['assets/blog/user','assets/blog/user'],
    ['images/covers','images/covers'],
    ['images/blog','images/blog'],
    ['reactions/data','reactions/data'],
    ['blog','blog'],
    ['books','books'],
    ['downloads','downloads'],
  ] as $pair)$addTree($root.'/'.$pair[0],$pair[1]);
  ksort($out);
  return $out;
}

function mavik_deploy_backup_info(string $backup): ?array {
  try{
    $raw=mavik_deploy_read_entry($backup,'BACKUP-INFO.json');
    $j=json_decode($raw,true);
    return is_array($j)?$j:null;
  }catch(Throwable $e){return null;}
}

function mavik_deploy_verify_backup(string $backup): array {
  if(!is_file($backup)||filesize($backup)<200)throw new RuntimeException('Резервна копія не створилася або порожня.');
  $info=mavik_deploy_backup_info($backup);
  if(!is_array($info)||($info['schema']??null)!==2||($info['kind']??'')!=='mavik-live-data-backup'||!is_array($info['files']??null))
    throw new RuntimeException('Резервна копія не пройшла перевірку маніфесту.');
  $checked=0;$bytes=0;
  foreach($info['files'] as $rel=>$meta){
    if(!is_string($rel)||!is_array($meta))throw new RuntimeException('Некоректний запис у backup manifest.');
    $raw=mavik_deploy_read_entry($backup,$rel);
    $sha=hash('sha256',$raw);
    if(!hash_equals((string)($meta['sha256']??''),$sha))throw new RuntimeException('Backup checksum не збігається: '.$rel);
    if((int)($meta['size']??-1)!==strlen($raw))throw new RuntimeException('Backup size не збігається: '.$rel);
    $checked++;$bytes+=strlen($raw);
  }
  $archiveSha=hash_file('sha256',$backup);if(!is_string($archiveSha)||!preg_match('/^[a-f0-9]{64}$/',$archiveSha))throw new RuntimeException('Не вдалося обчислити checksum резервної копії.');
  $sidecar=$backup.'.sha256';if(is_file($sidecar)){$line=trim((string)@file_get_contents($sidecar));$expected=strtolower((string)(preg_split('/\s+/', $line,2)[0]??''));if(!preg_match('/^[a-f0-9]{64}$/',$expected)||!hash_equals($expected,$archiveSha))throw new RuntimeException('Checksum архіву backup не збігається.');}
  return ['ok'=>true,'files'=>$checked,'bytes'=>$bytes,'info'=>$info,'archive_sha256'=>$archiveSha];
}

function mavik_deploy_backup(string $root,string $release): string {
  $dir=mavik_deploy_backup_dir($root);
  $safe=preg_replace('/[^A-Za-z0-9._-]+/','-',trim($release))?:'release';
  $useZip=class_exists('ZipArchive');
  $path=$dir.'/live-before-'.$safe.'-'.date('Ymd-His').($useZip?'.zip':'.tar');
  @unlink($path.'.sha256');
  $files=mavik_deploy_live_backup_files($root);
  $metaFiles=[];
  foreach($files as $rel=>$abs)$metaFiles[$rel]=['size'=>(int)filesize($abs),'sha256'=>hash_file('sha256',$abs)];
  $stateRaw=is_file(rtrim($root,'/').'/_site-state/boss-content.json')?@file_get_contents(rtrim($root,'/').'/_site-state/boss-content.json'):false;$state=$stateRaw?json_decode($stateRaw,true):null;$bookCount=is_array($state)?count(array_filter((array)($state['books']??[]),'is_array')):0;$blogCount=is_array($state)?count(array_filter((array)($state['blog']??[]),'is_array')):0;$orderRaw=is_file(rtrim($root,'/').'/_site-state/book-order.json')?@file_get_contents(rtrim($root,'/').'/_site-state/book-order.json'):false;$orderJ=$orderRaw?json_decode($orderRaw,true):null;$orderCount=is_array($orderJ)?count((array)($orderJ['order']??[])):0;
  $info=['schema'=>2,'kind'=>'mavik-live-data-backup','release'=>$release,'created_at'=>date(DATE_ATOM),'file_count'=>count($metaFiles),'live_counts'=>['books'=>$bookCount,'blog'=>$blogCount,'book_order'=>$orderCount],'files'=>$metaFiles];
  try{
    if($useZip){
      $z=new ZipArchive();
      if($z->open($path,ZipArchive::CREATE|ZipArchive::OVERWRITE)!==true)throw new RuntimeException('Не вдалося створити ZIP backup.');
      foreach($files as $rel=>$abs)mavik_deploy_add_to_zip($z,$abs,$rel);
      $encoded=json_encode($info,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE);
      if(!is_string($encoded))throw new RuntimeException('Не вдалося створити backup manifest.');
      $z->addFromString('BACKUP-INFO.json',$encoded."\n");
      $z->close();
    }else{
      $archive=new PharData($path);
      foreach($files as $rel=>$abs)$archive->addFile($abs,$rel);
      $encoded=json_encode($info,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE);
      if(!is_string($encoded))throw new RuntimeException('Не вдалося створити backup manifest.');
      $archive->addFromString('BACKUP-INFO.json',$encoded."\n");
      unset($archive);
    }
    $verify=mavik_deploy_verify_backup($path);
    $sha=(string)$verify['archive_sha256'];
    if(@file_put_contents($path.'.sha256',$sha."  ".basename($path)."\n",LOCK_EX)===false)throw new RuntimeException('Не вдалося зберегти checksum backup.');
  }catch(Throwable $e){
    @unlink($path);@unlink($path.'.sha256');
    throw new RuntimeException('Safety-backup не створено або не перевірено; deploy ЗАБОРОНЕНО: '.$e->getMessage());
  }
  mavik_deploy_prune_backups($root,7);
  return $path;
}

function mavik_deploy_restore_database_backup(string $root,string $backup): void {
  mavik_deploy_verify_backup($backup);
  $stage=mavik_deploy_state_dir($root).'/live-rollback-'.bin2hex(random_bytes(4));
  try{
    mavik_deploy_extract($backup,$stage);
    $infoRaw=@file_get_contents($stage.'/BACKUP-INFO.json');
    $info=$infoRaw?json_decode($infoRaw,true):null;
    if(!is_array($info)||!is_array($info['files']??null))throw new RuntimeException('Backup manifest не читається після розпакування.');
    foreach(array_keys($info['files']) as $rel){
      $rel=mavik_deploy_norm((string)$rel);
      if($rel===''||str_starts_with($rel,'_site-state/backups/')||str_starts_with($rel,'_site-state/deploy/'))continue;
      $src=$stage.'/'.$rel;
      if(!is_file($src))throw new RuntimeException('У backup бракує файла: '.$rel);
      $dest=rtrim($root,'/').'/'.$rel;
      $dir=dirname($dest);
      if(!is_dir($dir)&&!mkdir($dir,0755,true)&&!is_dir($dir))throw new RuntimeException('Не вдалося створити каталог для restore: '.$rel);
      $tmp=$dest.'.restore-'.bin2hex(random_bytes(3));
      if(!copy($src,$tmp)){@unlink($tmp);throw new RuntimeException('Не вдалося відновити '.$rel);}
      @chmod($tmp,str_starts_with($rel,'_site-state/')?0640:0644);
      if(!@rename($tmp,$dest)){@unlink($tmp);throw new RuntimeException('Не вдалося замінити '.$rel);}
    }
  }finally{mavik_deploy_rm_tree($stage);}
}

function mavik_deploy_manual_backup(string $root,string $label='manual'): string {
  $path=mavik_deploy_backup($root,$label);
  mavik_deploy_log($root,['at'=>date(DATE_ATOM),'status'=>'backup-created','label'=>$label,'backup'=>basename($path)]);
  return $path;
}

function mavik_deploy_json_file(string $file): ?array {
  $raw=is_file($file)?@file_get_contents($file):false;$j=$raw?json_decode($raw,true):null;return is_array($j)?$j:null;
}
function mavik_deploy_safe_json_write(string $file,array $data): void {
  $dir=dirname($file);if(!is_dir($dir)&&!mkdir($dir,0750,true)&&!is_dir($dir))throw new RuntimeException('Не вдалося створити LIVE DATA каталог.');
  $raw=json_encode($data,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE);if(!is_string($raw))throw new RuntimeException('Не вдалося закодувати LIVE DATA.');
  $tmp=$file.'.restore-safe-'.bin2hex(random_bytes(3));if(file_put_contents($tmp,$raw."\n",LOCK_EX)===false){@unlink($tmp);throw new RuntimeException('Не вдалося записати LIVE DATA.');}@chmod($tmp,0640);if(!@rename($tmp,$file)){@unlink($tmp);throw new RuntimeException('Не вдалося замінити LIVE DATA.');}
}
function mavik_deploy_restore_guard_snapshot(string $root): array {
  $state=rtrim($root,'/').'/_site-state';return [
    'manifest'=>mavik_deploy_json_file($state.'/boss-content.json'),
    'book_order'=>mavik_deploy_json_file($state.'/book-order.json'),
    'book_focus'=>mavik_deploy_json_file($state.'/book-focus.json'),
    'blog_focus'=>mavik_deploy_json_file($state.'/blog-focus.json')
  ];
}
function mavik_deploy_merge_newer_physical_records(string $root,?array $before): array {
  $file=rtrim($root,'/').'/_site-state/boss-content.json';$after=mavik_deploy_json_file($file);if(!is_array($after))$after=['version'=>7,'books'=>[],'blog'=>[]];if(!is_array($before))$before=['books'=>[],'blog'=>[]];$addedBooks=[];$addedBlog=[];
  foreach(['books','blog'] as $type){if(!is_array($after[$type]??null))$after[$type]=[];$known=[];foreach($after[$type] as $row)if(is_array($row)&&($slug=(string)($row['slug']??''))!=='')$known[$slug]=1;foreach((array)($before[$type]??[]) as $row){if(!is_array($row)||($slug=(string)($row['slug']??''))===''||isset($known[$slug]))continue;$physical=$type==='books'?rtrim($root,'/').'/books/'.$slug.'/index.html':rtrim($root,'/').'/blog/'.$slug.'/index.html';if(!is_file($physical))continue;$after[$type][]=$row;$known[$slug]=1;if($type==='books')$addedBooks[]=$slug;else $addedBlog[]=$slug;}}
  $after['version']=max(7,(int)($after['version']??0));$after['updated_at']=date(DATE_ATOM);mavik_deploy_safe_json_write($file,$after);return ['books'=>$addedBooks,'blog'=>$addedBlog];
}
function mavik_deploy_restore_navigation_guard(string $root,array $guard): void {
  $state=rtrim($root,'/').'/_site-state';foreach(['book_order'=>'book-order.json','book_focus'=>'book-focus.json','blog_focus'=>'blog-focus.json'] as $key=>$name)if(is_array($guard[$key]??null))mavik_deploy_safe_json_write($state.'/'.$name,$guard[$key]);
}
function mavik_deploy_reapply_current_book_order(string $root,?array $bookOrder): void {
  if(!is_array($bookOrder)||!is_array($bookOrder['order']??null))return;$file=rtrim($root,'/').'/_site-state/boss-content.json';$m=mavik_deploy_json_file($file);if(!is_array($m)||!is_array($m['books']??null))return;
  $by=[];$rest=[];foreach($m['books'] as $row){if(!is_array($row)||($slug=(string)($row['slug']??''))===''){$rest[]=$row;continue;}if(!isset($by[$slug]))$by[$slug]=$row;else $rest[]=$row;}
  $ordered=[];$used=[];foreach($bookOrder['order'] as $slug){$slug=(string)$slug;if($slug!==''&&isset($by[$slug])&&!isset($used[$slug])){$ordered[]=$by[$slug];$used[$slug]=1;}}
  foreach($m['books'] as $row){if(!is_array($row)||($slug=(string)($row['slug']??''))===''){continue;}if(!isset($used[$slug])){$ordered[]=$row;$used[$slug]=1;}}
  foreach($rest as $row)if(!is_array($row)||($slug=(string)($row['slug']??''))===''||!isset($used[$slug]))$ordered[]=$row;
  $m['books']=$ordered;$m['updated_at']=date(DATE_ATOM);mavik_deploy_safe_json_write($file,$m);
}

function mavik_deploy_restore_named_backup(string $root,string $name): array {
  if(!preg_match('/^live-before-[A-Za-z0-9._-]+\.(?:zip|tar)$/',$name))throw new RuntimeException('Некоректне ім’я backup.');
  $path=mavik_deploy_backup_dir($root).'/'.$name;if(!is_file($path))throw new RuntimeException('Backup не знайдено.');$lock=mavik_deploy_acquire_lock($root,'restore');
  try{
    $guard=mavik_deploy_restore_guard_snapshot($root);$safety=mavik_deploy_backup($root,'before-restore');mavik_deploy_restore_database_backup($root,$path);
    $reconciled=mavik_deploy_merge_newer_physical_records($root,is_array($guard['manifest']??null)?$guard['manifest']:null);mavik_deploy_restore_navigation_guard($root,$guard);mavik_deploy_reapply_current_book_order($root,is_array($guard['book_order']??null)?$guard['book_order']:null);
    $sync=function_exists('mavik_live_sync_after_deploy')?mavik_live_sync_after_deploy($root):[];
    $final=mavik_deploy_json_file(rtrim($root,'/').'/_site-state/boss-content.json');$books=is_array($final)?count(array_filter((array)($final['books']??[]),'is_array')):0;$blog=is_array($final)?count(array_filter((array)($final['blog']??[]),'is_array')):0;
    mavik_deploy_log($root,['at'=>date(DATE_ATOM),'status'=>'restore-success','backup'=>$name,'safety_backup'=>basename($safety),'reconciled'=>$reconciled,'books_after'=>$books,'blog_after'=>$blog]);
    return ['restored'=>$name,'safety_backup'=>basename($safety),'sync'=>$sync,'reconciled'=>$reconciled,'books_after'=>$books,'blog_after'=>$blog];
  }catch(Throwable $e){mavik_deploy_log($root,['at'=>date(DATE_ATOM),'status'=>'restore-failed','backup'=>$name,'error'=>$e->getMessage()]);throw $e;}finally{mavik_deploy_release_lock($lock);}
}

function mavik_deploy_backup_path(string $root,string $name): string {
  if(!preg_match('/^live-before-[A-Za-z0-9._-]+\.(?:zip|tar)$/',$name))throw new RuntimeException('Некоректне ім’я backup.');
  $path=mavik_deploy_backup_dir($root).'/'.$name;
  if(!is_file($path))throw new RuntimeException('Backup не знайдено.');
  return $path;
}

function mavik_deploy_daily_backup_if_due(string $root,int $hours=24): ?string {
  $files=mavik_deploy_backup_files($root);
  $newest=0;
  foreach($files as $f)$newest=max($newest,(int)@filemtime($f));
  if($newest>0&&time()-$newest<$hours*3600)return null;
  return mavik_deploy_backup($root,'daily-auto');
}

function mavik_deploy_stream_backup(string $root,string $name): void {
  $path=mavik_deploy_backup_path($root,$name);
  mavik_deploy_verify_backup($path);
  header('Content-Type: '.(str_ends_with(strtolower($path),'.zip')?'application/zip':'application/x-tar'));
  header('Content-Disposition: attachment; filename="'.basename($path).'"');
  header('Content-Length: '.(string)filesize($path));
  header('Cache-Control: no-store, private');
  readfile($path);
  exit;
}

function mavik_deploy_transaction_snapshot(string $root,array $paths): string {
  $dir=mavik_deploy_state_dir($root).'/tx-'.date('Ymd-His').'-'.bin2hex(random_bytes(3));if(!mkdir($dir,0700,true)&&!is_dir($dir))throw new RuntimeException('Не вдалося створити transaction snapshot.');$meta=['schema'=>1,'created_at'=>date(DATE_ATOM),'paths'=>[]];
  try{foreach(array_keys($paths) as $rel){$rel=mavik_deploy_norm((string)$rel);if($rel===''||mavik_deploy_protected($rel))continue;$src=rtrim($root,'/').'/'.$rel;$row=['path'=>$rel,'existed'=>is_file($src)||is_link($src)];if($row['existed']&&is_file($src)&&!is_link($src)){$dst=$dir.'/files/'.$rel;$d=dirname($dst);if(!is_dir($d)&&!mkdir($d,0700,true)&&!is_dir($d))throw new RuntimeException('Не вдалося створити transaction path.');if(!@link($src,$dst)&&!copy($src,$dst))throw new RuntimeException('Не вдалося застрахувати '.$rel);}$meta['paths'][]=$row;}file_put_contents($dir.'/snapshot.json',json_encode($meta,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES),LOCK_EX);return $dir;}catch(Throwable $e){mavik_deploy_rm_tree($dir);throw $e;}
}
function mavik_deploy_transaction_restore(string $root,string $tx): void {
  $raw=@file_get_contents($tx.'/snapshot.json');$j=$raw?json_decode($raw,true):null;if(!is_array($j))throw new RuntimeException('Некоректний transaction snapshot.');foreach((array)($j['paths']??[]) as $row){if(!is_array($row))continue;$rel=mavik_deploy_norm((string)($row['path']??''));if($rel===''||mavik_deploy_protected($rel))continue;$dest=rtrim($root,'/').'/'.$rel;if(is_file($dest)||is_link($dest))@unlink($dest);if(!empty($row['existed'])){$src=$tx.'/files/'.$rel;if(!is_file($src))throw new RuntimeException('У transaction snapshot бракує '.$rel);$d=dirname($dest);if(!is_dir($d))@mkdir($d,0755,true);if(!copy($src,$dest))throw new RuntimeException('Не вдалося відкотити '.$rel);}}
}

function mavik_deploy_backup_files(string $root): array {
  $dir=mavik_deploy_backup_dir($root);
  return array_values(array_merge(glob($dir.'/live-before-*.zip')?:[],glob($dir.'/live-before-*.tar')?:[]));
}

function mavik_deploy_backup_is_golden(string $file): bool {
  $info=mavik_deploy_backup_info($file);
  return is_array($info)&&str_starts_with(strtolower(trim((string)($info['release']??''))),'golden');
}

function mavik_deploy_backup_is_predeploy(string $file): bool {
  $info=mavik_deploy_backup_info($file);$label=is_array($info)?strtolower(trim((string)($info['release']??''))):'';
  return $label!==''&&preg_match('/^(?:manual|daily|before-restore|golden)/',$label)!==1;
}

function mavik_deploy_protected_backup_names(string $root): array {
  $files=mavik_deploy_backup_files($root);
  usort($files,fn($a,$b)=>filemtime($b)<=>filemtime($a));$out=[];
  foreach($files as $file)if(mavik_deploy_backup_is_golden($file)){$out[basename($file)]=true;break;}
  foreach($files as $file)if(mavik_deploy_backup_is_predeploy($file)){$out[basename($file)]=true;break;}
  if(!$out&&$files)$out[basename($files[0])]=true;
  return $out;
}
function mavik_deploy_protected_backup_name(string $root): string {
  $names=array_keys(mavik_deploy_protected_backup_names($root));return $names[0]??'';
}

function mavik_deploy_prune_backups(string $root,int $keep=7): void {
  $files=mavik_deploy_backup_files($root);usort($files,fn($a,$b)=>filemtime($b)<=>filemtime($a));$keepSet=[];
  /* Golden copies are removed only by an explicit owner action. */
  foreach($files as $f)if(mavik_deploy_backup_is_golden($f))$keepSet[$f]=1;
  foreach(mavik_deploy_protected_backup_names($root) as $name=>$yes)$keepSet[mavik_deploy_backup_dir($root).'/'.$name]=1;
  $keep=max(1,$keep);foreach(array_slice($files,0,$keep) as $f)$keepSet[$f]=1;
  $weeks=[];$months=[];foreach(array_slice($files,$keep) as $f){$ts=(int)filemtime($f);$wk=date('o-W',$ts);$mo=date('Y-m',$ts);if(count($weeks)<4&&!isset($weeks[$wk])){$weeks[$wk]=1;$keepSet[$f]=1;continue;}if(count($months)<3&&!isset($months[$mo])){$months[$mo]=1;$keepSet[$f]=1;}}
  foreach($files as $f)if(!isset($keepSet[$f])){@unlink($f);@unlink($f.'.sha256');}
}

function mavik_deploy_delete_backups(string $root,array $names): array {
  $names=array_values(array_unique(array_filter(array_map('strval',$names))));
  if(!$names)throw new RuntimeException('Не вибрано жодної резервної копії.');
  $lock=mavik_deploy_acquire_lock($root,'backup-delete');$deleted=[];
  try{
    $protected=mavik_deploy_protected_backup_names($root);
    foreach($names as $name){
      if(!preg_match('/^live-before-[A-Za-z0-9._-]+\.(?:zip|tar)$/',$name))throw new RuntimeException('Некоректне ім’я backup.');
      if(isset($protected[$name]))throw new RuntimeException('Поточний контрольний backup захищено від видалення. Спочатку створіть новий золотий або predeploy backup.');
    }
    foreach($names as $name){
      $path=mavik_deploy_backup_dir($root).'/'.$name;
      if(!is_file($path))continue;
      if(!@unlink($path))throw new RuntimeException('Не вдалося видалити '.$name.'.');
      @unlink($path.'.sha256');$deleted[]=$name;
    }
    mavik_deploy_log($root,['at'=>date(DATE_ATOM),'status'=>'backup-delete','backups'=>$deleted]);
    return $deleted;
  }finally{mavik_deploy_release_lock($lock);}
}

function mavik_deploy_backups(string $root): array {
  $files=mavik_deploy_backup_files($root);
  usort($files,fn($a,$b)=>filemtime($b)<=>filemtime($a));$out=[];
  $protected=mavik_deploy_protected_backup_names($root);
  foreach($files as $f){
    $info=mavik_deploy_backup_info($f);
    $out[]=['name'=>basename($f),'size'=>(int)filesize($f),'mtime'=>(int)filemtime($f),
      'release'=>(string)($info['release']??''),'created_at'=>(string)($info['created_at']??''),
      'file_count'=>(int)($info['file_count']??count((array)($info['files']??[]))),
      'books'=>(int)($info['live_counts']['books']??0),'blog'=>(int)($info['live_counts']['blog']??0),'book_order'=>(int)($info['live_counts']['book_order']??0),
      'verified'=>is_file($f.'.sha256'),'golden'=>mavik_deploy_backup_is_golden($f),'protected'=>isset($protected[basename($f)])];
  }
  return $out;
}


function mavik_deploy_failed_archives(string $root): array {
  $files=glob(mavik_deploy_state_dir($root).'/failed-*.zip')?:[];
  usort($files,fn($a,$b)=>filemtime($b)<=>filemtime($a));$out=[];
  foreach($files as $f)$out[]=['name'=>basename($f),'size'=>(int)filesize($f),'mtime'=>(int)filemtime($f)];
  return $out;
}

function mavik_deploy_delete_failed(string $root,string $name): void {
  if(!preg_match('/^failed-[A-Za-z0-9._-]+\.zip$/',$name))throw new RuntimeException('Некоректне ім’я архіву.');
  $p=mavik_deploy_state_dir($root).'/'.$name;
  if(!is_file($p)||!@unlink($p))throw new RuntimeException('Не вдалося видалити архів.');
}

function mavik_deploy_log(string $root,array $row): void {
  $f=mavik_deploy_state_dir($root).'/history.json';
  $raw=is_file($f)?file_get_contents($f):false;$j=$raw?json_decode($raw,true):null;
  if(!is_array($j))$j=[];$j[]=$row;$j=array_slice($j,-30);
  @file_put_contents($f,json_encode($j,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES),LOCK_EX);
}

function mavik_deploy_restore_backup(string $root,string $backup,array $newManaged): void { mavik_deploy_restore_database_backup($root,$backup); }


/* Boss-managed blog content belongs to live state, not to a possibly older release ZIP. */
function mavik_deploy_blog_content_snapshot(string $root): array {
  $root=rtrim($root,'/');$files=[];$paths=[$root.'/blog/index.html',$root.'/blog/feed.xml'];
  foreach(glob($root.'/blog/*/index.html')?:[] as $f)$paths[]=$f;
  foreach(array_values(array_unique($paths)) as $f){if(!is_file($f))continue;$raw=@file_get_contents($f);if($raw===false)continue;$rel=str_replace('\\','/',substr($f,strlen($root)+1));$files[$rel]=(string)$raw;}
  $deleted=[];$state=$root.'/_site-state/boss-content.json';$raw=is_file($state)?@file_get_contents($state):false;$j=$raw?json_decode($raw,true):null;
  if(is_array($j))foreach((array)($j['blog']??[]) as $post){if(!is_array($post)||empty($post['deleted']))continue;$slug=(string)($post['slug']??'');if(preg_match('/^[a-z0-9-]+$/',$slug))$deleted[$slug]=1;}
  return ['files'=>$files,'deleted'=>array_keys($deleted)];
}
function mavik_deploy_blog_content_restore(string $root,array $snapshot): int {
  $root=rtrim($root,'/');$restored=0;
  foreach((array)($snapshot['files']??[]) as $rel=>$raw){if(!is_string($rel)||!is_string($raw)||$raw==='')continue;try{$rel=mavik_deploy_norm($rel);}catch(Throwable $e){continue;}if(!preg_match('#^blog/(?:index\.html|feed\.xml|[a-z0-9-]+/index\.html)$#',$rel))continue;$dest=$root.'/'.$rel;$dir=dirname($dest);if(!is_dir($dir)&&!mkdir($dir,0755,true)&&!is_dir($dir))throw new RuntimeException('Не вдалося відновити live blog path.');$tmp=$dest.'.live-'.bin2hex(random_bytes(4));if(file_put_contents($tmp,$raw,LOCK_EX)===false){@unlink($tmp);throw new RuntimeException('Не вдалося відновити live blog content: '.$rel);}if(!@rename($tmp,$dest)){@unlink($tmp);throw new RuntimeException('Не вдалося повернути live blog content: '.$rel);}$restored++;}
  foreach((array)($snapshot['deleted']??[]) as $slug){$slug=(string)$slug;if(!preg_match('/^[a-z0-9-]+$/',$slug))continue;$file=$root.'/blog/'.$slug.'/index.html';if(is_file($file))@unlink($file);$dir=dirname($file);if(is_dir($dir))@rmdir($dir);}
  return $restored;
}

/* Static page <main> content is mutable in Boss and must survive releases. */
function mavik_deploy_static_page_content_snapshot(string $root): array {
  $root=rtrim($root,'/');$out=[];
  foreach(['about/index.html','copyright/index.html','privacy/index.html','platformy/index.html'] as $rel){$f=$root.'/'.$rel;if(!is_file($f))continue;$html=(string)@file_get_contents($f);if($html==='')continue;$low=strtolower($html);$a=strpos($low,'<main');if($a===false)continue;$gt=strpos($html,'>',$a);if($gt===false)continue;$b=strpos($low,'</main>',$gt+1);if($b===false)continue;$out[$rel]=substr($html,$gt+1,$b-$gt-1);}
  return $out;
}
function mavik_deploy_static_page_content_restore(string $root,array $snapshot): int {
  $root=rtrim($root,'/');$restored=0;
  foreach($snapshot as $rel=>$body){if(!is_string($rel)||!is_string($body)||!in_array($rel,['about/index.html','copyright/index.html','privacy/index.html','platformy/index.html'],true))continue;$f=$root.'/'.$rel;if(!is_file($f))continue;$html=(string)@file_get_contents($f);if($html==='')continue;$low=strtolower($html);$a=strpos($low,'<main');if($a===false)continue;$gt=strpos($html,'>',$a);if($gt===false)continue;$b=strpos($low,'</main>',$gt+1);if($b===false)continue;$next=substr($html,0,$gt+1).$body.substr($html,$b);if(file_put_contents($f,$next,LOCK_EX)===false)throw new RuntimeException('Не вдалося відновити live-вміст сторінки '.$rel.'.');$restored++;}
  return $restored;
}

/* Mutable book text belongs to live Boss state, not to release ZIPs. */
function mavik_deploy_reader_region(string $html,string $tag,string $attrName,string $attrNeedle): ?array {
  $low=strtolower($html);$seek=0;$openNeedle='<'.strtolower($tag);
  while(($a=strpos($low,$openNeedle,$seek))!==false){$gt=strpos($html,'>',$a);if($gt===false)return null;$open=substr($html,$a,$gt-$a+1);$ok=false;
    if($attrName==='id')$ok=preg_match('/\\bid\\s*=\\s*(["\\\'])'.preg_quote($attrNeedle,'/').'\\1/i',$open)===1;
    else{$v='';if(preg_match('/\\b'.preg_quote($attrName,'/').'\\s*=\\s*(["\\\'])(.*?)\\1/i',$open,$m))$v=(string)$m[2];$ok=in_array($attrNeedle,preg_split('/\\s+/',trim($v))?:[],true);}
    if($ok){$close='</'.strtolower($tag).'>';$b=strpos($low,$close,$gt+1);if($b===false)return null;return ['open_start'=>$a,'content_start'=>$gt+1,'content_end'=>$b,'close_end'=>$b+strlen($close),'content'=>substr($html,$gt+1,$b-$gt-1)];}$seek=$gt+1;
  }return null;
}
function mavik_deploy_reader_toc_region(string $html): ?array {
  $aside=mavik_deploy_reader_region($html,'aside','class','sidebar');if(!$aside)return null;$inner=(string)$aside['content'];$titlePos=stripos($inner,'>Зміст</div>');if($titlePos===false)return null;$start=$titlePos+strlen('>Зміст</div>');return ['content_start'=>(int)$aside['content_start']+$start,'content_end'=>(int)$aside['content_end'],'content'=>substr($inner,$start)];
}
function mavik_deploy_reader_content_snapshot(string $root): array {
  $out=[];foreach(glob(rtrim($root,'/').'/books/*/read/index.html')?:[] as $file){$slug=basename(dirname(dirname($file)));if(!preg_match('/^[a-z0-9-]+$/',$slug))continue;$html=(string)@file_get_contents($file);if($html==='')continue;$reader=mavik_deploy_reader_region($html,'article','id','reader');if(!$reader)continue;$body=(string)$reader['content'];if(trim(strip_tags($body))==='')continue;$toc=mavik_deploy_reader_toc_region($html);$out[$slug]=['body'=>$body,'toc'=>$toc?(string)$toc['content']:''];}return $out;
}
function mavik_deploy_reader_content_restore(string $root,array $snapshot): int {
  $restored=0;foreach($snapshot as $slug=>$data){if(!is_string($slug)||!preg_match('/^[a-z0-9-]+$/',$slug)||!is_array($data))continue;$file=rtrim($root,'/').'/books/'.$slug.'/read/index.html';if(!is_file($file))continue;$html=(string)@file_get_contents($file);$body=(string)($data['body']??'');$toc=(string)($data['toc']??'');if($html===''||trim(strip_tags($body))==='')continue;$reader=mavik_deploy_reader_region($html,'article','id','reader');if(!$reader)continue;$html2=substr($html,0,(int)$reader['content_start']).$body.substr($html,(int)$reader['content_end']);if($toc!==''){$tr=mavik_deploy_reader_toc_region($html2);if($tr)$html2=substr($html2,0,(int)$tr['content_start']).$toc.substr($html2,(int)$tr['content_end']);}if(file_put_contents($file,$html2,LOCK_EX)===false)throw new RuntimeException('Не вдалося відновити живий текст книги '.$slug.'.');$epub=rtrim($root,'/').'/downloads/'.$slug.'.epub';if(is_file($epub))@unlink($epub);$restored++;}return $restored;
}

function mavik_deploy_archive(string $root,string $zipPath,string $originalName='release.zip'): array {
  @set_time_limit(0);@ignore_user_abort(true);$readerSnapshot=mavik_deploy_reader_content_snapshot($root);$blogSnapshot=mavik_deploy_blog_content_snapshot($root);$staticPageSnapshot=mavik_deploy_static_page_content_snapshot($root);
  $check=mavik_deploy_validate($zipPath);
  $state=mavik_deploy_state_dir($root);$id=date('Ymd-His').'-'.bin2hex(random_bytes(4));
  $stage=$state.'/stage-'.$id;$backup='';$tx='';$newManaged=[];$release='?';$releaseLabel='?';
  try{
    mavik_deploy_extract($zipPath,$stage);
    $manifest=mavik_deploy_manifest($stage);$release=(string)$manifest['release'];$releaseLabel=trim((string)($manifest['release_label']??''));if($releaseLabel==='')$releaseLabel='R'.$release;
    $newManaged=array_fill_keys($manifest['managed_files'],1);
    foreach(['index.html','boss/index.php','_site-admin/deploy.php'] as $required)
      if(!isset($newManaged[$required])||!is_file($stage.'/'.$required))throw new RuntimeException('Маніфест не охоплює обов’язковий файл: '.$required);
    $oldManaged=[];
    $currentManifest=$root.'/.mavik-release.json';
    if(is_file($currentManifest)){
      $raw=file_get_contents($currentManifest);$old=$raw!==false?json_decode($raw,true):null;
      if(is_array($old)&&is_array($old['managed_files']??null))foreach($old['managed_files'] as $r){try{$n=mavik_deploy_norm((string)$r);if($n!==''&&!mavik_deploy_protected($n))$oldManaged[]=$n;}catch(Throwable $e){}}
    }
    $backup=mavik_deploy_backup($root,$releaseLabel);
    $affected=$newManaged;foreach($oldManaged as $rel)$affected[$rel]=1;$tx=mavik_deploy_transaction_snapshot($root,$affected);
    $removed=mavik_deploy_remove_obsolete($root,$oldManaged,$newManaged);
    $copied=mavik_deploy_copy_tree($stage,$root,$newManaged);$restoredReaders=mavik_deploy_reader_content_restore($root,$readerSnapshot);$restoredBlog=mavik_deploy_blog_content_restore($root,$blogSnapshot);$restoredStaticPages=mavik_deploy_static_page_content_restore($root,$staticPageSnapshot);
    $sync=mavik_live_sync_after_deploy($root);
    foreach(['index.html','boss/index.php','robots.txt','sitemap.xml','.mavik-release.json'] as $f)if(!is_file($root.'/'.$f)||filesize($root.'/'.$f)<1)throw new RuntimeException('Контроль після розгортання не пройдено: '.$f);
    mavik_deploy_log($root,['at'=>date(DATE_ATOM),'status'=>'success','release'=>$release,'release_label'=>$releaseLabel,'archive'=>$originalName,'copied'=>$copied,'removed'=>$removed,'backup'=>basename($backup)]);
    mavik_deploy_rm_tree($stage);if($tx!=='')mavik_deploy_rm_tree($tx);mavik_deploy_prune_backups($root,7);
    return ['release'=>$release,'release_label'=>$releaseLabel,'copied'=>$copied,'removed'=>$removed,'backup'=>basename($backup),'unpacked_bytes'=>(int)$check['unpacked_bytes']];
  }catch(Throwable $e){
    $rollback='';
    try{if($tx!==''&&is_dir($tx))mavik_deploy_transaction_restore($root,$tx);if($backup!==''&&is_file($backup))mavik_deploy_restore_database_backup($root,$backup);$rollback=' Попередню версію автоматично відновлено.';}catch(Throwable $r){$rollback=' Автовідновлення не вдалося: '.$r->getMessage();}if($tx!=='')mavik_deploy_rm_tree($tx);
    mavik_deploy_rm_tree($stage);
    mavik_deploy_log($root,['at'=>date(DATE_ATOM),'status'=>'failed','release'=>$release,'release_label'=>$releaseLabel,'archive'=>$originalName,'error'=>$e->getMessage(),'backup'=>$backup?basename($backup):null]);
    throw new RuntimeException($e->getMessage().$rollback);
  }
}


function mavik_deploy_current_release(string $root): int {
  $f=rtrim($root,'/').'/.mavik-release.json';
  if(!is_file($f))return 0;
  $raw=file_get_contents($f);$j=$raw!==false?json_decode($raw,true):null;
  return is_array($j)?(int)($j['release']??0):0;
}

function mavik_deploy_patch_meta(string $zipPath): ?array {
  $entries=mavik_deploy_entries($zipPath);$has=false;
  foreach($entries as $e)if((string)$e['path']==='.mavik-patch.json'){$has=true;break;}
  if(!$has)return null;
  $raw=mavik_deploy_read_entry($zipPath,'.mavik-patch.json');$j=json_decode($raw,true);
  if(!is_array($j)||($j['schema']??null)!==1||($j['kind']??'')!=='mavik-overlay')throw new RuntimeException('Некоректний маніфест overlay-патча.');
  $id=preg_replace('/[^A-Za-z0-9._-]/','',(string)($j['patch_id']??''))??'';$base=(int)($j['base_release']??0);
  if($id===''||$base<1)throw new RuntimeException('Overlay-патч не має коректного patch_id або base_release.');
  $targets=[];foreach((array)($j['targets']??[]) as $t){$t=strtolower(trim((string)$t));if(!in_array($t,['core','content'],true))throw new RuntimeException('Overlay-патч має невідому ціль: '.$t);$targets[$t]=1;}if($base>=217&&!$targets)throw new RuntimeException('R217+ overlay-патч зобов’язаний явно декларувати targets (["content"] або ["core"]).');
  $files=[];$hashes=is_array($j['sha256']??null)?$j['sha256']:[];
  foreach((array)($j['files']??[]) as $rel){
    if(!is_string($rel)||$rel==='')continue;$n=mavik_deploy_norm($rel);
    if($n===''||mavik_deploy_protected($n)||mavik_deploy_guarded_root_file($n)||in_array($n,['.mavik-release.json','.mavik-release-part.json','.mavik-patch.json'],true))throw new RuntimeException('Overlay-патч містить заборонений шлях: '.$n);
    $h=strtolower((string)($hashes[$n]??''));if(!preg_match('/^[a-f0-9]{64}$/',$h))throw new RuntimeException('Overlay-патч не має SHA-256 для '.$n.'.');
    $files[$n]=$h;
  }
  if(!$files)throw new RuntimeException('Overlay-патч не містить файлів для встановлення.');
  $delete=[];
  foreach((array)($j['delete_files']??[]) as $rel){
    if(!is_string($rel)||$rel==='')continue;$n=mavik_deploy_norm($rel);
    if($n===''||mavik_deploy_protected($n)||mavik_deploy_guarded_root_file($n)||isset($files[$n])||in_array($n,['.mavik-release.json','.mavik-release-part.json','.mavik-patch.json','index.html','boss/index.php','_site-admin/deploy.php'],true))throw new RuntimeException('Overlay-патч містить заборонене видалення: '.$n);
    $delete[$n]=1;
  }
  return ['patch_id'=>$id,'base_release'=>$base,'targets'=>array_keys($targets),'files'=>$files,'delete_files'=>array_keys($delete),'description'=>trim((string)($j['description']??''))];
}

function mavik_deploy_validate_patch(string $zipPath,array $meta): array {
  $entries=mavik_deploy_entries($zipPath);if(!$entries)throw new RuntimeException('ZIP-патч порожній.');
  if(count($entries)>12000)throw new RuntimeException('У ZIP-патчі забагато файлів.');
  $seen=[];$total=0;$allowed=array_fill_keys(array_keys((array)$meta['files']),1);$allowed['.mavik-patch.json']=1;$allowed['PATCH-INFO.txt']=1;
  foreach($entries as $e){$rel=(string)$e['path'];if(isset($seen[$rel]))throw new RuntimeException('У ZIP-патчі дублюється шлях: '.$rel);$seen[$rel]=1;$total+=(int)$e['size'];if($total>750*1024*1024)throw new RuntimeException('ZIP-патч завеликий після розпакування.');if(empty($e['dir'])&&!isset($allowed[$rel]))throw new RuntimeException('ZIP-патч містить незареєстрований файл: '.$rel);}
  if(!isset($seen['.mavik-patch.json']))throw new RuntimeException('У ZIP-патчі немає .mavik-patch.json.');
  foreach((array)$meta['files'] as $rel=>$expected){if(!isset($seen[$rel]))throw new RuntimeException('У ZIP-патчі бракує файла: '.$rel);$actual=hash('sha256',mavik_deploy_read_entry($zipPath,$rel));if(!hash_equals((string)$expected,$actual))throw new RuntimeException('SHA-256 не збігається для '.$rel.'.');}
  return ['entries'=>$entries,'unpacked_bytes'=>$total];
}

function mavik_deploy_apply_patch(string $root,string $zipPath,string $originalName,array $meta): array {
  @set_time_limit(0);@ignore_user_abort(true);$readerSnapshot=mavik_deploy_reader_content_snapshot($root);$check=mavik_deploy_validate_patch($zipPath,$meta);$current=mavik_deploy_current_release($root);
  if($current!==(int)$meta['base_release'])throw new RuntimeException('Патч '.$meta['patch_id'].' призначений для R'.$meta['base_release'].', а на сайті зараз R'.$current.'.');
  $state=mavik_deploy_state_dir($root);$stage=$state.'/patch-'.$meta['patch_id'].'-'.bin2hex(random_bytes(4));$backup='';$tx='';$rollbackSet=[];
  foreach(array_keys((array)$meta['files']) as $rel)$rollbackSet[$rel]=1;foreach((array)$meta['delete_files'] as $rel)$rollbackSet[$rel]=1;
  try{
    mavik_deploy_extract($zipPath,$stage);$backup=mavik_deploy_backup($root,'R'.$current.'-patch-'.$meta['patch_id']);$tx=mavik_deploy_transaction_snapshot($root,$rollbackSet);
    $copied=mavik_deploy_copy_tree($stage,$root,array_fill_keys(array_keys((array)$meta['files']),1));$deleted=0;
    foreach((array)$meta['delete_files'] as $rel){$p=$root.'/'.$rel;if(is_file($p)||is_link($p)){if(!@unlink($p))throw new RuntimeException('Не вдалося видалити '.$rel.'.');$deleted++;}}
    foreach((array)$meta['files'] as $rel=>$expected){$p=$root.'/'.$rel;if(!is_file($p)||!hash_equals((string)$expected,hash_file('sha256',$p)))throw new RuntimeException('Контроль після патча не пройдено: '.$rel);}
    foreach((array)$meta['delete_files'] as $rel)if(file_exists($root.'/'.$rel)||is_link($root.'/'.$rel))throw new RuntimeException('Файл не видалився: '.$rel);
    $restoredReaders=mavik_deploy_reader_content_restore($root,$readerSnapshot);$sync=mavik_live_sync_after_deploy($root);
    mavik_deploy_log($root,['at'=>date(DATE_ATOM),'status'=>'patch-success','release'=>$current,'patch_id'=>$meta['patch_id'],'targets'=>$meta['targets']??[],'archive'=>$originalName,'copied'=>$copied,'deleted'=>$deleted,'backup'=>basename($backup)]);
    mavik_deploy_rm_tree($stage);if($tx!=='')mavik_deploy_rm_tree($tx);mavik_deploy_prune_backups($root,7);
    return ['patch'=>true,'patch_id'=>$meta['patch_id'],'release'=>$current,'base_release'=>$meta['base_release'],'copied'=>$copied,'deleted'=>$deleted,'backup'=>basename($backup),'unpacked_bytes'=>(int)$check['unpacked_bytes']];
  }catch(Throwable $e){
    $rollback='';try{if($tx!==''&&is_dir($tx))mavik_deploy_transaction_restore($root,$tx);if($backup!==''&&is_file($backup))mavik_deploy_restore_database_backup($root,$backup);$rollback=' Попередній стан автоматично відновлено.';}catch(Throwable $r){$rollback=' Автовідновлення не вдалося: '.$r->getMessage();}if($tx!=='')mavik_deploy_rm_tree($tx);
    mavik_deploy_rm_tree($stage);mavik_deploy_log($root,['at'=>date(DATE_ATOM),'status'=>'patch-failed','release'=>$current,'patch_id'=>$meta['patch_id'],'targets'=>$meta['targets']??[],'archive'=>$originalName,'error'=>$e->getMessage(),'backup'=>$backup?basename($backup):null]);
    throw new RuntimeException($e->getMessage().$rollback);
  }
}

function mavik_deploy_from_upload(string $root,array $file): array {
  if(!mavik_deploy_supported())throw new RuntimeException('На сервері немає PHP-підтримки ZIP/Phar.');
  $err=(int)($file['error']??UPLOAD_ERR_NO_FILE);if($err!==UPLOAD_ERR_OK)throw new RuntimeException('Не вдалося отримати ZIP (код '.$err.').');
  $tmp=(string)($file['tmp_name']??'');$name=(string)($file['name']??'');if($tmp===''||!is_uploaded_file($tmp))throw new RuntimeException('Оберіть ZIP-збірку.');if(strtolower(pathinfo($name,PATHINFO_EXTENSION))!=='zip')throw new RuntimeException('Потрібен файл .zip.');
  $size=(int)($file['size']??0);if($size<1000)throw new RuntimeException('ZIP виглядає порожнім.');if($size>350*1024*1024)throw new RuntimeException('ZIP має бути до 350 МБ.');
  $lock=mavik_deploy_acquire_lock($root,'deploy');
  try{
    $state=mavik_deploy_state_dir($root);$safe=preg_replace('/[^A-Za-z0-9._-]+/','-',pathinfo($name,PATHINFO_FILENAME))?:'release';$saved=$state.'/failed-'.date('Ymd-His').'-'.$safe.'.zip';if(!move_uploaded_file($tmp,$saved))throw new RuntimeException('Не вдалося перенести ZIP у захищену папку.');
    try{
      $patch=mavik_deploy_patch_meta($saved);if($patch!==null){$result=mavik_deploy_apply_patch($root,$saved,$name,$patch);if(!@unlink($saved))$result['archive_cleanup_warning']='Патч встановлено, але ZIP не вдалося видалити автоматично.';return $result;}
      $meta=mavik_deploy_part_meta($saved);if($meta!==null)return mavik_deploy_multipart_receive($root,$saved,$name,$meta);
      $result=mavik_deploy_archive($root,$saved,$name);if(!@unlink($saved))$result['archive_cleanup_warning']='Збірку розгорнуто, але ZIP не вдалося видалити автоматично.';return $result;
    }catch(Throwable $e){throw new RuntimeException($e->getMessage().' Архів залишено у захищеній папці Boss для діагностики.');}
  }finally{mavik_deploy_release_lock($lock);}
}

function mavik_deploy_ini_limit(): string {
  return 'upload_max_filesize='.ini_get('upload_max_filesize').' · post_max_size='.ini_get('post_max_size');
}

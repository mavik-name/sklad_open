<?php
declare(strict_types=1);
require_once __DIR__.'/state.php';

function mavik_contact_inbox_dir(string $root): string {
  $dir=mavik_state_dir($root).'/contact-inbox';
  if(!is_dir($dir) && !mkdir($dir,0700,true) && !is_dir($dir)) throw new RuntimeException('Не вдалося створити сховище повідомлень із сайту.');
  @chmod($dir,0700);
  return $dir;
}
function mavik_contact_inbox_id(string $id): string {
  $id=trim($id);
  if(!preg_match('/^[a-z0-9-]{12,80}$/i',$id)) throw new InvalidArgumentException('Некоректний ID повідомлення.');
  return $id;
}
function mavik_contact_inbox_path(string $root,string $id): string {return mavik_contact_inbox_dir($root).'/'.mavik_contact_inbox_id($id).'.json';}
function mavik_contact_inbox_write(string $root,array $m): void {
  $id=mavik_contact_inbox_id((string)($m['id']??''));$file=mavik_contact_inbox_path($root,$id);$tmp=$file.'.tmp-'.bin2hex(random_bytes(3));
  $json=json_encode($m,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);if($json===false)throw new RuntimeException('Не вдалося закодувати повідомлення.');
  if(file_put_contents($tmp,$json,LOCK_EX)===false){@unlink($tmp);throw new RuntimeException('Не вдалося зберегти повідомлення.');}
  @chmod($tmp,0600);if(!rename($tmp,$file)){@unlink($tmp);throw new RuntimeException('Не вдалося завершити збереження повідомлення.');}@chmod($file,0600);
}
function mavik_contact_inbox_store(string $root,array $msg): array {
  $id=date('Ymd-His').'-'.bin2hex(random_bytes(6));$m=[
    'id'=>$id,'created_at'=>date(DATE_ATOM),'name'=>trim((string)($msg['name']??'')),'email'=>trim((string)($msg['email']??'')),
    'subject'=>trim((string)($msg['subject']??'')),'message'=>(string)($msg['message']??''),'lang'=>(string)($msg['lang']??'uk'),
    'seen'=>false,'seen_at'=>'','replied'=>false,'replied_at'=>'','mail_backup_sent'=>false,
  ];
  mavik_contact_inbox_write($root,$m);return $m;
}
function mavik_contact_inbox_list(string $root,int $limit=100): array {
  $files=glob(mavik_contact_inbox_dir($root).'/*.json')?:[];$out=[];
  foreach($files as $f){$raw=@file_get_contents($f);$m=$raw?json_decode($raw,true):null;if(is_array($m)&&!empty($m['id']))$out[]=$m;}
  usort($out,fn($a,$b)=>strcmp((string)($b['created_at']??''),(string)($a['created_at']??'')));
  return array_slice($out,0,max(1,$limit));
}
function mavik_contact_inbox_unread_count(string $root): int {$n=0;foreach(mavik_contact_inbox_list($root,500) as $m)if(empty($m['seen']))$n++;return $n;}
function mavik_contact_inbox_get(string $root,string $id,bool $markRead=true): ?array {
  $file=mavik_contact_inbox_path($root,$id);if(!is_file($file))return null;$raw=@file_get_contents($file);$m=$raw?json_decode($raw,true):null;if(!is_array($m))return null;
  if($markRead&&empty($m['seen'])){$m['seen']=true;$m['seen_at']=date(DATE_ATOM);mavik_contact_inbox_write($root,$m);}return $m;
}
function mavik_contact_inbox_patch(string $root,string $id,array $changes): ?array {
  $m=mavik_contact_inbox_get($root,$id,false);if(!$m)return null;foreach($changes as $k=>$v)$m[$k]=$v;mavik_contact_inbox_write($root,$m);return $m;
}
function mavik_contact_inbox_delete(string $root,string $id): void {$file=mavik_contact_inbox_path($root,$id);if(is_file($file)&&!@unlink($file))throw new RuntimeException('Не вдалося видалити повідомлення.');}

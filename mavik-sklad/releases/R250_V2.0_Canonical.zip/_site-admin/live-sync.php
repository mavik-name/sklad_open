<?php
declare(strict_types=1);
require_once __DIR__.'/core.php';

/* 1: post-deploy/live-state synchronizer.
 * Release files are presentation/code. Mutable content lives in /_site-state/.
 * After FULL/PATCH deploy this module reapplies state projections so visual work cannot
 * silently restore stale cards, announcement covers, platform links or SEO structures.
 */

function mavik_live_state_file(string $root,string $name): string {
  $live=rtrim($root,'/').'/_site-state/'.$name;
  return is_file($live)?$live:rtrim($root,'/').'/_site-admin/state-defaults/'.$name;
}
function mavik_live_json(string $root,string $name,array $fallback=[]): array {
  $f=mavik_live_state_file($root,$name);$raw=is_file($f)?@file_get_contents($f):false;$j=$raw?json_decode($raw,true):null;
  return is_array($j)?$j:$fallback;
}
function mavik_live_h(string $s): string {return htmlspecialchars($s,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');}
function mavik_live_image_attrs(string $root,string $src,bool $lazy=true,bool $priority=false): string {
  $path=(string)(parse_url($src,PHP_URL_PATH)??$src);if($path===''||!str_starts_with($path,'/'))return ' decoding="async"'.($lazy?' loading="lazy"':'').($priority?' fetchpriority="high"':'');$f=rtrim($root,'/').'/'.ltrim(rawurldecode($path),'/');$dims=@getimagesize($f);$wh=is_array($dims)&&!empty($dims[0])&&!empty($dims[1])?' width="'.(int)$dims[0].'" height="'.(int)$dims[1].'"':'';return $wh.' decoding="async"'.($lazy?' loading="lazy"':' loading="eager"').($priority?' fetchpriority="high"':'');
}
function mavik_live_display_image_url(string $url): string {
  $url=trim($url);if($url===''||str_contains($url,'?'))return $url;$path=(string)(parse_url($url,PHP_URL_PATH)??'');if(str_starts_with($path,'/images/covers/')||str_starts_with($path,'/images/blog/'))return $url.'?v=250v20c3';return $url;
}
function mavik_live_lower(string $s): string {return mavik_utf8_lower($s);}
function mavik_live_release_token(string $root): string {
  $raw=@file_get_contents(rtrim($root,'/').'/.mavik-release.json');$j=$raw?json_decode($raw,true):null;
  $explicit=is_array($j)?strtolower(trim((string)($j['cache_token']??''))):'';
  $explicit=preg_replace('/[^a-z0-9._-]+/','',$explicit)??'';
  if($explicit!=='')return $explicit;
  $label=is_array($j)?strtolower((string)($j['release_label']??'')):'';
  $token=preg_replace('/[^a-z0-9]+/','',$label)??'';if(preg_match('/^r(?=\d)/',$token))$token=substr($token,1);
  return $token!==''?$token:'250v20c3';
}
function mavik_live_sync_release_markers(string $root): array {
  $root=rtrim($root,'/');$token=mavik_live_release_token($root);$scanned=0;$changed=0;
  $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::LEAVES_ONLY);
  foreach($it as $f){
    if(!$f->isFile()||$f->isLink()||strtolower($f->getExtension())!=='html')continue;
    $path=$f->getPathname();$rel=str_replace('\\','/',substr($path,strlen($root)+1));
    if(str_starts_with($rel,'_site-state/')||str_starts_with($rel,'_site-admin/state-defaults/'))continue;
    $html=(string)@file_get_contents($path);if($html==='')continue;$scanned++;
    $next=preg_replace('#((?:/assets/|/images/|/favicon\.ico|/manifest\.webmanifest)[^"\'()\s<>?]*)\?v=[A-Za-z0-9._-]+#iu','$1?v='.$token,$html)??$html;
    if($next!==$html){mavik_live_write($path,$next);$changed++;}
  }
  return ['token'=>$token,'scanned'=>$scanned,'changed'=>$changed];
}
function mavik_live_canonical_genres(): array {
  return ['poetry'=>'Поезія','mystic'=>'Містика','fantasy'=>'Фантастика / фентезі','techno'=>'Технотрилер','thriller'=>'Трилер','psychological'=>'Психологічна','philosophical'=>'Філософська','drama'=>'Драма','war'=>'Воєнна','political'=>'Політична','humor'=>'Гумор / іронія','documentary'=>'Документальна','children'=>'Дитяча','women'=>'Жіночий роман','epistolary'=>'Епістолярна','legal'=>'Юридична'];
}
function mavik_live_genre_keys_for_book(array $book): array {
  $keys=[];foreach((array)($book['genre_keys']??[]) as $key){$key=preg_replace('/[^a-z0-9-]/','',mavik_live_lower((string)$key))??'';if($key!=='')$keys[$key]=true;}
  $hay=mavik_live_lower(trim((string)($book['genre']??'').' '.(string)($book['title']??'')));
  $rules=[
    'poetry'=>'/поез|вірш|верлібр/u','mystic'=>'/містич|містик|апокриф|криптоістор|легенд/u','fantasy'=>'/фантаст|фентез/u',
    'techno'=>'/технотрил|штучн.{0,12}інтелект|алгоритм/u','thriller'=>'/трилер/u','psychological'=>'/психолог/u',
    'philosophical'=>'/філософ|роман-притча|\bпритча\b/u','drama'=>'/драма/u','war'=>'/воєн|війна/u',
    'political'=>'/політич/u','humor'=>'/гумор|іроніч|сатира/u','documentary'=>'/документ|нотат/u',
    'children'=>'/дитяч|підлітк|казка/u','women'=>'/жіноч/u','epistolary'=>'/епістол|листи/u','legal'=>'/юридич/u'
  ];
  foreach($rules as $key=>$pattern)if(preg_match($pattern,$hay)===1)$keys[$key]=true;
  return array_keys($keys);
}
function mavik_live_normalize_genre_state(string $root): array {
  $file=rtrim($root,'/').'/_site-state/boss-content.json';$raw=is_file($file)?@file_get_contents($file):false;$j=$raw?json_decode($raw,true):null;
  if(!is_array($j)||!is_array($j['books']??null))return ['changed'=>0,'books'=>0];
  $changed=0;foreach($j['books'] as $i=>$book){if(!is_array($book))continue;$keys=mavik_live_genre_keys_for_book($book);$old=array_values(array_map('strval',(array)($book['genre_keys']??[])));if($keys!==$old){$j['books'][$i]['genre_keys']=$keys;$changed++;}}
  if($changed>0){$j['updated_at']=date(DATE_ATOM);mavik_live_write($file,json_encode($j,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE)."\n");}
  return ['changed'=>$changed,'books'=>count($j['books'])];
}
function mavik_live_book_language(array $b): string {
  $lang=strtolower(trim(str_replace('_','-',(string)($b['language']??'uk-UA'))));
  $placement=(string)($b['placement']??'books');
  return in_array($lang,['pl','pl-pl'],true)&&$placement==='direct'?'pl-PL':'uk-UA';
}
function mavik_live_og_locale(array $b): string {
  return mavik_live_book_language($b)==='pl-PL'?'pl_PL':'uk_UA';
}
function mavik_live_html_lang(string $html,string $lang): string {return preg_replace('#<html\b[^>]*\blang=["\'][^"\']*["\']#i','<html lang="'.mavik_live_h($lang).'"',$html,1)??$html;}

function mavik_live_book_duration_from_html(string $html): array {
  $text=html_entity_decode(strip_tags($html),ENT_QUOTES|ENT_HTML5,'UTF-8');$count=0;
  if(preg_match_all("/[\\p{L}\\p{N}]+(?:[’ʼ'\-][\\p{L}\\p{N}]+)*/u",$text,$m))$count=count($m[0]);
  $reading=$count>0?max(1,(int)ceil($count/200)):0;$listening=$count>0?max(1,(int)ceil($count/150)):0;
  return ['words'=>$count,'reading_minutes'=>$reading,'listening_minutes'=>$listening];
}
function mavik_live_book_duration(string $root,string $slug): array {
  $f=rtrim($root,'/').'/books/'.$slug.'/read/index.html';$html=is_file($f)?(string)@file_get_contents($f):'';
  if($html==='')return ['words'=>0,'reading_minutes'=>0,'listening_minutes'=>0];
  // Avoid a huge non-greedy regex here: long books can exhaust PCRE backtracking
  // and collapse to the old 1-minute fallback. Locate the reader container structurally.
  $idPos=strpos($html,'id="reader"');if($idPos===false)$idPos=strpos($html,"id='reader'");
  if($idPos!==false){
    $prefix=substr($html,0,$idPos);$open=strrpos($prefix,'<article');
    if($open!==false){
      $contentStart=strpos($html,'>',$idPos);
      if($contentStart!==false){
        $contentStart++;$end=strpos($html,'</article>',$contentStart);
        if($end!==false&&$end>$contentStart)return mavik_live_book_duration_from_html(substr($html,$contentStart,$end-$contentStart));
      }
    }
  }
  $textFile=rtrim($root,'/').'/books/'.$slug.'/read/text/index.html';$plain=is_file($textFile)?(string)@file_get_contents($textFile):'';
  if(trim($plain)!=='')return mavik_live_book_duration_from_html($plain);
  return ['words'=>0,'reading_minutes'=>0,'listening_minutes'=>0];
}
function mavik_live_duration_label(int $minutes): string {
  $minutes=max(1,$minutes);if($minutes<60)return '≈ '.$minutes.' хв';$h=intdiv($minutes,60);$m=$minutes%60;return $m===0?'≈ '.$h.' год':'≈ '.$h.' год '.str_pad((string)$m,2,'0',STR_PAD_LEFT).' хв';
}
function mavik_live_reader_duration_html(array $duration): string {
  if((int)($duration['words']??0)<1)return '';
  $r=mavik_live_h(mavik_live_duration_label((int)($duration['reading_minutes']??1)));$a=mavik_live_h(mavik_live_duration_label((int)($duration['listening_minutes']??1)));
  return '<div class="reader-duration" aria-label="Орієнтовний час читання та прослуховування"><span>читання '.$r.'</span><i aria-hidden="true">·</i><span>слухання '.$a.'</span></div>';
}

function mavik_live_book_actions_html(string $slug,bool $final,bool $hasEpub,array $duration): string {
  $readLabel=$final?'Читати безкоштовно →':'Тестове читання →';
  $actions='<a class="btn primary" href="read/">'.$readLabel.'</a><a class="btn listen-read" rel="nofollow" href="read/?listen=1">▶ Слухати</a><a class="btn music-read" href="read/#music">♫ Читати з музикою</a>';
  if($final&&$hasEpub)$actions.='<a class="btn" download href="../../downloads/'.mavik_live_h($slug).'.epub">Завантажити EPUB ↓</a>';
  return $actions;
}
function mavik_live_write(string $file,string $data): void {
  $dir=dirname($file);if(!is_dir($dir)&&!mkdir($dir,0755,true)&&!is_dir($dir))throw new RuntimeException('Live sync: не вдалося створити '.$dir);
  $tmp=$file.'.sync-'.bin2hex(random_bytes(4));if(file_put_contents($tmp,$data,LOCK_EX)===false)throw new RuntimeException('Live sync: не вдалося записати '.basename($file));@chmod($tmp,0644);if(!rename($tmp,$file)){@unlink($tmp);throw new RuntimeException('Live sync: не вдалося замінити '.basename($file));}
}
function mavik_live_replace_region(string $html,string $start,string $end,string $body): string {
  $a=strpos($html,$start);$b=$a===false?false:strpos($html,$end,$a+strlen($start));if($a===false||$b===false)return $html;
  return substr($html,0,$a+strlen($start)).$body.substr($html,$b);
}
function mavik_live_replace_meta(string $html,string $attr,string $key,string $value): string {
  return preg_replace_callback('#<meta\b[^>]*>#ui',static function($m)use($attr,$key,$value){$tag=(string)$m[0];if(!preg_match('#\b'.preg_quote($attr,'#').'\s*=\s*(["\'])'.preg_quote($key,'#').'\1#ui',$tag))return $tag;$safe=mavik_live_h($value);if(preg_match('#\bcontent\s*=\s*(["\']).*?\1#ui',$tag))return preg_replace('#\bcontent\s*=\s*(["\']).*?\1#ui','content="'.$safe.'"',$tag,1)??$tag;return rtrim(substr($tag,0,-1)).' content="'.$safe.'">';},$html)??$html;
}
function mavik_live_unique_books(array $books): array {
  $out=[];$seen=[];
  foreach($books as $b){
    if(!is_array($b))continue;$slug=(string)($b['slug']??'');
    if($slug===''||isset($seen[$slug]))continue;
    $seen[$slug]=true;$out[]=$b;
  }
  return $out;
}
function mavik_live_visible_books(array $m,bool $newOnly=false): array {
  // placement=direct is omitted from internal shelves/search/lists.
  // It remains public and indexable through its own URL and sitemap.
  $out=[];foreach(mavik_live_unique_books((array)($m['books']??[])) as $b){if(!empty($b['deleted'])||!empty($b['hidden'])||(string)($b['placement']??'books')!=='books')continue;if($newOnly&&empty($b['is_new']))continue;$out[]=$b;}return $out;
}
function mavik_live_announcement_books(array $m): array {
  $out=[];foreach(mavik_live_unique_books((array)($m['books']??[])) as $b){if(!empty($b['deleted'])||!empty($b['hidden'])||(string)($b['placement']??'books')!=='announcements')continue;$out[]=$b;}return $out;
}
function mavik_live_generic_announcement_url(array $item): string {
  $id=preg_replace('/[^a-z0-9-]/','',(string)($item['id']??''))??'';return $id!==''?'/announcements/'.$id.'/':'/announcements/';
}
function mavik_live_announcement_detail_page_html(string $title,string $desc,string $kicker,string $cover,string $canonical,string $bodyHtml='',bool $bookAnnouncement=false,string $status='',bool $coverRight=false): string {
  $img=$cover!==''?'<figure class="announcement-detail-cover"><img src="'.mavik_live_h(mavik_live_display_image_url($cover)).'" alt="Обкладинка — '.mavik_live_h($title).'" loading="eager" decoding="async"></figure>':'';
  $work=['@type'=>'CreativeWork','@id'=>$canonical.'#announcement','name'=>$title,'description'=>$desc,'url'=>$canonical,'inLanguage'=>'uk-UA','author'=>['@id'=>'https://mavik.name/#person']];if($cover!=='')$work['image']='https://mavik.name'.$cover;if($status!=='')$work['creativeWorkStatus']=$status;
  $crumb=['@type'=>'BreadcrumbList','itemListElement'=>[['@type'=>'ListItem','position'=>1,'name'=>'MaVik','item'=>'https://mavik.name/'],['@type'=>'ListItem','position'=>2,'name'=>'Анонси','item'=>'https://mavik.name/announcements/'],['@type'=>'ListItem','position'=>3,'name'=>$title,'item'=>$canonical]]];$schema=json_encode(['@context'=>'https://schema.org','@graph'=>[$work,$crumb]],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
  $bodyHtml=trim($bodyHtml);$body=$bodyHtml!==''?'<!-- BOSS_ANNOUNCEMENT_BODY_START --><section class="announcement-body-wrap"><div class="announcement-body">'.$bodyHtml.'</div></section><!-- BOSS_ANNOUNCEMENT_BODY_END -->':'';$bodyAttr=$bookAnnouncement?' data-book-placement="announcements"':'';$heroClass='announcement-detail-hero'.($coverRight?' announcement-cover-right':' announcement-cover-left');
  return '<!DOCTYPE html><html lang="uk-UA"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>'.mavik_live_h($title).' — анонс | MaVik</title><meta name="description" content="'.mavik_live_h($desc).'"><meta name="robots" content="index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1"><link rel="canonical" href="'.mavik_live_h($canonical).'"><meta property="og:locale" content="uk_UA"><meta property="og:type" content="website"><meta property="og:site_name" content="MaVik"><meta property="og:title" content="'.mavik_live_h($title).' — анонс | MaVik"><meta property="og:description" content="'.mavik_live_h($desc).'"><meta property="og:url" content="'.mavik_live_h($canonical).'">'.($cover!==''?'<meta property="og:image" content="https://mavik.name'.mavik_live_h($cover).'">':'').'<script type="application/ld+json">'.$schema.'</script><link href="/assets/app/site-shell.css?v=250v20c3" rel="stylesheet"><link href="/assets/app/floating-controls.css?v=250v20c3" rel="stylesheet"><link href="/assets/app/footer-clean.css?v=250v20c3" rel="stylesheet"><link href="/assets/app/brand-lock.css?v=250v20c3" rel="stylesheet"><link href="/assets/app/discovery.css?v=250v20c3" rel="stylesheet"><link href="/assets/app/book-share.css?v=250v20c3" rel="stylesheet"><link href="/assets/app/reactions.css?v=250v20c3" rel="stylesheet"><link href="/assets/app/global-system.css?v=250v20c3" rel="stylesheet"><link href="/favicon.ico?v=250v20c3" rel="icon" type="image/x-icon"></head><body class="announcements-page announcement-detail-page"'.$bodyAttr.'><header class="mavik-site-header"><div class="mavik-site-head-inner"><a aria-label="MaVik — на головну" class="mavik-site-brand" href="/"><img alt="MVV" src="/assets/brand/mavik-mvv-gold.svg" width="1876" height="1876"><span class="mavik-site-brand-copy"><strong>MaVik</strong><span>МАКАРЧУК ВІКТОР</span></span></a><nav aria-label="Головне меню" class="mavik-site-desktop-nav"><a href="/books/">Книги</a><a href="/music/">Музика</a><a href="/blog/">Блог</a><a href="/about/">Автор</a><a href="/announcements/" aria-current="page">Анонси</a><a href="/contact/">Контакт</a></nav><button aria-controls="mavikMobileMenu" aria-expanded="false" aria-label="Відкрити меню" class="mavik-site-mobile-toggle" type="button"><i></i><i></i><i></i></button></div><nav aria-hidden="true" aria-label="Мобільне меню" class="mavik-site-mobile-menu" id="mavikMobileMenu"><div class="mavik-site-mobile-inner"><a href="/books/">Книги</a><a href="/music/">Музика</a><a href="/blog/">Блог</a><a href="/about/">Автор</a><a href="/announcements/" aria-current="page">Анонси</a><a href="/contact/">Контакт</a></div></nav></header><main class="mavik-global-page wrap"><section class="section announcement-detail-section"><div class="announcement-detail-tools"><a class="btn primary announcement-back-btn" href="/announcements/"><span aria-hidden="true">←</span><span>Усі анонси</span></a><span class="announcement-share-slot"></span></div><div class="'.$heroClass.'">'.$img.'<div class="announcement-detail-copy"><div class="eyebrow">'.mavik_live_h($kicker).'</div><h1>'.mavik_live_h($title).'</h1><p class="lead">'.mavik_live_h($desc).'</p></div></div>'.$body.'</section></main><footer><span class="footer-copy-row">© 2026 · Макарчук Віктор - MaVik®<br>Всі права застережено</span><span class="footer-legal-row"><a class="footer-legal-link" href="/mavik/">Про MaVik</a> · <a class="footer-legal-link" href="/copyright/">Правова охорона творчого доробку</a> · <a class="footer-legal-link" href="/privacy/">Приватність</a></span></footer><script defer src="/assets/app/site-shell.js?v=250v20c3"></script><script defer src="/assets/app/floating-controls.js?v=250v20c3"></script><script defer src="/assets/app/book-share.js?v=250v20c3"></script><script defer src="/assets/app/reactions.js?v=250v20c3"></script></body></html>';
}

function mavik_live_generic_announcement_detail(string $root,array $item,?bool $coverRight=null): void {
  $id=preg_replace('/[^a-z0-9-]/','',(string)($item['id']??''))??'';if($id==='')return;$dir=rtrim($root,'/').'/announcements/'.$id;
  if(!empty($item['hidden'])||!empty($item['deleted'])){if(is_dir($dir)){foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST) as $f){$q=$f->getPathname();$f->isDir()?@rmdir($q):@unlink($q);}@rmdir($dir);}return;}
  $title=trim((string)($item['title']??''));if($title==='')return;$desc=trim((string)($item['description']??''));$kicker=trim((string)($item['kicker']??'Анонс'));$cover=trim((string)($item['cover']??''));$canonical='https://mavik.name/announcements/'.$id.'/';if($coverRight===null)$coverRight=mavik_live_announcement_cover_right($root,$id);mavik_live_write($dir.'/index.html',mavik_live_announcement_detail_page_html($title,$desc,$kicker,$cover,$canonical,'',false,'',$coverRight));
}
function mavik_live_sync_generic_announcement_details(string $root,array $state): void {foreach((array)($state['items']??[]) as $item)if(is_array($item))mavik_live_generic_announcement_detail($root,$item);}
function mavik_live_render_book_announcement_detail(string $root,array $book,?bool $coverRight=null): bool {
  if(!empty($book['deleted'])||!empty($book['hidden'])||(string)($book['placement']??'books')!=='announcements')return false;$slug=preg_replace('/[^a-z0-9-]/','',(string)($book['slug']??''))??'';if($slug==='')return false;
  $title=trim((string)($book['title']??$slug));$desc=trim((string)($book['description']??''));$genre=trim((string)($book['genre']??'Книга'));$kicker=$genre!==''?$genre.' · анонс':'Анонс';$cover=trim((string)($book['cover_catalog']??''));$status=trim((string)($book['announcement_reason']??''));if($status==='')$status=$desc;$body=trim(mavik_core_sanitize_html((string)($book['announcement_body_html']??'')));if(trim(strip_tags(html_entity_decode($body,ENT_QUOTES|ENT_HTML5,'UTF-8')))==='')$body='';$canonical='https://mavik.name/books/'.$slug.'/';if($coverRight===null)$coverRight=mavik_live_announcement_cover_right($root,$slug);mavik_live_write(rtrim($root,'/').'/books/'.$slug.'/index.html',mavik_live_announcement_detail_page_html($title,$desc,$kicker,$cover,$canonical,$body,true,$status,$coverRight));return true;
}

function mavik_live_announcement_combined_items(array $manifest,array $state): array {
  $map=[];foreach(mavik_live_announcement_books($manifest) as $b){$id=(string)($b['slug']??'');if($id!=='')$map[$id]=['kind'=>'book','id'=>$id,'book'=>$b];}
  $bookSlugs=[];foreach((array)($manifest['books']??[]) as $b)if(is_array($b)&&($id=(string)($b['slug']??''))!=='')$bookSlugs[$id]=1;
  foreach((array)($state['items']??[]) as $a){if(!is_array($a)||!empty($a['deleted'])||($id=(string)($a['id']??''))===''||isset($bookSlugs[$id]))continue;$map[$id]=['kind'=>'generic','id'=>$id,'item'=>$a];}
  $out=[];$seen=[];foreach((array)($state['order']??[]) as $id){$id=(string)$id;if(isset($map[$id])&&!isset($seen[$id])){$seen[$id]=1;$out[]=$map[$id];}}foreach($map as $id=>$x)if(!isset($seen[$id]))$out[]=$x;return $out;
}
function mavik_live_announcement_cover_right(string $root,string $id): bool {
  $id=(string)$id;if($id==='')return false;$manifest=mavik_live_json($root,'boss-content.json',['books'=>[],'blog'=>[]]);$state=mavik_live_json($root,'announcements.json',['visible'=>true,'items'=>[],'order'=>[]]);$pos=0;
  foreach(mavik_live_announcement_combined_items($manifest,$state) as $row){$pos++;if((string)($row['id']??'')===$id)return ($pos%2)===0;}
  return false;
}
function mavik_live_sync_announcement_details_ordered(string $root,array $manifest,array $state): void {
  $pos=0;foreach(mavik_live_announcement_combined_items($manifest,$state) as $row){$pos++;$right=($pos%2)===0;if(($row['kind']??'')==='book')mavik_live_render_book_announcement_detail($root,(array)$row['book'],$right);else mavik_live_generic_announcement_detail($root,(array)$row['item'],$right);}
}
function mavik_live_patch_announcement_body(string $html,array $book): string {
  $body=(string)($book['announcement_body_html']??'');$body=trim(mavik_core_sanitize_html($body));if(trim(strip_tags(html_entity_decode($body,ENT_QUOTES|ENT_HTML5,'UTF-8')))==='')$body='';$section=((string)($book['placement']??'books')==='announcements'&&$body!=='')?'<!-- BOSS_ANNOUNCEMENT_BODY_START --><section class="announcement-body-wrap"><div class="announcement-body">'.$body.'</div></section><!-- BOSS_ANNOUNCEMENT_BODY_END -->':'';$start='<!-- BOSS_ANNOUNCEMENT_BODY_START -->';$end='<!-- BOSS_ANNOUNCEMENT_BODY_END -->';
  if(str_contains($html,$start)&&str_contains($html,$end)){$a=strpos($html,$start);$b=strpos($html,$end,$a);if($a!==false&&$b!==false)$html=substr($html,0,$a).$section.substr($html,$b+strlen($end));}elseif($section!==''&&str_contains($html,'</main>'))$html=str_replace('</main>',$section.'</main>',$html);
  if($section!==''&&!str_contains($html,'id="mavikAnnouncementBodyStyle"')){$css='<style id="mavikAnnouncementBodyStyle">.announcement-body-wrap{width:min(940px,calc(100% - 56px));margin:-28px auto 80px;padding:30px 34px;border:1px solid var(--line);border-radius:18px;background:#111114}.announcement-body{font:18px/1.72 Georgia,serif;color:#d5cfc5}.announcement-body p{margin:0 0 1.15em}.announcement-body h2{font:500 32px/1.2 Georgia,serif;margin:1.45em 0 .55em;color:var(--text)}.announcement-body h3{font:500 24px/1.25 Georgia,serif;margin:1.35em 0 .5em}.announcement-body blockquote{border-left:3px solid var(--gold);margin:1.2em 0;padding:2px 0 2px 18px;color:#c8c0b5}.announcement-body a{color:var(--gold2);text-decoration:underline}.announcement-body ul,.announcement-body ol{padding-left:28px}@media(max-width:760px){.announcement-body-wrap{width:min(100% - 28px,620px);margin:-24px auto 60px;padding:22px 20px}.announcement-body{font-size:16px}}</style>';$html=str_replace('</head>',$css.'</head>',$html);}return $html;
}
function mavik_live_blog(array $m): array {
  $out=[];foreach((array)($m['blog']??[]) as $b){if(!is_array($b)||!empty($b['deleted'])||!empty($b['hidden']))continue;$out[]=$b;}usort($out,static fn($a,$b)=>strcmp((string)($b['date']??''),(string)($a['date']??'')));return $out;
}
function mavik_live_blog_seo_clean(string $s,int $max=400): string {
  $s=preg_replace('/\s+/u',' ',trim(strip_tags($s)))??trim(strip_tags($s));if($s==='')return '';
  if(mavik_utf8_strlen($s)>$max)$s=rtrim(mavik_utf8_substr($s,0,$max-1)).'…';return $s;
}
function mavik_live_blog_default_seo_title(string $title): string {
  $title=mavik_live_blog_seo_clean($title,150);if($title==='')return 'Блог MaVik';$x=$title.' | MaVik';return mavik_live_utf8_len($x)<=70?$x:$title;
}
function mavik_live_blog_cluster_catalog(): array {return [
  'auto'=>['label'=>'Автоматично','url'=>''],
  'shcho-pochytaty'=>['label'=>'Що почитати','url'=>'/shcho-pochytaty/'],
  'antiutopiia'=>['label'=>'Антиутопія','url'=>'/antiutopiia/'],
  'sotsialna-fantastyka'=>['label'=>'Соціальна фантастика','url'=>'/sotsialna-fantastyka/'],
  'fantastyka-ukrainskoyu'=>['label'=>'Фантастика українською','url'=>'/fantastyka-ukrainskoyu/'],
  'none'=>['label'=>'Без кластера','url'=>'']
];}
function mavik_live_blog_cluster_value(string $x): string {$x=trim($x);return isset(mavik_live_blog_cluster_catalog()[$x])?$x:'auto';}
function mavik_live_blog_haystack(array $p): string {return mavik_live_lower(trim(implode(' ',[(string)($p['title']??''),(string)($p['seo_title']??''),(string)($p['primary_query']??''),(string)($p['category']??''),(string)($p['excerpt']??''),implode(' ',array_map('strval',(array)($p['tags']??[]))),strip_tags((string)($p['body_html']??''))])));}
function mavik_live_blog_resolved_cluster(array $p): string {
  $set=mavik_live_blog_cluster_value((string)($p['seo_cluster']??'auto'));if($set!=='auto')return $set;$h=mavik_live_blog_haystack($p);
  foreach(['антиутоп','дистоп','зручн'] as $k)if(str_contains($h,$k))return 'antiutopiia';
  foreach(['соціальн','суспільств','алгоритм','демограф','майбутнє людини'] as $k)if(str_contains($h,$k))return 'sotsialna-fantastyka';
  foreach(['фантаст','наукова фантастика','science fiction','sci-fi'] as $k)if(str_contains($h,$k))return 'fantastyka-ukrainskoyu';
  foreach(['що почитати','що читати','почитати україн','книги україн','читати онлайн'] as $k)if(str_contains($h,$k))return 'shcho-pochytaty';return 'none';
}
function mavik_live_blog_normalize_post(array $p): array {
  $title=mavik_live_blog_seo_clean((string)($p['title']??''),180);$excerpt=mavik_live_blog_seo_clean((string)($p['excerpt']??''),400);
  if(trim((string)($p['seo_title']??''))==='')$p['seo_title']=mavik_live_blog_default_seo_title($title);else $p['seo_title']=mavik_live_blog_seo_clean((string)$p['seo_title'],180);
  if(trim((string)($p['meta_description']??''))==='')$p['meta_description']=$excerpt;else $p['meta_description']=mavik_live_blog_seo_clean((string)$p['meta_description'],400);
  if(trim((string)($p['primary_query']??''))==='')$p['primary_query']=$title;else $p['primary_query']=mavik_live_blog_seo_clean((string)$p['primary_query'],180);
  if(trim((string)($p['image_alt']??''))==='')$p['image_alt']=$title;else $p['image_alt']=mavik_live_blog_seo_clean((string)$p['image_alt'],240);
  $p['seo_cluster']=mavik_live_blog_cluster_value((string)($p['seo_cluster']??'auto'));return $p;
}
function mavik_live_blog_query_tokens(array $p): array {
  $q=mavik_live_lower((string)($p['primary_query']??$p['title']??''));$parts=preg_split('/[^\p{L}\p{N}]+/u',$q,-1,PREG_SPLIT_NO_EMPTY)?:[];$stop=['і','й','та','в','у','на','до','що','як','для','про','з','із','це','або','чи'];$out=[];foreach($parts as $x){if(mavik_live_utf8_len($x)<4||in_array($x,$stop,true))continue;$out[$x]=true;}return array_keys($out);
}
function mavik_live_blog_related_score(array $a,array $b): int {
  if((string)($a['slug']??'')===(string)($b['slug']??''))return -999;$score=0;$ca=mavik_live_blog_resolved_cluster($a);$cb=mavik_live_blog_resolved_cluster($b);if($ca!=='none'&&$ca===$cb)$score+=20;$hb=mavik_live_blog_haystack($b);foreach(mavik_live_blog_query_tokens($a) as $t)if(str_contains($hb,$t))$score+=3;return $score;
}
function mavik_live_blog_related_block(array $blog,array $post,int $limit=3): string {
  $rows=[];foreach($blog as $b){if(!is_array($b)||!empty($b['hidden'])||!empty($b['deleted']))continue;$sc=mavik_live_blog_related_score($post,$b);if($sc>0)$rows[]=['s'=>$sc,'p'=>$b];}usort($rows,static fn($a,$b)=>$b['s']<=>$a['s']);$links='';$cluster=mavik_live_blog_resolved_cluster($post);$cat=mavik_live_blog_cluster_catalog();if(isset($cat[$cluster])&&($url=(string)$cat[$cluster]['url'])!=='')$links.='<a href="'.mavik_live_h($url).'">'.mavik_live_h((string)$cat[$cluster]['label']).' →</a>';foreach(array_slice($rows,0,$limit) as $r){$b=(array)$r['p'];$links.='<a href="/blog/'.mavik_live_h((string)$b['slug']).'/">'.mavik_live_h((string)$b['title']).' →</a>';}return $links===''?'':'<!-- BOSS_SEO_RELATED_START --><div class="relatedbox seo-related"><h3>Читайте також</h3>'.$links.'</div><!-- BOSS_SEO_RELATED_END -->';
}
function mavik_live_blog_public_meta(string $html,string $attr,string $key): string {
  if(!preg_match('#<meta\\b[^>]*\\b'.preg_quote($attr,'#').'=["\\\']'.preg_quote($key,'#').'["\\\'][^>]*>#iu',$html,$m))return '';
  return preg_match('#\\bcontent=["\\\']([^"\\\']*)["\\\']#iu',(string)$m[0],$v)?trim(html_entity_decode((string)$v[1],ENT_QUOTES|ENT_HTML5,'UTF-8')):'';
}
function mavik_live_blog_public_text(string $html,string $pattern): string {
  if(!preg_match($pattern,$html,$m))return '';
  return trim(html_entity_decode(strip_tags((string)$m[1]),ENT_QUOTES|ENT_HTML5,'UTF-8'));
}
function mavik_live_blog_public_post(string $root,string $slug,string $file): ?array {
  $html=@file_get_contents($file);if($html===false||trim($html)===''||!str_contains($html,'class="article-body"'))return null;
  $title=mavik_live_blog_public_text($html,'#<h1\\b[^>]*>(.*?)</h1>#isu');
  if($title==='')$title=mavik_live_blog_public_meta($html,'property','og:title');
  $title=preg_replace('/\\s*\\|\\s*MaVik\\s*$/u','',$title)??$title;if($title==='')return null;
  $excerpt=mavik_live_blog_public_meta($html,'name','description');if($excerpt==='')$excerpt=mavik_live_blog_public_text($html,'#<p\\b[^>]*class=["\\\'][^"\\\']*\\barticle-deck\\b[^"\\\']*["\\\'][^>]*>(.*?)</p>#isu');
  $category=mavik_live_blog_public_text($html,'#<div\\b[^>]*class=["\\\'][^"\\\']*\\beyebrow\\b[^"\\\']*["\\\'][^>]*>(.*?)</div>#isu');if($category==='')$category='Література';
  $published=mavik_live_blog_public_meta($html,'property','article:published_time');$modified=mavik_live_blog_public_meta($html,'property','article:modified_time');
  $date=$published!==''?substr($published,0,10):date('Y-m-d',(int)(@filemtime($file)?:time()));if($published==='')$published=$date.'T12:00:00+03:00';if($modified==='')$modified=$published;
  $image=mavik_live_blog_public_meta($html,'property','og:image');if(str_starts_with($image,'https://mavik.name'))$image=(string)(parse_url($image,PHP_URL_PATH)??$image);$image=preg_replace('/\\?.*$/','',$image)??$image;
  $imageAlt=mavik_live_blog_public_meta($html,'property','og:image:alt');if($imageAlt==='')$imageAlt=$title;
  $body='';if(preg_match('#<article\\b[^>]*class=["\\\'][^"\\\']*\\barticle-body\\b[^"\\\']*["\\\'][^>]*>(.*?)<section\\b[^>]*class=["\\\'][^"\\\']*\\barticle-share-bottom\\b#isu',$html,$m))$body=trim((string)$m[1]);
  elseif(preg_match('#<article\\b[^>]*class=["\\\'][^"\\\']*\\barticle-body\\b[^"\\\']*["\\\'][^>]*>(.*?)<div\\b[^>]*class=["\\\'][^"\\\']*\\barticle-nav\\b#isu',$html,$m))$body=trim((string)$m[1]);
  if($body==='')return null;
  $body=preg_replace('#<!-- (?:R24[45]_SEO_RELATED|BOSS_SEO_RELATED)_START -->.*?<!-- (?:R24[45]_SEO_RELATED|BOSS_SEO_RELATED)_END -->#s','',$body)??$body;
  $tags=[];if(preg_match('#<script\\b[^>]*type=["\\\']application/ld\\+json["\\\'][^>]*>(.*?)</script>#isu',$html,$jm)){$j=json_decode(trim((string)$jm[1]),true);$nodes=[];if(is_array($j)){if(isset($j['@graph'])&&is_array($j['@graph']))$nodes=$j['@graph'];else $nodes=[$j];foreach($nodes as $n)if(is_array($n)&&(string)($n['@type']??'')==='BlogPosting'){foreach((array)($n['keywords']??[]) as $t){$t=trim((string)$t);if($t!==''&&$t!==$title)$tags[]=$t;}if($category==='Література'&&trim((string)($n['articleSection']??''))!=='')$category=trim((string)$n['articleSection']);break;}}}
  $tags=array_values(array_unique($tags));$plain=trim(preg_replace('/\\s+/u',' ',html_entity_decode(strip_tags($body),ENT_QUOTES|ENT_HTML5,'UTF-8'))??'');$words=preg_split('/\\s+/u',$plain,-1,PREG_SPLIT_NO_EMPTY)?:[];$mins=max(1,(int)ceil(count($words)/220));
  return mavik_live_blog_normalize_post(['title'=>$title,'slug'=>$slug,'category'=>$category,'excerpt'=>$excerpt,'date'=>$date,'tags'=>$tags,'image'=>$image,'body_html'=>$body,'sidebar_prefix_html'=>'','search_text'=>$plain,'reading_minutes'=>$mins,'published_at'=>$published,'updated_at'=>$modified,'managed'=>true,'hidden'=>false,'deleted'=>false,'seo_title'=>preg_replace('/\\s*\\|\\s*MaVik\\s*$/u','',mavik_live_blog_public_meta($html,'property','og:title'))?:mavik_live_blog_default_seo_title($title),'meta_description'=>$excerpt,'primary_query'=>$title,'image_alt'=>$imageAlt,'seo_cluster'=>'auto']);
}

function mavik_live_public_book_jsonld(string $html): ?array {
  if(!preg_match_all('#<script\\b[^>]*type=["\\\']application/ld\\+json["\\\'][^>]*>(.*?)</script>#isu',$html,$mm))return null;
  foreach((array)($mm[1]??[]) as $raw){$j=json_decode(trim((string)$raw),true);if(!is_array($j))continue;$nodes=[];if(isset($j['@graph'])&&is_array($j['@graph']))$nodes=$j['@graph'];else $nodes=[$j];foreach($nodes as $n){if(!is_array($n))continue;$type=$n['@type']??'';$types=is_array($type)?$type:[$type];if(in_array('Book',$types,true))return $n;$url=(string)($n['url']??$n['@id']??'');if(in_array('CreativeWork',$types,true)&&preg_match('#^https://mavik\\.name/books/[a-z0-9-]+/#',$url)===1)return $n;}}
  return null;
}
function mavik_live_public_book_from_landing(string $root,string $slug,string $file): ?array {
  $html=@file_get_contents($file);if($html===false||trim($html)==='')return null;$node=mavik_live_public_book_jsonld($html)??[];
  $title=trim((string)($node['name']??''));if($title==='')$title=mavik_live_blog_public_text($html,'#<h1\\b[^>]*>(.*?)</h1>#isu');if($title==='')return null;
  // Older/custom live book pages may lack valid Book JSON-LD. Do not lose them.
  $looksLikeBook=!empty($node)||str_contains($html,'class="book"')||str_contains($html,"class='book'")||str_contains($html,'book-free-note')||str_contains($html,'/books/'.$slug.'/read/');if(!$looksLikeBook)return null;
  $desc=trim((string)($node['description']??''));if($desc==='')$desc=mavik_live_blog_public_text($html,'#<p\\b[^>]*class=["\\\'][^"\\\']*\\bdesc\\b[^"\\\']*["\\\'][^>]*>(.*?)</p>#isu');if($desc==='')$desc=mavik_live_blog_public_meta($html,'name','description');
  $genre=$node['genre']??'';if(is_array($genre))$genre=implode(' / ',array_values(array_filter(array_map('strval',$genre))));$genre=trim((string)$genre);if($genre==='')$genre=mavik_live_blog_public_text($html,'#<div\\b[^>]*class=["\\\'][^"\\\']*\\beyebrow\\b[^"\\\']*["\\\'][^>]*>(.*?)</div>#isu');$genre=trim(preg_replace('/\\s*·\\s*анонс\\s*$/ui','',$genre)??$genre);if($genre==='')$genre='книга';
  $image=$node['image']??'';if(is_array($image))$image=(string)($image['url']??($image[0]??''));$image=trim((string)$image);if(str_starts_with($image,'https://mavik.name'))$image=(string)(parse_url($image,PHP_URL_PATH)??$image);$image=preg_replace('/\\?.*$/','',$image)??$image;
  if($image===''){$image=mavik_live_blog_public_meta($html,'property','og:image');if(str_starts_with($image,'https://mavik.name'))$image=(string)(parse_url($image,PHP_URL_PATH)??$image);$image=preg_replace('/\\?.*$/','',$image)??$image;}
  $lang=trim((string)($node['inLanguage']??''));if($lang===''){if(preg_match('#<html\\b[^>]*\\blang=["\\\']([^"\\\']+)["\\\']#iu',$html,$lm))$lang=trim((string)$lm[1]);}$lang=strtolower(str_replace('_','-',$lang));$language=str_starts_with($lang,'pl')?'pl-PL':'uk-UA';
  // The physical legacy landing has stale uk-UA metadata; recovery must keep this Polish book out of the Ukrainian catalogue.
  if($slug==='ewakuacja-albo-w-drodze-do-punktu-stabilizacyjnego')$language='pl-PL';
  $hasReader=is_file(rtrim($root,'/').'/books/'.$slug.'/read/index.html');$hasEpub=is_file(rtrim($root,'/').'/downloads/'.$slug.'.epub');
  $placement='books';if($language!=='uk-UA')$placement='direct';elseif(str_contains($html,'book-announcement-badge')||str_contains($html,'data-book-placement="announcements"')||str_contains($html,"data-book-placement='announcements'")||(!$hasReader&&str_contains($html,'href="/announcements/"')))$placement='announcements';elseif(str_contains($html,'data-book-placement="direct"')||str_contains($html,"data-book-placement='direct'"))$placement='direct';
  if($slug==='ewakuacja-albo-w-drodze-do-punktu-stabilizacyjnego')$placement='direct';
  $mode=str_contains($html,'Тестове читання')||str_contains($html,'бета-публікація')?'beta':'final';if($placement==='announcements')$mode='final';
  $date=date('Y-m-d',(int)(@filemtime($file)?:time()));$dateNode=trim((string)($node['datePublished']??''));if(preg_match('/^\d{4}-\d{2}-\d{2}/',$dateNode))$date=substr($dateNode,0,10);
  $platformLinks=[];if(preg_match('#<section\b[^>]*class=["\'][^"\']*\bplatforms\b[^"\']*["\'][^>]*>(.*?)</section>#isu',$html,$pm)){if(preg_match_all('#<a\b[^>]*href=["\'](https://[^"\']+)["\'][^>]*>(.*?)</a>#isu',(string)$pm[1],$am,PREG_SET_ORDER)){foreach($am as $a){$url=html_entity_decode(trim((string)$a[1]),ENT_QUOTES|ENT_HTML5,'UTF-8');$label=trim(html_entity_decode(strip_tags((string)$a[2]),ENT_QUOTES|ENT_HTML5,'UTF-8'));if($url!==''&&$label!=='')$platformLinks[]=['label'=>$label,'url'=>$url];}}}
  $availability=$placement==='announcements'?$desc:($mode==='beta'?'тестове читання · без EPUB':($hasEpub?'читати безкоштовно · EPUB':'читати безкоштовно'));$isNew=false;if($placement==='books'){try{$d=new DateTimeImmutable($date,new DateTimeZone('Europe/Kyiv'));$isNew=$d->getTimestamp()>=(time()-60*86400);}catch(Throwable $e){$isNew=false;}}
  $plain=mavik_live_lower(trim($title.' '.$genre.' '.$desc));
  $announcementReason=trim((string)($node['creativeWorkStatus']??''));if($placement==='announcements'&&$announcementReason==='')$announcementReason=$desc;
  $book=['title'=>$title,'slug'=>$slug,'genre'=>$genre,'genre_keys'=>[],'description'=>$desc,'date'=>$date,'cover_catalog'=>$image,'cover_home'=>$image,'publication_mode'=>$mode,'is_new'=>$isNew,'show_continuation'=>false,'search_text'=>$plain,'availability'=>$availability,'hidden'=>false,'deleted'=>false,'managed'=>true,'placement'=>$placement,'language'=>$language,'without_text'=>!$hasReader,'platform_links'=>$platformLinks,'announcement_reason'=>$announcementReason,'recovered_from_live'=>true,'recovered_at'=>date(DATE_ATOM)];
  $book['genre_keys']=mavik_live_genre_keys_for_book($book);return $book;
}
function mavik_live_find_orphan_books(string $root,array $registeredSlugs=[]): array {
  $root=rtrim($root,'/');$known=[];foreach($registeredSlugs as $slug){$slug=(string)$slug;if($slug!=='')$known[$slug]=true;}$out=[];
  foreach(glob($root.'/books/*/index.html')?:[] as $file){
    $slug=basename(dirname($file));if($slug===''||isset($known[$slug])||!preg_match('/^[a-z0-9-]+$/',$slug)||in_array($slug,['free','new'],true))continue;
    // Only adopt a real book surface. A reader is the strongest signal; Book JSON-LD is the fallback.
    $html=@file_get_contents($file);if($html===false||trim($html)==='')continue;$hasReader=is_file($root.'/books/'.$slug.'/read/index.html');$hasBookJson=is_array(mavik_live_public_book_jsonld($html));if(!$hasReader&&!$hasBookJson)continue;
    $b=mavik_live_public_book_from_landing($root,$slug,$file);if(!is_array($b)||empty($b['title']))continue;$out[$slug]=$b;
  }
  ksort($out,SORT_NATURAL);return $out;
}

function mavik_live_recover_public_books(string $root): array {
  $root=rtrim($root,'/');$live=$root.'/_site-state/boss-content.json';$seed=$root.'/_site-admin/state-defaults/boss-content.json';$source=is_file($live)?$live:$seed;$raw=is_file($source)?@file_get_contents($source):false;$j=$raw?json_decode($raw,true):null;if(!is_array($j))$j=['version'=>7,'blog'=>[],'books'=>[]];if(!is_array($j['blog']??null))$j['blog']=[];if(!is_array($j['books']??null))$j['books']=[];
  $known=[];foreach($j['books'] as $b)if(is_array($b)&&($slug=(string)($b['slug']??''))!=='')$known[$slug]=true;$recovered=[];$scanned=0;
  foreach(glob($root.'/books/*/index.html')?:[] as $file){$slug=basename(dirname($file));if($slug===''||isset($known[$slug])||!preg_match('/^[a-z0-9-]+$/',$slug)||in_array($slug,['free','new'],true))continue;$scanned++;$b=mavik_live_public_book_from_landing($root,$slug,$file);if(!$b)continue;$j['books'][]=$b;$known[$slug]=true;$recovered[]=$slug;}
  if($recovered){$j['version']=max(7,(int)($j['version']??0));$j['updated_at']=date(DATE_ATOM);if(!is_dir(dirname($live))&&!mkdir(dirname($live),0750,true)&&!is_dir(dirname($live)))throw new RuntimeException('Book recovery: state dir unavailable.');mavik_live_write($live,json_encode($j,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES)."\n");}
  return ['scanned_missing'=>$scanned,'recovered'=>count($recovered),'slugs'=>$recovered,'source'=>basename($source)];
}

function mavik_live_recover_public_blog_posts(string $root): array {
  $root=rtrim($root,'/');$live=$root.'/_site-state/boss-content.json';$seed=$root.'/_site-admin/state-defaults/boss-content.json';$source=is_file($live)?$live:$seed;$raw=is_file($source)?@file_get_contents($source):false;$j=$raw?json_decode($raw,true):null;if(!is_array($j))$j=['version'=>7,'blog'=>[],'books'=>[]];if(!is_array($j['blog']??null))$j['blog']=[];if(!is_array($j['books']??null))$j['books']=[];
  $known=[];foreach($j['blog'] as $p)if(is_array($p)&&($slug=(string)($p['slug']??''))!=='')$known[$slug]=true;$recovered=[];$scanned=0;
  foreach(glob($root.'/blog/*/index.html')?:[] as $file){$slug=basename(dirname($file));if($slug===''||isset($known[$slug])||!preg_match('/^[a-z0-9-]+$/',$slug))continue;$scanned++;$p=mavik_live_blog_public_post($root,$slug,$file);if(!$p)continue;$j['blog'][]=$p;$known[$slug]=true;$recovered[]=$slug;}
  if($recovered){usort($j['blog'],static fn($a,$b)=>strcmp((string)($b['published_at']??$b['date']??''),(string)($a['published_at']??$a['date']??'')));$j['version']=max(7,(int)($j['version']??0));$j['updated_at']=date(DATE_ATOM);if(!is_dir(dirname($live))&&!mkdir(dirname($live),0750,true)&&!is_dir(dirname($live)))throw new RuntimeException('Blog recovery: state dir unavailable.');mavik_live_write($live,json_encode($j,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES)."\n");}
  return ['scanned_missing'=>$scanned,'recovered'=>count($recovered),'slugs'=>$recovered,'source'=>basename($source)];
}
function mavik_live_migrate_blog_seo_state(string $root): array {
  $root=rtrim($root,'/');$live=$root.'/_site-state/boss-content.json';$seed=$root.'/_site-admin/state-defaults/boss-content.json';$source=is_file($live)?$live:$seed;$raw=is_file($source)?@file_get_contents($source):false;$j=$raw?json_decode($raw,true):null;if(!is_array($j))return ['scanned'=>0,'changed'=>0,'source'=>'missing'];$changed=0;$scanned=0;
  foreach((array)($j['blog']??[]) as $i=>$p){if(!is_array($p))continue;$scanned++;$n=mavik_live_blog_normalize_post($p);if($n!==$p){$j['blog'][$i]=$n;$changed++;}}
  $j['version']=max(7,(int)($j['version']??0));if($changed>0||$source!==$live||!is_file($live)){if(!is_dir(dirname($live))&&!mkdir(dirname($live),0750,true)&&!is_dir(dirname($live)))throw new RuntimeException('Blog SEO state: state dir unavailable.');mavik_live_write($live,json_encode($j,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES)."\n");}
  return ['scanned'=>$scanned,'changed'=>$changed,'source'=>basename($source)];
}
function mavik_live_sync_blog_hubs(string $root,array $manifest): array {
  $map=['antiutopiia'=>'antiutopiia','sotsialna-fantastyka'=>'sotsialna-fantastyka','fantastyka-ukrainskoyu'=>'fantastyka-ukrainskoyu','shcho-pochytaty'=>'shcho-pochytaty'];$blog=mavik_live_blog($manifest);$updated=0;
  foreach($map as $cluster=>$dir){$file=rtrim($root,'/').'/'.$dir.'/index.html';if(!is_file($file))continue;$html=(string)@file_get_contents($file);if($html==='')continue;$cards='';$n=0;foreach($blog as $p){if(mavik_live_blog_resolved_cluster($p)!==$cluster)continue;$cards.='<a class="topic-card" href="/blog/'.mavik_live_h((string)$p['slug']).'/"><small>З блогу MaVik · '.mavik_live_h(substr((string)($p['date']??''),0,10)).'</small><strong>'.mavik_live_h((string)$p['title']).'</strong><span>'.mavik_live_h((string)($p['excerpt']??'')).'</span></a>';if(++$n>=6)break;}$block=$cards!==''?'<!-- BOSS_BLOG_CLUSTER_START --><section class="section boss-blog-cluster"><h2>З блогу MaVik</h2><p class="section-copy">Свіжі матеріали за цією темою.</p><div class="grid">'.$cards.'</div></section><!-- BOSS_BLOG_CLUSTER_END -->':'';
    $html=preg_replace('#<!-- [A-Z0-9]+_BLOG_CLUSTER_START -->.*?<!-- [A-Z0-9]+_BLOG_CLUSTER_END -->#s','',$html)??$html;if($block!==''){$marker='<!-- BOSS_PAGE_BUILDER_SYSTEM_END:';$pos=strpos($html,$marker);if($pos!==false)$html=substr($html,0,$pos).$block.substr($html,$pos);else $html=str_replace('<div class="footer-space"></div>',$block.'<div class="footer-space"></div>',$html);}mavik_live_write($file,$html);$updated++;}
  return ['updated'=>$updated];
}
function mavik_live_platform_links(array $book): array {
  $out=[];foreach((array)($book['platform_links']??[]) as $x){if(!is_array($x))continue;$label=trim((string)($x['label']??''));$url=trim((string)($x['url']??''));if($label===''||!filter_var($url,FILTER_VALIDATE_URL)||!preg_match('#^https://#i',$url))continue;$out[]=['label'=>$label,'url'=>$url];}return $out;
}
function mavik_live_platform_html(array $book): string {
  $links=mavik_live_platform_links($book);$chips='';foreach($links as $x)$chips.='<a class="chip" href="'.mavik_live_h($x['url']).'" target="_blank" rel="noopener noreferrer">'.mavik_live_h($x['label']).' ↗</a>';
  if($chips!=='')return '<section class="platforms" data-book-platforms="1"><h2>На платформах</h2><div class="chips">'.$chips.'</div><p class="source-note">Авторська версія твору завжди доступна на mavik.name.</p></section>';
  return '<section class="platforms" data-book-platforms="1"><h2>На платформах</h2><p class="source-note">Даний твір можна прочитати виключно на авторському сайті: mavik.name</p></section>';
}
function mavik_live_patch_book_jsonld(string $html,array $book): string {
  $same=array_values(array_map(static fn($x)=>(string)$x['url'],mavik_live_platform_links($book)));$announcement=(string)($book['placement']??'books')==='announcements';$language=mavik_live_book_language($book);
  return preg_replace_callback('#(<script\b[^>]*type=["\']application/ld\+json["\'][^>]*>)(.*?)(</script>)#si',function($m)use($book,$same,$announcement,$language){$j=json_decode(trim((string)$m[2]),true);if(!is_array($j))return $m[0];$walk=function(&$n)use(&$walk,$book,$same,$announcement,$language){if(!is_array($n))return;$type=(string)($n['@type']??'');if($type==='Book'||($announcement&&$type==='CreativeWork')){if($announcement){$n['@type']='CreativeWork';$n['@id']='https://mavik.name/books/'.(string)($book['slug']??'').'/#announcement';unset($n['bookFormat'],$n['isAccessibleForFree'],$n['potentialAction']);$status=trim((string)($book['announcement_reason']??''));if($status!=='')$n['creativeWorkStatus']=$status;}else{$n['@type']='Book';$n['@id']='https://mavik.name/books/'.(string)($book['slug']??'').'/#book';$n['bookFormat']=((string)($book['publication_mode']??'final')==='final'?'https://schema.org/EBook':'https://schema.org/Book');} $n['name']=(string)($book['title']??'');$n['description']=(string)($book['description']??'');$n['genre']=(string)($book['genre']??'');$n['inLanguage']=$language;$n['url']='https://mavik.name/books/'.(string)($book['slug']??'').'/';$cover=trim((string)($book['cover_catalog']??''));if($cover!=='')$n['image']='https://mavik.name'.$cover;else unset($n['image']);if($same)$n['sameAs']=$same;else unset($n['sameAs']);}foreach($n as &$v)if(is_array($v))$walk($v);unset($v);};$walk($j);return $m[1].json_encode($j,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).$m[3];},$html)??$html;
}
function mavik_live_ensure_announcement_book_landing(string $root,array $book): bool {
  if(!empty($book['deleted'])||!empty($book['hidden'])||(string)($book['placement']??'books')!=='announcements')return false;$slug=preg_replace('/[^a-z0-9-]/','',(string)($book['slug']??''))??'';if($slug==='')return false;$file=rtrim($root,'/').'/books/'.$slug.'/index.html';$created=!is_file($file);mavik_live_render_book_announcement_detail($root,$book);return $created;
}
function mavik_live_ensure_announcement_book_landings(string $root,array $manifest): int {$n=0;foreach((array)($manifest['books']??[]) as $book)if(is_array($book)&&mavik_live_ensure_announcement_book_landing($root,$book))$n++;return $n;}
function mavik_live_sync_book_landings(string $root,array $manifest): void {
  foreach((array)($manifest['books']??[]) as $b){if(!is_array($b)||!empty($b['deleted'])||($slug=(string)($b['slug']??''))===''||(string)($b['placement']??'books')==='announcements')continue;$f=$root.'/books/'.$slug.'/index.html';if(!is_file($f))continue;$html=(string)@file_get_contents($f);if($html==='')continue;$block=mavik_live_platform_html($b);if(str_contains($html,'data-book-platforms="1"'))$html=preg_replace('#<section class="platforms" data-book-platforms="1">.*?</section>#s',$block,$html,1)??$html;else $html=preg_replace('#<section class="platforms">.*?</section>#s',$block,$html,1)??$html;$html=mavik_live_patch_book_jsonld($html,$b);$html=mavik_live_patch_announcement_body($html,$b);mavik_live_write($f,$html);}
}
function mavik_live_book_item(array $b,int $pos): array {
  $item=['@type'=>'Book','name'=>(string)($b['title']??''),'url'=>'https://mavik.name/books/'.(string)($b['slug']??'').'/', 'description'=>(string)($b['description']??''),'genre'=>(string)($b['genre']??''),'author'=>['@id'=>'https://mavik.name/#person'],'inLanguage'=>mavik_live_book_language($b),'isAccessibleForFree'=>true];$cover=trim((string)($b['cover_catalog']??''));if($cover!=='')$item['image']='https://mavik.name'.$cover;$same=array_values(array_map(static fn($x)=>(string)$x['url'],mavik_live_platform_links($b)));if($same)$item['sameAs']=$same;return ['@type'=>'ListItem','position'=>$pos,'item'=>$item];
}
function mavik_live_patch_itemlist_jsonld(string $html,array $books): string {
  $items=[];$p=0;foreach($books as $b)$items[]=mavik_live_book_item($b,++$p);
  return preg_replace_callback('#(<script\b[^>]*type=["\']application/ld\+json["\'][^>]*>)(.*?)(</script>)#si',function($m)use($items){$j=json_decode(trim((string)$m[2]),true);if(!is_array($j))return $m[0];$changed=false;$walk=function(&$n)use(&$walk,$items,&$changed){if(!is_array($n))return;if(($n['@type']??'')==='ItemList'){$n['numberOfItems']=count($items);$n['itemListElement']=$items;$changed=true;return;}foreach($n as &$v)if(is_array($v))$walk($v);unset($v);};$walk($j);return $changed?$m[1].json_encode($j,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).$m[3]:$m[0];},$html)??$html;
}
function mavik_live_patch_page_jsonld_description(string $html,string $pageUrl,string $description): string {
  return preg_replace_callback('#(<script\b[^>]*type=["\']application/ld\+json["\'][^>]*>)(.*?)(</script>)#si',function($m)use($pageUrl,$description){$j=json_decode(trim((string)$m[2]),true);if(!is_array($j))return $m[0];$changed=false;$walk=function(&$n)use(&$walk,$pageUrl,$description,&$changed){if(!is_array($n))return;$type=(string)($n['@type']??'');if(in_array($type,['CollectionPage','WebPage'],true)&&(string)($n['url']??'')===$pageUrl){$n['description']=$description;$changed=true;}foreach($n as &$v)if(is_array($v))$walk($v);unset($v);};$walk($j);return $changed?$m[1].json_encode($j,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).$m[3]:$m[0];},$html)??$html;
}
function mavik_live_sync_books_page(string $root,array $books,bool $newOnly=false): void {
  $f=$root.($newOnly?'/books/new/index.html':'/books/index.html');if(!is_file($f))return;$html=(string)@file_get_contents($f);if($html==='')return;$cards='';$betaCount=0;
  foreach($books as $b){$slug=(string)$b['slug'];$title=(string)$b['title'];$genre=(string)($b['genre']??'');$desc=(string)($b['description']??'');$cover=(string)($b['cover_catalog']??'');$beta=(string)($b['publication_mode']??'final')==='beta';if($beta)$betaCount++;if($newOnly){$cards.='<a class="book-card" href="/books/'.mavik_live_h($slug).'/"><img alt="Обкладинка — '.mavik_live_h($title).'" src="'.mavik_live_h(mavik_live_display_image_url($cover)).'"'.mavik_live_image_attrs($root,$cover,true).' /><div class="book-copy"><div class="book-type">'.mavik_live_h($genre.($beta?' · тестове читання':'')).'</div><h3 class="book-title">'.mavik_live_h($title).'</h3><p class="book-desc">'.mavik_live_h($desc).'</p><span class="book-free">'.($beta?'Тестове читання →':'Читати онлайн безкоштовно →').'</span></div></a>';}else{$keys=implode(' ',mavik_live_genre_keys_for_book($b));$search=mavik_live_h(mavik_live_lower($title.' '.$genre.' '.$desc));$cards.='<a class="card" data-genres="'.mavik_live_h($keys).'" data-search="'.$search.'" href="'.mavik_live_h($slug).'/"><img src="'.mavik_live_h(mavik_live_display_image_url($cover)).'" alt="'.mavik_live_h($title).'"'.mavik_live_image_attrs($root,$cover,true).' /><div class="meta"><div class="type">'.mavik_live_h($genre.($beta?' · тестове читання':'')).'</div><div class="title">'.mavik_live_h($title).'</div><div class="availability">'.mavik_live_h($beta?'тестове читання · без EPUB':'читати на сайті · EPUB').'</div></div></a>';}}
  $count=count($books);$finalCount=$count-$betaCount;
  if($newOnly){
    $html=mavik_live_replace_region($html,'<!-- BOSS_NEW_BOOKS_START -->','<!-- BOSS_NEW_BOOKS_END -->',$cards);
    $desc=$betaCount>0?'Нові книги Макарчука Віктора (MaVik): '.$count.' актуальних творів у рубриці «Новинки» — '.$finalCount.' завершених, '.$betaCount.' у тестовому читанні.':'Нові книги Макарчука Віктора (MaVik): '.$count.' завершених творів у рубриці «Новинки», читати онлайн безкоштовно на mavik.name.';
    $copy=$betaCount>0?'Тут зібрані найновіші твори MaVik. '.$finalCount.' завершених; '.$betaCount.' зараз у тестовому читанні. Тексти можна читати безкоштовно та без реєстрації.':'Тут зібрані найновіші твори MaVik. Усі доступні тут книги завершені й опубліковані повністю. Тексти можна читати безкоштовно та без реєстрації.';
    $html=preg_replace('#(<h2>Нові книги</h2>\s*<p class="section-copy">).*?(</p>)#su','$1'.mavik_live_h($copy).'$2',$html,1)??$html;
    $pageUrl='https://mavik.name/books/new/';
  }else{
    $html=mavik_live_replace_region($html,'<!-- BOSS_BOOKS_START -->','<!-- BOSS_BOOKS_END -->',$cards);$html=preg_replace('/<span[^>]+id="bookResultCount"[^>]*>.*?<\/span>/u','<span id="bookResultCount" class="genre-result-count">'.$count.' творів</span>',$html,1)??$html;
    $counts=[];foreach($books as $book)foreach(mavik_live_genre_keys_for_book((array)$book) as $key)$counts[$key]=($counts[$key]??0)+1;
    $catalog=mavik_live_canonical_genres();$custom=mavik_live_json($root,'book-genres.json',[]);foreach((array)($custom['items']??[]) as $key=>$label)if(!isset($catalog[$key])&&trim((string)$label)!=='')$catalog[(string)$key]=(string)$label;
    $filters='<button aria-pressed="true" class="genre-filter is-active" data-genre="all" type="button">Усі</button>';
    foreach($catalog as $key=>$label)if(($counts[$key]??0)>0)$filters.='<button aria-pressed="false" class="genre-filter" data-genre="'.mavik_live_h((string)$key).'" type="button">'.mavik_live_h((string)$label).'<span class="genre-filter-count">'.(int)$counts[$key].'</span></button>';
    $html=preg_replace('#(<div\b[^>]*class=["\'][^"\']*\bgenre-filters\b[^"\']*["\'][^>]*>).*?(</div>)#su','$1'.$filters.'$2',$html,1)??$html;
    $desc='Книги Макарчука Віктора (MaVik) українською: повні тексти читати онлайн безкоштовно; для завершених творів доступний EPUB.';
    $pageUrl='https://mavik.name/books/';
  }
  foreach([['name','description'],['property','og:description'],['name','twitter:description']] as $m)$html=mavik_live_replace_meta($html,$m[0],$m[1],$desc);$html=mavik_live_patch_itemlist_jsonld($html,$books);$html=mavik_live_patch_page_jsonld_description($html,$pageUrl,$desc);mavik_live_write($f,$html);
}

function mavik_live_sync_home_books(string $root,array $books): void {
  $f=$root.'/index.html';if(!is_file($f))return;$html=(string)@file_get_contents($f);if($html==='')return;$core=mavik_live_json($root,'site-core.json',[]);$desktop=max(1,min(40,(int)($core['home']['books_limit_desktop']??8)));$mobile=max(1,min(40,(int)($core['home']['books_limit_mobile']??8)));$limit=max($desktop,$mobile);$cards='';$i=0;
  foreach($books as $b){if($i++>=$limit)break;$beta=(string)($b['publication_mode']??'final')==='beta';$cards.='<article class="book-card reveal"><a href="books/'.mavik_live_h((string)$b['slug']).'/"><div class="cover-shell"><img src="'.mavik_live_h(mavik_live_display_image_url((string)($b['cover_home']??$b['cover_catalog']??''))).'" alt="'.mavik_live_h((string)$b['title']).'"'.mavik_live_image_attrs($root,(string)($b['cover_home']??$b['cover_catalog']??''),true).' /></div></a><div class="card-meta"><div class="card-type">'.mavik_live_h((string)($b['genre']??'').($beta?' · тестове читання':'')).'</div><h3 class="card-title"><a href="books/'.mavik_live_h((string)$b['slug']).'/">'.mavik_live_h((string)$b['title']).'</a></h3><p class="card-copy">'.mavik_live_h((string)($b['description']??'')).'</p></div></article>';}
  $style='<style id="bossHomeBookLimits">@media (min-width:769px){#home-books .book-grid>article.book-card:nth-child(n+'.($desktop+1).'){display:none!important}}@media (max-width:768px){#home-books .book-grid>article.book-card:nth-child(n+'.($mobile+1).'){display:none!important}}</style>';$html=mavik_live_replace_region($html,'<!-- BOSS_HOME_BOOKS_START -->','<!-- BOSS_HOME_BOOKS_END -->',$cards);if(preg_match('#<style id="bossHomeBookLimits">.*?</style>#s',$html))$html=preg_replace('#<style id="bossHomeBookLimits">.*?</style>#s',$style,$html,1)??$html;else $html=str_replace('</head>',$style."\n</head>",$html);mavik_live_write($f,$html);
}
function mavik_live_home_blog_list_html(array $blog,string $focusSlug): string {
  $out='';$shown=0;foreach($blog as $p){if(!is_array($p)||($slug=(string)($p['slug']??''))===''||$slug===$focusSlug)continue;$mins=max(1,(int)($p['reading_minutes']??5));$out.='<article class="reveal"><div class="journal-meta"><span>'.mavik_live_h((string)($p['category']??'Література')).'</span><span>'.$mins.' хв</span></div><h3><a href="blog/'.mavik_live_h($slug).'/">'.mavik_live_h((string)($p['title']??'')).'</a></h3><p>'.mavik_live_h((string)($p['excerpt']??'')).'</p></article>';if(++$shown>=3)break;}return $out;
}
function mavik_live_sync_blog_focus(string $root,array $manifest): void {
  $blog=mavik_live_blog($manifest);if(!$blog)return;$focus=mavik_live_json($root,'blog-focus.json',[]);$slug=(string)($focus['slug']??'');$x=$blog[0];foreach($blog as $b)if((string)($b['slug']??'')===$slug){$x=$b;break;}$focusSlug=(string)($x['slug']??'');$f=$root.'/index.html';if(!is_file($f))return;$html=(string)@file_get_contents($f);$mins=max(1,(int)($x['reading_minutes']??5));$feature='<article class="journal-feature reveal"><a class="journal-media" href="blog/'.mavik_live_h($focusSlug).'/"><img alt="'.mavik_live_h((string)($x['image_alt']??$x['title'])).'" src="'.mavik_live_h(mavik_live_display_image_url((string)($x['image']??''))).'"'.mavik_live_image_attrs($root,(string)($x['image']??''),false,true).' />'.'</a><div class="journal-copy"><div class="journal-meta"><span>У фокусі</span><span>'.$mins.' хв</span></div><h3><a href="blog/'.mavik_live_h($focusSlug).'/">'.mavik_live_h((string)$x['title']).'</a></h3><p>'.mavik_live_h((string)($x['excerpt']??'')).'</p><div class="hero-actions" style="margin-top:22px"><a class="btn btn-primary" href="blog/'.mavik_live_h($focusSlug).'/">Читати статтю →</a><a class="btn" href="blog/">Увесь блог</a></div></div></article>';$html=mavik_live_replace_region($html,'<!-- BOSS_HOME_BLOG_START -->','<!-- BOSS_HOME_BLOG_END -->',$feature);$html=mavik_live_replace_region($html,'<!-- BOSS_HOME_BLOG_LIST_START -->','<!-- BOSS_HOME_BLOG_LIST_END -->',mavik_live_home_blog_list_html($blog,$focusSlug));mavik_live_write($f,$html);
}
function mavik_live_sync_announcements(string $root,array $manifest): void {
  $state=mavik_live_json($root,'announcements.json',['visible'=>true,'items'=>[],'order'=>[]]);$f=$root.'/announcements/index.html';if(!is_file($f))return;$html=(string)@file_get_contents($f);$cards='';
  if(!isset($state['visible'])||!empty($state['visible']))foreach(mavik_live_announcement_combined_items($manifest,$state) as $row){if(($row['kind']??'')==='book'){$b=(array)$row['book'];$cover=(string)($b['cover_catalog']??'');$image=$cover!==''?'<img src="'.mavik_live_h(mavik_live_display_image_url($cover)).'" alt="Обкладинка — '.mavik_live_h((string)$b['title']).'"'.mavik_live_image_attrs($root,$cover,true).'>':'<div class="announcement-cover-placeholder" aria-hidden="true">MVV</div>';$cards.='<a class="announcement-card" data-book-announcement="'.mavik_live_h((string)$b['slug']).'" href="/books/'.mavik_live_h((string)$b['slug']).'/">'.$image.'<div class="announcement-copy"><small>'.mavik_live_h((string)($b['genre']??'Книга')).' · анонс</small><strong>'.mavik_live_h((string)$b['title']).'</strong><span>'.mavik_live_h(trim((string)($b['announcement_reason']??''))!==''?(string)$b['announcement_reason']:(string)($b['description']??'')).'</span></div></a>';}else{$x=(array)$row['item'];if(!empty($x['hidden'])||!empty($x['deleted']))continue;$title=(string)($x['title']??'');if($title==='')continue;$href=trim((string)($x['href']??''));if($href==='')$href=mavik_live_generic_announcement_url($x);$open='<a class="announcement-card" href="'.mavik_live_h($href).'">';$close='</a>';$cover=(string)($x['cover']??'');$image=$cover!==''?'<img src="'.mavik_live_h(mavik_live_display_image_url($cover)).'" alt="Обкладинка — '.mavik_live_h($title).'"'.mavik_live_image_attrs($root,$cover,true).'>':'<div class="announcement-cover-placeholder" aria-hidden="true">MVV</div>';$cards.=$open.$image.'<div class="announcement-copy"><small>'.mavik_live_h((string)($x['kicker']??'Анонс')).'</small><strong>'.mavik_live_h($title).'</strong><span>'.mavik_live_h((string)($x['description']??'')).'</span></div>'.$close;}}
  if($cards==='')$cards='<p class="section-copy">Нових анонсів поки немає.</p>';$section='<section class="section" data-boss-announcements="1"><h2>Анонси</h2><div class="announcement-grid">'.$cards.'</div><div class="actions"><a class="btn" href="/books/new/">Нові опубліковані книги →</a><a class="btn" href="/books/">Бібліотека →</a></div></section>';if(str_contains($html,'data-boss-announcements="1"'))$html=preg_replace('#<section class="section" data-boss-announcements="1">.*?</section>#s',$section,$html,1)??$html;else{$start=strpos($html,'<section class="section"><h2>Анонси</h2>');$end=$start!==false?strpos($html,'<div class="footer-space"></div>',$start):false;if($start!==false&&$end!==false)$html=substr($html,0,$start).$section.substr($html,$end);}mavik_live_write($f,$html);mavik_live_sync_announcement_details_ordered($root,$manifest,$state);
}
function mavik_live_blog_focus_slug(string $root,array $blog): string {
  $f=mavik_live_state_file($root,'blog-focus.json');$raw=is_file($f)?@file_get_contents($f):false;$j=$raw?json_decode($raw,true):null;$slug=is_array($j)?trim((string)($j['slug']??'')):'';
  if($slug!=='')foreach($blog as $p)if(is_array($p)&&(string)($p['slug']??'')===$slug)return $slug;
  return $blog&&is_array($blog[0])?(string)($blog[0]['slug']??''):'';
}
function mavik_live_sync_blog_index(string $root,array $manifest): void {
  $f=rtrim($root,'/').'/blog/index.html';if(!is_file($f))return;$html=(string)@file_get_contents($f);if($html==='')return;$blog=mavik_live_blog($manifest);$focus=mavik_live_blog_focus_slug($root,$blog);$focusPost=null;
  foreach($blog as $p)if(is_array($p)&&(string)($p['slug']??'')===$focus){$focusPost=$p;break;}if(!$focusPost&&$blog)$focusPost=$blog[0];
  if(is_array($focusPost)&&!empty($focusPost['image'])){$image=(string)$focusPost['image'];$url='https://mavik.name'.$image;$html=mavik_live_replace_meta($html,'property','og:image',$url);$html=mavik_live_replace_meta($html,'name','twitter:image',$url);$alt=trim((string)($focusPost['image_alt']??$focusPost['title']??''));if($alt!==''){$html=mavik_live_property_meta($html,'og:image:alt',$alt);$html=mavik_live_meta($html,'twitter:image:alt',$alt);}$path=(string)(parse_url($image,PHP_URL_PATH)??$image);if($path!==''&&str_starts_with($path,'/')){$dim=@getimagesize(rtrim($root,'/').'/'.ltrim(rawurldecode($path),'/'));if(is_array($dim)&&!empty($dim[0])&&!empty($dim[1])){$html=mavik_live_property_meta($html,'og:image:width',(string)(int)$dim[0]);$html=mavik_live_property_meta($html,'og:image:height',(string)(int)$dim[1]);}}}
  $html=preg_replace_callback('#(<script\b[^>]*type=["\']application/ld\+json["\'][^>]*>)(.*?)(</script>)#si',function($m)use($blog){$j=json_decode(trim((string)$m[2]),true);if(!is_array($j))return $m[0];$changed=false;$walk=function(&$n)use(&$walk,$blog,&$changed){if(!is_array($n))return;if(($n['@type']??'')==='Blog'){$rows=[];foreach($blog as $p){if(!is_array($p))continue;$slug=(string)($p['slug']??'');if($slug==='')continue;$rows[]=['@type'=>'BlogPosting','headline'=>(string)($p['title']??''),'description'=>(string)($p['meta_description']??$p['excerpt']??''),'url'=>'https://mavik.name/blog/'.$slug.'/','datePublished'=>substr((string)($p['published_at']??$p['date']??''),0,10),'image'=>'https://mavik.name'.(string)($p['image']??''),'keywords'=>(string)($p['primary_query']??''),'author'=>['@id'=>'https://mavik.name/#person']];}$n['blogPost']=$rows;$changed=true;return;}foreach($n as &$v)if(is_array($v))$walk($v);unset($v);};$walk($j);return $changed?$m[1].json_encode($j,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).$m[3]:$m[0];},$html)??$html;
  mavik_live_write($f,$html);
}

function mavik_live_sync_sitemap(string $root,array $manifest): void {
  $f=$root.'/sitemap.xml';if(!is_file($f))return;$xml=(string)@file_get_contents($f);$rows='';
  $seenBookSlugs=[];foreach(mavik_live_unique_books((array)($manifest['books']??[])) as $b){if(!empty($b['deleted'])||!empty($b['hidden'])||!in_array((string)($b['placement']??'books'),['books','direct'],true)||($slug=trim((string)($b['slug']??'')))==='')continue;if(isset($seenBookSlugs[$slug]))continue;$seenBookSlugs[$slug]=true;$d=substr((string)($b['updated_at']??$b['date']??date('Y-m-d')),0,10);$rows.='<url><loc>https://mavik.name/books/'.mavik_live_h($slug).'/</loc><lastmod>'.mavik_live_h($d).'</lastmod></url>';if((string)($b['publication_mode']??'final')==='final'&&is_file($root.'/books/'.$slug.'/read/index.html'))$rows.='<url><loc>https://mavik.name/books/'.mavik_live_h($slug).'/read/</loc><lastmod>'.mavik_live_h($d).'</lastmod></url>';}
  foreach(mavik_live_blog($manifest) as $b){$d=substr((string)($b['updated_at']??$b['date']??date('Y-m-d')),0,10);$rows.='<url><loc>https://mavik.name/blog/'.mavik_live_h((string)$b['slug']).'/</loc><lastmod>'.mavik_live_h($d).'</lastmod>'.(!empty($b['image'])?'<image:image><image:loc>https://mavik.name'.mavik_live_h((string)$b['image']).'</image:loc><image:caption>'.mavik_live_h((string)($b['image_alt']??$b['title']??'Стаття блогу MaVik')).'</image:caption><image:title>'.mavik_live_h((string)($b['title']??'')).'</image:title></image:image>':'').'</url>';}
  $start='<!-- BOSS_SITEMAP_START -->';$end='<!-- BOSS_SITEMAP_END -->';if(str_contains($xml,$start)&&str_contains($xml,$end)){$xml=mavik_live_replace_region($xml,$start,$end,$rows);}else{foreach((array)($manifest['books']??[]) as $b){if(!is_array($b)||($slug=trim((string)($b['slug']??'')))==='')continue;$q=preg_quote('https://mavik.name/books/'.$slug.'/','#');$xml=preg_replace('#<url>(?:(?!</url>).)*?<loc>'.$q.'(?:read/)?</loc>(?:(?!</url>).)*?</url>#s','',$xml)??$xml;}foreach(mavik_live_blog($manifest) as $b){$slug=trim((string)($b['slug']??''));if($slug==='')continue;$q=preg_quote('https://mavik.name/blog/'.$slug.'/','#');$xml=preg_replace('#<url>(?:(?!</url>).)*?<loc>'.$q.'</loc>(?:(?!</url>).)*?</url>#s','',$xml)??$xml;}$block=$start.$rows.$end;$xml=str_replace('</urlset>',$block.'</urlset>',$xml);} $xml=preg_replace_callback('#<url>(?:(?!</url>).)*?<loc>https://mavik\.name/(?:books/|blog/)?</loc>(?:(?!</url>).)*?</url>#s',static function($m){return preg_replace('#<image:image>.*?</image:image>#s','',$m[0])??$m[0];},$xml)??$xml;mavik_live_write($f,$xml);
}
function mavik_live_merge_numeric_tree(array $a,array $b): array {
  foreach($b as $k=>$v){if(isset($a[$k])&&is_array($a[$k])&&is_array($v))$a[$k]=mavik_live_merge_numeric_tree($a[$k],$v);elseif(isset($a[$k])&&is_numeric($a[$k])&&is_numeric($v))$a[$k]+=$v;elseif($k==='last_event')$a[$k]=max((string)($a[$k]??''),(string)$v);elseif(!array_key_exists($k,$a))$a[$k]=$v;}return $a;
}
function mavik_live_ensure_runtime_dirs(string $root): void {
  foreach(['covers','blog'] as $type){$u=rtrim($root,'/').'/images/'.$type.'/user';if(!is_dir($u))@mkdir($u,0755,true);}
}
function mavik_live_rm_path(string $path): bool {
  if(is_file($path)||is_link($path))return @unlink($path);if(!is_dir($path))return false;$ok=true;$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);foreach($it as $f){$q=$f->getPathname();if($f->isDir()&&!$f->isLink()){$ok=@rmdir($q)&&$ok;}else{$ok=@unlink($q)&&$ok;}}return @rmdir($path)&&$ok;
}
function mavik_live_meta(string $html,string $name,string $value): string {
  if(preg_match('#<meta\b[^>]*\bname=["\']'.preg_quote($name,'#').'["\'][^>]*>#iu',$html))return mavik_live_replace_meta($html,'name',$name,$value);
  return str_replace('</head>','<meta name="'.mavik_live_h($name).'" content="'.mavik_live_h($value).'"/></head>',$html);
}
function mavik_live_canonical(string $html,string $url): string {
  $tag='<link rel="canonical" href="'.mavik_live_h($url).'"/>';
  if(preg_match('#<link\b[^>]*\brel=["\']canonical["\'][^>]*>#iu',$html))return preg_replace('#<link\b[^>]*\brel=["\']canonical["\'][^>]*>#iu',$tag,$html,1)??$html;
  return str_replace('</head>',$tag.'</head>',$html);
}
function mavik_live_property_meta(string $html,string $property,string $value): string {
  if(preg_match('#<meta\b[^>]*\bproperty=["\']'.preg_quote($property,'#').'["\'][^>]*>#iu',$html))return mavik_live_replace_meta($html,'property',$property,$value);
  return str_replace('</head>','<meta property="'.mavik_live_h($property).'" content="'.mavik_live_h($value).'"/></head>',$html);
}
function mavik_live_title(string $html,string $title): string {
  $tag='<title>'.mavik_live_h($title).'</title>';
  if(preg_match('#<title\b[^>]*>.*?</title>#siu',$html))return preg_replace('#<title\b[^>]*>.*?</title>#siu',$tag,$html,1)??$html;
  return str_replace('</head>',$tag.'</head>',$html);
}
function mavik_live_utf8_len(string $s): int {if(function_exists('mb_strlen'))return mb_strlen($s,'UTF-8');$m=[];return preg_match_all('/./us',$s,$m)?:strlen($s);}
function mavik_live_reader_title(string $title): string {$x=$title.' — повний текст | MaVik';if(mavik_live_utf8_len($x)>65)$x=$title.' — читати | MaVik';return $x;}
function mavik_live_reader_description(array $b): string {
  $title=trim((string)($b['title']??''));$base='Повний текст «'.$title.'» онлайн безкоштовно. '.trim((string)($b['description']??''));
  $base=preg_replace('/\s+/u',' ',trim($base))??trim($base);$max=176;
  if(function_exists('mb_strlen')){if(mb_strlen($base,'UTF-8')<=$max)return $base;$cut=mb_substr($base,0,$max-1,'UTF-8');}
  else{$chars=preg_split('//u',$base,-1,PREG_SPLIT_NO_EMPTY);if(!is_array($chars)||count($chars)<=$max)return $base;$cut=implode('',array_slice($chars,0,$max-1));}
  $pos=strrpos($cut,' ');if($pos!==false&&$pos>80)$cut=substr($cut,0,$pos);return rtrim($cut).'…';
}
function mavik_live_reader_schema(array $b): string {
  $slug=(string)($b['slug']??'');$title=(string)($b['title']??'');$url='https://mavik.name/books/'.$slug.'/read/';$landing='https://mavik.name/books/'.$slug.'/';$j=['@context'=>'https://schema.org','@graph'=>[
    ['@type'=>'WebPage','@id'=>$url.'#webpage','url'=>$url,'name'=>$title.' — повний текст онлайн','description'=>mavik_live_reader_description($b),'inLanguage'=>mavik_live_book_language($b),'isPartOf'=>['@id'=>'https://mavik.name/#website'],'mainEntity'=>['@id'=>$landing.'#book']],
    ['@type'=>'BreadcrumbList','@id'=>$url.'#breadcrumb','itemListElement'=>[
      ['@type'=>'ListItem','position'=>1,'name'=>'Книги','item'=>'https://mavik.name/books/'],
      ['@type'=>'ListItem','position'=>2,'name'=>$title,'item'=>$landing],
      ['@type'=>'ListItem','position'=>3,'name'=>'Читати онлайн','item'=>$url]
    ]]
  ]];
  return '<script type="application/ld+json" data-mavik-reader-schema="1">'.json_encode($j,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).'</script>';
}
function mavik_live_sync_reader_seo(string $root,string $html,array $b,bool $indexable): string {
  $slug=(string)$b['slug'];$title=(string)($b['title']??'');$url='https://mavik.name/books/'.$slug.'/read/';$language=mavik_live_book_language($b);$html=mavik_live_html_lang($html,$language);$cover=trim((string)($b['cover_catalog']??''));$image=$cover!==''?'https://mavik.name'.$cover:'https://mavik.name/images/author/viktor-makarchuk.jpg';$desc=mavik_live_reader_description($b);
  $html=mavik_live_title($html,mavik_live_reader_title($title));$html=mavik_live_meta($html,'description',$desc);$html=mavik_live_meta($html,'author','Макарчук Віктор · MaVik');
  $og=['og:type'=>'article','og:site_name'=>'MaVik','og:locale'=>mavik_live_og_locale($b),'og:title'=>$title.' — повний текст онлайн','og:description'=>$desc,'og:url'=>$url,'og:image'=>$image,'og:image:alt'=>'Обкладинка — '.$title];$coverPath=(string)(parse_url($cover,PHP_URL_PATH)??$cover);if($coverPath!==''&&str_starts_with($coverPath,'/')){$dim=@getimagesize(rtrim($root,'/').'/'.ltrim(rawurldecode($coverPath),'/'));if(is_array($dim)&&!empty($dim[0])&&!empty($dim[1])){$og['og:image:width']=(string)(int)$dim[0];$og['og:image:height']=(string)(int)$dim[1];}}foreach($og as $k=>$v)$html=mavik_live_property_meta($html,$k,$v);
  foreach(['twitter:card'=>'summary_large_image','twitter:title'=>$title.' — повний текст онлайн','twitter:description'=>$desc,'twitter:image'=>$image,'twitter:image:alt'=>'Обкладинка — '.$title] as $k=>$v)$html=mavik_live_meta($html,$k,$v);
  $html=preg_replace('#<script\b[^>]*data-mavik-reader-schema=["\']1["\'][^>]*>.*?</script>#siu','',$html)??$html;$html=str_replace('</head>',mavik_live_reader_schema($b).'</head>',$html);
  $html=preg_replace('#<link\b[^>]*type=["\']application/epub\+zip["\'][^>]*?/?>#iu','',$html)??$html;
  if($indexable&&is_file($root.'/downloads/'.$slug.'.epub'))$html=str_replace('</head>','<link rel="alternate" type="application/epub+zip" href="https://mavik.name/downloads/'.mavik_live_h($slug).'.epub" title="EPUB"/></head>',$html);
  return $html;
}
function mavik_live_public_book(array $b): bool {return empty($b['deleted'])&&empty($b['hidden'])&&trim((string)($b['slug']??''))!=='';}
function mavik_live_final_book(array $b): bool {return (string)($b['publication_mode']??'final')==='final';}
/* Large readers can exceed PCRE backtracking limits. Extract structural regions
 * with bounded tag scans instead of running dot-star regexes across megabytes of prose. */
function mavik_live_html_region(string $html,string $tag,string $attrName='',string $attrNeedle=''): ?array {
  $low=strtolower($html);$seek=0;$openNeedle='<'.strtolower($tag);
  while(($a=strpos($low,$openNeedle,$seek))!==false){$gt=strpos($html,'>',$a);if($gt===false)return null;$open=substr($html,$a,$gt-$a+1);$ok=$attrName===''&&$attrNeedle==='';
    if(!$ok&&$attrName==='id')$ok=preg_match('/\bid\s*=\s*(["\'])'.preg_quote($attrNeedle,'/').'\1/i',$open)===1;
    elseif(!$ok&&$attrName!==''){$v='';if(preg_match('/\b'.preg_quote($attrName,'/').'\s*=\s*(["\'])(.*?)\1/i',$open,$m))$v=(string)$m[2];$ok=in_array($attrNeedle,preg_split('/\s+/',trim($v))?:[],true);}
    if($ok){$close='</'.strtolower($tag).'>';$b=strpos($low,$close,$gt+1);if($b===false)return null;return ['open_start'=>$a,'content_start'=>$gt+1,'content_end'=>$b,'close_end'=>$b+strlen($close),'content'=>substr($html,$gt+1,$b-$gt-1)];}$seek=$gt+1;
  }return null;
}
function mavik_live_reader_toc_region(string $html,string $class='sidebar'): ?array {
  $aside=mavik_live_html_region($html,'aside','class',$class);if(!$aside)return null;$inner=(string)$aside['content'];$titlePos=stripos($inner,'>Зміст</div>');if($titlePos===false)return null;$start=$titlePos+strlen('>Зміст</div>');return ['content_start'=>(int)$aside['content_start']+$start,'content_end'=>(int)$aside['content_end'],'content'=>substr($inner,$start)];
}
function mavik_live_reader_payload(string $root,string $slug): array {
  $f=$root.'/books/'.$slug.'/read/index.html';$html=is_file($f)?(string)@file_get_contents($f):'';$body='';$toc='';if($html==='')return ['body'=>'','toc'=>''];
  $reader=mavik_live_html_region($html,'article','id','reader');if($reader)$body=(string)$reader['content'];$tr=mavik_live_reader_toc_region($html,'sidebar');if($tr)$toc=(string)$tr['content'];return ['body'=>$body,'toc'=>$toc];
}
function mavik_live_create_epub(string $root,array $b): bool {
  $slug=(string)$b['slug'];$out=$root.'/downloads/'.$slug.'.epub';if(is_file($out))return true;if(!class_exists('ZipArchive')&&!class_exists('PharData'))return false;$payload=mavik_live_reader_payload($root,$slug);$body=(string)$payload['body'];if(trim(strip_tags($body))==='')return false;$cover=(string)($b['cover_catalog']??'');$coverFile=$root.'/'.ltrim(rawurldecode($cover),'/');if(!is_file($coverFile))return false;$ext=strtolower(pathinfo($coverFile,PATHINFO_EXTENSION));if($ext==='jpeg')$ext='jpg';if($ext!=='jpg')return false;$mime='image/jpeg';
  $tmpBase=$root.'/_site-state/tmp';if(!is_dir($tmpBase)&&!mkdir($tmpBase,0750,true)&&!is_dir($tmpBase))return false;$tmp=$tmpBase.'/epub-'.bin2hex(random_bytes(5));
  try{if(!mkdir($tmp.'/META-INF',0750,true)&&!is_dir($tmp.'/META-INF'))return false;if(!mkdir($tmp.'/OEBPS',0750,true)&&!is_dir($tmp.'/OEBPS'))return false;file_put_contents($tmp.'/mimetype','application/epub+zip');file_put_contents($tmp.'/META-INF/container.xml','<?xml version="1.0" encoding="UTF-8"?><container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>');if(!copy($coverFile,$tmp.'/OEBPS/cover.'.$ext))return false;$title=(string)($b['title']??'Книга');$author='Макарчук Віктор Вікторович';$language=mavik_live_book_language($b);$languagePrimary=strtolower(explode('-',$language)[0]);file_put_contents($tmp.'/OEBPS/cover.xhtml','<?xml version="1.0" encoding="utf-8"?><html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" xml:lang="'.$language.'"><head><title>Обкладинка</title><link rel="stylesheet" type="text/css" href="styles.css"/></head><body class="cover-page" epub:type="cover"><img src="cover.'.$ext.'" alt="Обкладинка — '.mavik_live_h($title).'"/></body></html>');$bodyE=str_replace('&nbsp;',' ',$body);file_put_contents($tmp.'/OEBPS/text.xhtml','<?xml version="1.0" encoding="utf-8"?><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="'.$language.'"><head><title>'.mavik_live_h($title).'</title><link rel="stylesheet" type="text/css" href="styles.css"/></head><body>'.$bodyE.'</body></html>');file_put_contents($tmp.'/OEBPS/copyright.xhtml','<?xml version="1.0" encoding="utf-8"?><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="'.$language.'"><head><title>Авторські права</title></head><body><h1>Авторські права</h1><p>© 2026 MaVik / Макарчук Віктор Вікторович. Усі права захищено.</p><p>Контакт щодо прав та ліцензування: viktor@mavik.name</p><p>Повні умови: https://mavik.name/copyright/</p></body></html>');file_put_contents($tmp.'/OEBPS/styles.css','body{font-family:serif;line-height:1.6;margin:6%}h2{page-break-before:always;margin-top:2em}p{margin:.8em 0}.cover-page{margin:0;padding:0;text-align:center}.cover-page img{display:block;width:100%;height:auto;max-height:100vh;object-fit:contain;margin:0 auto}');$nav=(string)$payload['toc'];preg_match_all('#<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>#su',$nav,$nm,PREG_SET_ORDER);$items='';foreach($nm as $x){$href=(string)$x[1];if(str_starts_with($href,'#'))$href='text.xhtml'.$href;$items.='<li><a href="'.mavik_live_h($href).'">'.trim((string)$x[2]).'</a></li>';}if($items==='')$items='<li><a href="text.xhtml">Початок</a></li>';file_put_contents($tmp.'/OEBPS/nav.xhtml','<?xml version="1.0" encoding="utf-8"?><html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" xml:lang="'.$language.'"><head><title>Зміст</title></head><body><nav epub:type="toc"><h1>Зміст</h1><ol>'.$items.'</ol></nav></body></html>');$uid='urn:uuid:'.bin2hex(random_bytes(16));$opf='<?xml version="1.0" encoding="UTF-8"?><package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="id" xml:lang="'.$languagePrimary.'"><metadata xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:identifier id="id">'.$uid.'</dc:identifier><dc:title>'.mavik_live_h($title).'</dc:title><dc:creator>'.mavik_live_h($author).'</dc:creator><dc:language>'.$languagePrimary.'</dc:language><dc:rights>© 2026 MaVik / Макарчук Віктор Вікторович. Усі права захищено. Контакт: viktor@mavik.name.</dc:rights><meta property="dcterms:modified">'.gmdate('Y-m-d\TH:i:s\Z').'</meta><meta name="cover" content="cover-image"/></metadata><manifest><item id="cover-image" href="cover.'.$ext.'" media-type="'.$mime.'" properties="cover-image"/><item id="cover" href="cover.xhtml" media-type="application/xhtml+xml"/><item id="text" href="text.xhtml" media-type="application/xhtml+xml"/><item id="rights" href="copyright.xhtml" media-type="application/xhtml+xml"/><item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/><item id="css" href="styles.css" media-type="text/css"/></manifest><spine><itemref idref="cover"/><itemref idref="rights"/><itemref idref="text"/></spine><guide><reference type="cover" title="Обкладинка" href="cover.xhtml"/></guide></package>';file_put_contents($tmp.'/OEBPS/content.opf',$opf);if(!is_dir(dirname($out)))@mkdir(dirname($out),0755,true);$outTmp=$out.'.tmp-'.bin2hex(random_bytes(4)).'.zip';$ok=false;if(class_exists('ZipArchive')){$z=new ZipArchive();if($z->open($outTmp,ZipArchive::CREATE|ZipArchive::OVERWRITE)!==true)return false;$z->addFile($tmp.'/mimetype','mimetype');$z->setCompressionName('mimetype',ZipArchive::CM_STORE);$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($tmp,FilesystemIterator::SKIP_DOTS));foreach($it as $ff){$rel=substr($ff->getPathname(),strlen($tmp)+1);if($rel==='mimetype')continue;$z->addFile($ff->getPathname(),$rel);}unset($it);$ok=$z->close();}elseif(class_exists('PharData')){try{$z=new PharData($outTmp,0,null,Phar::ZIP);$z->addFile($tmp.'/mimetype','mimetype');$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($tmp,FilesystemIterator::SKIP_DOTS));foreach($it as $ff){$rel=substr($ff->getPathname(),strlen($tmp)+1);if($rel==='mimetype')continue;$z->addFile($ff->getPathname(),$rel);}unset($it);unset($z);$ok=is_file($outTmp);}catch(Throwable $e){$ok=false;}}if(!$ok){@unlink($outTmp);return false;}if(!rename($outTmp,$out)){@unlink($outTmp);return false;}@chmod($out,0644);return true;}finally{mavik_live_rm_path($tmp);}
}
function mavik_live_sync_text_reader_state(string $root,array $b): void {
  $slug=(string)$b['slug'];$dir=$root.'/books/'.$slug.'/read/text';if(!is_dir($dir))return;$final=mavik_live_final_book($b);$status=$final?'':'Тестове читання · бета-публікація';
  foreach(glob($dir.'/*.txt')?:[] as $f){$x=(string)@file_get_contents($f);if($x==='')continue;if(str_ends_with($f,'index.txt')){$x=preg_replace('/^STATUS:.*\R/m','',$x)??$x;if(!$final&&$status!==''&&str_contains($x,"AUTHOR: "))$x=preg_replace('/^(AUTHOR:.*\R)/m','$1STATUS: '.$status."\n",$x,1)??$x;}else{$x=preg_replace('/^Статус:.*\R/mu','',$x)??$x;if(!$final&&$status!==''&&str_contains($x,"Макарчук Віктор · MaVik\n"))$x=str_replace("Макарчук Віктор · MaVik\n","Макарчук Віктор · MaVik\nСтатус: ".$status."\n",$x);}mavik_live_write($f,$x);}
  $f=$dir.'/index.html';if(is_file($f)){$html=(string)@file_get_contents($f);$html=mavik_live_meta($html,'robots','noindex,follow');$html=mavik_live_canonical($html,'https://mavik.name/books/'.$slug.'/read/');$html=preg_replace('#<p class="meta">Статус:.*?</p>#su','',$html)??$html;if(!$final){$needle='<p class="meta">Макарчук Віктор · MaVik</p>';$html=str_replace($needle,$needle.'<p class="meta">Статус: '.mavik_live_h($status).'</p>',$html);}mavik_live_write($f,$html);}
}
function mavik_live_add_body_class(string $html,string $class): string {
  if(preg_match('#<body\b[^>]*\bclass=["\']([^"\']*)["\'][^>]*>#iu',$html,$m)){if(preg_match('/(?:^|\s)'.preg_quote($class,'/').'(?:\s|$)/u',(string)$m[1]))return $html;return preg_replace_callback('#<body\b([^>]*)\bclass=(["\'])([^"\']*)\2([^>]*)>#iu',static fn($x)=>'<body'.$x[1].'class='.$x[2].trim($x[3].' '.$class).$x[2].$x[4].'>',$html,1)??$html;}
  return preg_replace('#<body\b([^>]*)>#iu','<body class="'.mavik_live_h($class).'"$1>',$html,1)??$html;
}
function mavik_live_sync_reader_state(string $root,array $b): void {
  $slug=(string)$b['slug'];$f=$root.'/books/'.$slug.'/read/index.html';if(!is_file($f))return;$html=(string)@file_get_contents($f);if($html==='')return;$html=mavik_live_add_body_class($html,'reader-body');$indexable=in_array((string)($b['placement']??'books'),['books','direct'],true)&&mavik_live_final_book($b);$robots=$indexable?'index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1':'noindex,follow,max-image-preview:large';$html=mavik_live_meta($html,'robots',$robots);$html=mavik_live_canonical($html,'https://mavik.name/books/'.$slug.'/read/');$html=mavik_live_sync_reader_seo($root,$html,$b,$indexable);$status=mavik_live_final_book($b)?'Повний текст · веб-читанка mavik.name':'Тестове читання · бета-публікація · текст у роботі';
  $html=str_replace('{{BOOK_DURATION}}','',$html);$html=preg_replace('#<div\b[^>]*class=["\'][^"\']*\breader-duration\b[^"\']*["\'][^>]*>.*?</div>#su','',$html)??$html;$duration=mavik_live_book_duration($root,$slug);$durationHtml=mavik_live_reader_duration_html($duration);
  $pos=strpos($html,'<section class="book-hero">');if($pos!==false){$head=substr($html,0,$pos);$tail=substr($html,$pos);$tail=preg_replace('#(<div\b[^>]*class=["\'][^"\']*\bgenre\b[^"\']*["\'][^>]*>).*?(</div>)#su','$1'.mavik_live_h($status).'$2'.$durationHtml,$tail,1)??$tail;$html=$head.$tail;}mavik_live_write($f,$html);mavik_live_sync_text_reader_state($root,$b);
}
function mavik_live_sync_landing_state(string $root,array $b): void {
  if((string)($b['placement']??'books')==='announcements'){mavik_live_render_book_announcement_detail($root,$b);return;}
  $slug=(string)$b['slug'];$f=$root.'/books/'.$slug.'/index.html';if(!is_file($f))return;$html=(string)@file_get_contents($f);if($html==='')return;$final=mavik_live_final_book($b);$placement=(string)($b['placement']??'books');$placement=in_array($placement,['books','announcements','direct'],true)?$placement:'books';$html=preg_replace('#<body\b([^>]*)\sdata-book-placement=["\'][^"\']*["\']([^>]*)>#iu','<body$1$2>',$html,1)??$html;$html=preg_replace('#<body\b([^>]*)>#iu','<body$1 data-book-placement="'.mavik_live_h($placement).'">',$html,1)??$html;$html=mavik_live_html_lang($html,mavik_live_book_language($b));$html=mavik_live_replace_meta($html,'property','og:locale',mavik_live_og_locale($b));$announcement=(string)($b['placement']??'books')==='announcements';$html=mavik_live_replace_meta($html,'property','og:type',$announcement?'website':'book');$html=mavik_live_meta($html,'robots','index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1');$html=mavik_live_canonical($html,'https://mavik.name/books/'.$slug.'/');$cover=(string)($b['cover_catalog']??'');if($cover!=='')$html=preg_replace_callback('#<img\b[^>]*class=["\'][^"\']*\bcover\b[^"\']*["\'][^>]*>#iu',function($m)use($cover){$tag=$m[0];$tag=preg_replace('#\bsrc=["\'][^"\']*["\']#iu','src="'.mavik_live_h(mavik_live_display_image_url($cover)).'"',$tag,1)??$tag;return $tag;},$html,1)??$html;$html=preg_replace('#<div class="book-beta-badge(?: book-announcement-badge)?">.*?</div>#su','',$html)??$html;if($announcement)$badge='<div class="book-beta-badge book-announcement-badge">Анонс</div>';elseif(!$final)$badge='<div class="book-beta-badge">Тестове читання · бета-публікація</div>';else $badge='';if($badge!=='')$html=preg_replace('#(<div\b[^>]*class=["\'][^"\']*\beyebrow\b[^"\']*["\'][^>]*>.*?</div>)#su','$1'.$badge,$html,1)??$html;$hasReader=is_file($root.'/books/'.$slug.'/read/index.html');$hasEpub=is_file($root.'/downloads/'.$slug.'.epub');if($announcement){$note=trim((string)($b['announcement_reason']??$b['description']??'Анонс'));$actions='<a class="btn primary" href="/announcements/">Усі анонси →</a>';}elseif($hasReader){$note=$final?'Повний текст · безкоштовно · без реєстрації':'Тестове читання · текст у роботі · без реєстрації';$duration=mavik_live_book_duration($root,$slug);$actions=mavik_live_book_actions_html($slug,$final,$hasEpub,$duration);}else{$note='Сторінка книги · матеріали до читання ще не опубліковано';$actions='';}$html=preg_replace('#(<p\b[^>]*class=["\'][^"\']*\bbook-free-note\b[^"\']*["\'][^>]*>).*?(</p>)#su','$1'.mavik_live_h($note).'$2',$html,1)??$html;$html=preg_replace('#<div\b[^>]*class=["\'][^"\']*\bactions\b[^"\']*["\'][^>]*>.*?</div>#su','<div class="actions">'.$actions.'</div>',$html,1)??$html;$html=preg_replace('#<link\b[^>]*rel=["\']alternate["\'][^>]*type=["\']application/epub\+zip["\'][^>]*?/?>#iu','',$html)??$html;if(!$announcement&&$final&&$hasEpub)$html=str_replace('</head>','<link href="https://mavik.name/downloads/'.mavik_live_h($slug).'.epub" rel="alternate" title="EPUB" type="application/epub+zip"/></head>',$html);$html=mavik_live_patch_book_jsonld($html,$b);mavik_live_write($f,$html);
}
function mavik_live_sync_book_publication_state(string $root,array $manifest): array {
  $epubCreated=0;$epubRemoved=0;$readers=0;$landings=0;foreach((array)($manifest['books']??[]) as $b){if(!is_array($b)||!mavik_live_public_book($b))continue;$slug=(string)$b['slug'];$final=mavik_live_final_book($b);$placement=(string)($b['placement']??'books');$epub=$root.'/downloads/'.$slug.'.epub';if(in_array($placement,['books','direct'],true)&&$final&&is_file($root.'/books/'.$slug.'/read/index.html')&&!is_file($epub)){if(mavik_live_create_epub($root,$b))$epubCreated++;}elseif(in_array($placement,['books','direct'],true)&&!$final&&is_file($epub)){if(@unlink($epub))$epubRemoved++;}$rf=$root.'/books/'.$slug.'/read/index.html';if(is_file($rf)){$readers++;mavik_live_sync_reader_state($root,$b);}$lf=$root.'/books/'.$slug.'/index.html';if(is_file($lf)){$landings++;mavik_live_sync_landing_state($root,$b);}}
  return ['readers'=>$readers,'landings'=>$landings,'epub_created'=>$epubCreated,'epub_removed'=>$epubRemoved];
}
function mavik_live_sync_free_books(string $root,array $manifest): void {
  $file=$root.'/books/free/index.html';if(!is_file($file))return;$html=(string)@file_get_contents($file);if($html==='')return;$books=[];foreach(mavik_live_visible_books($manifest) as $b){if(!mavik_live_final_book($b))continue;$books[]=$b;}$cards='';$items=[];$pos=0;foreach($books as $b){$pos++;$slug=(string)$b['slug'];$title=(string)$b['title'];$genre=(string)($b['genre']??'');$desc=(string)($b['description']??'');$cover=(string)($b['cover_catalog']??'');$cards.='<a class="book-card" href="/books/'.mavik_live_h($slug).'/"><img alt="Обкладинка — '.mavik_live_h($title).'" src="'.mavik_live_h(mavik_live_display_image_url($cover)).'"'.mavik_live_image_attrs($root,$cover,true).' /><div class="book-copy"><div class="book-type">'.mavik_live_h($genre).'</div><h3 class="book-title">'.mavik_live_h($title).'</h3><p class="book-desc">'.mavik_live_h($desc).'</p><span class="book-free">Читати онлайн безкоштовно →</span></div></a>';$items[]=['@type'=>'ListItem','position'=>$pos,'item'=>['@type'=>'Book','name'=>$title,'url'=>'https://mavik.name/books/'.$slug.'/','image'=>'https://mavik.name'.$cover,'author'=>['@id'=>'https://mavik.name/#person'],'inLanguage'=>'uk-UA','isAccessibleForFree'=>true]];}$html=preg_replace('#(<section class="section">.*?<div class="grid">).*?(</div><div class="actions">)#su','$1'.$cards.'$2',$html,1)??$html;$html=preg_replace_callback('#(<script\b[^>]*type=["\']application/ld\+json["\'][^>]*>)(.*?)(</script>)#si',function($m)use($items){$j=json_decode(trim((string)$m[2]),true);if(!is_array($j))return $m[0];$changed=false;$walk=function(&$n)use(&$walk,$items,&$changed){if(!is_array($n))return;if(($n['@type']??'')==='ItemList'){$n['numberOfItems']=count($items);$n['itemListElement']=$items;$changed=true;return;}foreach($n as &$v)if(is_array($v))$walk($v);unset($v);};$walk($j);return $changed?$m[1].json_encode($j,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).$m[3]:$m[0];},$html)??$html;mavik_live_write($file,$html);
}

function mavik_live_sync_shcho_pochytaty(string $root,array $manifest): void {
  $file=rtrim($root,'/').'/shcho-pochytaty/index.html';if(!is_file($file))return;$html=(string)@file_get_contents($file);if($html==='')return;
  $new=array_slice(mavik_live_visible_books($manifest,true),0,6);$cards='';foreach($new as $b){$slug=(string)$b['slug'];$title=(string)($b['title']??'');$genre=(string)($b['genre']??'');$desc=(string)($b['description']??'');$cover=(string)($b['cover_catalog']??'');$beta=(string)($b['publication_mode']??'final')==='beta';$cards.='<a class="book-card" href="/books/'.mavik_live_h($slug).'/"><img alt="Обкладинка — '.mavik_live_h($title).'" src="'.mavik_live_h(mavik_live_display_image_url($cover)).'"'.mavik_live_image_attrs($root,$cover,true).' /><div class="book-copy"><div class="book-type">'.mavik_live_h($genre.($beta?' · тестове читання':'')).'</div><h3 class="book-title">'.mavik_live_h($title).'</h3><p class="book-desc">'.mavik_live_h($desc).'</p><span class="book-free">'.($beta?'Тестове читання →':'Читати онлайн безкоштовно →').'</span></div></a>';}
  $html=mavik_live_replace_region($html,'<!-- BOSS_SHCHO_NEW_START -->','<!-- BOSS_SHCHO_NEW_END -->',$cards);
  $ann='';foreach(mavik_live_announcement_books($manifest) as $b){$slug=(string)$b['slug'];$title=(string)($b['title']??'');$genre=(string)($b['genre']??'');$reason=trim((string)($b['announcement_reason']??$b['description']??''));$copy=$genre.($reason!==''?' · '.$reason:'');$ann.='<a class="topic-card" href="/books/'.mavik_live_h($slug).'/"><small>Готується до публікації</small><strong>'.mavik_live_h($title).'</strong><span>'.mavik_live_h($copy).'</span></a>';}
  if($ann==='')$ann='<div class="topic-card"><small>Анонси</small><strong>Нових анонсів зараз немає</strong><span>Перегляньте вже опубліковані книги.</span></div>';
  $html=mavik_live_replace_region($html,'<!-- BOSS_SHCHO_ANN_START -->','<!-- BOSS_SHCHO_ANN_END -->',$ann);
  mavik_live_write($file,$html);
}

function mavik_live_seo_landing_match(array $b,string $kind): bool {
  if(!mavik_live_public_book($b)||(string)($b['placement']??'books')==='direct')return false;$title=mavik_live_lower((string)($b['title']??''));$genre=mavik_live_lower((string)($b['genre']??''));$desc=mavik_live_lower((string)($b['description']??''));$hay=$title.' '.$genre.' '.$desc.' '.implode(' ',(array)($b['genre_keys']??[]));
  if($kind==='fantasy')return preg_match('/фантаст|фентез|антиутоп|дистоп|техно|штучн.*інтелект|\\bші\\b/u',$hay)===1;
  if($kind==='social')return preg_match('/соціальн.*фантаст|антиутоп|дистоп|всесвіт 25/u',$hay)===1||in_array((string)($b['slug']??''),['bezimenni','toi-shcho-nese-svitlo'],true);
  if($kind==='anti')return preg_match('/антиутоп|дистоп|всесвіт 25/u',$hay)===1;
  return false;
}
function mavik_live_sync_seo_landings(string $root,array $manifest): void {
  $spec=['fantastyka-ukrainskoyu'=>'fantasy','sotsialna-fantastyka'=>'social','antiutopiia'=>'anti'];foreach($spec as $slug=>$kind){$file=rtrim($root,'/').'/'.$slug.'/index.html';if(!is_file($file))continue;$html=(string)@file_get_contents($file);if($html==='')continue;$books=[];foreach(mavik_live_unique_books((array)($manifest['books']??[])) as $b)if(is_array($b)&&mavik_live_seo_landing_match($b,$kind))$books[]=$b;$cards='';foreach($books as $b){$bs=(string)$b['slug'];$title=(string)($b['title']??'');$genre=(string)($b['genre']??'');$desc=(string)($b['description']??'');$cover=(string)($b['cover_catalog']??'');$label=(string)($b['placement']??'books')==='announcements'?'Дивитися анонс →':'Читати онлайн безкоштовно →';$cards.='<a class="book-card" href="/books/'.mavik_live_h($bs).'/"><img alt="Обкладинка — '.mavik_live_h($title).'" src="'.mavik_live_h(mavik_live_display_image_url($cover)).'"'.mavik_live_image_attrs($root,$cover,true).' /><div class="book-copy"><div class="book-type">'.mavik_live_h($genre).'</div><h3 class="book-title">'.mavik_live_h($title).'</h3><p class="book-desc">'.mavik_live_h($desc).'</p><span class="book-free">'.$label.'</span></div></a>';}$html=mavik_live_replace_region($html,'<!-- BOSS_SEO_CARDS_START -->','<!-- BOSS_SEO_CARDS_END -->','<div class="grid">'.$cards.'</div>');$html=mavik_live_patch_itemlist_jsonld($html,$books);mavik_live_write($file,$html);}
}

/* Technical normalization that runs after LIVE CONTENT FIRST restore.
 * It may repair markup/projections, but it must not replace newer editorial text with release text. */
function mavik_live_heading_looks_like_prose(string $text): bool {
  $text=trim(preg_replace('/\s+/u',' ',strip_tags(html_entity_decode($text,ENT_QUOTES|ENT_HTML5,'UTF-8')))??$text);$len=mavik_live_utf8_len($text);$sent=preg_match_all('/[.!?…](?:\s|$)/u',$text,$m)?:0;return ($len>120&&$sent>=3)||$len>220;
}
function mavik_live_heading_attr(string $attrs,string $name): string {
  if(preg_match('/\b'.preg_quote($name,'/').'\s*=\s*(["\'])(.*?)\1/isu',$attrs,$m))return html_entity_decode((string)$m[2],ENT_QUOTES|ENT_HTML5,'UTF-8');return '';
}
function mavik_live_heading_set_attr(string $attrs,string $name,string $value): string {
  $safe=mavik_live_h($value);$pattern='/\s+'.preg_quote($name,'/').'\s*=\s*(["\']).*?\1/isu';if(preg_match($pattern,$attrs))return preg_replace($pattern,' '.$name.'="'.$safe.'"',$attrs,1)??$attrs;return rtrim($attrs).' '.$name.'="'.$safe.'"';
}
function mavik_live_heading_slug(string $text): string {
  $map=['а'=>'a','б'=>'b','в'=>'v','г'=>'h','ґ'=>'g','д'=>'d','е'=>'e','є'=>'ye','ж'=>'zh','з'=>'z','и'=>'y','і'=>'i','ї'=>'yi','й'=>'i','к'=>'k','л'=>'l','м'=>'m','н'=>'n','о'=>'o','п'=>'p','р'=>'r','с'=>'s','т'=>'t','у'=>'u','ф'=>'f','х'=>'kh','ц'=>'ts','ч'=>'ch','ш'=>'sh','щ'=>'shch','ь'=>'','ю'=>'iu','я'=>'ia','’'=>'','\''=>'','`'=>''];$x=strtr(mavik_live_lower(trim($text)),$map);$x=preg_replace('/[^a-z0-9]+/','-',$x)??'';return trim($x,'-');
}
function mavik_live_petlia_collapse_known_duplicate(string $body): array {
  $changed=false;$first='#<h2\b[^>]*\bid=["\']hlava-chetverta-serhiy["\'][^>]*>.*?</h2>#isu';$second='#<h2\b[^>]*\bid=["\']hlava-chetverta["\'][^>]*>.*?</h2>#isu';
  if(!preg_match($first,$body,$a,PREG_OFFSET_CAPTURE)||!preg_match($second,$body,$b,PREG_OFFSET_CAPTURE))return [$body,false];$aTag=(string)$a[0][0];$aPos=(int)$a[0][1];$bTag=(string)$b[0][0];$bPos=(int)$b[0][1];if($bPos<=$aPos)return [$body,false];$aEnd=$aPos+strlen($aTag);$bEnd=$bPos+strlen($bTag);$firstContent=substr($body,$aEnd,$bPos-$aEnd);$after=substr($body,$bEnd);$marker='';if(preg_match('#^\s*<p\b[^>]*>\s*<strong>\s*Сергій\s*</strong>\s*</p>\s*#isu',$after,$mm))$marker=(string)$mm[0];$firstDup=ltrim($firstContent);$afterDup=substr($after,strlen($marker));$probe=substr($afterDup,0,strlen($firstDup));if($firstDup!==''&&hash_equals($firstDup,$probe)){$body=substr($body,0,$bPos).substr($afterDup,strlen($firstDup));$changed=true;}return [$body,$changed];
}
function mavik_live_reader_normalize_body(string $body,string $slug=''): array {
  $changed=false;if($slug==='petlia'){[$body,$petliaChanged]=mavik_live_petlia_collapse_known_duplicate($body);$changed=$changed||$petliaChanged;}$used=[];$seq=0;
  $out=preg_replace_callback('#<h([123])\b([^>]*)>(.*?)</h\1>#isu',function($m)use(&$used,&$seq,&$changed){$tag=(int)$m[1];$attrs=(string)$m[2];$inner=(string)$m[3];$text=trim(preg_replace('/\s+/u',' ',strip_tags(html_entity_decode($inner,ENT_QUOTES|ENT_HTML5,'UTF-8')))??strip_tags($inner));if(mavik_live_heading_looks_like_prose($text)){$changed=true;return '<p>'.$inner.'</p>';}$target=$tag===1?2:$tag;if($tag===1)$changed=true;if($target===2){$seq++;$id=trim(mavik_live_heading_attr($attrs,'id'));if($id===''||isset($used[$id])){$base=mavik_live_heading_slug($text);if($base==='')$base='section-'.$seq;$candidate=$base;$i=2;while(isset($used[$candidate])){$candidate=$base.'-'.$i;$i++;}$id=$candidate;$attrs=mavik_live_heading_set_attr($attrs,'id',$id);$changed=true;}$used[$id]=true;}return '<h'.$target.$attrs.'>'.$inner.'</h'.$target.'>';},$body);return [$out??$body,$changed];
}
function mavik_live_reader_toc_levels(string $html): array {
  $out=[];$tr=mavik_live_reader_toc_region($html,'sidebar');if(!$tr)$tr=mavik_live_reader_toc_region($html,'drawer-panel');if(!$tr)return $out;$chunk=(string)$tr['content'];
  if(preg_match_all('#<a\b[^>]*class=["\'][^"\']*\btoc-link\b[^"\']*\blevel-([123])\b[^"\']*["\'][^>]*href=["\']\#([^"\']+)["\'][^>]*>#isu',$chunk,$links,PREG_SET_ORDER))foreach($links as $x)$out[(string)$x[2]]=(int)$x[1];return $out;
}
function mavik_live_reader_toc_from_body(string $body,array $levels=[]): string {
  $toc=[];if(!preg_match_all('#<h([23])\b([^>]*)>(.*?)</h\1>#isu',$body,$m,PREG_SET_ORDER))return '';
  foreach($m as $h){$tag=(int)$h[1];$attrs=(string)$h[2];$inner=(string)$h[3];$text=trim(preg_replace('/\s+/u',' ',strip_tags(html_entity_decode($inner,ENT_QUOTES|ENT_HTML5,'UTF-8')))??strip_tags($inner));if($text===''||mavik_live_heading_looks_like_prose($text))continue;$id=trim(mavik_live_heading_attr($attrs,'id'));if($id==='')continue;$level=(int)($levels[$id]??0);if(!in_array($level,[1,2,3],true)){$level=(int)mavik_live_heading_attr($attrs,'data-toc');if(!in_array($level,[1,2,3],true))$level=$tag===3?3:2;}$toc[]='<a class="toc-link level-'.$level.'" href="#'.mavik_live_h($id).'">'.mavik_live_h($text).'</a>';}
  return implode("\n",$toc);
}
function mavik_live_reader_replace_toc(string $html,string $toc): string {
  foreach(['sidebar','drawer-panel'] as $class){$tr=mavik_live_reader_toc_region($html,$class);if(!$tr)continue;$html=substr($html,0,(int)$tr['content_start']).$toc.substr($html,(int)$tr['content_end']);}return $html;
}
function mavik_live_sync_reader_structures(string $root): array {
  $root=rtrim($root,'/');$scanned=0;$changed=0;$petliaCollapsed=0;
  foreach(glob($root.'/books/*/read/index.html')?:[] as $file){
    $slug=basename(dirname(dirname($file)));if(!preg_match('/^[a-z0-9-]+$/',$slug))continue;
    $html=(string)@file_get_contents($file);if($html==='')continue;$scanned++;
    $reader=mavik_live_html_region($html,'article','id','reader');if(!$reader)continue;
    $body=(string)$reader['content'];if(trim(strip_tags($body))==='')continue;
    [$clean,$bodyChanged]=mavik_live_reader_normalize_body($body,$slug);
    $levels=mavik_live_reader_toc_levels($html);$toc=mavik_live_reader_toc_from_body($clean,$levels);
    $next=$html;
    if($bodyChanged)$next=substr($next,0,(int)$reader['content_start']).$clean.substr($next,(int)$reader['content_end']);
    // Always reconcile both desktop and mobile TOC with the actual heading IDs.
    // Older readers can have a correct body/sidebar but stale drawer anchors.
    $next=mavik_live_reader_replace_toc($next,$toc);
    if($next===$html)continue;
    if($bodyChanged&&$slug==='petlia'&&!preg_match('/\bid=["\']hlava-chetverta["\']/iu',$clean))$petliaCollapsed++;
    mavik_live_write($file,$next);
    if($bodyChanged){
      $text=$root.'/books/'.$slug.'/read/text/index.html';
      if(is_file($text)){$th=(string)@file_get_contents($text);if($th!==''){$tr=mavik_live_html_region($th,'article');if($tr){$th2=substr($th,0,(int)$tr['content_start']).$clean.substr($th,(int)$tr['content_end']);if($th2!==$th)mavik_live_write($text,$th2);}}}
      $epub=$root.'/downloads/'.$slug.'.epub';if(is_file($epub))@unlink($epub);
    }
    $changed++;
  }
  return ['scanned'=>$scanned,'changed'=>$changed,'petlia_collapsed'=>$petliaCollapsed];
}
function mavik_live_blog_article_schema(array $p): string {
  $p=mavik_live_blog_normalize_post($p);$slug=(string)($p['slug']??'');$title=(string)($p['title']??'');$desc=(string)($p['meta_description']??$p['excerpt']??'');$url='https://mavik.name/blog/'.$slug.'/';$image=trim((string)($p['image']??''));$alt=trim((string)($p['image_alt']??$title));$published=(string)($p['published_at']??($p['date']??''));$updated=(string)($p['updated_at']??$published);$tags=array_values(array_filter(array_map(static fn($x)=>trim((string)$x),(array)($p['tags']??[])),static fn($x)=>$x!==''));if(!$tags){$cat=trim((string)($p['category']??''));if($cat!=='')$tags[]=$cat;}$keywords=array_values(array_unique(array_filter(array_merge([(string)($p['primary_query']??'')],$tags))));$body=strip_tags((string)($p['body_html']??''));$wc=preg_match_all('/[\p{L}\p{N}]+/u',$body,$m)?:0;
  $article=['@type'=>'BlogPosting','@id'=>$url.'#article','headline'=>$title,'description'=>$desc,'datePublished'=>$published,'dateModified'=>$updated,'inLanguage'=>'uk-UA','mainEntityOfPage'=>$url,'isPartOf'=>['@id'=>'https://mavik.name/#website'],'articleSection'=>(string)($p['category']??'Блог'),'keywords'=>$keywords,'wordCount'=>$wc,'author'=>['@type'=>'Person','@id'=>'https://mavik.name/#person','name'=>'Макарчук Віктор Вікторович','alternateName'=>['Макарчук Віктор','MaVik'],'email'=>'viktor@mavik.name']];if($image!=='')$article['image']=['@type'=>'ImageObject','url'=>'https://mavik.name'.$image,'caption'=>$alt];
  $j=['@context'=>'https://schema.org','@graph'=>[$article,['@type'=>'BreadcrumbList','@id'=>$url.'#breadcrumbs','itemListElement'=>[['@type'=>'ListItem','position'=>1,'name'=>'MaVik','item'=>'https://mavik.name/'],['@type'=>'ListItem','position'=>2,'name'=>'Блог','item'=>'https://mavik.name/blog/'],['@type'=>'ListItem','position'=>3,'name'=>$title,'item'=>$url]]]]];return json_encode($j,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)?:'{}';
}
function mavik_live_blog_article_technical(string $root,array $p,array $blog=[]): bool {
  $p=mavik_live_blog_normalize_post($p);$slug=trim((string)($p['slug']??''));if(!preg_match('/^[a-z0-9-]+$/',$slug))return false;$file=rtrim($root,'/').'/blog/'.$slug.'/index.html';if(!is_file($file))return false;$html=(string)@file_get_contents($file);if($html==='')return false;$before=$html;$title=trim((string)($p['title']??''));$seoTitle=trim((string)($p['seo_title']??mavik_live_blog_default_seo_title($title)));$desc=trim((string)($p['meta_description']??$p['excerpt']??''));$alt=trim((string)($p['image_alt']??$title));$image=trim((string)($p['image']??''));$url='https://mavik.name/blog/'.$slug.'/';
  $html=mavik_live_canonical($html,$url);if($seoTitle!==''){$html=mavik_live_title($html,$seoTitle);$html=mavik_live_property_meta($html,'og:title',$seoTitle);$html=mavik_live_meta($html,'twitter:title',$seoTitle);}if($alt!==''){$html=mavik_live_property_meta($html,'og:image:alt',$alt);$html=mavik_live_meta($html,'twitter:image:alt',$alt);}if($image!==''){$imageUrl='https://mavik.name'.$image;$html=mavik_live_property_meta($html,'og:image',$imageUrl);$html=mavik_live_meta($html,'twitter:image',$imageUrl);$path=(string)(parse_url($image,PHP_URL_PATH)??$image);$dim=$path!==''&&str_starts_with($path,'/')?@getimagesize(rtrim($root,'/').'/'.ltrim(rawurldecode($path),'/')):false;if(is_array($dim)&&!empty($dim[0])&&!empty($dim[1])){$html=mavik_live_property_meta($html,'og:image:width',(string)(int)$dim[0]);$html=mavik_live_property_meta($html,'og:image:height',(string)(int)$dim[1]);$html=preg_replace_callback('#<figure\b[^>]*class=["\'][^"\']*\bhero-image\b[^"\']*["\'][^>]*>\s*<img\b([^>]*)>#isu',function($m)use($dim,$alt){$attrs=(string)$m[1];foreach(['width','height','loading','decoding','fetchpriority','alt'] as $n)$attrs=preg_replace('/\s+'.$n.'\s*=\s*(["\']).*?\1/isu','',$attrs)??$attrs;$attrs.=' alt="'.mavik_live_h($alt).'" width="'.(int)$dim[0].'" height="'.(int)$dim[1].'" loading="eager" decoding="async" fetchpriority="high"';return '<img'.$attrs.'>';},$html,1)??$html;}}
  if($desc!==''){$html=mavik_live_meta($html,'description',$desc);$html=mavik_live_property_meta($html,'og:description',$desc);$html=mavik_live_meta($html,'twitter:description',$desc);}$schema=mavik_live_blog_article_schema($p);$replaced=false;$html=preg_replace_callback('#<script\b[^>]*type=["\']application/ld\+json["\'][^>]*>(.*?)</script>#isu',function($m)use($schema,&$replaced){$j=json_decode(trim((string)$m[1]),true);$has=false;$walk=function($n)use(&$walk,&$has){if(!is_array($n)||$has)return;if(($n['@type']??'')==='BlogPosting'){$has=true;return;}foreach($n as $v)if(is_array($v))$walk($v);};$walk($j);if(!$has)return (string)$m[0];$replaced=true;return '<script type="application/ld+json">'.$schema.'</script>';},$html,1)??$html;if(!$replaced)$html=str_replace('</head>','<script type="application/ld+json">'.$schema.'</script></head>',$html);
  $related=mavik_live_blog_related_block($blog,$p);$html=preg_replace('#<!-- [A-Z0-9]+_SEO_RELATED_START -->.*?<!-- [A-Z0-9]+_SEO_RELATED_END -->#s','',$html)??$html;if($related!==''&&preg_match('#<aside\b[^>]*class=["\'][^"\']*\barticle-side\b[^"\']*["\'][^>]*>#isu',$html,$m,PREG_OFFSET_CAPTURE)){$tag=(string)$m[0][0];$pos=(int)$m[0][1]+strlen($tag);$html=substr($html,0,$pos).$related.substr($html,$pos);}
  if(!str_contains($html,'href="/contact/"')&&!str_contains($html,"href='/contact/'"))$html=str_replace('<a href="/about/">Автор</a>','<a href="/about/">Автор</a><a href="/contact/">Контакт</a>',$html);if($html!==$before){mavik_live_write($file,$html);return true;}return false;
}
function mavik_live_sync_blog_articles_technical(string $root,array $manifest): array {
  $blog=mavik_live_blog($manifest);$scanned=0;$changed=0;foreach($blog as $p){if(!is_array($p))continue;$scanned++;if(mavik_live_blog_article_technical($root,$p,$blog))$changed++;}return ['scanned'=>$scanned,'changed'=>$changed];
}

function mavik_live_dedupe_books_state(string $root): array {
  $file=mavik_state_path($root,'boss-content.json');
  if(!is_file($file))return ['removed'=>0,'books'=>0];
  $raw=@file_get_contents($file);$j=$raw?json_decode($raw,true):null;
  if(!is_array($j)||!is_array($j['books']??null))return ['removed'=>0,'books'=>0];
  $out=[];$where=[];$removed=0;
  foreach($j['books'] as $b){
    if(!is_array($b)){$out[]=$b;continue;}
    $slug=(string)($b['slug']??'');
    if($slug===''||!isset($where[$slug])){
      if($slug!=='')$where[$slug]=count($out);
      $out[]=$b;continue;
    }
    $removed++;$i=$where[$slug];
    // The first record is authoritative because Boss edit/hide/show actions target
    // the first matching slug. Only fill fields that are genuinely absent there.
    foreach($b as $k=>$v){
      if(!array_key_exists($k,$out[$i])||$out[$i][$k]===null||$out[$i][$k]===''||$out[$i][$k]===[]){$out[$i][$k]=$v;}
    }
  }
  if($removed>0){$j['books']=$out;$j['updated_at']=date(DATE_ATOM);mavik_live_write($file,json_encode($j,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES)."\n");}
  return ['removed'=>$removed,'books'=>count(array_filter($out,'is_array'))];
}

function mavik_live_apply_current_state_corrections(string $root): array {
  $dedupe=mavik_live_dedupe_books_state($root);
  $genres=mavik_live_normalize_genre_state($root);
  return ['seed_merge_disabled'=>true,'deduped_books'=>(int)($dedupe['removed']??0),'books_after_dedupe'=>(int)($dedupe['books']??0),'genre_records_fixed'=>(int)($genres['changed']??0)];
}

function mavik_live_reapply_book_order(string $root): array {
  $root=rtrim($root,'/');$stateFile=$root.'/_site-state/boss-content.json';$orderFile=$root.'/_site-state/book-order.json';
  $stateRaw=is_file($stateFile)?@file_get_contents($stateFile):false;$orderRaw=is_file($orderFile)?@file_get_contents($orderFile):false;
  $state=$stateRaw?json_decode($stateRaw,true):null;$order=$orderRaw?json_decode($orderRaw,true):null;
  if(!is_array($state)||!is_array($state['books']??null)||!is_array($order)||!is_array($order['order']??null))return ['changed'=>false,'ordered'=>0];
  $before=$state['books'];$by=[];$rest=[];
  foreach($before as $book){if(!is_array($book)||($slug=trim((string)($book['slug']??'')))===''||isset($by[$slug])){$rest[]=$book;continue;}$by[$slug]=$book;}
  $out=[];$used=[];foreach($order['order'] as $slug){$slug=(string)$slug;if(isset($by[$slug])&&!isset($used[$slug])){$out[]=$by[$slug];$used[$slug]=true;}}
  foreach($before as $book){if(!is_array($book)||($slug=trim((string)($book['slug']??'')))==='')continue;if(isset($by[$slug])&&!isset($used[$slug])){$out[]=$by[$slug];$used[$slug]=true;}}
  foreach($rest as $book)if(!is_array($book)||trim((string)($book['slug']??''))==='')$out[]=$book;
  if($out===$before)return ['changed'=>false,'ordered'=>count($out)];
  $state['books']=$out;$state['updated_at']=date(DATE_ATOM);mavik_live_write($stateFile,json_encode($state,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE)."\n");
  return ['changed'=>true,'ordered'=>count($out)];
}

function mavik_live_apply_runtime_cleanup(string $root): array {
  $removed=[];$root=rtrim($root,'/');
  // Keep the media index aligned with files that actually exist. No release-specific
  // deletion lists belong here: deploy must not carry permanent one-off migrations.
  $mediaFile=mavik_state_path($root,'media-library.json');
  if(is_file($mediaFile)){
    $raw=@file_get_contents($mediaFile);$ml=$raw?json_decode($raw,true):null;
    if(is_array($ml)){
      $changed=false;
      foreach(['blog','covers'] as $type){
        $arr=[];
        foreach((array)($ml[$type]??[]) as $name){
          $name=(string)$name;$ext=strtolower(pathinfo($name,PATHINFO_EXTENSION));
          if($name===''||!in_array($ext,['jpg','jpeg','png','webp','gif','avif'],true)){$changed=true;continue;}
          $path=$root.'/images/'.$type.'/'.$name;if(!is_file($path)){$changed=true;continue;}
          if(!in_array($name,$arr,true))$arr[]=$name;else $changed=true;
        }
        $ml[$type]=$arr;
      }
      if($changed){$ml['updated_at']=date(DATE_ATOM);mavik_live_write($mediaFile,json_encode($ml,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES)."\n");$removed[]='media-library:stale-references';}
    }
  }
  return ['removed'=>$removed,'reason'=>'runtime-media-reconcile'];
}
function mavik_live_bootstrap_current(string $root): array {
  $state=mavik_live_apply_current_state_corrections($root);$cleanup=mavik_live_apply_runtime_cleanup($root);$core=mavik_core_load($root);mavik_core_render_all_pages($root,$core);$readerStructure=mavik_live_sync_reader_structures($root);
  // A duplicate cleanup changes authoritative state, so immediately rebuild every public
  // projection that can expose a book card. This makes the repair visible on the first
  // Boss request after the patch is installed, without requiring a manual save/rebuild.
  if((int)($state['deduped_books']??0)>0){
    $manifest=mavik_live_json($root,'boss-content.json',['books'=>[],'blog'=>[]]);$books=mavik_live_visible_books($manifest);$new=mavik_live_visible_books($manifest,true);
    mavik_live_sync_books_page($root,$books,false);mavik_live_sync_books_page($root,$new,true);mavik_live_sync_home_books($root,$books);mavik_live_sync_free_books($root,$manifest);mavik_live_sync_shcho_pochytaty($root,$manifest);mavik_live_sync_seo_landings($root,$manifest);mavik_live_sync_sitemap($root,$manifest);
  }
  return ['state'=>$state,'cleanup'=>$cleanup,'reader_structure'=>$readerStructure,'core_version'=>(int)($core['version']??0)];
}
function mavik_live_sync_after_deploy(string $root): array {
  $bookRecovery=mavik_live_recover_public_books($root);$blogRecovery=mavik_live_recover_public_blog_posts($root);$order=mavik_live_reapply_book_order($root);$blogSeoMigration=mavik_live_migrate_blog_seo_state($root);$bootstrap=mavik_live_bootstrap_current($root);$manifest=mavik_live_json($root,'boss-content.json',['books'=>[],'blog'=>[]]);mavik_live_ensure_runtime_dirs($root);$announcementLandings=mavik_live_ensure_announcement_book_landings($root,$manifest);$readerStructures=mavik_live_sync_reader_structures($root);$publication=mavik_live_sync_book_publication_state($root,$manifest);$blogTechnical=mavik_live_sync_blog_articles_technical($root,$manifest);mavik_live_sync_blog_index($root,$manifest);$books=mavik_live_visible_books($manifest);$new=mavik_live_visible_books($manifest,true);mavik_live_sync_announcements($root,$manifest);mavik_live_sync_books_page($root,$books,false);mavik_live_sync_books_page($root,$new,true);mavik_live_sync_home_books($root,$books);mavik_live_sync_blog_focus($root,$manifest);mavik_live_sync_book_landings($root,$manifest);mavik_live_sync_free_books($root,$manifest);mavik_live_sync_shcho_pochytaty($root,$manifest);mavik_live_sync_seo_landings($root,$manifest);$blogHubs=mavik_live_sync_blog_hubs($root,$manifest);mavik_live_sync_sitemap($root,$manifest);
  $knownBooks=[];foreach((array)($manifest['books']??[]) as $book)if(is_array($book)&&($slug=(string)($book['slug']??''))!=='')$knownBooks[]=$slug;$unresolvedBooks=mavik_live_find_orphan_books($root,$knownBooks);
  $knownBlog=[];foreach((array)($manifest['blog']??[]) as $post)if(is_array($post)&&($slug=(string)($post['slug']??''))!=='')$knownBlog[$slug]=true;$unresolvedBlog=[];foreach(glob(rtrim($root,'/').'/blog/*/index.html')?:[] as $file){$slug=basename(dirname($file));if($slug!==''&&!isset($knownBlog[$slug])&&preg_match('/^[a-z0-9-]+$/',$slug))$unresolvedBlog[]=$slug;}
  if($unresolvedBooks||$unresolvedBlog)throw new RuntimeException('Reconciliation не завершено: книги '.count($unresolvedBooks).', дописи '.count($unresolvedBlog).'. Deploy/restore не підтверджено.');
  $releaseMarkers=mavik_live_sync_release_markers($root);
  return ['book_recovery'=>$bookRecovery,'blog_recovery'=>$blogRecovery,'book_order'=>$order,'blog_seo_migration'=>$blogSeoMigration,'blog_hubs'=>$blogHubs,'bootstrap'=>$bootstrap,'release_markers'=>$releaseMarkers,'announcement_landings_created'=>$announcementLandings,'reader_structures'=>$readerStructures,'publication'=>$publication,'blog_technical'=>$blogTechnical,'books'=>count($books),'final_books'=>count(array_filter($books,static fn($b)=>mavik_live_final_book((array)$b))),'new_books'=>count($new),'announcements'=>count(mavik_live_announcement_books($manifest))];
}

/* Current sync is version-agnostic; one-release migrations are not retained. */

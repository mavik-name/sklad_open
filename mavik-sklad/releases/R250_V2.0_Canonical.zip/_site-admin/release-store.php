<?php
declare(strict_types=1);

/*
 * MaVik release shelf.
 * Active slots:
 *   canonical -> R250_V2.0_Canonical.zip
 *   candidate -> R250_V2.0_Release_Candidate.zip
 * One previous canonical is retained as a service rollback.
 */

function mavik_release_store_dir(string $root): string {
  $dir=rtrim($root,'/').'/_site-releases';
  if(!is_dir($dir)&&!mkdir($dir,0755,true)&&!is_dir($dir))throw new RuntimeException('Не вдалося створити локальне сховище релізів.');
  @chmod($dir,0755);
  $guard=$dir.'/.htaccess';
  if(!is_file($guard)){
    @file_put_contents($guard,"Options -Indexes\n<IfModule mod_authz_core.c>\n  Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n  Deny from all\n</IfModule>\n",LOCK_EX);
    @chmod($guard,0644);
  }
  $rollback=$dir.'/rollback';
  if(!is_dir($rollback))@mkdir($rollback,0755,true);
  @chmod($rollback,0755);
  $rg=$rollback.'/.htaccess';
  if(!is_file($rg)){@file_put_contents($rg,"Options -Indexes\n<IfModule mod_authz_core.c>\n  Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n  Deny from all\n</IfModule>\n",LOCK_EX);@chmod($rg,0644);}
  return $dir;
}
function mavik_release_store_slot(string $slot): string {
  if(!in_array($slot,['canonical','candidate','previous'],true))throw new RuntimeException('Некоректний слот релізу.');
  return $slot;
}
function mavik_release_store_filename(string $slot): string {
  $slot=mavik_release_store_slot($slot);
  return match($slot){
    'canonical'=>'R250_V2.0_Canonical.zip',
    'candidate'=>'R250_V2.0_Release_Candidate.zip',
    'previous'=>'R250_V2.0_Canonical_PREVIOUS.zip',
  };
}
function mavik_release_store_path(string $root,string $slot): string {
  $slot=mavik_release_store_slot($slot);$dir=mavik_release_store_dir($root);
  return $slot==='previous'?$dir.'/rollback/'.mavik_release_store_filename($slot):$dir.'/'.mavik_release_store_filename($slot);
}
function mavik_release_store_validate_zip(string $path): array {
  if(!is_file($path)||filesize($path)<=0)throw new RuntimeException('ZIP релізу не знайдено або він порожній.');
  if(filesize($path)>100*1024*1024)throw new RuntimeException('Реліз у сховищі має бути до 100 МБ.');
  $check=mavik_deploy_validate($path);
  $raw=mavik_deploy_read_entry($path,'.mavik-release.json');$manifest=json_decode($raw,true);
  if(!is_array($manifest))throw new RuntimeException('Некоректний .mavik-release.json.');
  $label=trim((string)($manifest['release_label']??''));
  if($label!==''&&$label!=='R250_V2.0_Canonical')throw new RuntimeException('Це не канонічна гілка R250_V2.0.');
  return ['manifest'=>$manifest,'entries'=>(array)($check['entries']??[]),'unpacked_bytes'=>(int)($check['unpacked_bytes']??0)];
}
function mavik_release_store_info(string $root,string $slot): array {
  $slot=mavik_release_store_slot($slot);$path=mavik_release_store_path($root,$slot);
  $out=['slot'=>$slot,'name'=>mavik_release_store_filename($slot),'exists'=>is_file($path),'path'=>$path,'size'=>0,'mtime'=>0,'sha256'=>'','valid'=>false,'generated_at'=>''];
  if(!$out['exists'])return $out;
  $out['size']=(int)filesize($path);$out['mtime']=(int)filemtime($path);$out['sha256']=(string)hash_file('sha256',$path);
  try{$v=mavik_release_store_validate_zip($path);$out['valid']=true;$out['generated_at']=trim((string)($v['manifest']['generated_at']??''));}catch(Throwable $e){$out['error']=$e->getMessage();}
  return $out;
}
function mavik_release_store_atomic_bytes(string $target,string $bytes): void {
  $dir=dirname($target);if(!is_dir($dir)&&!mkdir($dir,0755,true)&&!is_dir($dir))throw new RuntimeException('Не вдалося створити каталог релізу.');
  $tmp=$target.'.part-'.bin2hex(random_bytes(4));
  if(@file_put_contents($tmp,$bytes,LOCK_EX)!==strlen($bytes)){@unlink($tmp);throw new RuntimeException('Не вдалося записати реліз.');}
  @chmod($tmp,0644);
  try{mavik_release_store_validate_zip($tmp);}catch(Throwable $e){@unlink($tmp);throw $e;}
  if(!@rename($tmp,$target)){@unlink($tmp);throw new RuntimeException('Не вдалося завершити запис релізу.');}
  @chmod($target,0644);
}
function mavik_release_store_upload_candidate(string $root,array $file): array {
  if((int)($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK||empty($file['tmp_name'])||!is_uploaded_file((string)$file['tmp_name']))throw new RuntimeException('Оберіть ZIP Release Candidate.');
  $name=(string)($file['name']??'');if(!preg_match('/\.zip$/i',$name))throw new RuntimeException('Release Candidate має бути ZIP-файлом.');
  if((int)($file['size']??0)>100*1024*1024)throw new RuntimeException('Release Candidate має бути до 100 МБ.');
  mavik_release_store_validate_zip((string)$file['tmp_name']);
  $bytes=@file_get_contents((string)$file['tmp_name']);if(!is_string($bytes))throw new RuntimeException('Не вдалося прочитати Release Candidate.');
  mavik_release_store_atomic_bytes(mavik_release_store_path($root,'candidate'),$bytes);
  return mavik_release_store_info($root,'candidate');
}
function mavik_release_store_stream(string $root,string $slot): void {
  $slot=mavik_release_store_slot($slot);$path=mavik_release_store_path($root,$slot);
  if(!is_file($path))throw new RuntimeException('Цього релізу немає в локальному сховищі.');
  header('Content-Type: application/zip');header('Content-Disposition: attachment; filename="'.mavik_release_store_filename($slot).'"');header('Content-Length: '.filesize($path));header('Cache-Control: no-store, private');readfile($path);exit;
}
function mavik_release_store_remote_path(string $slot): string {
  $slot=mavik_release_store_slot($slot);if($slot==='previous')throw new RuntimeException('Rollback не є активним релізом.');
  return 'mavik-sklad/releases/'.mavik_release_store_filename($slot);
}
function mavik_release_store_remote_folder_url(): string { return 'https://github.com/mavik-name/sklad_open/tree/main/mavik-sklad/releases'; }
function mavik_release_store_remote_info(string $root,string $slot): array {
  $slot=mavik_release_store_slot($slot);if($slot==='previous')return ['exists'=>false,'slot'=>$slot];
  $cfg=mavik_workspace_github_load($root);
  $out=['slot'=>$slot,'exists'=>false,'name'=>mavik_release_store_filename($slot),'path'=>mavik_release_store_remote_path($slot),'size'=>0,'sha'=>'','html_url'=>''];
  if(!mavik_workspace_github_ready($cfg))return $out;
  $ep='/repos/mavik-name/sklad_open/contents/'.mavik_workspace_github_api_path((string)$out['path']).'?ref=main';
  try{$j=mavik_workspace_github_request($cfg,'GET',$ep);}catch(RuntimeException $e){if(str_contains($e->getMessage(),'(404)'))return $out;throw $e;}
  if(!is_array($j)||($j['type']??'')!=='file')return $out;
  $out['exists']=true;$out['size']=(int)($j['size']??0);$out['sha']=(string)($j['sha']??'');$out['html_url']=(string)($j['html_url']??'');
  return $out;
}
function mavik_release_store_remote_push(string $root,string $slot): array {
  $slot=mavik_release_store_slot($slot);if($slot==='previous')throw new RuntimeException('Rollback не надсилається як активний реліз.');
  $local=mavik_release_store_info($root,$slot);if(empty($local['exists'])||empty($local['valid']))throw new RuntimeException('Локальний реліз відсутній або не пройшов перевірку.');
  $cfg=mavik_workspace_github_load($root);if(!mavik_workspace_github_ready($cfg))throw new RuntimeException('Дальній склад не підключено: збережіть GitHub token у розділі «Файли».');
  $bytes=@file_get_contents((string)$local['path']);if(!is_string($bytes))throw new RuntimeException('Не вдалося прочитати локальний реліз.');
  $path=mavik_release_store_remote_path($slot);$sha=mavik_workspace_github_existing_sha($cfg,$path);
  $body=['message'=>'MaVik releases: sync '.mavik_release_store_filename($slot),'content'=>base64_encode($bytes),'branch'=>'main'];if($sha!==null)$body['sha']=$sha;
  mavik_workspace_github_request($cfg,'PUT','/repos/mavik-name/sklad_open/contents/'.mavik_workspace_github_api_path($path),$body);
  return mavik_release_store_remote_info($root,$slot);
}
function mavik_release_store_remote_bytes(string $root,string $slot): string {
  $slot=mavik_release_store_slot($slot);$cfg=mavik_workspace_github_load($root);if(!mavik_workspace_github_ready($cfg))throw new RuntimeException('Дальній склад не підключено.');
  $meta=mavik_release_store_remote_info($root,$slot);if(empty($meta['exists'])||empty($meta['sha']))throw new RuntimeException('На дальньому складі цього релізу немає.');
  $blob=mavik_workspace_github_request($cfg,'GET','/repos/mavik-name/sklad_open/git/blobs/'.rawurlencode((string)$meta['sha']));
  $content=str_replace(["\r","\n"],'',(string)($blob['content']??''));$bytes=base64_decode($content,true);
  if(!is_string($bytes)||$bytes==='')throw new RuntimeException('Не вдалося отримати ZIP із дальнього складу.');
  return $bytes;
}
function mavik_release_store_remote_pull(string $root,string $slot): array {
  $slot=mavik_release_store_slot($slot);if($slot==='previous')throw new RuntimeException('Rollback не завантажується з активного складу.');
  mavik_release_store_atomic_bytes(mavik_release_store_path($root,$slot),mavik_release_store_remote_bytes($root,$slot));
  return mavik_release_store_info($root,$slot);
}
function mavik_release_store_remote_delete(string $root,string $slot): void {
  $slot=mavik_release_store_slot($slot);if($slot==='previous')return;
  $cfg=mavik_workspace_github_load($root);if(!mavik_workspace_github_ready($cfg))return;
  $path=mavik_release_store_remote_path($slot);$sha=mavik_workspace_github_existing_sha($cfg,$path)??'';if($sha==='')return;
  mavik_workspace_github_request($cfg,'DELETE','/repos/mavik-name/sklad_open/contents/'.mavik_workspace_github_api_path($path),['message'=>'MaVik releases: remove '.mavik_release_store_filename($slot),'sha'=>$sha,'branch'=>'main']);
}
function mavik_release_store_discard_candidate(string $root,bool $remote=true): void {
  $path=mavik_release_store_path($root,'candidate');if(is_file($path))@unlink($path);
  if($remote)mavik_release_store_remote_delete($root,'candidate');
}
function mavik_release_store_promote(string $root,bool $syncRemote=true): array {
  $candidate=mavik_release_store_info($root,'candidate');if(empty($candidate['exists'])||empty($candidate['valid']))throw new RuntimeException('Немає перевіреного Release Candidate у локальному сховищі.');
  $canonicalPath=mavik_release_store_path($root,'canonical');$previousPath=mavik_release_store_path($root,'previous');
  if(is_file($canonicalPath)){
    $old=@file_get_contents($canonicalPath);if(!is_string($old)||$old==='')throw new RuntimeException('Не вдалося зберегти попередній Canonical.');
    mavik_release_store_atomic_bytes($previousPath,$old);
  }
  $bytes=@file_get_contents((string)$candidate['path']);if(!is_string($bytes)||$bytes==='')throw new RuntimeException('Не вдалося прочитати Release Candidate.');
  mavik_release_store_atomic_bytes($canonicalPath,$bytes);
  if($syncRemote){
    $cfg=mavik_workspace_github_load($root);
    if(mavik_workspace_github_ready($cfg)){mavik_release_store_remote_push($root,'canonical');mavik_release_store_remote_delete($root,'candidate');}
  }
  @unlink((string)$candidate['path']);
  return mavik_release_store_info($root,'canonical');
}
function mavik_release_store_restore_previous(string $root): array {
  $prev=mavik_release_store_info($root,'previous');if(empty($prev['exists'])||empty($prev['valid']))throw new RuntimeException('Службового rollback немає.');
  $bytes=@file_get_contents((string)$prev['path']);if(!is_string($bytes)||$bytes==='')throw new RuntimeException('Не вдалося прочитати rollback.');
  mavik_release_store_atomic_bytes(mavik_release_store_path($root,'canonical'),$bytes);
  return mavik_release_store_info($root,'canonical');
}
function mavik_release_store_sync_all_to_remote(string $root): int {
  $n=0;foreach(['canonical','candidate'] as $slot){$i=mavik_release_store_info($root,$slot);if(!empty($i['exists'])&&!empty($i['valid'])){mavik_release_store_remote_push($root,$slot);$n++;}}return $n;
}

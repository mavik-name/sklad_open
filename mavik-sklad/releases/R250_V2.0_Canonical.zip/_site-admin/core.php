<?php
declare(strict_types=1);
require_once __DIR__.'/state.php';
require_once __DIR__.'/utf8.php';

function mavik_core_atomic_write(string $file,string $data): void {
  $dir=dirname($file);if(!is_dir($dir)&&!mkdir($dir,0755,true)&&!is_dir($dir))throw new RuntimeException('Не вдалося створити каталог.');
  $tmp=$file.'.tmp-'.bin2hex(random_bytes(4));if(file_put_contents($tmp,$data,LOCK_EX)===false)throw new RuntimeException('Помилка запису файла.');
  if(!rename($tmp,$file)){@unlink($tmp);throw new RuntimeException('Не вдалося замінити файл.');}
}
function mavik_core_state_file(string $root): string {return mavik_state_seed($root,'site-core.json');}
function mavik_core_load(string $root): array {
  $f=mavik_core_state_file($root);$raw=is_file($f)?file_get_contents($f):false;$j=$raw?json_decode($raw,true):null;$changed=false;
  if(!is_array($j)){$j=['version'=>7,'home'=>['books_limit_desktop'=>8,'books_limit_mobile'=>8],'menu'=>[],'sections'=>[],'pages'=>[]];$changed=true;}
  if(!isset($j['home'])||!is_array($j['home'])){$j['home']=[];$changed=true;}
  $legacy=max(1,min(40,(int)($j['home']['books_limit']??8)));
  $desk=max(1,min(40,(int)($j['home']['books_limit_desktop']??$legacy)));$mob=max(1,min(40,(int)($j['home']['books_limit_mobile']??$legacy)));
  if(($j['home']['books_limit_desktop']??null)!==$desk||($j['home']['books_limit_mobile']??null)!==$mob||array_key_exists('books_limit',$j['home']))$changed=true;
  $j['home']['books_limit_desktop']=$desk;$j['home']['books_limit_mobile']=$mob;unset($j['home']['books_limit']);
  if(!isset($j['menu'])||!is_array($j['menu'])){$j['menu']=[];$changed=true;}
  foreach($j['menu'] as &$it){if(!is_array($it))continue;$label=trim((string)($it['label']??($it['labels']['uk']??'')));$path=trim((string)($it['path']??($it['hrefs']['uk']??($it['href']??''))));if(($it['label']??null)!==$label||isset($it['labels'])||isset($it['hrefs'])||isset($it['href']))$changed=true;$it['label']=$label;$it['path']=$path!==''?$path:'/';unset($it['labels'],$it['hrefs'],$it['href']);if(!isset($it['hidden']))$it['hidden']=false;}unset($it);
  if(!isset($j['sections'])||!is_array($j['sections'])||$j['sections']){$j['sections']=[];$changed=true;}if(!isset($j['pages'])||!is_array($j['pages'])||$j['pages']){$j['pages']=[];$changed=true;}unset($j['static_pages_seed_version']);
  if((int)($j['version']??0)!==7){$j['version']=7;$changed=true;}
  if($changed){$j['updated_at']=date(DATE_ATOM);mavik_core_atomic_write($f,json_encode($j,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));}
  return $j;
}
function mavik_core_save(string $root,array $j): void {$j['version']=7;$j['updated_at']=date(DATE_ATOM);foreach((array)($j['menu']??[]) as &$it)if(is_array($it)){if(!isset($it['label'])&&isset($it['labels']['uk']))$it['label']=(string)$it['labels']['uk'];unset($it['labels'],$it['hrefs'],$it['href']);}unset($it);mavik_core_atomic_write(mavik_core_state_file($root),json_encode($j,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));mavik_core_render_all_pages($root,$j);}
function mavik_core_home_book_limits(string $root): array {
  $home=(array)(mavik_core_load($root)['home']??[]);
  return [
    'desktop'=>max(1,min(40,(int)($home['books_limit_desktop']??8))),
    'mobile'=>max(1,min(40,(int)($home['books_limit_mobile']??8))),
  ];
}
function mavik_core_home_book_limit(string $root): int {$x=mavik_core_home_book_limits($root);return max((int)$x['desktop'],(int)$x['mobile']);}
function mavik_core_menu_sorted(array $core): array {$items=array_values(array_filter((array)($core['menu']??[]),'is_array'));usort($items,fn($a,$b)=>((int)($a['sort']??0)<=> (int)($b['sort']??0))?:strcmp((string)($a['id']??''),(string)($b['id']??'')));return $items;}
function mavik_core_menu_payload(string $root,?array $core=null): array {
  $core=$core??mavik_core_load($root);$out=['version'=>5,'generated_at'=>date(DATE_ATOM),'items'=>[]];
  foreach(mavik_core_menu_sorted($core) as $it){if(!empty($it['hidden']))continue;$id=(string)($it['id']??'');$label=trim((string)($it['label']??''));$href=trim((string)($it['path']??''));if($id!==''&&$label!==''&&$href!=='')$out['items'][]=['id'=>$id,'label'=>$label,'href'=>$href];}
  return $out;
}
function mavik_core_export_menu(string $root,?array $core=null): void {mavik_core_atomic_write($root.'/assets/app/site-menu.json',json_encode(mavik_core_menu_payload($root,$core),JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));}
function mavik_core_safe_slug(string $s): string {$s=mavik_utf8_lower(trim($s));$map=['а'=>'a','б'=>'b','в'=>'v','г'=>'h','ґ'=>'g','д'=>'d','е'=>'e','є'=>'ye','ж'=>'zh','з'=>'z','и'=>'y','і'=>'i','ї'=>'yi','й'=>'i','к'=>'k','л'=>'l','м'=>'m','н'=>'n','о'=>'o','п'=>'p','р'=>'r','с'=>'s','т'=>'t','у'=>'u','ф'=>'f','х'=>'kh','ц'=>'ts','ч'=>'ch','ш'=>'sh','щ'=>'shch','ь'=>'','ю'=>'iu','я'=>'ia','’'=>'','\''=>''];$s=strtr($s,$map);$s=preg_replace('/[^a-z0-9]+/','-',$s)??'';return trim($s,'-');}
function mavik_core_clean_path(string $path): string {
  $path=trim($path);if(preg_match('#^https://#i',$path))return $path;$path=parse_url($path,PHP_URL_PATH)?:$path;$parts=[];foreach(explode('/',trim($path,'/')) as $p){$p=mavik_core_safe_slug($p);if($p!=='')$parts[]=$p;}return '/'.implode('/',$parts).'/';
}
function mavik_core_sanitize_html_fallback(string $raw): string {
  $raw=preg_replace('#<(script|style|iframe|object|embed|svg|math|form|input|button|textarea|select)\b[^>]*>.*?</\1\s*>#is','',$raw)??$raw;
  $raw=preg_replace('#<(script|style|iframe|object|embed|svg|math|form|input|button|textarea|select)\b[^>]*/?>#is','',$raw)??$raw;
  $allowed='<p><h1><h2><h3><h4><strong><b><em><i><blockquote><ul><ol><li><a><br><hr><figure><figcaption><img><section><article><div><span><small>';
  $raw=strip_tags($raw,$allowed);
  $void=['br'=>true,'hr'=>true,'img'=>true];
  $raw=preg_replace_callback('#<([a-z0-9]+)\b([^>]*)>#i',function($m)use($void){
    $tag=strtolower($m[1]);$attrs=(string)$m[2];$get=function(string $name)use($attrs): string {if(preg_match('/\b'.preg_quote($name,'/').'\s*=\s*(["\'])(.*?)\1/is',$attrs,$x))return html_entity_decode((string)$x[2],ENT_QUOTES|ENT_HTML5,'UTF-8');if(preg_match('/\b'.preg_quote($name,'/').'\s*=\s*([^\s>]+)/i',$attrs,$x))return html_entity_decode(trim((string)$x[1],"\"'"),ENT_QUOTES|ENT_HTML5,'UTF-8');return '';};
    $out='<'.$tag;
    $allowedClasses=['static-figure','static-float-left','static-float-right','static-image-center','static-image-wide','section','intro','grid','topic-card','actions','btn','primary','rights-grid','rights-card','rights-card-major','rights-number','rights-law','rights-final','rights-seal','rights-final-title','rights-contact','rights-contact-email','num','mavik-text-gold','mavik-text-light','mavik-text-black','mavik-text-white','mavik-bg-gold','mavik-bg-light','mavik-align-left','mavik-align-center','mavik-align-right'];$classes=preg_split('/\s+/',trim($get('class')))?:[];$classes=array_values(array_intersect($classes,$allowedClasses));$cls=implode(' ',$classes);if($cls!=='')$out.=' class="'.htmlspecialchars($cls,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8').'"';
    if($tag==='a'){$href=trim($get('href'));if($href!==''&&(preg_match('~^(https://|mailto:|/|#)~i',$href)))$out.=' href="'.htmlspecialchars($href,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8').'"';$target=$get('target');if($target==='_blank')$out.=' target="_blank" rel="noopener noreferrer"';}
    if($tag==='img'){$src=trim($get('src'));if($src===''||(!str_starts_with($src,'/images/')&&!str_starts_with($src,'/assets/')&&!preg_match('#^https://#i',$src)))return '';$out.=' src="'.htmlspecialchars($src,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8').'"';$alt=$get('alt');$out.=' alt="'.htmlspecialchars($alt,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8').'" loading="lazy"';foreach(['width','height'] as $n){$v=$get($n);if(preg_match('/^\d{1,5}$/',$v))$out.=' '.$n.'="'.$v.'"';}}
    return $out.(!empty($void[$tag])?'>':'>');
  },$raw)??$raw;
  return trim($raw);
}
function mavik_core_sanitize_html(string $raw): string {
  $raw=trim($raw);if($raw==='')return '';if(!str_contains($raw,'<')){$blocks=preg_split('/\n\s*\n/u',$raw)?:[];$parts=[];foreach($blocks as $b){$b=trim((string)$b);if($b==='')continue;if(str_starts_with($b,'### '))$parts[]='<h3>'.htmlspecialchars(trim(substr($b,4)),ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8').'</h3>';elseif(str_starts_with($b,'## '))$parts[]='<h2>'.htmlspecialchars(trim(substr($b,3)),ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8').'</h2>';else$parts[]='<p>'.nl2br(htmlspecialchars($b,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8'),false).'</p>';}$raw=implode('',$parts);}
  if(!class_exists('DOMDocument'))return mavik_core_sanitize_html_fallback($raw);
  $d=new DOMDocument('1.0','UTF-8');$old=libxml_use_internal_errors(true);$d->loadHTML('<?xml encoding="UTF-8"><div id="mavik-core-root">'.$raw.'</div>',LIBXML_HTML_NOIMPLIED|LIBXML_HTML_NODEFDTD);libxml_clear_errors();libxml_use_internal_errors($old);$root=null;foreach($d->getElementsByTagName('div') as $x)if($x->getAttribute('id')==='mavik-core-root'){$root=$x;break;}if(!$root)return '';
  $allowed=['p','h1','h2','h3','h4','strong','b','em','i','blockquote','ul','ol','li','a','br','hr','figure','figcaption','img','section','article','div','span','small'];
  $walk=function(DOMNode $node)use(&$walk,$allowed){for($ch=$node->firstChild;$ch;){$next=$ch->nextSibling;if($ch instanceof DOMComment){$node->removeChild($ch);$ch=$next;continue;}if($ch instanceof DOMElement){$tag=strtolower($ch->tagName);if(!in_array($tag,$allowed,true)){if(in_array($tag,['script','style','iframe','object','embed','svg','math','form','input','button','textarea','select'],true)){$node->removeChild($ch);$ch=$next;continue;}$walk($ch);while($ch->firstChild)$node->insertBefore($ch->firstChild,$ch);$node->removeChild($ch);$ch=$next;continue;}$keep=['class'];if($tag==='a')$keep=['class','href','target','rel'];elseif($tag==='img')$keep=['class','src','alt','loading','width','height'];if($ch->hasAttributes())for($i=$ch->attributes->length-1;$i>=0;$i--){$a=$ch->attributes->item($i);if($a&&!in_array(strtolower($a->name),$keep,true))$ch->removeAttributeNode($a);}if($ch->hasAttribute('class')){$cls=preg_replace('/[^A-Za-z0-9 _-]/','',$ch->getAttribute('class'))??'';$tokens=preg_split('/\s+/',trim($cls))?:[];$allowedEditor=['mavik-text-gold','mavik-text-light','mavik-text-black','mavik-text-white','mavik-bg-gold','mavik-bg-light','mavik-align-left','mavik-align-center','mavik-align-right'];$tokens=array_values(array_filter($tokens,static fn($c)=>!str_starts_with($c,'mavik-text-')&&!str_starts_with($c,'mavik-bg-')||in_array($c,$allowedEditor,true)));if($tokens)$ch->setAttribute('class',implode(' ',$tokens));else$ch->removeAttribute('class');}if($tag==='a'){$href=trim($ch->getAttribute('href'));if($href!==''&&!preg_match('~^(https://|mailto:|/|#)~i',$href))$ch->removeAttribute('href');elseif(preg_match('#^https://#i',$href)){$host=strtolower((string)(parse_url($href,PHP_URL_HOST)??''));if($host!==''&&!in_array($host,['mavik.name','www.mavik.name'],true)){$ch->setAttribute('target','_blank');$ch->setAttribute('rel','noopener noreferrer');}else{$ch->removeAttribute('target');$ch->removeAttribute('rel');}}}if($tag==='img'){$src=trim($ch->getAttribute('src'));if($src===''||(!str_starts_with($src,'/images/')&&!str_starts_with($src,'/assets/')&&!preg_match('#^https://#i',$src))){$node->removeChild($ch);$ch=$next;continue;}$ch->setAttribute('loading','lazy');}$walk($ch);} $ch=$next;}};$walk($root);$out='';foreach(iterator_to_array($root->childNodes) as $n)$out.=$d->saveHTML($n);return trim($out);
}
function mavik_core_page_effectively_hidden(string $root,array $p,array $core): bool {return true;}
function mavik_core_menu_links_html(string $root,?array $core=null,string $currentPath=''): string {
  $payload=mavik_core_menu_payload($root,$core);$current=parse_url($currentPath,PHP_URL_PATH)?:$currentPath;$current='/'.trim((string)$current,'/').'/';if($current==='//')$current='/';$out='';
  foreach((array)($payload['items']??[]) as $it){if(!is_array($it))continue;$label=trim((string)($it['label']??''));$href=trim((string)($it['href']??''));if($label===''||$href==='')continue;$active='';if(str_starts_with($href,'/')){$p=parse_url($href,PHP_URL_PATH)?:$href;$p='/'.trim((string)$p,'/').'/';if($p==='//')$p='/';if($p===$current)$active=' aria-current="page"';}$out.='<a href="'.htmlspecialchars($href,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8').'"'.$active.'>'.htmlspecialchars($label,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8').'</a>';}
  return $out;
}
function mavik_core_patch_ssr_menu(string $html,string $links): string {
  $special=function(string $inner): string {$keep='';if(preg_match_all('#<a\b[^>]*class=["\'][^"\']*(?:mavik-site-ding|ding-small|js-ding|mavik-owner-access|mavik-menu-back)[^"\']*["\'][^>]*>.*?</a>#siu',$inner,$m))$keep=implode('',(array)$m[0]);return $keep;};
  $html=preg_replace_callback('#(<nav\b[^>]*class=["\'][^"\']*\bmavik-site-desktop-nav\b[^"\']*["\'][^>]*>)(.*?)(</nav>)#siu',static function($m)use($links,$special){return $m[1].$links.$special((string)$m[2]).$m[3];},$html)??$html;
  $html=preg_replace_callback('#(<div\b[^>]*class=["\'][^"\']*\bmavik-site-mobile-inner\b[^"\']*["\'][^>]*>)(.*?)(</div>)#siu',static function($m)use($links,$special){return $m[1].$links.$special((string)$m[2]).$m[3];},$html)??$html;
  return $html;
}
function mavik_core_render_all_pages(string $root,?array $core=null): void {
  $core=$core??mavik_core_load($root);mavik_core_export_menu($root,$core);$root=rtrim($root,'/');$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS));
  foreach($it as $f){if(!$f->isFile()||strtolower($f->getExtension())!=='html')continue;$path=str_replace('\\','/',$f->getPathname());$rel=ltrim(substr($path,strlen($root)),'/');if(str_starts_with($rel,'_site-admin/')||str_starts_with($rel,'boss/'))continue;$html=@file_get_contents($path);if(!is_string($html)||!str_contains($html,'mavik-site-desktop-nav')||str_contains($html,'{{'))continue;$url=$rel==='index.html'?'/':('/'.preg_replace('#index\.html$#','',$rel));$links=mavik_core_menu_links_html($root,$core,$url);$new=mavik_core_patch_ssr_menu($html,$links);if($new!==$html)mavik_core_atomic_write($path,$new);}
}

function mavik_core_image_root(string $root): string {return $root.'/images';}
function mavik_core_image_folder(string $root,string $folder): string {$folder=trim($folder,'/');if($folder==='')return mavik_core_image_root($root);$parts=[];foreach(explode('/',$folder) as $p){$p=mavik_core_safe_slug($p);if($p==='')throw new RuntimeException('Некоректна назва каталогу.');$parts[]=$p;}return mavik_core_image_root($root).'/'.implode('/',$parts);}
function mavik_core_image_folders(string $root): array {$base=mavik_core_image_root($root);$out=[];$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($base,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::SELF_FIRST);foreach($it as $f){if(!$f->isDir()||$f->isLink())continue;$rel=str_replace('\\','/',substr($f->getPathname(),strlen($base)+1));if($rel===''||str_starts_with($rel,'.'))continue;$depth=substr_count($rel,'/');if($depth>2)continue;$out[]=$rel;}sort($out,SORT_NATURAL|SORT_FLAG_CASE);return $out;}
function mavik_core_image_files(string $root,string $folder): array {$dir=mavik_core_image_folder($root,$folder);if(!is_dir($dir))return [];$out=[];foreach(scandir($dir)?:[] as $n){if($n==='.'||$n==='..'||$n==='.htaccess')continue;$p=$dir.'/'.$n;if(!is_file($p))continue;$ext=strtolower(pathinfo($n,PATHINFO_EXTENSION));if(!in_array($ext,['jpg','jpeg','png','webp','gif','avif'],true))continue;$dim=@getimagesize($p);$rel=str_replace('\\','/',substr($p,strlen($root)));$out[]=['file'=>$n,'url'=>$rel,'bytes'=>(int)filesize($p),'width'=>(int)($dim[0]??0),'height'=>(int)($dim[1]??0)];}usort($out,fn($a,$b)=>strnatcasecmp($a['file'],$b['file']));return $out;}
function mavik_core_image_create_folder(string $root,string $parent,string $name): string {$slug=mavik_core_safe_slug($name);if($slug==='')throw new RuntimeException('Вкажіть назву каталогу.');$parent=trim($parent,'/');$rel=trim(($parent!==''?$parent.'/':'').$slug,'/');$dir=mavik_core_image_folder($root,$rel);if(is_dir($dir))throw new RuntimeException('Такий каталог уже існує.');if(!mkdir($dir,0755,true)&&!is_dir($dir))throw new RuntimeException('Не вдалося створити каталог.');return $rel;}
function mavik_core_imagemagick_bin(string $name): string {
  foreach(['/usr/bin/'.$name,'/usr/local/bin/'.$name,'/opt/imagemagick/bin/'.$name] as $p)if(is_file($p)&&is_executable($p))return $p;
  if(function_exists('shell_exec')){$q=@shell_exec('command -v '.escapeshellarg($name).' 2>/dev/null');$q=is_string($q)?trim($q):'';if($q!==''&&is_file($q)&&is_executable($q))return $q;}
  return '';
}
function mavik_core_crop_3x2_inplace(string $file): array {
  $dim=@getimagesize($file);$w=(int)($dim[0]??0);$h=(int)($dim[1]??0);$mime=(string)($dim['mime']??'');
  if($w<1||$h<1)throw new RuntimeException('Не вдалося визначити розмір зображення.');
  if(!in_array($mime,['image/jpeg','image/png','image/webp'],true))throw new RuntimeException('Для автоматичного формату 3:2 підтримуються JPG, PNG і WebP.');
  $already32=abs(($w/$h)-1.5)<=0.015;
  if($already32&&$mime!=='image/webp'&&$w<=1200)return ['width'=>$w,'height'=>$h,'changed'=>false];
  if($already32){$tw=$w;$th=$h;}
  elseif(($w/$h)>1.5){$th=$h-($h%2);$tw=(int)($th*3/2);if($tw>$w){$tw=$w-($w%3);$th=(int)($tw*2/3);}}
  else{$tw=$w-($w%3);$th=(int)($tw*2/3);if($th>$h){$th=$h-($h%2);$tw=(int)($th*3/2);}}
  if($tw<3||$th<2)throw new RuntimeException('Зображення надто мале для формату 3:2.');
  $sx=max(0,(int)floor(($w-$tw)/2));$sy=max(0,(int)floor(($h-$th)/2));
  // Blog derivative: never upscale; cap large uploads at the SEO-friendly 1200×800.
  $ow=$tw;$oh=$th;if($ow>1200){$ow=1200;$oh=800;}

  if(class_exists('Imagick')){
    try{
      $im=new Imagick($file);$im->setIteratorIndex(0);
      if(method_exists($im,'autoOrientImage'))@$im->autoOrientImage();
      $im->cropImage($tw,$th,$sx,$sy);$im->setImagePage(0,0,0,0);if($ow!==$tw||$oh!==$th)$im->resizeImage($ow,$oh,Imagick::FILTER_LANCZOS,1);
      if($mime==='image/webp'){$im->setImageBackgroundColor('white');if(method_exists($im,'setImageAlphaChannel'))@$im->setImageAlphaChannel(Imagick::ALPHACHANNEL_REMOVE);$im->setImageFormat('jpeg');$im->setImageCompressionQuality(92);}
      $im->stripImage();if(!$im->writeImage($file))throw new RuntimeException('Не вдалося записати 3:2 версію.');
      $im->clear();$im->destroy();clearstatcache(true,$file);return ['width'=>$ow,'height'=>$oh,'changed'=>true];
    }catch(Throwable $e){}
  }

  $canGd=function_exists('imagecreatetruecolor')&&function_exists('imagecopyresampled');
  if($canGd){
    $src=$mime==='image/png'&&function_exists('imagecreatefrompng')?@imagecreatefrompng($file):($mime==='image/jpeg'&&function_exists('imagecreatefromjpeg')?@imagecreatefromjpeg($file):($mime==='image/webp'&&function_exists('imagecreatefromwebp')?@imagecreatefromwebp($file):false));
    if($src){
      $dst=imagecreatetruecolor($ow,$oh);
      if($mime==='image/png'){imagealphablending($dst,false);imagesavealpha($dst,true);$transparent=imagecolorallocatealpha($dst,0,0,0,127);imagefilledrectangle($dst,0,0,$ow,$oh,$transparent);}else{$white=imagecolorallocate($dst,255,255,255);imagefilledrectangle($dst,0,0,$ow,$oh,$white);}
      $ok=imagecopyresampled($dst,$src,0,0,$sx,$sy,$ow,$oh,$tw,$th);
      if($ok)$ok=$mime==='image/png'?imagepng($dst,$file,6):imagejpeg($dst,$file,92);
      imagedestroy($dst);imagedestroy($src);
      if($ok){clearstatcache(true,$file);return ['width'=>$ow,'height'=>$oh,'changed'=>true];}
    }
  }

  $convert=mavik_core_imagemagick_bin('convert');
  if($convert!==''&&function_exists('shell_exec')){
    $tmp=$file.'.crop-'.bin2hex(random_bytes(4)).($mime==='image/png'?'.png':'.jpg');
    $format=$mime==='image/png'?'png:':'jpeg:';$flatten=$mime==='image/webp'?' -background white -alpha remove -alpha off':'';
    $resize=($ow!==$tw||$oh!==$th)?(' -resize '.(int)$ow.'x'.(int)$oh.'!'):'';
    $cmd=escapeshellarg($convert).' '.escapeshellarg($file).' -auto-orient -gravity center -crop '.(int)$tw.'x'.(int)$th.'+0+0 +repage'.$resize.$flatten.' -strip '.escapeshellarg($format.$tmp).' 2>/dev/null';
    @shell_exec($cmd);
    if(is_file($tmp)&&filesize($tmp)>0){
      $ok=@copy($tmp,$file);@unlink($tmp);
      if($ok){clearstatcache(true,$file);$d=@getimagesize($file);$nw=(int)($d[0]??0);$nh=(int)($d[1]??0);if($nw>0&&$nh>0&&abs(($nw/$nh)-1.5)<=0.015)return ['width'=>$nw,'height'=>$nh,'changed'=>true];}
    }else @unlink($tmp);
  }
  throw new RuntimeException('Сервер не має доступного декодера для автоматичного формату 3:2.');
}
function mavik_core_png_has_transparency(string $file): bool {
  if(class_exists('Imagick')){
    try{$im=new Imagick($file);$im->setIteratorIndex(0);if(!$im->getImageAlphaChannel()){ $im->clear();$im->destroy();return false; }$ext=$im->getImageChannelExtrema(Imagick::CHANNEL_ALPHA);$qr=Imagick::getQuantumRange();$qmax=(float)max(array_map('floatval',array_values((array)$qr)));$im->clear();$im->destroy();if(is_array($ext)&&isset($ext['minima'],$ext['maxima']))return (float)$ext['minima']<(float)$ext['maxima']||(float)$ext['minima']<$qmax;}catch(Throwable $e){}
  }
  if(!function_exists('imagecreatefrompng')){
    $identify=mavik_core_imagemagick_bin('identify');if($identify!==''&&function_exists('shell_exec')){$cmd=escapeshellarg($identify).' -format '.escapeshellarg('%[opaque]').' '.escapeshellarg($file).' 2>/dev/null';$out=@shell_exec($cmd);$v=strtolower(trim(is_string($out)?$out:''));if($v==='true')return false;if($v==='false')return true;}
    return true; // без жодного декодера безпечніше зберегти PNG
  }
  $im=@imagecreatefrompng($file);if(!$im)return true;
  try{
    $transparent=@imagecolortransparent($im);if(is_int($transparent)&&$transparent>=0)return true;
    $colors=@imagecolorstotal($im);if(is_int($colors)&&$colors>0){for($i=0;$i<$colors;$i++){$c=@imagecolorsforindex($im,$i);if(is_array($c)&&(int)($c['alpha']??0)>0)return true;}return false;}
    $w=imagesx($im);$h=imagesy($im);for($y=0;$y<$h;$y++){for($x=0;$x<$w;$x++){if((imagecolorat($im,$x,$y)&0x7F000000)!==0)return true;}}
    return false;
  }finally{imagedestroy($im);}
}
function mavik_core_png_to_jpeg(string $source,string $dest,int $quality=92): void {
  $quality=max(75,min(96,$quality));
  if(class_exists('Imagick')){
    try{$im=new Imagick($source);$im->setIteratorIndex(0);$im->setImageBackgroundColor('white');$flat=$im->mergeImageLayers(Imagick::LAYERMETHOD_FLATTEN);$flat->setImageFormat('jpeg');$flat->setImageCompressionQuality($quality);$flat->stripImage();if(!$flat->writeImage($dest))throw new RuntimeException('Не вдалося записати JPEG.');$flat->clear();$flat->destroy();$im->clear();$im->destroy();return;}catch(Throwable $e){@unlink($dest);}
  }
  if(!function_exists('imagecreatefrompng')||!function_exists('imagejpeg')){
    $convert=mavik_core_imagemagick_bin('convert');if($convert!==''&&function_exists('shell_exec')){$cmd=escapeshellarg($convert).' '.escapeshellarg($source).' -background white -alpha remove -alpha off -strip -quality '.(int)$quality.' '.escapeshellarg('jpeg:'.$dest).' 2>/dev/null';@shell_exec($cmd);if(is_file($dest)&&filesize($dest)>0)return;@unlink($dest);}
    throw new RuntimeException('Сервер не має GD/Imagick/ImageMagick для автоматичної конвертації PNG → JPG.');
  }
  $src=@imagecreatefrompng($source);if(!$src)throw new RuntimeException('Не вдалося прочитати PNG.');$w=imagesx($src);$h=imagesy($src);$dst=imagecreatetruecolor($w,$h);if(!$dst){imagedestroy($src);throw new RuntimeException('Не вдалося підготувати JPEG.');}$white=imagecolorallocate($dst,255,255,255);imagefilledrectangle($dst,0,0,$w,$h,$white);imagealphablending($dst,true);imagecopy($dst,$src,0,0,0,0,$w,$h);$ok=@imagejpeg($dst,$dest,$quality);imagedestroy($dst);imagedestroy($src);if(!$ok){@unlink($dest);throw new RuntimeException('Не вдалося записати JPEG.');}
}
function mavik_core_store_uploaded_image(array $f,string $dir,string $base,int $maxBytes=16777216,bool $allowTransparentPng=true,int $jpegQuality=92): string {
  if(!is_dir($dir)&&!mkdir($dir,0755,true)&&!is_dir($dir))throw new RuntimeException('Не вдалося створити каталог зображень.');
  if(empty($f['tmp_name'])||!is_uploaded_file((string)$f['tmp_name']))throw new RuntimeException('Оберіть зображення.');if((int)($f['size']??0)>$maxBytes)throw new RuntimeException('Зображення перевищує дозволений розмір.');
  $fi=new finfo(FILEINFO_MIME_TYPE);$mime=(string)$fi->file((string)$f['tmp_name']);if(!in_array($mime,['image/jpeg','image/png'],true))throw new RuntimeException('Підтримуються JPG і PNG.');
  $base=mavik_core_safe_slug($base)?:'image';$pngTransparent=false;$ext='jpg';if($mime==='image/png'){$pngTransparent=mavik_core_png_has_transparency((string)$f['tmp_name']);if($pngTransparent){if(!$allowTransparentPng)throw new RuntimeException('Цей тип зображення має бути JPG. PNG із прозорістю не конвертується автоматично.');$ext='png';}}
  $name=$base.'.'.$ext;$n=2;while(is_file($dir.'/'.$name))$name=$base.'-'.$n++.'.'.$ext;$dest=$dir.'/'.$name;
  if($mime==='image/png'&&!$pngTransparent){$tmp=$dest.'.tmp-'.bin2hex(random_bytes(4));try{mavik_core_png_to_jpeg((string)$f['tmp_name'],$tmp,$jpegQuality);if(!rename($tmp,$dest))throw new RuntimeException('Не вдалося встановити JPEG.');}finally{if(is_file($tmp))@unlink($tmp);}}
  else{if(!move_uploaded_file((string)$f['tmp_name'],$dest))throw new RuntimeException('Не вдалося зберегти зображення.');}
  @chmod($dest,0644);return $name;
}
function mavik_core_image_upload(string $root,string $folder,array $f): string {$dir=mavik_core_image_folder($root,$folder);if(!is_dir($dir))throw new RuntimeException('Каталог не знайдено.');$base=mavik_core_safe_slug(pathinfo((string)($f['name']??'image'),PATHINFO_FILENAME))?:'image';$isCover=$folder==='covers'||str_starts_with($folder,'covers/');return mavik_core_store_uploaded_image($f,$dir,$base,16*1024*1024,!$isCover,92);}
function mavik_core_image_in_use(string $root,string $url): bool {$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS));foreach($it as $f){if(!$f->isFile()||$f->isLink())continue;$p=$f->getPathname();if(str_contains($p,'/_site-state/')||str_contains($p,'/_site-admin/'))continue;$ext=strtolower(pathinfo($p,PATHINFO_EXTENSION));if(!in_array($ext,['html','json','xml','php','css','js'],true))continue;$raw=@file_get_contents($p);if($raw!==false&&str_contains($raw,$url))return true;}return false;}
function mavik_core_image_delete(string $root,string $folder,string $file): void {$file=basename($file);if(!preg_match('/^[A-Za-z0-9._-]+$/',$file))throw new RuntimeException('Некоректне ім’я файла.');$dir=mavik_core_image_folder($root,$folder);$p=$dir.'/'.$file;if(!is_file($p))throw new RuntimeException('Файл не знайдено.');$url=str_replace('\\','/',substr($p,strlen($root)));if(mavik_core_image_in_use($root,$url))throw new RuntimeException('Зображення використовується на сайті. Спочатку приберіть його зі сторінки або замініть.');if(!@unlink($p))throw new RuntimeException('Не вдалося видалити файл.');}
function mavik_core_image_delete_folder(string $root,string $folder): void {$folder=trim($folder,'/');if($folder===''||in_array($folder,['covers','blog','author'],true))throw new RuntimeException('Цей системний каталог не можна видаляти.');$dir=mavik_core_image_folder($root,$folder);if(!is_dir($dir))throw new RuntimeException('Каталог не знайдено.');$items=array_values(array_diff(scandir($dir)?:[],['.','..','.htaccess']));if($items)throw new RuntimeException('Спочатку видаліть файли та вкладені каталоги.');if(!@rmdir($dir))throw new RuntimeException('Не вдалося видалити каталог.');}

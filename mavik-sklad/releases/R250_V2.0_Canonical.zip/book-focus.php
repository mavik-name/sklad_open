<?php
declare(strict_types=1);
require_once __DIR__.'/_site-admin/state.php';
require_once __DIR__.'/_site-admin/live-sync.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Robots-Tag: noindex, nofollow, noarchive');
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
    http_response_code(405);
    echo json_encode(['book'=>null]);
    exit;
}
$root=__DIR__;
$catalogFile=$root.'/books/index.html';
$html=is_file($catalogFile)?file_get_contents($catalogFile):false;
if($html===false){http_response_code(500);echo json_encode(['book'=>null]);exit;}
function slug_from_href(string $href): string {
    $path=(string)(parse_url($href,PHP_URL_PATH)??$href);
    $parts=array_values(array_filter(explode('/',trim($path,'/')),'strlen'));
    if(!$parts)return '';
    return ($parts[0]??'')==='books'?(string)($parts[1]??''):(string)$parts[0];
}
function root_url(string $url): string {
    $url=html_entity_decode($url,ENT_QUOTES|ENT_HTML5,'UTF-8');
    if(str_starts_with($url,'../'))return '/'.substr($url,3);
    if(str_starts_with($url,'./'))return '/books/'.substr($url,2);
    if(str_starts_with($url,'/'))return $url;
    return '/books/'.ltrim($url,'/');
}
$books=[];
preg_match_all('#<a\b(?=[^>]*\bclass=["\'][^"\']*\bcard\b[^"\']*["\'])(?=[^>]*\bhref=["\']([^"\']+)["\'])[^>]*>(.*?)</a>#si',$html,$matches,PREG_SET_ORDER);
foreach($matches as $m){
    $href=html_entity_decode((string)$m[1],ENT_QUOTES|ENT_HTML5,'UTF-8');
    $slug=slug_from_href($href);if($slug==='')continue;$inner=(string)$m[2];
    $title=$slug;$type='';$cover='';
    if(preg_match('#<div\b[^>]*class=["\'][^"\']*\btitle\b[^"\']*["\'][^>]*>(.*?)</div>#si',$inner,$x))$title=trim(html_entity_decode(strip_tags($x[1]),ENT_QUOTES|ENT_HTML5,'UTF-8'));
    if(preg_match('#<div\b[^>]*class=["\'][^"\']*\btype\b[^"\']*["\'][^>]*>(.*?)</div>#si',$inner,$x))$type=trim(html_entity_decode(strip_tags($x[1]),ENT_QUOTES|ENT_HTML5,'UTF-8'));
    if(preg_match('#<img\b[^>]*src=["\']([^"\']+)["\']#si',$inner,$x))$cover=root_url((string)$x[1]);
    $books[$slug]=['slug'=>$slug,'title'=>$title,'type'=>$type,'cover'=>$cover,'url'=>'/books/'.$slug.'/'];
}
$file=mavik_state_seed($root,'book-focus.json');
$raw=is_file($file)?file_get_contents($file):false;$data=$raw!==false?json_decode($raw,true):null;
$slug=is_array($data)?(string)($data['slug']??''):'';
$book=$slug!==''&&isset($books[$slug])?$books[$slug]:null;
if($book===null&&$slug!==''&&preg_match('/^[a-z0-9-]+$/',$slug)){
    $landing=$root.'/books/'.$slug.'/index.html';
    if(is_file($landing)&&function_exists('mavik_live_public_book_from_landing')){
        $b=mavik_live_public_book_from_landing($root,$slug,$landing);
        if(is_array($b)&&empty($b['hidden'])&&!empty($b['title']))$book=['slug'=>$slug,'title'=>(string)$b['title'],'type'=>(string)($b['genre']??''),'cover'=>(string)($b['cover_home']??$b['cover_catalog']??''),'url'=>'/books/'.$slug.'/'];
    }
}
echo json_encode(['book'=>$book],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);

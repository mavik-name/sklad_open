<?php
declare(strict_types=1);
date_default_timezone_set('Europe/Kyiv');
$config=require __DIR__.'/boss/config.php';
$root=realpath((string)($config['site_root']??__DIR__));
if(!$root){http_response_code(500);exit;}
require $root.'/_site-admin/auth.php';
mavik_owner_session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');
header('X-Robots-Tag: noindex, nofollow, noarchive');

$stateFile=mavik_state_seed($root,'boss-content.json');
$raw=is_file($stateFile)?@file_get_contents($stateFile):false;
$state=$raw?json_decode($raw,true):null;
if(!is_array($state))$state=['blog'=>[]];

$authed=mavik_owner_authed();
if($authed&&empty($_SESSION['mavik_boss_csrf']))$_SESSION['mavik_boss_csrf']=bin2hex(random_bytes(24));

$items=[];
foreach((array)($state['blog']??[]) as $p){
  if(!is_array($p)||!empty($p['deleted']))continue;
  $hidden=!empty($p['hidden']);
  if($hidden&&!$authed)continue;
  $slug=preg_replace('/[^a-z0-9-]/','',(string)($p['slug']??''))??'';
  if($slug==='')continue;
  $items[]=[
    'slug'=>$slug,
    'date'=>(string)($p['date']??''),
    'published_at'=>(string)($p['published_at']??''),
    'hidden'=>$hidden,
  ];
}
echo json_encode([
  'owner'=>[
    'authenticated'=>$authed,
    'csrf'=>$authed?(string)($_SESSION['mavik_boss_csrf']??''):'',
  ],
  'items'=>$items,
],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);

<?php
declare(strict_types=1);
require_once __DIR__.'/_site-admin/stats-lite.php';
header('Cache-Control: no-store');header('X-Robots-Tag: noindex, nofollow, noarchive');
if(($_SERVER['REQUEST_METHOD']??'')!=='POST'){http_response_code(405);exit;}
if((int)($_SERVER['CONTENT_LENGTH']??0)>8192){http_response_code(413);exit;}
$raw=(string)@file_get_contents('php://input');$in=[];parse_str($raw,$in);if(!$in)$in=$_POST;
try{mavik_stats_lite_record(__DIR__,is_array($in)?$in:[],(string)($_SERVER['HTTP_REFERER']??''));}catch(Throwable $e){}
http_response_code(204);

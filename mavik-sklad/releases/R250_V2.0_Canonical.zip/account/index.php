<?php
declare(strict_types=1);
date_default_timezone_set('Europe/Kyiv');
$config=require dirname(__DIR__).'/boss/config.php';
$root=realpath((string)$config['site_root']); if(!$root){http_response_code(500);exit('Site root error');}
require $root.'/_site-admin/auth.php'; mavik_owner_session_start();
header('Cache-Control: no-store, private'); header('X-Robots-Tag: noindex, nofollow, noarchive');
function ah(string $s): string{return htmlspecialchars($s,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');}
$next=mavik_safe_next((string)($_GET['next']??$_POST['next']??'/'),'/');
if(isset($_GET['logout'])){mavik_owner_logout();header('Location: /');exit;}
$owner=mavik_owner_load($root);$registered=mavik_owner_exists($root);$error='';$success='';
$forgot=isset($_GET['forgot']);$resetToken=trim((string)($_GET['reset']??$_POST['reset_token']??''));$resetMode=$resetToken!=='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  try{
    if(!mavik_owner_csrf_ok((string)($_POST['csrf']??'')))throw new RuntimeException('Сесію форми втрачено. Оновіть сторінку.');
    $action=(string)($_POST['action']??'');
    if($action==='forgot'){
      mavik_owner_reset_request($root,(string)($_POST['email']??''));
      $success='Якщо це email власника, на нього надіслано одноразове посилання для скидання пароля. Воно діє 30 хвилин.';$forgot=true;
    } elseif($action==='reset'){
      $pass=(string)($_POST['password']??'');$pass2=(string)($_POST['password2']??'');if($pass!==$pass2)throw new RuntimeException('Паролі не збігаються.');
      $email=mavik_owner_reset_consume($root,$resetToken,$pass);if(!mavik_owner_login($root,$email,$pass))throw new RuntimeException('Пароль змінено, але автоматичний вхід не вдався.');
      header('Location: /boss/?tab=security&password_reset=1');exit;
    } else {
      $tries=(int)($_SESSION['owner_tries']??0);$last=(int)($_SESSION['owner_last_try']??0);
      if($tries>=7&&time()-$last<900)throw new RuntimeException('Забагато спроб. Спробуйте через 15 хвилин.');
      if($action==='register'){
        if($registered)throw new RuntimeException('Реєстрацію власника вже закрито.');
        $name=trim((string)($_POST['name']??''));$email=trim((string)($_POST['email']??''));$pass=(string)($_POST['password']??'');$pass2=(string)($_POST['password2']??'');$setup=(string)($_POST['setup_password']??'');
        if($pass!==$pass2)throw new RuntimeException('Паролі не збігаються.');
        if(!password_verify($setup,(string)$config['password_hash']))throw new RuntimeException('Невірний чинний пароль Boss.');
        mavik_owner_register($root,$name,$email,$pass);$registered=true;
        if(!mavik_owner_login($root,$email,$pass))throw new RuntimeException('Акаунт створено, але автоматичний вхід не вдався.');
        $_SESSION['owner_tries']=0;header('Location: '.$next);exit;
      }
      if($action==='login'){
        $email=trim((string)($_POST['email']??''));$pass=(string)($_POST['password']??'');
        if(!$registered)throw new RuntimeException('Спочатку зареєструйте власника сайту.');
        if(!mavik_owner_login($root,$email,$pass)){$_SESSION['owner_tries']=$tries+1;$_SESSION['owner_last_try']=time();usleep(350000);throw new RuntimeException('Невірна email-адреса або пароль.');}
        $_SESSION['owner_tries']=0;header('Location: '.$next);exit;
      }
    }
  }catch(Throwable $e){$error=$e->getMessage();}
}
$owner=mavik_owner_load($root);$resetValid=$resetMode?mavik_owner_reset_validate($root,$resetToken):null;
?><!doctype html><html lang="uk-UA"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow,noarchive"><title><?php if($resetMode):?>Новий пароль<?php elseif($forgot):?>Скидання пароля<?php else:?><?= $registered?'Вхід власника':'Реєстрація власника' ?><?php endif;?> · MaVik</title><link rel="icon" href="/favicon.ico"><style>
:root{color-scheme:dark;--bg:#09090a;--panel:#111113;--line:#302d28;--text:#eee9df;--muted:#9f998f;--gold:#d9bd86;--bad:#ffaaa3;--good:#b8dda9}*{box-sizing:border-box}body{margin:0;min-height:100vh;background:radial-gradient(circle at 20% 0,rgba(217,189,134,.11),transparent 30rem),var(--bg);color:var(--text);font:14px/1.5 Arial,sans-serif;display:grid;place-items:center;padding:24px}.box{width:min(520px,100%);background:rgba(17,17,19,.96);border:1px solid var(--line);border-radius:24px;padding:30px;box-shadow:0 28px 80px rgba(0,0,0,.42)}.brand{font:500 35px Georgia,serif}.brand span{color:var(--gold)}.sub{color:var(--muted);margin:7px 0 24px;line-height:1.65}.notice{border:1px solid #4d402d;background:#17130e;border-radius:14px;padding:12px 14px;color:#d9c8a6;margin-bottom:18px;font-size:12px}label{display:block;color:#b7b0a5;font-size:12px;margin:0 0 14px}input{display:block;width:100%;margin-top:7px;padding:13px 14px;border:1px solid #39352f;border-radius:12px;background:#09090a;color:#fff;font-size:16px;outline:none}input:focus{border-color:#806b45}.btn{width:100%;border:1px solid #806b45;background:#19150f;color:#e1c58e;border-radius:999px;padding:13px 18px;font-weight:700;cursor:pointer;margin-top:4px}.links{display:flex;justify-content:center;gap:18px;flex-wrap:wrap;margin-top:18px}.links a{color:#bdb5a8;text-decoration:none;font-size:12px}.err,.okmsg{margin:0 0 16px;padding:12px;border-radius:12px}.err{border:1px solid #633;background:#1b1010;color:var(--bad)}.okmsg{border:1px solid #354c31;background:#10180e;color:var(--good)}.owner{margin-bottom:18px;color:#cfc7bb}.owner b{color:#fff}.hint{color:#777169;font-size:11px;margin-top:-7px;margin-bottom:13px}
</style></head><body><main class="box"><div class="brand">MaVik · <span>власник</span></div>
<?php if(mavik_owner_authed()&&!$resetMode&&!$forgot): ?><p class="sub">Ви вже увійшли як власник сайту.</p><div class="owner"><b><?=ah((string)($_SESSION['mavik_owner_name']??'Власник MaVik'))?></b><br><?=ah((string)($_SESSION['mavik_owner_email']??''))?></div><div class="links"><a href="/boss/">Адмінка →</a><a href="/">Сайт →</a><a href="?logout=1">Вийти</a></div>
<?php elseif($resetMode): ?><p class="sub">Задайте новий пароль власника.</p><?php if($error):?><div class="err"><?=ah($error)?></div><?php endif;?><?php if(!$resetValid):?><div class="err">Посилання недійсне, вже використане або прострочене.</div><div class="links"><a href="?forgot=1">Запросити нове посилання</a><a href="/account/">← До входу</a></div><?php else:?><form method="post"><input type="hidden" name="csrf" value="<?=ah(mavik_owner_csrf())?>"><input type="hidden" name="action" value="reset"><input type="hidden" name="reset_token" value="<?=ah($resetToken)?>"><label>Новий пароль<input type="password" name="password" autocomplete="new-password" minlength="12" required autofocus></label><div class="hint">Щонайменше 12 символів.</div><label>Повторіть новий пароль<input type="password" name="password2" autocomplete="new-password" minlength="12" required></label><button class="btn">Зберегти новий пароль</button></form><?php endif;?>
<?php elseif($forgot): ?><p class="sub">Введіть email власника. Якщо він збігається з акаунтом, сайт надішле одноразове посилання для нового пароля.</p><?php if($error):?><div class="err"><?=ah($error)?></div><?php endif;?><?php if($success):?><div class="okmsg"><?=ah($success)?></div><?php endif;?><form method="post"><input type="hidden" name="csrf" value="<?=ah(mavik_owner_csrf())?>"><input type="hidden" name="action" value="forgot"><label>Email<input type="email" name="email" autocomplete="email" required value="<?=ah((string)($owner['email']??$config['email']??''))?>"></label><button class="btn">Надіслати посилання</button></form><div class="links"><a href="/account/">← До входу</a></div>
<?php elseif(!$registered): ?><p class="sub">Перший і єдиний акаунт стає власником mavik.name. Після його створення публічна реєстрація автоматично закриється.</p><div class="notice">Для першої реєстрації потрібен чинний пароль Boss. Це не дозволить сторонній людині перехопити сайт до вашої реєстрації.</div><?php if($error):?><div class="err"><?=ah($error)?></div><?php endif;?><form method="post"><input type="hidden" name="csrf" value="<?=ah(mavik_owner_csrf())?>"><input type="hidden" name="action" value="register"><input type="hidden" name="next" value="<?=ah($next)?>"><label>Ім’я<input name="name" autocomplete="name" required value="Макарчук Віктор"></label><label>Email<input type="email" name="email" autocomplete="email" required value="<?=ah((string)($config['email']??'viktor@mavik.name'))?>"></label><label>Новий пароль<input type="password" name="password" autocomplete="new-password" minlength="12" required></label><div class="hint">Щонайменше 12 символів.</div><label>Повторіть новий пароль<input type="password" name="password2" autocomplete="new-password" minlength="12" required></label><label>Чинний пароль Boss<input type="password" name="setup_password" autocomplete="current-password" required></label><button class="btn">Зареєструвати власника</button></form><div class="links"><a href="/">← На сайт</a></div>
<?php else: ?><p class="sub">Реєстрація вже закрита. Увійдіть під акаунтом власника, щоб побачити кнопку «Адмінка» на сайті.</p><?php if($error):?><div class="err"><?=ah($error)?></div><?php endif;?><form method="post"><input type="hidden" name="csrf" value="<?=ah(mavik_owner_csrf())?>"><input type="hidden" name="action" value="login"><input type="hidden" name="next" value="<?=ah($next)?>"><label>Email<input type="email" name="email" autocomplete="username" required value="<?=ah((string)($owner['email']??$config['email']??''))?>"></label><label>Пароль<input type="password" name="password" autocomplete="current-password" required autofocus></label><button class="btn">Увійти</button></form><div class="links"><a href="?forgot=1">Забули пароль?</a><a href="/">← На сайт</a></div><?php endif; ?></main></body></html>
